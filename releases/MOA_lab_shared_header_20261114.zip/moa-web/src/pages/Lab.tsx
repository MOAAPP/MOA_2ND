import { useNavigate } from 'react-router-dom';
import { Card, Icon, SectionTitle } from '../components/ui';
import AppHeader from '../components/AppHeader';
import { lessonById, pickToday, stockLessonId } from '../lib/learning';
import { STOCKS, livePrice, stockByName } from '../lib/market';
import { getState, skippedTotal, useStore, won } from '../lib/store';
import { APP_TODAY } from '../lib/store';

/** /lab — 금융 실험실: 가상 예·적금 + 가상 주식·ETF + 학습 + 평행세계를 한곳에 */
export default function Lab() {
  const navigate = useNavigate();
  const savings = useStore((s) => s.savings);
  const invest = useStore((s) => s.invest);
  const skipped = useStore((s) => skippedTotal(s));
  useStore((s) => s.learning);

  const savingTotal = savings.reduce((a, p) => a + p.principal, 0);
  const stockTotal = STOCKS.reduce((a, s) => a + (invest.holdings[s.name] || 0) * livePrice(s.name), 0);
  const lastBuy = invest.orders.find((o) => o.side === 'buy' && o.status === 'filled');
  const lastLesson = lastBuy ? lessonById(stockLessonId(stockByName(lastBuy.name)?.code || '')) : null;
  const today = pickToday(getState(), APP_TODAY);
  const todayLesson = lessonById(today.id)!;

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <AppHeader profileTo="/more" />
      <div className="px-4 pt-3 space-y-3.5">
        <div className="px-1">
          <p className="text-[12px] font-semibold text-toss-gray500 mb-1">금융 실험실</p>
          <h1 className="text-[22px] font-extrabold text-toss-gray900 tracking-tight leading-snug">진짜 돈을 쓰기 전에<br />가상으로 먼저 해봐요</h1>
          <p className="text-[13px] text-toss-gray500 mt-1">여기서 쓰는 돈은 독립된 가상 연습 자산이라 실제 계좌에는 영향이 없어요.</p>
        </div>

        <section className="bg-white rounded-[24px] p-4 shadow-card space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-[15px] font-bold text-toss-gray900">금융 학습</h2>
            <button type="button" onClick={() => navigate('/growth')} className="text-[11px] font-bold text-toss-blue">성장 기록 ›</button>
          </div>
          <button type="button" onClick={() => navigate('/learn')} className="w-full rounded-[18px] bg-[#E8F3FF] p-3.5 text-left flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center shrink-0"><span className="text-[21px]" aria-hidden="true">📚</span></span>
            <span className="flex-1 min-w-0"><span className="block text-[14px] font-bold text-toss-gray900">전체 금융 학습 보기</span><span className="block text-[11px] text-toss-gray500 mt-0.5">퀴즈 없이 개념 카드부터 자유롭게 둘러봐요</span></span>
            <Icon name="chevron_right" className="text-toss-blue" />
          </button>
          <button type="button" onClick={() => navigate(`/learn/${todayLesson.id}`)} className="w-full flex items-center justify-between px-2 py-2 text-left gap-2">
            <span className="min-w-0"><span className="block text-[10.5px] font-bold text-toss-blue">오늘의 추천 학습</span><span className="block text-[13px] font-semibold text-toss-gray800 truncate">{todayLesson.emoji} {todayLesson.title}</span></span>
            <span className="text-[11px] font-bold text-toss-gray500 shrink-0">바로 읽기 ›</span>
          </button>
        </section>

        <div className="grid grid-cols-2 gap-2.5">
          <button type="button" onClick={() => navigate('/savings')} className="text-left bg-white rounded-[22px] p-4 shadow-card active:scale-[0.98] transition-transform">
            <span className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center"><Icon name="savings" className="text-[22px]" /></span>
            <p className="mt-3 text-[14px] font-bold text-toss-gray900">가상 예·적금</p>
            <p className="text-[11.5px] text-toss-gray500 mt-0.5">안정적인 자산 형성 연습</p>
            <p className="text-[15px] font-extrabold text-toss-gray900 tabular-nums mt-2">{won(savingTotal)}</p>
          </button>
          <button type="button" onClick={() => navigate('/invest')} className="text-left bg-white rounded-[22px] p-4 shadow-card active:scale-[0.98] transition-transform">
            <span className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center"><Icon name="candlestick_chart" className="text-[22px]" /></span>
            <p className="mt-3 text-[14px] font-bold text-toss-gray900">가상 주식·ETF</p>
            <p className="text-[11.5px] text-toss-gray500 mt-0.5">변동성과 손익 경험</p>
            <p className="text-[15px] font-extrabold text-toss-gray900 tabular-nums mt-2">{won(stockTotal)}</p>
            <p className="text-[11px] text-toss-gray500">주문 가능 {won(invest.cash)}</p>
          </button>
        </div>

        <button type="button" onClick={() => navigate('/agent')} className="w-full rounded-[20px] bg-[#E8F3FF] border border-blue-100 px-4 py-3.5 text-left flex items-center justify-between">
          <span><span className="block text-[13.5px] font-bold text-toss-blue">내 조건으로 금융 경로 탐색</span><span className="block text-[11px] text-toss-gray500 mt-0.5">목표·필수결제·최소 잔액을 함께 비교해요</span></span>
          <Icon name="chevron_right" className="text-toss-blue" />
        </button>
        <Card>
          <SectionTitle>이번 거래로 배우기</SectionTitle>
          {lastBuy && lastLesson ? (
            <button type="button" onClick={() => navigate(`/learn/${lastLesson.id}?from=trade&order=${lastBuy.id}&amount=${lastBuy.price * lastBuy.shares}`)} className="w-full text-left rounded-2xl bg-toss-gray50 p-4 flex items-center gap-3">
              <span className="text-[26px]">{lastLesson.emoji}</span>
              <span className="flex-1 min-w-0"><span className="block text-[14px] font-bold text-toss-gray900 truncate">{lastLesson.title}</span>
                <span className="block text-[12px] text-toss-gray500 mt-0.5">방금 산 {lastBuy.name} 이해하기 · 카드 {lastLesson.cards.length}장 + 퀴즈</span></span>
              <Icon name="chevron_right" className="text-toss-gray400" />
            </button>
          ) : (
            <p className="text-[12.5px] text-toss-gray500">가상 거래소에서 ETF를 사면, 그 종목을 이해하는 카드와 퀴즈가 여기에 생겨요.</p>
          )}
        </Card>

        <Card>
          <SectionTitle>같은 돈으로 다른 선택 실험</SectionTitle>
          <p className="text-[13px] text-toss-gray600 leading-relaxed">사지 않기로 한 금액 <b className="text-toss-gray900">{won(skipped)}</b>을 저축했을 때와 투자했을 때 미래가 어떻게 다른지 비교해요.</p>
          <button type="button" onClick={() => navigate(skipped ? `/world?amount=${skipped}&title=${encodeURIComponent('사지 않기로 한 금액')}` : '/world')} className="mt-3 w-full py-3 rounded-2xl bg-toss-lightBlue text-toss-blue text-[13px] font-bold flex items-center justify-center gap-1">
            <Icon name="auto_awesome" className="text-[16px]" /> 평행세계에서 비교하기
          </button>
        </Card>

      </div>
    </div>
  );
}
