import { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore } from '../lib/store';
import { GENERAL_LESSONS, lessonById, pickToday } from '../lib/learning';
import './Home.css';

const dateLabel = new Intl.DateTimeFormat('ko-KR', {
  month: 'long', day: 'numeric', weekday: 'long',
}).format(new Date(`${APP_TODAY}T00:00:00`));

function Arrow({ size = 20 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14m-6-6 6 6-6 6" /></svg>;
}
function Chevron({ size = 18 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6" /></svg>;
}

/** Editorial illustrations with finance meaning, not decorative emoji or generic bubbles. */
function CoverArt({ lesson, featured = false }) {
  const id = lesson.id;
  const type = id === 'emergency' ? 'emergency' : id === 'compound' ? 'compound'
    : (id === 'etf' || id.startsWith('stock-') || id.includes('order')) ? 'investment' : 'money';
  return <div className={`moa-story-art moa-story-art--${type} ${featured ? 'moa-story-art--featured' : ''}`} aria-hidden="true">
    <div className="moa-story-art__index">MOA / FINANCIAL NOTES</div>
    {type === 'emergency' ? <div className="moa-story-art__receipt">
      <span className="receipt-head">MY MONEY PLAN</span>
      <span className="receipt-rule" />
      <span className="receipt-row"><i /> <b /></span>
      <span className="receipt-row"><i /> <b /></span>
      <span className="receipt-row"><i /> <b /></span>
      <span className="receipt-rule" />
      <strong>PLAN B.</strong>
    </div> : null}
    {type === 'compound' ? <div className="moa-story-art__compound">
      <span className="compound-plus">+</span><span className="compound-sign">%</span>
      <span className="compound-formula">TODAY <b>→</b> TOMORROW</span>
    </div> : null}
    {type === 'investment' ? <div className="moa-story-art__invest">
      <span className="invest-card invest-card--one"><span>01</span><b>STOCKS</b></span>
      <span className="invest-card invest-card--two"><span>02</span><b>BONDS</b></span>
      <span className="invest-card invest-card--three"><span>03</span><b>ETF</b></span>
    </div> : null}
    {type === 'money' ? <div className="moa-story-art__money">
      <span>MY</span><strong>MONEY</strong><span>MY CHOICE</span>
    </div> : null}
    <div className="moa-story-art__bottom"><span>NOTE No. {id === 'emergency' ? '01' : id === 'compound' ? '02' : '03'}</span><span>MOA</span></div>
  </div>;
}

function StoryCard({ lesson, featured, reason, isDone, navigate }) {
  return <button type="button" className={`moa-story-card ${featured ? 'moa-story-card--featured' : ''}`}
    onClick={() => navigate(`/learn/${lesson.id}`)} aria-label={`${lesson.title} 카드뉴스 읽기`}>
    <CoverArt lesson={lesson} featured={featured} />
    <div className="moa-story-card__details">
      <div className="moa-story-card__meta"><span>{featured ? 'TODAY FOR YOU' : 'MOA ARTICLE'}</span><span>{lesson.minutes}분 읽기</span></div>
      <strong>{lesson.title}</strong>
      <p>{featured ? reason : lesson.summary}</p>
      <div className="moa-story-card__foot"><span>{isDone ? '다시 읽어보기' : '카드뉴스 읽기'}</span><Arrow size={17} /></div>
    </div>
  </button>;
}

function HomeScreen() {
  const navigate = useNavigate();
  const state = useStore((s) => s);
  const recommendation = pickToday(state, APP_TODAY);
  const lesson = lessonById(recommendation.id) || GENERAL_LESSONS[0];
  const otherLessons = GENERAL_LESSONS.filter((item) => item.id !== lesson.id).slice(0, 3);
  const stories = [lesson, ...otherLessons];
  const completed = state.learning.done.length;
  const thinking = state.wishes.filter((item) => item.status === 'thinking' || item.status === 'later').length;
  const latestLesson = (state.learning.quizDone || []).includes(lesson.id);

  return <div className="moa-editorial-home" data-testid="moa-learning-home">
    <AppHeader profileTo="/more" />
    <main className="moa-editorial-content">
      <header className="moa-editorial-hero">
        <div className="moa-editorial-eyebrow"><span>MOA JOURNAL</span><time>{dateLabel}</time></div>
        <h1>돈 공부,<br /><span className="moa-editorial-emphasis">내 이야기부터.</span></h1>
        <p>어렵게만 느껴졌던 금융 이야기,<br />내 소비와 학습 기록에 맞춰 하나씩 알아가요.</p>
        <div className="moa-editorial-hero-foot"><span>나에게 필요한 금융 콘텐츠</span><span className="moa-editorial-counter">01 <i>/</i> 04</span></div>
      </header>

      <section className="moa-editorial-stories" aria-label="오늘의 맞춤 금융 카드뉴스">
        <div className="moa-editorial-section-heading">
          <div><span className="moa-editorial-kicker">CURATED FOR YOU</span><h2>오늘의 카드뉴스</h2></div>
          <button type="button" onClick={() => navigate('/learn')}>전체 보기 <Chevron size={16}/></button>
        </div>
        <div className="moa-editorial-story-track" role="group" aria-label="금융 카드뉴스 가로 목록">
          {stories.map((item, index) => <StoryCard key={item.id} lesson={item} featured={index === 0}
            reason={recommendation.reason} isDone={state.learning.done.includes(item.id)} navigate={navigate} />)}
        </div>
        <div className="moa-editorial-track-footer">
          <div className="moa-editorial-track-index"><span className="is-active"/><span/><span/><span/></div>
          <span>옆으로 넘겨 더 읽어보세요 <Arrow size={13}/></span>
        </div>
      </section>

      <section className="moa-editorial-next" aria-label="오늘의 학습 이어가기">
        <div className="moa-editorial-section-heading">
          <div><span className="moa-editorial-kicker">KEEP GOING</span><h2>읽고, 직접 경험해요</h2></div>
        </div>
        <button type="button" className="moa-editorial-feature-row" onClick={() => navigate(`/learn/${lesson.id}${latestLesson ? '' : '/quiz'}`)}>
          <div><span className="moa-editorial-feature-meta">01 · 1분 복습</span><strong>읽은 이야기, 퀴즈로 확인하기</strong><p>{completed ? `${completed}개의 학습을 마쳤어요` : '한 문제부터 가볍게 시작해요'}</p></div><Chevron size={21}/>
        </button>
        <button type="button" className="moa-editorial-feature-row" onClick={() => navigate('/world')}>
          <div><span className="moa-editorial-feature-meta">02 · 평행통장</span><strong>선택에 따라 달라지는 내 미래</strong><p>살까, 말까 고민한 소비를 비교해요</p></div><Chevron size={21}/>
        </button>
      </section>

      <section className="moa-editorial-finance" aria-label="내 금융 활동">
        <div className="moa-editorial-section-heading"><div><span className="moa-editorial-kicker">YOUR FINANCE</span><h2>내 돈의 오늘</h2></div></div>
        <div className="moa-editorial-finance-grid">
          <button type="button" onClick={() => navigate('/ledger')}><span>01 / 가계부</span><strong>소비 흐름<br />확인하기</strong><Arrow size={20}/></button>
          <button type="button" onClick={() => navigate(thinking ? '/wishlist' : '/record')}><span>02 / 소비 선택</span><strong>{thinking ? `${thinking}건의 소비` : '오늘 소비를'}<br />{thinking ? '고민 중이에요' : '기록해요'}</strong><Arrow size={20}/></button>
        </div>
      </section>
      <p className="moa-editorial-notice">현재 카드뉴스는 앱에 준비된 금융 학습 콘텐츠이며, 추천은 소비·학습 기록에 따른 규칙 기반 방식이에요. 실시간 AI 생성 및 은행 계좌 연동은 아직 제공되지 않습니다.</p>
    </main>
  </div>;
}

export default memo(HomeScreen);
