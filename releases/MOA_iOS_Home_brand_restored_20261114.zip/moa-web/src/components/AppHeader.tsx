import { useNavigate } from 'react-router-dom';
import logoUrl from '../assets/moa-logo.webp';

// 탭 화면(홈·가계부·평행세계·더보기) 공통 상단 헤더 — Stitch 홈 헤더 기준
export default function AppHeader({ profileTo = '/more' }: { profileTo?: string }) {
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-50 px-5 pt-3.5 pb-2.5 backdrop-blur-xl border-b border-slate-100 bg-white/90 select-none shrink-0">
      <div className="flex items-center justify-between h-9">
        <button type="button" aria-label="홈으로" onClick={() => navigate('/')} className="flex items-center">
          <img src={logoUrl} alt="MOA" className="h-7 w-auto object-contain block select-none" />
        </button>
        <div className="flex items-center space-x-2">
          <button
            type="button"
            aria-label="알림"
            onClick={() => navigate('/notifications')}
            className="relative p-1.5 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-colors"
          >
            <svg className="w-5 h-5 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#00D2D3] ring-2 ring-white" />
          </button>
          <button
            type="button"
            aria-label="내 프로필"
            onClick={() => navigate(profileTo)}
            className="p-1.5 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-colors"
          >
            <svg className="w-5 h-5 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
}
