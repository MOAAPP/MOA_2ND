import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { Icon } from '../components/ui';
import { comparePurchaseChoice, type CashPoint } from '../lib/choiceComparison';
import { APP_TODAY, useStore, won, WISH_LABEL } from '../lib/store';

type Period = 7 | 30 | 90;
const PERIODS: { days: Period; label: string }[] = [
  { days: 7, label: '7일' }, { days: 30, label: '1개월' }, { days: 90, label: '3개월' },
];
const numeric = (value: string) => Math.min(100000000, Number(value.replace(/[^\d]/g, '')) || 0);
const short = (iso: string) => `${Number(iso.slice(5, 7))}/${Number(iso.slice(8, 10))}`;

function ComparisonChart({ points }: { points: CashPoint[] }) {
  const all = points.flatMap((p) => [p.bought, p.kept]);
  const min = Math.min(...all);
  const max = Math.max(...all);
  const range = Math.max(max - min, 1000);
  const y = (v: number) => 118 - ((v - min) / range) * 90;
  const x = (i: number) => 15 + (i / Math.max(1, points.length - 1)) * 290;
  const line = (key: 'bought' | 'kept') => points.map((p, i) => `${x(i)},${y(p[key])}`).join(' ');
  return (
    <div>
      <svg viewBox="0 0 320 144" className="w-full" role="img" aria-label="구매한 경우와 구매하지 않은 경우의 예상 결제계좌 잔액 비교 그래프">
        {[26, 72, 118].map((gridY) => <line key={gridY} x1="12" x2="308" y1={gridY} y2={gridY} stroke="#E5E8EB" strokeDasharray="3 5" />)}
        <polyline points={line('bought')} fill="none" stroke="#F04452" strokeWidth="2.8" strokeLinejoin="round" strokeLinecap="round" />
        <polyline points={line('kept')} fill="none" stroke="#3182F6" strokeWidth="2.8" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => <g key={p.day}>
          <circle cx={x(i)} cy={y(p.bought)} r="3.2" fill="#F04452" stroke="white" strokeWidth="1.4" />
          <circle cx={x(i)} cy={y(p.kept)} r="3.2" fill="#3182F6" stroke="white" strokeWidth="1.4" />
          {(i === 0 || i === points.length - 1 || i === Math.floor(points.length / 2)) && <text x={x(i)} y="137" fontSize="9" textAnchor="middle" fill="#8B95A1">{short(p.date)}</text>}
        </g>)}
      </svg>
      <div className="flex justify-center items-center gap-5 text-[11px] font-semibold text-toss-gray600">
        <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#F04452]" />구매한 나</span>
        <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#3182F6]" />구매하지 않은 나</span>
      </div>
    </div>
  );
}

/** /world: 소비 선택 A/B 비교가 중심. 기존 6개 세계선·3D 탐험은 /world/explore에 유지. */
export default function WorldChoice() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const s = useStore((current) => current);
  const wishes = s.wishes;
  const purchases = s.txs.filter((t) => t.type === 'expense' && !t.sample && !t.wishId && t.date <= APP_TODAY);
  const requested = params.get('wish');
  const first = (requested && wishes.some((w) => w.id === requested)) ? requested : (params.get('amount') ? 'custom' : wishes[0]?.id || 'sample');
  const [source, setSource] = useState(first);
  const [name, setName] = useState(params.get('title') || '노이즈캔슬링 헤드폰');
  const [amountText, setAmountText] = useState(params.get('amount') || '259000');
  const [period, setPeriod] = useState<Period>(30);

  useEffect(() => {
    if (params.get('view')) {
      navigate(`/world/explore?${params.toString()}`, { replace: true });
      return;
    }
    const wishId = params.get('wish');
    if (wishId && wishes.some((w) => w.id === wishId)) setSource(wishId);
    else if (params.get('amount')) {
      setSource('custom'); setAmountText(params.get('amount')!);
      setName(params.get('title') || '직접 입력한 소비');
    }
  }, [params.toString(), navigate]); // URL로 넘어온 구매 고민 / 직접 입력 소비를 우선 표시

  const selected = wishes.find((w) => w.id === source);
  const selectedTx = source.startsWith('tx:') ? purchases.find((t) => t.id === source.slice(3)) : undefined;
  const isManual = source === 'custom';
  const finalName = source === 'sample' ? '노이즈캔슬링 헤드폰' : isManual ? name.trim() || '소비 고민' : selected?.name || selectedTx?.title || '소비 고민';
  const amount = source === 'sample' ? 259000 : isManual ? numeric(amountText) : selected?.amount || selectedTx?.amount || 0;
  const projection = useMemo(() => comparePurchaseChoice(s, { name: finalName, amount, wish: selected, transaction: selectedTx }, period), [s, finalName, amount, selected, selectedTx, period]);
  const valid = amount >= 1000 && amount <= 100000000;
  const suffix = selected ? ` · ${WISH_LABEL[selected.status]}` : selectedTx ? ' · 직접 기록한 가계부 지출' : isManual ? ' · 직접 입력한 가상 비교' : ' · 시연용 가상 사례';
  const extra = new URLSearchParams({ title: finalName, amount: String(amount), view: 'B' });
  if (selected) extra.set('wish', selected.id);
  const exploreUrl = `/world/explore?${extra.toString()}`;
  const notice = projection.actual === 'bought' ? '기록된 구매와 구매하지 않은 경우를 현재 잔액 기준으로 비교했어요.'
    : selected ? '현재 구매하지 않은 상태를 기준으로, 오늘 샀다면 어땠을지 계산했어요.'
    : '실제 거래가 아닌 예시 금액으로 두 가지 선택을 연습해요.';

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-[104px]">
      <AppHeader />
      <div className="px-4 pt-5 space-y-3.5">
        <div className="px-1">
          <span className="inline-flex items-center text-[11px] font-bold text-toss-blue bg-[#E8F3FF] rounded-full px-2.5 py-1">MOA · 선택의 다른 미래</span>
          <h1 className="text-[24px] font-extrabold text-toss-gray900 leading-snug tracking-tight mt-2">그때 샀다면,<br />사지 않았다면?</h1>
          <p className="text-[12.5px] leading-relaxed text-toss-gray500 mt-2">하나의 소비 선택이 오늘의 현금과 앞으로의 결제 일정에 만드는 차이를 살펴봐요.</p>
        </div>

        <section className="bg-white rounded-[24px] p-4 shadow-card space-y-3" aria-label="비교할 소비 선택">
          <div className="flex items-center justify-between">
            <h2 className="text-[14px] font-bold text-toss-gray900">비교할 소비</h2>
            <button type="button" onClick={() => navigate('/wishlist')} className="text-[11.5px] text-toss-blue font-bold">소비 결정 보관함 ›</button>
          </div>
          <label htmlFor="world-choice-source" className="sr-only">비교할 구매 고민 선택</label>
          <select id="world-choice-source" value={source} onChange={(e) => setSource(e.target.value)} className="w-full text-[13px] font-semibold text-toss-gray800 bg-toss-gray50 rounded-xl border border-toss-gray200 px-3 py-3">
            <option value="sample">예시 · 노이즈캔슬링 헤드폰</option>
            <option value="custom">금액·상품명 직접 입력</option>
            {wishes.map((w) => <option key={w.id} value={w.id}>{w.name} · {WISH_LABEL[w.status]}</option>)}
            {purchases.map((t) => <option key={t.id} value={`tx:${t.id}`}>{t.title} · 가계부 지출</option>)}
          </select>
          {isManual ? <div className="flex gap-2">
            <label className="flex-1 min-w-0"><span className="block text-[11px] text-toss-gray500 mb-1">상품명</span>
              <input value={name} onChange={(e) => setName(e.target.value)} maxLength={50} className="w-full px-3 py-2.5 bg-white rounded-xl border border-toss-gray200 text-[13px] font-semibold" /></label>
            <label className="w-[128px] shrink-0"><span className="block text-[11px] text-toss-gray500 mb-1">가격(원)</span>
              <input inputMode="numeric" value={amountText} onChange={(e) => setAmountText(e.target.value.replace(/[^\d]/g, '').slice(0, 9))} className="w-full px-3 py-2.5 bg-white rounded-xl border border-toss-gray200 text-[13px] font-bold tabular-nums" /></label>
          </div> : <div className="flex justify-between items-center px-1">
            <span className="text-[13px] font-semibold text-toss-gray700 truncate">{finalName}</span><span className="text-[16px] font-extrabold text-toss-gray900 tabular-nums">{won(amount)}</span>
          </div>}
          <p className="text-[11px] text-toss-gray500">{notice}{suffix}</p>
          {!valid && <p role="alert" className="text-[12px] font-semibold text-rose-500">비교할 금액을 1,000원 이상으로 입력해 주세요.</p>}
        </section>

        {valid && <>
          <section aria-label="구매 여부에 따른 두 세계" className="grid grid-cols-2 gap-2.5">
            <div className="bg-white rounded-[23px] p-3.5 shadow-card border border-rose-100">
              <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#F04452]" /><p className="text-[12px] font-bold text-toss-gray800">구매한 나</p></div>
              <div className="h-[75px] flex items-center justify-center my-2 relative"><span className="absolute h-[60px] w-[60px] rounded-full bg-gradient-to-br from-rose-100 to-orange-50" /><span className="relative text-[40px]" role="img" aria-label="쇼핑백">🛍️</span></div>
              <p className="text-[10.5px] text-toss-gray500">구매한 상품의 효용</p>
              <p className="text-[16px] font-extrabold text-toss-gray900 tracking-tight mt-1">상품을 얻어요</p>
              <p className="text-[11px] leading-snug text-rose-600 mt-1.5">구매 지출 {won(amount)}</p>
              {projection.actual === 'bought' && <span className="mt-2 inline-flex rounded-md bg-rose-50 text-rose-600 px-2 py-1 text-[10px] font-bold">내가 한 선택</span>}
            </div>
            <div className="bg-gradient-to-b from-[#EAF4FF] to-white rounded-[23px] p-3.5 shadow-card border border-blue-100">
              <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#3182F6]" /><p className="text-[12px] font-bold text-toss-blue">구매하지 않은 나</p></div>
              <div className="h-[75px] flex items-center justify-center my-2 relative"><span className="absolute h-[60px] w-[60px] rounded-full bg-gradient-to-br from-sky-100 to-indigo-50" /><span className="relative text-[40px]" role="img" aria-label="지갑">👛</span></div>
              <p className="text-[10.5px] text-toss-gray500">다른 곳에 쓸 수 있는 선택권</p>
              <p className="text-[16px] font-extrabold text-toss-gray900 tracking-tight mt-1">구매비를 남겨요</p>
              <p className="text-[11px] leading-snug text-toss-blue mt-1.5">보유 가능한 금액 {won(amount)}</p>
              {projection.actual === 'kept' && <span className="mt-2 inline-flex rounded-md bg-blue-100 text-blue-600 px-2 py-1 text-[10px] font-bold">내가 한 선택</span>}
            </div>
          </section>

          <section className="bg-white rounded-[24px] p-4 shadow-card" aria-label="미래 현금흐름 비교">
            <div className="flex items-center justify-between gap-2 mb-3">
              <h2 className="text-[15px] font-bold text-toss-gray900">두 세계의 결제계좌 잔액</h2>
              <span className="text-[10px] text-toss-gray400">가상 계산</span>
            </div>
            <div role="group" aria-label="비교 기간" className="grid grid-cols-3 gap-1 bg-toss-gray50 rounded-xl p-1 mb-4">
              {PERIODS.map((p) => <button type="button" key={p.days} aria-pressed={period === p.days} onClick={() => setPeriod(p.days)} className={`py-2 rounded-lg text-[12px] font-bold ${period === p.days ? 'bg-white shadow-sm text-toss-blue' : 'text-toss-gray500'}`}>{p.label}</button>)}
            </div>
            <ComparisonChart points={projection.points} />
            <div className="grid grid-cols-2 gap-2 mt-4">
              <div className="bg-rose-50/70 rounded-2xl p-3"><p className="text-[11px] text-toss-gray500">{period === 7 ? '7일' : period === 30 ? '1개월' : '3개월'} 뒤 · 구매</p><p className="font-extrabold text-[15px] text-toss-gray900 tabular-nums mt-1">{won(projection.boughtEnd)}</p></div>
              <div className="bg-blue-50/80 rounded-2xl p-3"><p className="text-[11px] text-toss-gray500">{period === 7 ? '7일' : period === 30 ? '1개월' : '3개월'} 뒤 · 미구매</p><p className="font-extrabold text-[15px] text-toss-gray900 tabular-nums mt-1">{won(projection.keptEnd)}</p></div>
            </div>
            <div className="mt-3 border-t border-toss-gray100 pt-3 flex justify-between items-center gap-2">
              <span className="text-[12px] font-semibold text-toss-gray700">결제계좌 잔액 차이</span>
              <span className="text-[16px] font-extrabold text-toss-blue tabular-nums">{won(projection.delta)}</span>
            </div>
            <p className="text-[11.5px] leading-relaxed text-toss-gray500 mt-2">등록된 급여·필수결제·거래 일정을 동일하게 적용한 비교예요. 미래 변동지출은 제외했어요. 미구매 금액은 수익이 아니라 남아 있는 소비 예산이에요.</p>
            {/* 신용카드 승인·현금 결제는 통장에서 즉시 차감하지 않음 */}
            {(/신용카드|credit|현금/i.test(projection.payment)) && <p className="mt-1.5 text-[11px] text-amber-700">결제수단 특성상 당장 통장 잔액 차이가 없을 수 있어요. 신용카드는 예정 청구일에 반영돼요.</p>}
          </section>

          <section className="bg-white rounded-[24px] p-4 shadow-card" aria-label="결제 위험 차이">
            <div className="flex items-center justify-between mb-3"><h2 className="text-[14px] font-bold text-toss-gray900">필수결제에는 어떤 영향이 있을까?</h2><button onClick={() => navigate('/bills')} className="text-[11px] text-toss-blue font-bold">결제 일정 수정 ›</button></div>
            <div className="space-y-2 text-[12px]">
              <div className="flex justify-between gap-2"><span className="text-toss-gray600">구매한 세계</span><span className={`font-bold ${projection.boughtRisk ? 'text-rose-600' : 'text-emerald-600'}`}>{projection.boughtRisk ? `${short(projection.boughtRisk)} 최소 잔액 미달` : '등록 일정에서 부족 없음'}</span></div>
              <div className="flex justify-between gap-2"><span className="text-toss-gray600">미구매 세계</span><span className={`font-bold ${projection.keptRisk ? 'text-rose-600' : 'text-emerald-600'}`}>{projection.keptRisk ? `${short(projection.keptRisk)} 최소 잔액 미달` : '등록 일정에서 부족 없음'}</span></div>
            </div>
            <p className="mt-2 text-[10.5px] text-toss-gray400">실제 결제 보장을 뜻하지 않아요. 등록되지 않은 지출과 수입 변동은 반영되지 않았어요.</p>
          </section>
        </>}

        <section className="bg-white rounded-[24px] p-4 shadow-card space-y-2.5">
          <h2 className="text-[15px] font-bold text-toss-gray900">다른 선택도 있었을까요?</h2>
          <p className="text-[12.5px] leading-relaxed text-toss-gray500">구매를 미루거나, 가상 적금·ETF·혼합 배분으로 선택을 넓혀 보세요.</p>
          <button type="button" disabled={!valid} onClick={() => navigate(exploreUrl)} className="w-full flex items-center justify-between rounded-2xl bg-[#E8F3FF] px-4 py-3.5 text-left disabled:opacity-50">
            <span><span className="block text-[13px] font-bold text-toss-blue">6가지 세계선 더 탐험하기</span><span className="block text-[11px] text-toss-gray500 mt-0.5">기존 3D 행성 · 저축 · 투자 · 연기 · 상세 비교</span></span>
            <Icon name="chevron_right" className="text-toss-blue" />
          </button>
          <button type="button" disabled={!valid} onClick={() => navigate(`/agent?amount=${amount}`)} className="w-full flex items-center justify-between rounded-2xl bg-toss-gray50 px-4 py-3.5 text-left disabled:opacity-50">
            <span><span className="block text-[13px] font-bold text-toss-gray900">내 목표에 맞는 경로 찾기</span><span className="block text-[11px] text-toss-gray500 mt-0.5">목표·월세·최소 잔액으로 규칙 기반 비교</span></span>
            <Icon name="chevron_right" className="text-toss-gray500" />
          </button>
          <button type="button" onClick={() => navigate('/world/explore?view=E')} className="w-full flex items-center justify-between rounded-2xl border border-toss-gray200 px-4 py-3 text-left">
            <span className="text-[12.5px] font-bold text-toss-gray700">이전에 저장한 평행세계 보기</span><Icon name="chevron_right" className="text-toss-gray400" />
          </button>
        </section>
      </div>
    </div>
  );
}
