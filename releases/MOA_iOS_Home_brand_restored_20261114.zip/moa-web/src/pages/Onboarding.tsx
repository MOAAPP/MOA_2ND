import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import WorldTwinScene from '../three/WorldTwinScene';
import { Icon, PrimaryButton } from '../components/ui';
import { getState, setState, scaleBudgets } from '../lib/store';

import LOGO from '../assets/moa-logo.webp';

const VALUES = [
  { icon: 'event_upcoming', color: 'text-rose-500 bg-rose-50', title: '결제일 전에 먼저 알려드려요', body: '카드값·월세가 빠져나가기 전에 잔액이 부족할지 미리 계산해요.' },
  { icon: 'school', color: 'text-amber-500 bg-amber-50', title: '3분 금융 학습과 퀴즈', body: '내 거래와 고민에 맞춘 개념 카드와 퀴즈로 배우고, 틀린 문제는 다시 풀어요.' },
  { icon: 'science', color: 'text-emerald-600 bg-emerald-50', title: '진짜 돈 쓰기 전에 가상으로', body: '가상 예·적금과 ETF로 먼저 해보고, 산 종목은 바로 학습 카드로 이해해요.' },
  { icon: 'auto_awesome', color: 'text-toss-blue bg-toss-lightBlue', title: '같은 돈, 다른 선택을 비교', body: '참은 금액을 사기·미루기·저축·투자했을 때 미래를 평행세계에서 나란히 봐요.' },
];

const BANKS = ['토스뱅크', '카카오뱅크', 'KB국민', '신한', '하나', '우리'];
const LEVELS = [['beginner', '처음이에요', '예금과 적금 차이부터'], ['basic', '조금 알아요', '적금은 해봤어요'], ['experienced', '익숙해요', '투자도 해봤어요']] as const;
const INTERESTS = ['저축', '투자', '절약', '비상금'];
const GOALS = ['여행 자금 모으기', '비상금 만들기', '첫 투자 시작하기', '목돈 모으기'];

export default function Onboarding() {
  const navigate = useNavigate();
  const init = getState().profile;
  const [step, setStep] = useState(0);
  const [name, setName] = useState(init.name === '지현' ? '' : init.name);
  const [payday, setPayday] = useState(init.payday);
  const [budget, setBudget] = useState(init.monthlyBudget);
  const [bank, setBank] = useState<string | null>(null);
  const [level, setLevel] = useState<string>(init.level || '');
  const [interests, setInterests] = useState<string[]>(init.interests || []);
  const [goal, setGoal] = useState(init.goal || GOALS[0]);
  const [goalAmount, setGoalAmount] = useState(init.goalAmount || 1000000);
  const [balance, setBalance] = useState(getState().finance.balance);

  const finish = () => {
    setState((s) => ({
      onboarded: true,
      profile: { ...s.profile, name: name.trim() || '모아', payday, monthlyBudget: budget, bank, level, interests, goal, goalAmount },
      budgets: scaleBudgets(s.budgets, budget),
      finance: { ...s.finance, balance },
    }));
    navigate('/', { replace: true });
  };

  return (
    <div className="min-h-full flex flex-col bg-[#F8FAFC]">
      {step > 0 && (
        <header className="h-14 px-4 flex items-center justify-between">
          <button type="button" aria-label="이전 단계" onClick={() => setStep((s) => s - 1)} className="w-9 h-9 -ml-1 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5">
            <Icon name="arrow_back_ios_new" className="text-[20px]" />
          </button>
          <div className="flex gap-1.5" aria-label={`${step}/4 단계`}>
            {[1, 2, 3, 4].map((i) => <span key={i} className={`h-1.5 rounded-full transition-all ${i <= step ? 'w-5 bg-toss-blue' : 'w-1.5 bg-toss-gray200'}`} />)}
          </div>
          <span className="w-9" />
        </header>
      )}

      {step === 0 && (
        <div className="flex-1 flex flex-col relative overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(circle_at_50%_30%,#DBEAFE_0%,#F8FAFC_62%)]" />
          <div className="relative px-6 pt-14">
            <img src={LOGO} alt="모아" className="h-9 w-auto" />
            <h1 className="mt-6 text-[28px] leading-[1.32] font-extrabold tracking-tight text-toss-gray900">
              결제일까지 안전하게,<br />아낀 돈은 <span className="text-toss-blue">평행세계</span>에서
            </h1>
            <p className="mt-3 text-[15px] text-toss-gray600 leading-relaxed">배우고, 가상으로 해보고, 같은 돈의 다른 미래를 비교해요.</p>
          </div>
          <WorldTwinScene className="relative w-full h-[300px] mt-2" />
          <div className="relative mt-auto px-5 pb-8 space-y-3">
            <PrimaryButton onClick={() => setStep(1)}>시작하기</PrimaryButton>
            <p className="text-center text-[12px] text-toss-gray500">시연용 금융 데이터는 이 브라우저에 저장되며, 실제 은행과 연결되지 않아요</p>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="flex-1 flex flex-col px-5 moa-fade-up">
          <h2 className="mt-4 text-[24px] font-extrabold tracking-tight text-toss-gray900 leading-snug">모아는 이렇게<br />도와드려요</h2>
          <ul className="mt-7 space-y-3.5">
            {VALUES.map((v) => (
              <li key={v.title} className="flex gap-4 bg-white rounded-[22px] p-5 shadow-card">
                <span className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${v.color}`}><Icon name={v.icon} fill className="text-[26px]" /></span>
                <span>
                  <span className="block text-[15px] font-bold text-toss-gray900">{v.title}</span>
                  <span className="block mt-1 text-[13px] text-toss-gray600 leading-relaxed">{v.body}</span>
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-auto pb-8 pt-6"><PrimaryButton onClick={() => setStep(2)}>다음</PrimaryButton></div>
        </div>
      )}

      {step === 2 && (
        <div className="flex-1 flex flex-col px-5 moa-fade-up">
          <h2 className="mt-4 text-[24px] font-extrabold tracking-tight text-toss-gray900 leading-snug">결제일 계산을 위해<br />몇 가지만 알려주세요</h2>
          <label className="block mt-8">
            <span className="text-[13px] font-semibold text-toss-gray600">이름 (닉네임)</span>
            <input value={name} onChange={(e) => setName(e.target.value.slice(0, 12))} placeholder="예: 지현" className="mt-2 w-full text-[20px] font-bold text-toss-gray900 border-b-2 border-toss-gray200 focus:border-toss-blue outline-none pb-2 bg-transparent placeholder:text-toss-gray300" />
          </label>
          <div className="mt-8">
            <span className="text-[13px] font-semibold text-toss-gray600">월급(용돈) 받는 날</span>
            <div className="mt-3 grid grid-cols-5 gap-2">
              {[1, 10, 15, 21, 25].map((d) => (
                <button key={d} type="button" onClick={() => setPayday(d)} className={`py-3 rounded-xl text-[14px] font-bold transition-all ${payday === d ? 'bg-toss-blue text-white shadow-sm' : 'bg-white text-toss-gray700 shadow-card'}`}>{d}일</button>
              ))}
            </div>
          </div>
          <label className="block mt-8">
            <span className="text-[13px] font-semibold text-toss-gray600">한 달 생활비 예산</span>
            <div className="mt-2 flex items-end gap-1 border-b-2 border-toss-gray200 focus-within:border-toss-blue pb-2">
              <input inputMode="numeric" value={budget ? budget.toLocaleString('ko-KR') : ''} onChange={(e) => setBudget(Math.min(99999999, Number(e.target.value.replace(/\D/g, '')) || 0))} className="flex-1 text-[22px] font-extrabold text-toss-gray900 outline-none bg-transparent tabular-nums" />
              <span className="text-[17px] font-bold text-toss-gray700 pb-0.5">원</span>
            </div>
          </label>
          <div className="mt-auto pb-8 pt-6"><PrimaryButton onClick={() => setStep(3)} disabled={budget < 10000}>다음</PrimaryButton></div>
        </div>
      )}

      {step === 3 && (
        <div className="flex-1 flex flex-col px-5 moa-fade-up">
          <h2 className="mt-4 text-[24px] font-extrabold tracking-tight text-toss-gray900 leading-snug">학습과 실험을<br />나에게 맞춰볼게요</h2>
          <div className="mt-7">
            <span className="text-[13px] font-semibold text-toss-gray600">금융 경험</span>
            <div className="mt-2.5 grid grid-cols-3 gap-2">
              {LEVELS.map(([k, t, d]) => (
                <button key={k} type="button" onClick={() => setLevel(k)} className={`py-3 px-2 rounded-2xl text-left transition-all ${level === k ? 'bg-toss-lightBlue ring-2 ring-toss-blue' : 'bg-white shadow-card'}`}>
                  <span className={`block text-[14px] font-bold ${level === k ? 'text-toss-blue' : 'text-toss-gray900'}`}>{t}</span>
                  <span className="block text-[11px] text-toss-gray500 mt-0.5">{d}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="mt-6">
            <span className="text-[13px] font-semibold text-toss-gray600">관심 분야 <span className="text-toss-gray400 font-medium">(여러 개 선택)</span></span>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {INTERESTS.map((it) => {
                const on = interests.includes(it);
                return <button key={it} type="button" aria-pressed={on} onClick={() => setInterests((v) => (on ? v.filter((x) => x !== it) : [...v, it]))} className={`px-4 py-2 rounded-full text-[13px] font-bold transition-all ${on ? 'bg-toss-blue text-white' : 'bg-white text-toss-gray700 shadow-card'}`}>{it}</button>;
              })}
            </div>
          </div>
          <div className="mt-6">
            <span className="text-[13px] font-semibold text-toss-gray600">금융 목표</span>
            <div className="mt-2.5 grid grid-cols-2 gap-2">
              {GOALS.map((g) => <button key={g} type="button" onClick={() => setGoal(g)} className={`py-3 rounded-xl text-[13px] font-bold transition-all ${goal === g ? 'bg-toss-blue text-white' : 'bg-white text-toss-gray700 shadow-card'}`}>{g}</button>)}
            </div>
            <div className="mt-3 flex items-end gap-1 border-b-2 border-toss-gray200 focus-within:border-toss-blue pb-2">
              <span className="text-[13px] text-toss-gray500 pb-1 mr-1 shrink-0 whitespace-nowrap">목표 금액</span>
              <input inputMode="numeric" value={goalAmount ? goalAmount.toLocaleString('ko-KR') : ''} onChange={(e) => setGoalAmount(Math.min(999999999, Number(e.target.value.replace(/\D/g, '')) || 0))} className="flex-1 min-w-0 text-[20px] font-extrabold text-toss-gray900 outline-none bg-transparent tabular-nums text-right" aria-label="목표 금액" />
              <span className="text-[16px] font-bold text-toss-gray700 pb-0.5">원</span>
            </div>
          </div>
          <div className="mt-auto pb-8 pt-6"><PrimaryButton onClick={() => setStep(4)} disabled={!level}>{level ? '다음' : '금융 경험을 골라주세요'}</PrimaryButton></div>
        </div>
      )}

      {step === 4 && (
        <div className="flex-1 flex flex-col px-5 moa-fade-up">
          <h2 className="mt-4 text-[24px] font-extrabold tracking-tight text-toss-gray900 leading-snug">주거래은행을<br />알려주세요</h2>
          <p className="mt-2 text-[14px] text-toss-gray600">잔액과 결제 일정으로 쓸 수 있는 돈을 계산해요. 자동 연결이 열리기 전까지는 직접 입력한 값을 써요.</p>
          <label className="block mt-6">
            <span className="text-[13px] font-semibold text-toss-gray600">지금 통장 잔액</span>
            <div className="mt-2 flex items-end gap-1 border-b-2 border-toss-gray200 focus-within:border-toss-blue pb-2">
              <input inputMode="numeric" value={balance ? balance.toLocaleString('ko-KR') : ''} onChange={(e) => setBalance(Math.min(999999999, Number(e.target.value.replace(/\D/g, '')) || 0))} className="flex-1 text-[22px] font-extrabold text-toss-gray900 outline-none bg-transparent tabular-nums" aria-label="통장 잔액" />
              <span className="text-[17px] font-bold text-toss-gray700 pb-0.5">원</span>
            </div>
          </label>
          <p className="mt-6 text-[13px] font-semibold text-toss-gray600">주거래은행</p>
          <div className="mt-2.5 grid grid-cols-3 gap-2.5">
            {BANKS.map((b) => (
              <button key={b} type="button" onClick={() => setBank(b)} className={`py-4 rounded-2xl text-[13px] font-bold transition-all flex flex-col items-center gap-2 ${bank === b ? 'bg-toss-lightBlue text-toss-blue ring-2 ring-toss-blue' : 'bg-white text-toss-gray700 shadow-card'}`}>
                <span className={`w-9 h-9 rounded-full flex items-center justify-center text-white text-[13px] font-extrabold ${bank === b ? 'bg-toss-blue' : 'bg-toss-gray300'}`}>{b[0]}</span>
                {b}
              </button>
            ))}
          </div>
          <div className="mt-6 flex items-start gap-2 rounded-2xl bg-white p-4 shadow-card">
            <Icon name="verified_user" className="text-emerald-500 text-[20px]" fill />
            <p className="text-[12px] text-toss-gray600 leading-relaxed">자동 연결이 열리면 조회 권한만 요청해요. 송금·결제 권한은 요청하지 않아요. 월세·카드값 같은 필수 결제는 설정 › 잔액·필수 결제 관리에서 바꿀 수 있어요.</p>
          </div>
          <div className="mt-auto pb-8 pt-6 space-y-2">
            <PrimaryButton onClick={finish}>{bank ? `${bank}로 시작하기` : '시작하기'}</PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
}
