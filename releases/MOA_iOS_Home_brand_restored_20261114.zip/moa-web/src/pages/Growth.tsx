import { useNavigate } from 'react-router-dom';
import { Card, Icon, PageHeader, SectionTitle } from '../components/ui';
import { LESSONS, REVIEW_STEPS, lessonAccuracy, lessonById, reviewQueue } from '../lib/learning';
import { APP_TODAY, WISH_LABEL, fmtShares, timeAgo, todayDate, useStore, won } from '../lib/store';

/** /growth — 나의 금융 성장 기록 */
export default function Growth() {
  const navigate = useNavigate();
  const learning = useStore((s) => s.learning);
  const orders = useStore((s) => s.invest.orders);
  const scenarios = useStore((s) => s.scenarios);
  const wishes = useStore((s) => s.wishes);

  const attempts = learning.attempts || [];
  const correctCount = attempts.filter((q) => q.correct).length;
  const queue = reviewQueue(attempts, APP_TODAY);
  const acc = lessonAccuracy(attempts);
  const week = [...Array(7)].map((_, k) => { const d = todayDate(); d.setDate(d.getDate() - (6 - k)); const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; return { iso, d, on: (learning.activity || []).includes(iso) }; });
  const doneLessons = learning.done.map((id) => lessonById(id)).filter(Boolean);
  const decided = wishes.filter((w) => w.status !== 'thinking');

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader title="나의 금융 성장 기록" />
      <div className="px-4 pt-3 space-y-3.5">
        <Card className="!p-4">
          <div className="grid grid-cols-4 gap-1 text-center">
            {[
              ['카드 완료', `${learning.done.length}/${LESSONS.length}`],
              ['퀴즈 정답률', attempts.length ? `${Math.round((correctCount / attempts.length) * 100)}%` : '-'],
              ['가상 거래', `${orders.filter((o) => o.status === 'filled').length}건`],
              ['저장한 실험', `${scenarios.length}건`],
            ].map(([k, v]) => (
              <div key={k} className="py-1">
                <p className="text-[17px] font-extrabold text-toss-gray900 tabular-nums">{v}</p>
                <p className="text-[11px] text-toss-gray500 mt-0.5">{k}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle action={<span className="text-[12px] text-toss-gray500">{week.filter((w) => w.on).length}/7일</span>}>최근 7일 학습</SectionTitle>
          <div className="grid grid-cols-7 gap-1.5 text-center">
            {week.map((w) => (
              <div key={w.iso}>
                <div className={`h-9 rounded-xl flex items-center justify-center ${w.on ? 'bg-toss-blue text-white' : 'bg-toss-gray100 text-toss-gray400'}`}><Icon name={w.on ? 'check' : 'remove'} className="text-[18px]" /></div>
                <p className={`text-[11px] mt-1 ${w.iso === APP_TODAY ? 'font-bold text-toss-gray900' : 'text-toss-gray500'}`}>{'일월화수목금토'[w.d.getDay()]}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle action={<span className="text-[12px] text-toss-gray500">1·3·7일 간격</span>}>복습 일정</SectionTitle>
          {queue.length === 0 ? <Empty text="틀린 문제가 생기면 1일·3일·7일 뒤에 다시 풀도록 알려드려요." /> : (
            <ul className="space-y-2">
              {queue.map((r) => {
                const l = lessonById(r.lessonId)!;
                const q = l.quiz.find((x) => x.id === r.questionId);
                return (
                  <li key={r.questionId}>
                    <button type="button" onClick={() => navigate(r.due ? `/learn/${r.lessonId}/quiz?review=${encodeURIComponent(r.questionId)}` : `/learn/${r.lessonId}`)} className={`w-full text-left rounded-2xl p-3.5 border ${r.due ? 'bg-rose-50/70 border-rose-100' : 'bg-toss-gray50 border-transparent'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-[12px] font-bold text-toss-gray700">{l.emoji} {l.title}</span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${r.due ? 'bg-rose-500 text-white' : 'bg-white text-toss-gray600'}`}>{r.due ? '오늘 복습' : `${r.daysLeft}일 뒤`} · {REVIEW_STEPS[r.stage]}일차</span>
                      </div>
                      <p className="text-[12.5px] text-toss-gray800 mt-1">{q?.q}</p>
                      <p className="text-[11px] text-toss-gray500 mt-0.5">틀린 횟수 {r.wrongCount}번 · {r.stage}/3단계</p>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card>
          <SectionTitle>개념별 이해도</SectionTitle>
          {Object.keys(acc).length === 0 ? <Empty text="퀴즈를 풀면 개념별 정답률이 쌓여요." /> : (
            <ul className="space-y-3">
              {Object.entries(acc).sort((x, y) => x[1].rate - y[1].rate).map(([id, r]) => {
                const l = lessonById(id);
                if (!l) return null;
                return (
                  <li key={id}>
                    <div className="flex items-center justify-between text-[13px]"><span className="font-semibold text-toss-gray900 truncate">{l.emoji} {l.title}</span><span className="font-bold tabular-nums text-toss-gray700 shrink-0">{Math.round(r.rate * 100)}% <span className="text-[11px] text-toss-gray400 font-medium">({r.correct}/{r.tries})</span></span></div>
                    <div className="mt-1.5 h-1.5 rounded-full bg-toss-gray100 overflow-hidden"><div className={`h-full rounded-full ${r.rate >= 0.8 ? 'bg-emerald-500' : r.rate >= 0.5 ? 'bg-toss-blue' : 'bg-rose-400'}`} style={{ width: `${Math.max(4, r.rate * 100)}%` }} /></div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card>
          <SectionTitle action={<button type="button" onClick={() => navigate('/learn')} className="text-[12px] font-semibold text-toss-blue">학습하러 가기 ›</button>}>학습한 개념</SectionTitle>
          {doneLessons.length === 0 ? <Empty text="아직 끝까지 읽은 학습이 없어요." /> : (
            <div className="flex flex-wrap gap-1.5">
              {doneLessons.map((l) => (
                <button key={l!.id} type="button" onClick={() => navigate(`/learn/${l!.id}`)} className="px-3 py-1.5 rounded-full bg-toss-lightBlue text-toss-blue text-[12px] font-bold">{l!.emoji} {l!.title}</button>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <SectionTitle action={<button type="button" onClick={() => navigate('/invest')} className="text-[12px] font-semibold text-toss-blue">거래소 ›</button>}>가상 매매 이력</SectionTitle>
          {orders.length === 0 ? <Empty text="가상 거래소에서 첫 주문을 넣어보세요." /> : (
            <ul className="divide-y divide-toss-gray100">
              {orders.slice(0, 6).map((o) => (
                <li key={o.id} className="py-2.5 flex items-center justify-between text-[13px]">
                  <span><b className={o.side === 'buy' ? 'text-rose-500' : 'text-toss-blue'}>{o.side === 'buy' ? '매수' : '매도'}</b> <span className="font-semibold text-toss-gray900">{o.name}</span>
                    <span className="block text-[11px] text-toss-gray500">{fmtShares(o.shares)}주 · {won(o.price * o.shares)} · {timeAgo(o.at)}</span></span>
                  <span className={`text-[11px] font-bold px-2 py-1 rounded-lg ${o.status === 'filled' ? 'bg-emerald-50 text-emerald-700' : o.status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-toss-gray100 text-toss-gray500'}`}>
                    {o.status === 'filled' ? '체결' : o.status === 'pending' ? '대기' : '취소'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <SectionTitle action={<button type="button" onClick={() => navigate('/world/explore?view=E')} className="text-[12px] font-semibold text-toss-blue">보관함 ›</button>}>저장한 평행세계</SectionTitle>
          {scenarios.length === 0 ? <Empty text="평행세계에서 비교한 결과를 저장하면 여기에 모여요." /> : (
            <ul className="space-y-2">
              {scenarios.slice(0, 4).map((s) => (
                <li key={s.id} className="flex items-center justify-between text-[13px]">
                  <span className="min-w-0"><span className="block font-bold text-toss-gray900 truncate">{s.title}</span><span className="block text-[11px] text-toss-gray500">{won(s.amount)} · {s.worldName} · {s.years}년</span></span>
                  <span className="font-extrabold text-toss-blue tabular-nums shrink-0">{won(s.value)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <SectionTitle action={<button type="button" onClick={() => navigate('/wishlist')} className="text-[12px] font-semibold text-toss-blue">보관함 ›</button>}>소비 결정</SectionTitle>
          {decided.length === 0 ? <Empty text="구매 고민을 담고 결정하면 기록돼요." /> : (
            <ul className="space-y-2">
              {decided.slice(0, 4).map((w) => (
                <li key={w.id} className="flex items-center justify-between text-[13px]">
                  <span className="font-semibold text-toss-gray900 truncate">{w.name}</span>
                  <span className="text-[11px] font-bold text-toss-gray600 shrink-0">{WISH_LABEL[w.status]} · {won(w.amount)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="text-[12.5px] text-toss-gray500 py-3 flex items-center gap-1.5"><Icon name="info" className="text-[16px] text-toss-gray400" />{text}</p>;
}
