import { useState } from 'react';
import { Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { useApp } from '../lib/app';
import { useStore, setState, APP_TODAY, uid } from '../lib/store';

const FAQ = [
  { q: '평행세계는 실제 돈이 움직이나요?', a: '아니요. 평행세계, 가상 예·적금, 가상 투자는 모두 실제 돈이 오가지 않는 시뮬레이션이에요. 안 쓴 돈이 어떻게 자랄 수 있었는지 보여드리는 기능이에요.' },
  { q: '결제일 부족 예측은 어떻게 계산되나요?', a: '사용자가 입력한 통장 잔액에서 등록된 카드값·정기결제·월세 등을 차감해 계산해요. 변동 지출의 예측은 현재 제공되지 않아요.' },
  { q: '구매 고민에 담으면 잔액에서 빠지나요?', a: '빠지지 않아요. 고민 목록은 결정을 미뤄두는 공간이고, 실제로 샀을 때만 가계부에 기록하면 돼요.' },
  { q: '가상 투자 수익률은 실제 시세인가요?', a: '현재는 실제 거래소 시세가 아닌 학습용 가상 가격이에요. 실제 투자 결과와 다를 수 있고 투자 권유가 아니에요.' },
  { q: '계좌 연결은 안전한가요?', a: '현재 자동 계좌 연결 기능은 제공되지 않아요. 사용자가 직접 입력한 금액만 브라우저 안에 저장됩니다.' },
];

export default function Support() {
  const { toast } = useApp();
  const [open, setOpen] = useState<number | null>(0);
  const [msg, setMsg] = useState('');
  const drafts = useStore((s) => s.supportDrafts || []);

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-12">
      <PageHeader title="고객센터" />
      <div className="px-4 pt-3 space-y-3.5">
        <Card className="!px-0 !pb-2">
          <div className="px-5"><SectionTitle>자주 묻는 질문</SectionTitle></div>
          <ul className="divide-y divide-toss-gray100">
            {FAQ.map((f, i) => (
              <li key={f.q}>
                <button type="button" aria-expanded={open === i} onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between gap-3 px-5 py-3.5 text-left">
                  <span className="text-[14px] font-semibold text-toss-gray900"><b className="text-toss-blue mr-1.5">Q</b>{f.q}</span>
                  <Icon name="expand_more" className={`text-toss-gray400 transition-transform ${open === i ? 'rotate-180' : ''}`} />
                </button>
                {open === i && <p className="px-5 pb-4 -mt-1 text-[13px] text-toss-gray600 leading-relaxed">{f.a}</p>}
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionTitle action={<span className="text-[12px] text-toss-gray500 font-semibold">프론트 시연용</span>}>문의 내용 임시 보관</SectionTitle>
          <textarea value={msg} onChange={(e) => setMsg(e.target.value.slice(0, 500))} rows={4} placeholder="불편했던 점이나 궁금한 점을 남겨주세요" className="w-full rounded-2xl bg-toss-gray50 p-4 text-[14px] text-toss-gray900 outline-none focus:ring-2 focus:ring-toss-blue/40 resize-none placeholder:text-toss-gray400" />
          <div className="flex justify-end text-[11px] text-toss-gray400 mt-1 mb-3">{msg.length}/500</div>
          <PrimaryButton disabled={msg.trim().length < 5} onClick={() => { setState((s) => ({ supportDrafts: [{ id: uid('support'), body: msg.trim(), at: APP_TODAY }, ...(s.supportDrafts || [])] })); setMsg(''); toast('이 브라우저에 문의 초안을 저장했어요. 실제 전송은 되지 않아요'); }}>초안 저장하기</PrimaryButton>
          <p className="mt-2 text-[11px] text-toss-gray500">백엔드 연결 전에는 문의가 상담원에게 발송되지 않으며, 이 기기에만 임시로 보관돼요.</p>
          {drafts.length > 0 && <details className="mt-3 text-[12px] text-toss-gray600"><summary className="font-bold cursor-pointer">보관 중인 문의 초안 {drafts.length}건</summary>{drafts.map((d) => <p key={d.id} className="border-b py-2 whitespace-pre-wrap">{d.at} · {d.body}</p>)}</details>}
        </Card>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden divide-y divide-toss-gray100">
          {['서비스 이용약관', '개인정보처리방침', '오픈소스 라이선스'].map((t) => (
            <details key={t} className="group">
              <summary className="list-none flex items-center justify-between px-5 py-4 cursor-pointer">
                <span className="text-[14px] font-semibold text-toss-gray900">{t}</span>
                <Icon name="chevron_right" className="text-toss-gray400 group-open:rotate-90 transition-transform" />
              </summary>
              <p className="px-5 pb-4 text-[12.5px] text-toss-gray500 leading-relaxed">
                {t === '오픈소스 라이선스'
                  ? 'React (MIT), React Router (MIT), three.js (MIT), Tailwind CSS (MIT), Pretendard (OFL-1.1), Material Symbols (Apache-2.0)'
                  : `${t}은 현재 작성·검토 중인 시연 항목입니다. 정식 약관이나 개인정보 처리방침으로 사용하지 마세요.`}
              </p>
            </details>
          ))}
        </section>
      </div>
    </div>
  );
}
