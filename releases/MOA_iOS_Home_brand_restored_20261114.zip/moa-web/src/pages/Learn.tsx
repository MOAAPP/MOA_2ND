import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { GENERAL_LESSONS, lessonById, pickToday, type Lesson } from '../lib/learning';
import { finishQuiz, fmtShares, getState, recordQuiz, setLessonProgress, useStore, won, type LessonCardLike } from '../lib/store';
import { APP_TODAY } from '../lib/store';

const dateLabel = (iso: string) => `${Number(iso.slice(5, 7))}월 ${Number(iso.slice(8, 10))}일`;

/** /learn — 오늘의 금융 학습 + 전체 학습 목록 */
export function LearnHub() {
  const navigate = useNavigate();
  const learning = useStore((s) => s.learning);
  const today = pickToday(getState(), APP_TODAY);
  const lesson = lessonById(today.id)!;
  const read = learning.progress[lesson.id] || 0;

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader title="금융 학습" right={<button type="button" onClick={() => navigate('/growth')} aria-label="성장 기록" className="text-toss-blue"><span className="text-[11px] font-bold whitespace-nowrap">기록</span></button>} />
      <div className="px-4 pt-3 space-y-3.5">
        <button type="button" onClick={() => navigate(`/learn/${lesson.id}`)} className="w-full text-left rounded-[26px] p-5 bg-gradient-to-br from-[#1E3A8A] via-[#2552C9] to-[#3182F6] text-white shadow-floating active:scale-[0.99] transition-transform">
          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-white/15 rounded-full px-2.5 py-1"><Icon name="school" className="text-[14px]" /> 오늘의 추천</span>
          <p className="mt-3 text-[22px] font-extrabold leading-snug tracking-tight">{lesson.emoji} {lesson.title}</p>
          <p className="mt-1.5 text-[13px] text-blue-100 leading-relaxed">{today.reason}</p>
          <div className="mt-4 flex items-center justify-between text-[12px] text-blue-100">
            <span>카드 {lesson.cards.length}장 · 퀴즈 {lesson.quiz.length}문제 · 약 {lesson.minutes}분</span>
            <span className="font-bold text-white">{read ? `${read}/${lesson.cards.length} 읽음` : '시작하기'} ›</span>
          </div>
        </button>

        <p className="text-[11px] text-toss-gray500 px-1">현재 카드는 앱에 포함된 시연용 금융 학습 노트예요. AI 생성·외부 뉴스 연동은 백엔드 연결 이후 제공돼요.</p>
        <Card>
          <SectionTitle action={<button type="button" onClick={() => navigate('/growth')} className="text-[12px] font-semibold text-toss-blue">성장 기록 ›</button>}>전체 학습</SectionTitle>
          <ul className="divide-y divide-toss-gray100 -mx-1">
            {GENERAL_LESSONS.map((l) => {
              const done = learning.done.includes(l.id);
              const qd = (learning.quizDone || []).includes(l.id);
              return (
                <li key={l.id}>
                  <button type="button" onClick={() => navigate(`/learn/${l.id}`)} className="w-full flex items-center gap-3 px-1 py-3 text-left">
                    <span className="w-10 h-10 rounded-2xl bg-toss-gray50 flex items-center justify-center text-[20px] shrink-0">{l.emoji}</span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-[14px] font-bold text-toss-gray900 truncate">{l.title}</span>
                      <span className="block text-[12px] text-toss-gray500 mt-0.5">{l.topic} · 약 {l.minutes}분</span>
                    </span>
                    {qd ? <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">퀴즈 완료</span>
                      : done ? <span className="text-[11px] font-bold text-toss-blue bg-toss-lightBlue px-2 py-1 rounded-lg">카드 완료</span>
                      : <Icon name="chevron_right" className="text-toss-gray400 text-[20px]" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </Card>
      </div>
    </div>
  );
}

/** /learn/:id — 개념 카드 */
export function LessonCards() {
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const lesson = lessonById(id);
  const fromTrade = params.get('from') === 'trade';
  const amount = Number(params.get('amount')) || 0;
  const [i, setI] = useState(0);
  const order = getState().invest.orders.find((o) => o.id === params.get('order'));
  // 매수 직후: 주문 영수증 → 종목 개념·위험 카드 → 같은 돈으로 다른 선택 비교
  const cards: LessonCardLike[] = !lesson ? [] : fromTrade ? [
    ...(order ? [{ emoji: '🧾', title: '방금 체결된 주문', body: `${order.name}\n${fmtShares(order.shares)}주 × ${won(order.price)} = ${won(order.price * order.shares)}\n${order.type === 'limit' ? `지정가 ${won(order.limitPrice || order.price)}` : '시장가'} 주문 · 남은 방어 머니 ${won(getState().invest.cash)}`, point: '이 거래를 기준으로 아래 카드를 골랐어요' }] : []),
    ...lesson.cards,
    ...(amount ? [{ emoji: '⚖️', title: '같은 돈, 다른 선택이었다면', body: `${won(amount)}을 1년 동안 두었을 때(가정)\n· 적금 연 3.8%: ${won(amount * 1.038)}\n· 이 ETF 기준 연 7.2%: ${won(amount * 1.072)}\n· 시장이 10% 하락하면: ${won(amount * 0.9)}`, point: '투자는 더 벌 수도, 원금보다 줄어들 수도 있어요' }] : []),
  ] : lesson.cards;

  useEffect(() => { if (lesson) setLessonProgress(lesson.id, i + 1, cards.length); }, [i, lesson, cards.length]);
  if (!lesson) return <NotFound />;

  const card = cards[i];
  const last = i === cards.length - 1;
  const reason = fromTrade
    ? `가상 거래소에서 ${amount ? won(amount) + '어치를 ' : ''}매수해서 골랐어요`
    : pickToday(getState(), APP_TODAY).id === lesson.id ? pickToday(getState(), APP_TODAY).reason : lesson.summary;
  const qs = params.toString();

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10 flex flex-col">
      <PageHeader title={fromTrade ? '이번 거래로 배우기' : '금융 학습'} right={<button type="button" onClick={() => navigate('/learn')} className="text-[12px] text-toss-blue font-bold whitespace-nowrap">전체 보기</button>} />
      <div className="px-4 pt-3 flex-1 flex flex-col">
        <div className="px-1">
          <p className="text-[12px] font-bold text-toss-blue">{lesson.topic}</p>
          <h1 className="text-[22px] font-extrabold text-toss-gray900 tracking-tight leading-snug mt-0.5">{lesson.emoji} {lesson.title}</h1>
          <p className="text-[12.5px] text-toss-gray600 mt-1.5 leading-relaxed">{reason}</p>
          <p className="text-[11px] text-toss-gray400 mt-1">{lesson.source} · {dateLabel(lesson.updated)} 업데이트</p>
        </div>

        <div className="flex gap-1 mt-4" aria-label={`${i + 1}/${cards.length}`}>
          {cards.map((_, k) => <span key={k} className={`h-1 flex-1 rounded-full transition-colors ${k <= i ? 'bg-toss-blue' : 'bg-toss-gray200'}`} />)}
        </div>

        <section key={i} className="mt-3 bg-white rounded-[28px] p-6 shadow-card min-h-[300px] flex flex-col animate-[moa-fade-up_.25s_ease]">
          <span className="text-[40px] leading-none">{card.emoji}</span>
          <p className="text-[11px] font-bold text-toss-gray400 mt-5">{i + 1} / {cards.length}</p>
          <h2 className="text-[19px] font-extrabold text-toss-gray900 leading-snug tracking-tight mt-1">{card.title}</h2>
          <p className="text-[15px] text-toss-gray700 leading-[1.7] mt-3 whitespace-pre-line">{card.body}</p>
          {card.point && <p className="mt-auto pt-4"><span className="inline-block text-[12.5px] font-bold text-toss-blue bg-toss-lightBlue rounded-xl px-3 py-2">💡 {card.point}</span></p>}
        </section>

        <div className="mt-auto pt-5 flex gap-2">
          <button type="button" disabled={i === 0} onClick={() => setI((v) => v - 1)} className="w-14 shrink-0 rounded-2xl bg-white text-toss-gray700 shadow-card disabled:opacity-40 flex items-center justify-center" aria-label="이전 카드">
            <Icon name="arrow_back_ios_new" className="text-[18px]" />
          </button>
          {last
            ? <div className="flex-1 flex flex-col gap-2">
                <PrimaryButton onClick={() => navigate(`/learn/${lesson.id}/quiz${qs ? `?${qs}` : ''}`)}>이해도 퀴즈 풀기 ({lesson.quiz.length}문제) · 선택</PrimaryButton>
                <button type="button" onClick={() => navigate('/learn')} className="py-2.5 rounded-2xl border border-toss-gray200 text-toss-gray700 text-[12.5px] font-bold">퀴즈 없이 다른 학습 보기</button>
              </div>
            : <PrimaryButton onClick={() => setI((v) => v + 1)}>다음 카드</PrimaryButton>}
        </div>
      </div>
    </div>
  );
}

/** /learn/:id/quiz — 퀴즈와 해설 */
export function LessonQuiz() {
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const lesson = lessonById(id);
  const [n, setN] = useState(0);
  const [pick, setPick] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  if (!lesson) return <NotFound />;

  const reviewId = params.get('review');
  const questions = reviewId ? lesson.quiz.filter((item) => item.id === reviewId) : lesson.quiz;
  if (!questions.length) return <NotFound />;
  const q = questions[n];
  const amount = Number(params.get('amount')) || 0;
  const practice = practiceTarget(lesson, amount);

  const submit = () => {
    if (pick == null) return;
    const correct = pick === q.answer;
    setSubmitted(true);
    if (correct) setScore((v) => v + 1);
    recordQuiz({ questionId: q.id, lessonId: lesson.id, correct });
  };
  const next = () => {
    if (n === questions.length - 1) { if (!reviewId) finishQuiz(lesson.id); return setFinished(true); }
    setN((v) => v + 1); setPick(null); setSubmitted(false);
  };

  if (finished) {
    const all = score === questions.length;
    return (
      <div className="min-h-full bg-[#F2F4F6] pb-10">
        <PageHeader title="퀴즈 결과" onBack={() => navigate(`/learn/${lesson.id}`)} />
        <div className="px-4 pt-6 space-y-3.5">
          <Card className="text-center !py-8">
            <div className="text-[44px]">{all ? '🎉' : '📚'}</div>
            <p className="mt-2 text-[22px] font-extrabold text-toss-gray900">{questions.length}문제 중 {score}문제 정답</p>
            <p className="mt-1 text-[13px] text-toss-gray500">{all ? '개념을 잘 이해했어요. 직접 실험해 볼까요?' : '틀린 문제는 성장 기록에서 다시 볼 수 있어요.'}</p>
          </Card>
          {(() => {
            const nx = pickToday(getState(), APP_TODAY);
            const nl = lessonById(nx.id);
            return nl && nl.id !== lesson.id ? (
              <button type="button" onClick={() => navigate(`/learn/${nl.id}`)} className="w-full text-left bg-white rounded-[22px] p-4 shadow-card">
                <p className="text-[11px] font-bold text-toss-blue">다음 추천 학습</p>
                <p className="text-[15px] font-bold text-toss-gray900 mt-0.5">{nl.emoji} {nl.title}</p>
                <p className="text-[12px] text-toss-gray500 mt-0.5">{nx.reason}</p>
              </button>
            ) : !all ? (
              <button type="button" onClick={() => navigate(`/learn/${lesson.id}`)} className="w-full text-left bg-rose-50 rounded-[22px] p-4">
                <p className="text-[11px] font-bold text-rose-600">틀린 문제 다시 보기</p>
                <p className="text-[13px] text-toss-gray700 mt-0.5">카드를 한 번 더 보고, 1일 뒤에 다시 풀어볼게요.</p>
              </button>
            ) : null;
          })()}
          <PrimaryButton onClick={() => navigate(practice.to)}>{practice.label}</PrimaryButton>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => navigate(`/learn/${lesson.id}`)} className="py-3.5 rounded-2xl bg-white shadow-card text-[13px] font-bold text-toss-gray700">카드 다시 보기</button>
            <button type="button" onClick={() => navigate('/growth')} className="py-3.5 rounded-2xl bg-white shadow-card text-[13px] font-bold text-toss-gray700">성장 기록 보기</button>
          </div>
        </div>
      </div>
    );
  }

  const correct = submitted && pick === q.answer;
  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10 flex flex-col">
      <PageHeader title={`퀴즈 ${n + 1}/${questions.length}`} />
      <div className="px-4 pt-4 flex-1 flex flex-col">
        <p className="text-[12px] font-bold text-toss-blue px-1">{lesson.emoji} {lesson.title}</p>
        <h1 className="text-[20px] font-extrabold text-toss-gray900 leading-snug tracking-tight mt-1 px-1">{q.q}</h1>
        <div className="mt-5 space-y-2" role="radiogroup">
          {q.options.map((o, k) => {
            const state = !submitted ? (pick === k ? 'pick' : '') : k === q.answer ? 'right' : pick === k ? 'wrong' : 'dim';
            return (
              <button key={k} type="button" role="radio" aria-checked={pick === k} disabled={submitted} onClick={() => setPick(k)}
                className={`w-full text-left rounded-2xl px-4 py-4 text-[15px] font-semibold border-2 transition-all flex items-center justify-between ${
                  state === 'pick' ? 'border-toss-blue bg-toss-lightBlue/60 text-toss-blue'
                  : state === 'right' ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                  : state === 'wrong' ? 'border-rose-400 bg-rose-50 text-rose-600'
                  : state === 'dim' ? 'border-transparent bg-white text-toss-gray400' : 'border-transparent bg-white text-toss-gray800 shadow-card'}`}>
                <span>{o}</span>
                {state === 'right' && <Icon name="check_circle" className="text-[20px]" fill />}
                {state === 'wrong' && <Icon name="cancel" className="text-[20px]" fill />}
              </button>
            );
          })}
        </div>
        {submitted && (
          <div className={`mt-4 rounded-2xl p-4 ${correct ? 'bg-emerald-50' : 'bg-rose-50'}`}>
            <p className={`text-[14px] font-bold ${correct ? 'text-emerald-700' : 'text-rose-600'}`}>{correct ? '정답이에요!' : '아쉬워요, 정답은 따로 있어요'}</p>
            <p className="text-[13.5px] text-toss-gray700 leading-relaxed mt-1">{q.explain}</p>
          </div>
        )}
        <div className="mt-auto pt-5">
          {submitted
            ? <PrimaryButton onClick={next}>{n === questions.length - 1 ? '결과 보기' : '다음 문제'}</PrimaryButton>
            : <PrimaryButton onClick={submit} disabled={pick == null}>제출하기</PrimaryButton>}
        </div>
      </div>
    </div>
  );
}

function practiceTarget(lesson: Lesson, amount: number) {
  if (lesson.practice.to === '/world' && amount) return { label: lesson.practice.label, to: `/world?amount=${amount}&title=${encodeURIComponent(lesson.title.replace(/를 샀어요|을 샀어요/, ''))}` };
  return lesson.practice;
}

function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="min-h-full bg-[#F2F4F6]">
      <PageHeader title="금융 학습" />
      <div className="p-8 text-center">
        <p className="text-[14px] text-toss-gray600">학습 내용을 찾을 수 없어요.</p>
        <button type="button" onClick={() => navigate('/learn')} className="mt-4 px-4 py-2.5 rounded-xl bg-toss-lightBlue text-toss-blue text-[13px] font-bold">학습 목록으로</button>
      </div>
    </div>
  );
}
