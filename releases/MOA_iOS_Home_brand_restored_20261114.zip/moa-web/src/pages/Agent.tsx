import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { impactOf, beforePayday, futurePurchaseImpact, md } from '../lib/finance';
import { worldAssets, worldOutflow } from '../lib/bridge';
import { getState, setState, useStore, won } from '../lib/store';
import { useApp } from '../lib/app';

type PathId = 1 | 2 | 3 | 4 | 5 | 6;
const PATHS: { id: PathId; name: string; summary: string; icon: string }[] = [
  { id: 1, name: '지금 구매', summary: '현재 소비의 즉시 지출', icon: 'shopping_bag' },
  { id: 2, name: '현금 보유', summary: '바로 쓸 수 있는 돈을 지키기', icon: 'account_balance_wallet' },
  { id: 3, name: '구매 연기', summary: '구매 시점까지 현금 유지', icon: 'schedule' },
  { id: 4, name: '가상 저축', summary: '이자 가정과 유동성의 차이', icon: 'savings' },
  { id: 5, name: '가상 투자', summary: '손실 가능성을 포함한 실습', icon: 'candlestick_chart' },
  { id: 6, name: '혼합 배분', summary: '소비·저축·투자를 나누기', icon: 'pie_chart' },
];

const numberOf = (value: string) => Math.max(0, Math.min(100000000, Number(value.replace(/[^0-9]/g, '')) || 0));

/** AI Agent API가 오기 전까지 사용자 목표·제약·금융 엔진을 연결하는 프론트 시연 화면 */
export default function Agent() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const [params] = useSearchParams();
  const state = useStore((s) => s);
  const [goal, setGoal] = useState(state.profile.goal || '여행 자금 모으기');
  const [target, setTarget] = useState(state.profile.goalAmount || 600000);
  const [amount, setAmount] = useState(() => numberOf(params.get('amount') || '100000') || 100000);
  const [years, setYears] = useState(1);
  const [ran, setRan] = useState(false);
  const bp = beforePayday(state);
  const opts = state.simSettings;
  const risk = opts.risk;

  const paths = useMemo(() => {
    const results = worldAssets(amount, years, opts) as Record<PathId, number>;
    return PATHS.map((p) => {
      const out = worldOutflow(p.id, amount, years, opts) as number;
      const immediate = impactOf(out, state);
      const future = p.id === 3 ? futurePurchaseImpact(amount, opts.delayMonths, state) : null;
      const valid = immediate.spendable >= 0 && !immediate.risk && !future?.risk;
      const reason = !valid
        ? immediate.spendable < 0
          ? `현재 조건에서 최소 잔액과 필수결제 이후 ${won(-immediate.spendable)} 부족`
          : future?.risk
            ? `${md(future.risk.date)}에 잔액 부족 가능`
            : `${immediate.risk ? md(immediate.risk.date) : '결제일'}에 잔액 부족 가능`
        : p.id === 3
          ? `${future ? md(future.date) : '예정일'}에 구매 · 현재 현금 보존`
          : p.id === 2 ? '즉시 출금 없이 현금을 유지'
          : '등록된 필수결제와 최소 잔액 조건 충족';
      return { ...p, value: results[p.id], cash: immediate.spendable, valid, reason, meetsTarget: results[p.id] >= target, progress: target > 0 ? Math.min(999, Math.round((Math.max(0, results[p.id]) / target) * 100)) : 0 };
    });
  }, [amount, years, opts, state, target]);

  const order: Record<typeof risk, PathId[]> = {
    stable: [2, 3, 4, 6, 1, 5],
    balanced: [6, 4, 2, 3, 5, 1],
    active: [6, 5, 4, 2, 3, 1],
  };
  const candidates = paths.filter((p) => p.valid).sort((a, b) => Number(b.meetsTarget) - Number(a.meetsTarget) || order[risk].indexOf(a.id) - order[risk].indexOf(b.id)).slice(0, 3);
  const excluded = paths.filter((p) => !p.valid);
  const evaluate = () => {
    if (!goal.trim() || amount < 1000 || target < 1000) { toast('목표와 실험 금액을 확인해 주세요', 'error'); return; }
    setState((s) => ({ profile: { ...s.profile, goal: goal.trim(), goalAmount: target } }));
    setRan(true);
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-12">
      <PageHeader title="내 조건으로 경로 탐색" right={<button type="button" onClick={() => navigate('/bills')} className="text-[12px] font-bold text-toss-blue">잔액 수정</button>} />
      <div className="px-4 pt-4 space-y-3.5">
        <div className="px-1">
          <h1 className="text-[22px] font-extrabold text-toss-gray900 leading-snug">내 목표를 지키면서<br />어떤 선택을 할 수 있을까?</h1>
          <p className="mt-1.5 text-[12.5px] text-toss-gray500 leading-relaxed">백엔드 연결 전에는 AI Agent가 아닌, 프론트 규칙과 금융 계산으로 조건을 비교해요.</p>
        </div>
        <Card>
          <SectionTitle>나의 목표와 실험 조건</SectionTitle>
          <div className="space-y-3">
            <label className="block"><span className="text-[12px] font-bold text-toss-gray600">금융 목표</span>
              <input value={goal} onChange={(e) => { setGoal(e.target.value); setRan(false); }} maxLength={60} className="mt-1 w-full rounded-xl bg-toss-gray50 border border-toss-gray100 px-3.5 py-3 text-[14px] outline-none focus:border-toss-blue" placeholder="예: 월세를 지키면서 여행 자금 모으기" /></label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block"><span className="text-[12px] font-bold text-toss-gray600">목표 금액</span>
                <input inputMode="numeric" value={target ? target.toLocaleString('ko-KR') : ''} onChange={(e) => { setTarget(numberOf(e.target.value)); setRan(false); }} className="mt-1 w-full rounded-xl bg-toss-gray50 border border-toss-gray100 px-3 py-3 text-[14px] font-bold outline-none focus:border-toss-blue" aria-label="목표 금액" /></label>
              <label className="block"><span className="text-[12px] font-bold text-toss-gray600">비교할 금액</span>
                <input inputMode="numeric" value={amount ? amount.toLocaleString('ko-KR') : ''} onChange={(e) => { setAmount(numberOf(e.target.value)); setRan(false); }} className="mt-1 w-full rounded-xl bg-toss-gray50 border border-toss-gray100 px-3 py-3 text-[14px] font-bold outline-none focus:border-toss-blue" aria-label="비교 금액" /></label>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[12px] font-bold text-toss-gray600">미래 비교 기간</span>
              <div className="flex gap-1.5">{[1, 3, 5].map((y) => <button type="button" key={y} onClick={() => { setYears(y); setRan(false); }} className={`px-3 py-1.5 rounded-lg text-[12px] font-bold ${years === y ? 'bg-toss-blue text-white' : 'bg-toss-gray100 text-toss-gray600'}`}>{y}년</button>)}</div>
            </div>
            <div className="rounded-xl bg-[#F2F6FC] px-3.5 py-3 text-[12px] text-toss-gray600 space-y-1">
              <p>생활비 통장 <b>{won(bp.balance)}</b> · 최소 잔액 <b>{won(bp.minBalance)}</b></p>
              <p>다음 월급 전 필수결제 <b>{won(bp.essential)}</b> · 현재 여유 <b>{won(bp.spendable)}</b></p>
              <p>위험 선호 <b>{risk === 'stable' ? '안정추구형' : risk === 'balanced' ? '위험중립형' : '적극투자형'}</b> <button onClick={() => navigate('/more')} className="text-toss-blue underline ml-1">변경</button></p>
            </div>
            <PrimaryButton onClick={evaluate}>조건에 맞는 경로 비교하기</PrimaryButton>
          </div>
        </Card>

        {ran && <>
          <Card>
            <SectionTitle action={<span className="text-[11px] font-bold text-emerald-600">금융 규칙 검증</span>}>조건을 통과한 경로 {candidates.length}개</SectionTitle>
            <p className="text-[12px] text-toss-gray500 mb-3">필수결제·최소 잔액을 먼저 검증하고, 입력한 목표 금액의 달성 가능성과 위험 선호를 함께 비교했어요. 수익률은 가정이에요.</p>
            {candidates.length ? <div className="space-y-2.5">{candidates.map((p, i) => <div key={p.id} className="rounded-2xl bg-toss-gray50 p-4 border border-transparent">
              <div className="flex items-center gap-2"><span className="w-7 h-7 rounded-full bg-white text-toss-blue text-[12px] font-extrabold flex items-center justify-center">{i + 1}</span><Icon name={p.icon} className="text-toss-gray700"/><b className="text-[14px] text-toss-gray900">{p.name}</b></div>
              <p className="text-[12px] text-toss-gray500 mt-1">{p.summary}</p>
              <div className="grid grid-cols-2 gap-2 mt-3"><div><span className="block text-[11px] text-toss-gray500">{years}년 후 가정금액</span><b className="text-[15px] text-toss-gray900">{won(p.value)}</b></div><div><span className="block text-[11px] text-toss-gray500">오늘 쓸 수 있는 여유</span><b className="text-[15px] text-emerald-600">{won(p.cash)}</b></div></div>
              <p className={`text-[11px] mt-2 font-semibold ${p.meetsTarget ? 'text-emerald-600' : 'text-amber-700'}`}>목표 {won(target)} 대비 {p.progress}% · {p.meetsTarget ? '목표 금액 충족 가정' : '목표 금액 미달 가정'}</p>
              <p className="text-[11px] text-toss-gray600 mt-2"><Icon name="check_circle" className="text-[13px] align-middle text-emerald-500" /> {p.reason}</p>
            </div>)}</div> : <p className="text-[13px] text-rose-600 py-3">현재 입력 조건을 만족하는 경로가 없어요. 필수결제·실험 금액·최소 잔액을 조정해 다시 비교해 주세요.</p>}
          </Card>
          {excluded.length > 0 && <Card>
            <SectionTitle>조건에서 제외된 경로</SectionTitle>
            <div className="space-y-2">{excluded.map((p) => <div key={p.id} className="rounded-xl border border-rose-100 bg-rose-50/60 px-3 py-2.5"><p className="text-[13px] font-bold text-toss-gray700">{p.name}</p><p className="text-[11.5px] text-rose-600 mt-1">{p.reason}</p></div>)}</div>
          </Card>}
          <Card>
            <SectionTitle>이 분석의 근거</SectionTitle>
            <p className="text-[12px] text-toss-gray600 leading-relaxed">입력 목표 금액·기간 → 현재 잔액·월급·필수결제 조회 → 소비·현금·적금·투자·혼합의 6개 경로 계산 → 최소 잔액 검증 → 목표 달성 가정과 위험 선호 순으로 최대 3개 제시. 목표가 충족된다고 실제 달성이 보장되는 것은 아니에요.</p>
            <p className="text-[11px] text-amber-700 bg-amber-50 p-3 rounded-xl mt-3 leading-relaxed">실제 AI 모델·ML 예측·외부 시장 데이터는 아직 호출하지 않아요. 적금 연 {opts.saveRate}%, 투자 연 {opts.investRate}%는 가정이며 변동 지출·세금·실제 카드 청구 확정액은 완전히 반영되지 않았어요.</p>
          </Card>
          <PrimaryButton onClick={() => navigate(`/world/explore?view=B&amount=${amount}&title=${encodeURIComponent(goal)}`)}>6개 평행세계로 자세히 비교</PrimaryButton>
        </>}
      </div>
    </div>
  );
}
