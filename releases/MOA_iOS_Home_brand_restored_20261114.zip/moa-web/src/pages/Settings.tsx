import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BottomSheet, Card, Icon, ListRow, PageHeader, PrimaryButton, Toggle } from '../components/ui';
import { TX_LABEL, APP_TODAY, getState, setState, useStore, resetDemoData } from '../lib/store';
import { useApp } from '../lib/app';

export default function Settings() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const profile = useStore((s) => s.profile);
  const settings = useStore((s) => s.settings);
  const set = (k: string, v: boolean) => setState((s) => ({ settings: { ...s.settings, [k]: v } }));
  const la = useStore((s) => s.learnAlert);
  const setLa = (p: Partial<typeof la>) => setState((s) => ({ learnAlert: { ...s.learnAlert, ...p } }));
  const [consentOpen, setConsentOpen] = useState(false);
  const TIMES = ['08:00', '12:30', '21:00'];
  const TOPICS = ['오늘의 학습', '복습할 문제', '가상 거래 체결', '결제일 알림'];

  const exportCsv = () => {
    const mine = [...getState().txs].sort((a, b) => a.date.localeCompare(b.date)).map((t) => [t.date, t.title, `${TX_LABEL[t.type]}·${t.category}`, String(t.type === 'income' ? t.amount : -t.amount), t.sample ? '시연 예시' : '직접 입력']);
    const rows = [['날짜', '내용', '카테고리', '금액', '데이터 구분'], ...mine];
    const cell = (v: string) => `"${String(v).replace(/"/g, '""')}"`;
    const blob = new Blob(['\uFEFF' + rows.map((r) => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = `moa-가계부-${APP_TODAY.slice(0,7)}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    toast('가계부를 CSV로 내보냈어요', 'download');
  };

  const restartOnboarding = () => {
    setState({ onboarded: false });
    navigate('/onboarding', { replace: true });
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-12">
      <PageHeader title="설정" />
      <div className="px-4 pt-3 space-y-3.5">
        <Card className="flex items-center gap-4">
          <span className="w-14 h-14 rounded-full bg-gradient-to-br from-toss-blue to-indigo-500 text-white text-[22px] font-extrabold flex items-center justify-center">{profile.name.slice(0, 1)}</span>
          <div className="flex-1">
            <p className="text-[17px] font-bold text-toss-gray900">{profile.name} 님</p>
            <p className="text-[12px] text-toss-gray500 mt-0.5">월급일 매월 {profile.payday}일 · 월 예산 {profile.monthlyBudget.toLocaleString('ko-KR')}원</p>
          </div>
          <button type="button" onClick={() => navigate('/budget')} className="text-[12px] font-bold text-toss-blue bg-toss-lightBlue px-3 py-1.5 rounded-full">수정</button>
        </Card>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden">
          <h2 className="px-5 pt-4 pb-1 text-[13px] font-bold text-toss-gray500">연결</h2>
          <ListRow icon={<Icon name="account_balance" className="text-toss-blue" />} iconBg="bg-toss-lightBlue" title="생활비 통장" sub={profile.bank ? `${profile.bank} 선택됨 · 자동 연결 준비 중` : '은행 선택 전 · 직접 기록으로 관리 중'} onClick={() => toast('자동 연결이 열리면 알림으로 알려드릴게요', 'info')} />
          <ListRow icon={<Icon name="credit_card" className="text-violet-500" />} iconBg="bg-violet-50" title="체크카드" sub="자동 연결 준비 중 · 직접 기록으로 관리 중" onClick={() => toast('자동 연결이 열리면 알림으로 알려드릴게요', 'info')} />
          <ListRow icon={<Icon name="event_repeat" className="text-amber-500" />} iconBg="bg-amber-50" title="잔액·필수 결제 관리" sub="월세·카드값·최소 잔액" onClick={() => navigate('/bills')} />
        </section>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden">
          <h2 className="px-5 pt-4 pb-1 text-[13px] font-bold text-toss-gray500">알림</h2>
          <ListRow icon={<Icon name="notifications_active" className="text-rose-500" />} iconBg="bg-rose-50" title="푸시 알림" right={<Toggle label="푸시 알림" checked={settings.push} onChange={(v) => set('push', v)} />} />
          <ListRow icon={<Icon name="event_upcoming" className="text-amber-500" />} iconBg="bg-amber-50" title="결제일 부족 경고" sub="결제 3일 전에 알려드려요" right={<Toggle label="결제일 부족 경고" checked={settings.payAlert} onChange={(v) => set('payAlert', v)} />} />
          <ListRow icon={<Icon name="wb_sunny" className="text-orange-500" />} iconBg="bg-orange-50" title="모닝 브리핑" sub="알림 시간은 아래 학습 알림 설정과 별도로 표시돼요" right={<Toggle label="모닝 브리핑" checked={settings.aiBrief} onChange={(v) => set('aiBrief', v)} />} />
          <ListRow icon={<Icon name="campaign" className="text-toss-gray600" />} title="혜택·이벤트 알림" right={<Toggle label="혜택 알림" checked={settings.marketing} onChange={(v) => set('marketing', v)} />} />
        </section>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden">
          <h2 className="px-5 pt-4 pb-1 text-[13px] font-bold text-toss-gray500">학습 알림</h2>
          <ListRow icon={<Icon name="school" className="text-toss-blue" />} iconBg="bg-toss-lightBlue" title="오늘의 학습 알림" sub={la.on ? `매일 ${la.time}` : '꺼짐'} right={<Toggle label="오늘의 학습 알림" checked={la.on} onChange={(v) => setLa({ on: v })} />} />
          {la.on && (
            <div className="px-5 pb-4 space-y-3">
              <div>
                <p className="text-[12px] font-semibold text-toss-gray500 mb-1.5">받는 시간</p>
                <div className="flex gap-1.5">{TIMES.map((t) => <button key={t} type="button" onClick={() => setLa({ time: t })} className={`px-3 py-1.5 rounded-full text-[12px] font-bold ${la.time === t ? 'bg-toss-blue text-white' : 'bg-toss-gray100 text-toss-gray600'}`}>{t}</button>)}</div>
              </div>
              <div>
                <p className="text-[12px] font-semibold text-toss-gray500 mb-1.5">받을 내용</p>
                <div className="flex flex-wrap gap-1.5">{TOPICS.map((t) => { const on = la.topics.includes(t); return <button key={t} type="button" aria-pressed={on} onClick={() => setLa({ topics: on ? la.topics.filter((x) => x !== t) : [...la.topics, t] })} className={`px-3 py-1.5 rounded-full text-[12px] font-bold ${on ? 'bg-toss-gray900 text-white' : 'bg-toss-gray100 text-toss-gray600'}`}>{t}</button>; })}</div>
              </div>
              <div className="flex items-center justify-between rounded-2xl bg-[#EEF0FF] p-3.5">
                <div>
                  <p className="text-[13px] font-bold text-[#4752C4]">Discord로도 받기</p>
                  <p className="text-[11px] text-toss-gray600 mt-0.5">{la.discord ? '동의 완료 · 연동되면 이 설정대로 보내드려요' : '학습 카드와 복습 알림을 Discord로 받아요'}</p>
                </div>
                <Toggle label="Discord로도 받기" checked={la.discord} onChange={(v) => (v && !la.discordConsent ? setConsentOpen(true) : setLa({ discord: v }))} />
              </div>
            </div>
          )}
        </section>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden">
          <h2 className="px-5 pt-4 pb-1 text-[13px] font-bold text-toss-gray500">보안 · 데이터</h2>
          <ListRow icon={<Icon name="lock" className="text-emerald-600" />} iconBg="bg-emerald-50" title="앱 잠금" sub="UI 설정 시연 · 실제 기기 잠금 미연결" right={<Toggle label="앱 잠금" checked={settings.lock} onChange={(v) => set('lock', v)} />} />
          <ListRow icon={<Icon name="download" className="text-toss-blue" />} iconBg="bg-toss-lightBlue" title="가계부 내보내기" sub="CSV 파일로 저장" onClick={exportCsv} />
        </section>

        <section className="bg-white rounded-[24px] shadow-card overflow-hidden">
          <ListRow icon={<Icon name="help" className="text-toss-gray600" />} title="고객센터 · 약관" onClick={() => navigate('/support')} />
          <ListRow icon={<Icon name="info" className="text-toss-gray600" />} title="앱 버전" right={<span className="text-[13px] text-toss-gray500">0.1.0 (프론트 시연)</span>} />
        </section>

        <BottomSheet open={consentOpen} onClose={() => setConsentOpen(false)} title="Discord 알림 동의">
          <div className="space-y-3 text-[13px] text-toss-gray700 leading-relaxed">
            <p>Discord로 보내는 내용은 아래로 한정돼요.</p>
            <ul className="rounded-2xl bg-toss-gray50 p-4 space-y-1.5 text-[12.5px]">
              <li>· 오늘의 학습 카드 제목과 바로가기</li>
              <li>· 복습할 퀴즈 개수</li>
              <li>· 선택한 경우 가상 거래 체결·결제일 알림</li>
            </ul>
            <p className="text-[12px] text-toss-gray500">잔액·거래 내역 같은 금융 정보 원문은 보내지 않아요. 언제든 끌 수 있어요.</p>
            <PrimaryButton onClick={() => { setLa({ discord: true, discordConsent: true }); setConsentOpen(false); toast('Discord 알림에 동의했어요'); }}>동의하고 켜기</PrimaryButton>
          </div>
        </BottomSheet>

        <div className="flex justify-center gap-5 pt-2 text-[13px] text-toss-gray500">
          <button type="button" onClick={restartOnboarding}>온보딩 다시 보기</button>
          <span className="text-toss-gray300">|</span>
          <button type="button" onClick={() => { if (window.confirm('이 브라우저에 저장된 모든 MOA 시연 기록을 초기화할까요? 복구할 수 없어요.')) { resetDemoData(); navigate('/onboarding', { replace: true }); } }} className="text-rose-500">시연 데이터 초기화</button>
        </div>
      </div>
    </div>
  );
}
