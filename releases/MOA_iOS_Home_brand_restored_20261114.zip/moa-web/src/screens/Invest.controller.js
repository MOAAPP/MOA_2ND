/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s06. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  let defenseMoney = 518000;
  let totalAsset = 138000;
  let currentStock = {
    name: "TIGER 미국S&P500",
    price: 62100,
    shares: 1.45,
    rate: "+1.8%",
    profit: 4810
  };
  let currentOrderMode = 'buy'; // 'buy' or 'sell'
  let orderShares = 1;
  let orderType = 'market';

  // 종목 탭 필터
  function changeMarketTab(tab, btn) {
    const buttons = document.querySelectorAll('.market-tab-btn');
    buttons.forEach(b => {
      b.className = 'market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all';
    });
    btn.className = 'market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-white shrink-0 shadow-sm transition-all';

    const cards = document.querySelectorAll('.stock-card');
    cards.forEach(c => {
      const cats = c.getAttribute('data-category').split(',');
      if (tab === 'all' || cats.includes(tab)) {
        c.style.display = 'block';
      } else {
        c.style.display = 'none';
      }
    });
  }

  // 주문 모달 열기
  function openOrderModal(name, price, shares, rate, profit, mode) {
    currentStock = { name, price, shares, rate, profit };
    orderShares = 1;
    currentOrderMode = mode || 'buy';

    document.getElementById('modal-stock-name').innerText = name;
    document.getElementById('modal-stock-price').innerText = price.toLocaleString('ko-KR');
    document.getElementById('modal-user-shares').innerText = shares + '주';
    document.getElementById('modal-stock-rate').innerText = rate;

    // 호가창 가격 시뮬레이션
    document.getElementById('hoga-current').innerText = price.toLocaleString('ko-KR');
    document.getElementById('hoga-ask-1').innerText = (price + 100).toLocaleString('ko-KR');
    document.getElementById('hoga-ask-2').innerText = (price + 200).toLocaleString('ko-KR');
    document.getElementById('hoga-bid-1').innerText = (price - 100).toLocaleString('ko-KR');
    document.getElementById('hoga-bid-2').innerText = (price - 200).toLocaleString('ko-KR');

    setOrderMode(currentOrderMode);

    const backdrop = document.getElementById('order-modal-backdrop');
    const content = document.getElementById('order-modal-content');
    backdrop.classList.remove('opacity-0', 'pointer-events-none');
    backdrop.classList.add('opacity-100');
    content.classList.remove('translate-y-full');
    content.classList.add('translate-y-0');
    document.body.style.overflow = 'hidden';
  }

  function closeOrderModal() {
    const backdrop = document.getElementById('order-modal-backdrop');
    const content = document.getElementById('order-modal-content');
    backdrop.classList.remove('opacity-100');
    backdrop.classList.add('opacity-0', 'pointer-events-none');
    content.classList.remove('translate-y-0');
    content.classList.add('translate-y-full');
    document.body.style.overflow = '';
  }

  function handleBackdropClick(e) {
    if (e.target === document.getElementById('order-modal-backdrop')) {
      closeOrderModal();
    }
  }

  // 매수 / 매도 토글
  function setOrderMode(mode) {
    currentOrderMode = mode;
    const btnBuy = document.getElementById('btn-tab-buy');
    const btnSell = document.getElementById('btn-tab-sell');
    const submitBtn = document.getElementById('btn-submit-order');

    if (mode === 'buy') {
      btnBuy.className = 'py-2.5 rounded-xl font-extrabold text-sm transition-all bg-rose-500 text-white shadow-sm';
      btnSell.className = 'py-2.5 rounded-xl font-extrabold text-sm transition-all text-slate-600 hover:text-slate-900';
      submitBtn.className = 'w-full py-4 rounded-2xl text-white font-extrabold text-[15px] shadow-floating transition-all active:scale-[0.98] bg-rose-500 hover:bg-rose-600';
      
      const maxSharesBuy = Math.floor(defenseMoney / currentStock.price);
      document.getElementById('max-possible-shares').innerText = `${maxSharesBuy}주`;
      document.getElementById('order-unit-desc').innerHTML = `매수 가능: <b class="text-slate-800">${maxSharesBuy}주</b>`;
    } else {
      btnSell.className = 'py-2.5 rounded-xl font-extrabold text-sm transition-all bg-blue-600 text-white shadow-sm';
      btnBuy.className = 'py-2.5 rounded-xl font-extrabold text-sm transition-all text-slate-600 hover:text-slate-900';
      submitBtn.className = 'w-full py-4 rounded-2xl text-white font-extrabold text-[15px] shadow-floating transition-all active:scale-[0.98] bg-blue-600 hover:bg-blue-700';
      
      const maxSharesSell = Math.floor(currentStock.shares);
      document.getElementById('max-possible-shares').innerText = `${maxSharesSell}주`;
      document.getElementById('order-unit-desc').innerHTML = `매도 가능: <b class="text-slate-800">${currentStock.shares}주</b>`;
    }
    updateOrderSummary();
  }

  function setOrderType(type) {
    orderType = type;
    const btnMarket = document.getElementById('btn-type-market');
    const btnLimit = document.getElementById('btn-type-limit');
    if (type === 'market') {
      btnMarket.className = 'px-2.5 py-1 rounded-md bg-white text-slate-900 shadow-xs';
      btnLimit.className = 'px-2.5 py-1 rounded-md text-slate-500';
      showToast('시장가: 현재 가장 유리한 호가로 즉시 체결됩니다.');
    } else {
      btnLimit.className = 'px-2.5 py-1 rounded-md bg-white text-slate-900 shadow-xs';
      btnMarket.className = 'px-2.5 py-1 rounded-md text-slate-500';
      showToast('지정가: 설정 호가 도달 시 체결 대기됩니다.');
    }
  }

  function adjustShares(delta) {
    const nextVal = orderShares + delta;
    if (nextVal < 1) return;
    orderShares = nextVal;
    updateOrderSummary();
  }

  function setShareRatio(ratio) {
    if (currentOrderMode === 'buy') {
      const maxSharesBuy = Math.floor(defenseMoney / currentStock.price);
      orderShares = Math.max(1, Math.floor(maxSharesBuy * ratio));
    } else {
      orderShares = Math.max(1, Math.floor(currentStock.shares * ratio));
    }
    updateOrderSummary();
  }

  function updateOrderSummary() {
    document.getElementById('input-shares').innerText = orderShares;
    const totalOrderCost = currentStock.price * orderShares;
    document.getElementById('order-total-price').innerText = totalOrderCost.toLocaleString('ko-KR');

    const submitBtn = document.getElementById('btn-submit-order');
    if (currentOrderMode === 'buy') {
      const afterMoney = Math.max(0, defenseMoney - totalOrderCost);
      document.getElementById('after-order-money').innerText = afterMoney.toLocaleString('ko-KR') + '원';
      submitBtn.innerText = `방어 머니로 ${totalOrderCost.toLocaleString('ko-KR')}원 가상 매수하기`;
    } else {
      const afterMoney = defenseMoney + totalOrderCost;
      document.getElementById('after-order-money').innerText = afterMoney.toLocaleString('ko-KR') + '원 (회수 입금)';
      submitBtn.innerText = `${orderShares}주 가상 매도하여 방어 머니로 회수하기`;
    }
  }

  function submitVirtualOrder() {
    const totalOrderCost = currentStock.price * orderShares;

    if (currentOrderMode === 'buy') {
      if (defenseMoney < totalOrderCost) {
        showToast('주문 가능 방어 머니가 부족합니다.');
        return;
      }
      defenseMoney -= totalOrderCost;
      totalAsset += totalOrderCost;
      currentStock.shares = (parseFloat(currentStock.shares) + orderShares).toFixed(2);
      showToast(`[가상 체결 완료] ${currentStock.name} ${orderShares}주 매수 완료!`);
    } else {
      defenseMoney += totalOrderCost;
      totalAsset = Math.max(0, totalAsset - totalOrderCost);
      currentStock.shares = Math.max(0, (parseFloat(currentStock.shares) - orderShares)).toFixed(2);
      showToast(`[가상 체결 완료] ${currentStock.name} ${orderShares}주 매도 회수 완료!`);
    }

    // 화면 데이터 실시간 갱신
    document.getElementById('available-defense-money').innerText = defenseMoney.toLocaleString('ko-KR');
    document.getElementById('user-total-asset').innerText = totalAsset.toLocaleString('ko-KR');

    closeOrderModal();
  }

  // 실시간 체결 티커 문구 주기적 롤링 시뮬레이션
  const tickers = [
    '<b class="text-slate-900">시연 예시</b> · <b>TIGER 미국S&P500</b> 2주 매수 체결',
    '<b class="text-slate-900">시연 예시</b> · <b>MOA 평행 우주·AI</b> 1주 매수 체결',
    '<b class="text-slate-900">시연 예시</b> · <b>ACE 미국나스닥100</b> 1주 매수 체결',
    '<b class="text-slate-900">시연 예시</b> · <b>SOL 한국고배당</b> 3주 매도 체결',
    '<b class="text-slate-900">시연 예시</b> · 방어머니로 <b>S&P500</b> 1주 모으기 성공'
  ];
  let tickerIdx = 0;
  setInterval(() => {
    tickerIdx = (tickerIdx + 1) % tickers.length;
    const tickerEl = document.getElementById('ticker-live-text');
    if (tickerEl) {
      tickerEl.innerHTML = tickers[tickerIdx];
    }
  }, 3200);

  // 토스트 메시지 함수
  let toastTimer = null;
  function showToast(message) {
    const toast = document.getElementById('share-toast');
    const toastText = document.getElementById('share-toast-text');
    if (!toast) return;

    if (toastText && message) {
      toastText.innerText = message;
    }

    if (toastTimer) clearTimeout(toastTimer);

    toast.classList.remove('opacity-0', 'pointer-events-none');
    toast.classList.add('opacity-100');

    toastTimer = setTimeout(() => {
      toast.classList.remove('opacity-100');
      toast.classList.add('opacity-0', 'pointer-events-none');
    }, 2400);
  }


/* ---- */


  function switchModalTab(tabKey) {
    const tabs = ['hoga', 'chart', 'history', 'info'];
    tabs.forEach(t => {
      const view = document.getElementById('view-' + t);
      const btn = document.getElementById('tab-btn-' + t);
      if (view) {
        if (t === tabKey) {
          view.classList.remove('hidden');
        } else {
          view.classList.add('hidden');
        }
      }
      if (btn) {
        if (t === tabKey) {
          btn.className = 'pb-2 border-b-2 border-slate-900 text-slate-900 transition-colors modal-sub-tab font-bold';
        } else {
          btn.className = 'pb-2 border-b-2 border-transparent text-slate-400 hover:text-slate-700 transition-colors modal-sub-tab';
        }
      }
    });
  }

  function executeOrderQuick(mode) {
    currentOrderMode = mode;
    submitVirtualOrder();
  }


/* ---- */


  function switchModalTab(tabKey) {
    const tabs = ['orderbook', 'chart', 'history', 'info'];
    tabs.forEach(t => {
      const view = document.getElementById('tab-content-' + t);
      const btn = document.getElementById('tab-btn-' + t);
      if (view) {
        if (t === tabKey) {
          view.style.display = 'block';
          view.classList.remove('hidden');
        } else {
          view.style.display = 'none';
          view.classList.add('hidden');
        }
      }
      if (btn) {
        if (t === tabKey) {
          btn.className = 'pb-2 border-b-2 border-blue-600 text-blue-600 font-bold transition-colors modal-sub-tab';
        } else {
          btn.className = 'pb-2 border-b-2 border-transparent text-slate-400 hover:text-slate-700 transition-colors modal-sub-tab';
        }
      }
    });
  }

  function closeCompleteModal() {
    const modal = document.getElementById('order-complete-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.style.display = 'none';
    }
  }

  function openCompleteModal(stockName, shares, price, mode) {
    const modal = document.getElementById('order-complete-modal');
    if (!modal) return;
    const completeTitle = document.getElementById('complete-title');
    const completeSub = document.getElementById('complete-subtitle');
    const completeShares = document.getElementById('complete-shares');
    const completeAmount = document.getElementById('complete-amount');
    
    if (completeTitle) completeTitle.innerHTML = `${shares}주 ${mode === 'buy' ? '매수' : '매도'} 주문이<br/>체결되었어요!`;
    if (completeSub) completeSub.innerText = `${stockName || 'TIGER 미국S&P500'} · 체결가 ${(price || 62100).toLocaleString('ko-KR')}원`;
    if (completeShares) completeShares.innerText = `${shares}주`;
    if (completeAmount) completeAmount.innerText = `${((price || 62100) * shares).toLocaleString('ko-KR')}원`;
    
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
  }

  function goToExecutionHistory() {
    closeCompleteModal();
    switchModalTab('history');
    showToast('체결 내역으로 이동했습니다.');
  }

  function filterHistory(filterType, btn) {
    const btnAll = document.getElementById('history-filter-all');
    const btnMy = document.getElementById('history-filter-my');
    if (btnAll && btnMy) {
      btnAll.className = 'px-3 py-1 rounded-full text-xs font-medium bg-white text-slate-600 border border-slate-200/70 hover:text-slate-900';
      btnMy.className = 'px-3 py-1 rounded-full text-xs font-medium bg-white text-slate-600 border border-slate-200/70 hover:text-slate-900';
    }
    if (btn) {
      btn.className = 'px-3 py-1 rounded-full text-xs font-bold bg-slate-900 text-white shadow-xs';
    }
    const marketRows = document.querySelectorAll('.history-market');
    marketRows.forEach(row => {
      if (filterType === 'my') {
        row.style.display = 'none';
      } else {
        row.style.display = 'flex';
      }
    });
  }

  // executeOrderQuick 오버라이드: 체결 팝업 표시
  window.executeOrderQuick = function(mode) {
    currentOrderMode = mode;
    openCompleteModal(currentStock.name, orderShares, currentStock.price, mode);
  };


  // MOA: 보유 수량·방어 머니·주문 내역을 공통 상태로 관리 (src/lib/bridge.js investBridge)
  const __inv = app.moa.investBridge({
    document, app, root, setInterval,
    get: { order: () => ({ mode: currentOrderMode, shares: orderShares, type: orderType }), stock: () => currentStock },
    set: { cash: (v) => { defenseMoney = v; }, mode: (m) => { currentOrderMode = m; } },
    orig: { openOrderModal, updateOrderSummary, setOrderType, closeOrderModal, openCompleteModal, showToast },
  });
  openOrderModal = __inv.api.openOrderModal; updateOrderSummary = __inv.api.updateOrderSummary; setOrderType = __inv.api.setOrderType;
  submitVirtualOrder = __inv.api.submitVirtualOrder; executeOrderQuick = __inv.api.executeOrderQuick;
  function openStockSearch() { __inv.api.openStockSearch(); }
  const __goToExecutionHistory = goToExecutionHistory;
  goToExecutionHistory = function () {
    __goToExecutionHistory();
    const b = document.getElementById('order-modal-backdrop'), ct = document.getElementById('order-modal-content');
    b.classList.remove('opacity-0', 'pointer-events-none'); b.classList.add('opacity-100');
    ct.classList.remove('translate-y-full'); ct.classList.add('translate-y-0');
  };
  try { delete globalThis.window.executeOrderQuick; } catch (e) {}
  document.addEventListener('DOMContentLoaded', () => __inv.init());

  const api = {};
  if (typeof changeMarketTab === 'function') api.changeMarketTab = changeMarketTab;
  if (typeof openOrderModal === 'function') api.openOrderModal = openOrderModal;
  if (typeof closeOrderModal === 'function') api.closeOrderModal = closeOrderModal;
  if (typeof handleBackdropClick === 'function') api.handleBackdropClick = handleBackdropClick;
  if (typeof setOrderMode === 'function') api.setOrderMode = setOrderMode;
  if (typeof setOrderType === 'function') api.setOrderType = setOrderType;
  if (typeof adjustShares === 'function') api.adjustShares = adjustShares;
  if (typeof setShareRatio === 'function') api.setShareRatio = setShareRatio;
  if (typeof updateOrderSummary === 'function') api.updateOrderSummary = updateOrderSummary;
  if (typeof submitVirtualOrder === 'function') api.submitVirtualOrder = submitVirtualOrder;
  if (typeof showToast === 'function') api.showToast = showToast;
  if (typeof switchModalTab === 'function') api.switchModalTab = switchModalTab;
  if (typeof executeOrderQuick === 'function') api.executeOrderQuick = executeOrderQuick;
  if (typeof closeCompleteModal === 'function') api.closeCompleteModal = closeCompleteModal;
  if (typeof openCompleteModal === 'function') api.openCompleteModal = openCompleteModal;
  if (typeof goToExecutionHistory === 'function') api.goToExecutionHistory = goToExecutionHistory;
  if (typeof filterHistory === 'function') api.filterHistory = filterHistory;
  if (typeof openStockSearch === 'function') api.openStockSearch = openStockSearch;
  return { api, cleanup };
}
