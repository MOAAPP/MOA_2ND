/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s07 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './World.controller';
import './World.css';

import WorldTwinScene from '../three/WorldTwinScene';

import AppHeader from '../components/AppHeader';

function WorldScreen() {
  const navigate = useNavigate();
  const { rootRef, run } = useLegacyScreen(mount, {});
  return (
    <div ref={rootRef} className="stitch-screen scr-world flex justify-center items-center min-h-full p-0">
{/* Mobile Container (390px Viewport Shell) */}
<div className="relative w-full max-w-[390px] h-full bg-[#F2F4F6] flex flex-col min-h-full overflow-hidden">
{/* BEGIN: TopHeader */}
<AppHeader profileTo="/more" />
{/* END: TopHeader */}
<div className="bg-white px-4 py-2 border-b border-blue-100 flex items-center justify-between">
  <button type="button" onClick={() => navigate('/world')} className="text-[12px] font-bold text-[#3182F6]">‹ 구매 vs 미구매 비교로</button>
  <span className="text-[10px] text-[#8B95A1]">6가지 세계 · 심화 탐험</span>
</div>
{/* BEGIN: Sub-Navigation Tabs (5 Interactive Modules) */}
<nav className="sticky top-[57px] z-20 bg-white border-b border-[#E5E8EB] px-3 py-2">
<div className="flex items-center space-x-1 overflow-x-auto no-scrollbar" id="nav-tabs-container">
<button className="nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition-all bg-[#3182F6] text-white shadow-sm" id="tab-btn-A" onClick={(event) => run(event, (c) => { c.switchView('A'); })}>
메인 탐험
</button>
{" "}
<button className="nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6B7684] hover:text-[#191F28] hover:bg-slate-100 transition-all" id="tab-btn-B" onClick={(event) => run(event, (c) => { c.switchView('B'); })}>
6개 세계
</button>
{" "}
<button className="nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6B7684] hover:text-[#191F28] hover:bg-slate-100 transition-all" id="tab-btn-C" onClick={(event) => run(event, (c) => { c.switchView('C'); })}>
미래 맞비교
</button>
{" "}
<button className="nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6B7684] hover:text-[#191F28] hover:bg-slate-100 transition-all" id="tab-btn-D" onClick={(event) => run(event, (c) => { c.switchView('D'); })}>
상세 리포트
</button>
{" "}
<button className="nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6B7684] hover:text-[#191F28] hover:bg-slate-100 transition-all" id="tab-btn-E" onClick={(event) => run(event, (c) => { c.switchView('E'); })}>
기록 보관함
</button>
</div>
</nav>
{/* END: Sub-Navigation Tabs */}
{/* BEGIN: Scrollable Dynamic Content Container */}
<main className="flex-1 overflow-y-auto no-scrollbar pb-24 safe-bottom">
{/* ========================================================================= */}
{/* [VIEW A: 평행세계 메인 탐험] */}
{/* ========================================================================= */}
<section className="p-4 space-y-3.5 fade-enter" id="view-A">
{/* 1. 3D Three.js Digital Twin Hero Section */}
<div className="bg-gradient-to-b from-[#f0f7ff] via-white to-[#f8fafc] border border-blue-100/60 rounded-3xl p-5 shadow-sm overflow-hidden relative">
{/* Top FinTech Status Badges */}
<div className="flex items-center justify-between mb-2 relative z-10">
<div className="flex items-center space-x-1.5">
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100/80 text-blue-700">
<span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-1 animate-pulse" />
{" "}Lv.3 오아시스 행성
</span>
</div>
<span className="text-[10px] font-semibold text-[#8B95A1] bg-white/80 border border-slate-200/80 px-2 py-0.5 rounded-full">
연 7.2% 복리 시뮬레이션 가동 중
</span>
</div>
{/* Real 3D Digital Twin Three.js Scene Component */}
<div className="w-full h-[260px] relative flex items-center justify-center">
<div className="w-full h-[260px] relative" style={{ display: "block" }}>
<WorldTwinScene className="w-full h-full" />
</div>
</div>
{/* Bottom Overlay Status Card */}
<div className="mt-2 bg-white/90 backdrop-blur-md rounded-2xl p-3 border border-blue-100/80 flex items-center justify-between shadow-subtle">
<div>
<div className="text-[10px] text-[#8B95A1] font-medium">
소비 방어 누적 자산
</div>
<div className="text-sm font-black text-[#191F28] tracking-tight">
518,000원 방어 완료
</div>
</div>
<div className="text-right">
<span className="text-[10px] text-[#059669] font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
디지털 트윈 동기화
</span>
<div className="text-[11px] font-extrabold text-[#3182F6] mt-0.5">
+555,296원 (1년 예상)
</div>
</div>
</div>
</div>
{/* 2. 오늘 결정 실험실 (의사결정 입력 카드) */}
<div className="bg-white rounded-3xl p-4 border border-[#E5E8EB] shadow-sm">
<div className="flex items-center justify-between mb-2.5">
<span className="text-[11px] font-bold text-[#3182F6] bg-[#E8F3FF] px-2 py-0.5 rounded-md">
오늘의 결정 실험실
</span>
{" "}
<span className="text-[11px] text-[#8B95A1]">
금액 변경 가능
</span>
</div>
<div className="flex items-center space-x-3">
<div className="w-11 h-11 rounded-2xl bg-blue-50 text-[#3182F6] flex items-center justify-center text-xl shrink-0 border border-blue-100/60">
🎧
</div>
<div className="flex-1">
<input className="w-full text-xs font-bold text-[#191F28] border-none p-0 focus:ring-0 bg-transparent placeholder-[#8B95A1]" id="item-title-input" defaultValue="소니 노이즈캔슬링 헤드폰" />
<div className="flex items-baseline space-x-1 mt-0.5">
<span className="text-base font-extrabold text-[#8B95A1]">
₩
</span>
{" "}
<input className="text-xl font-black text-[#191F28] border-none p-0 focus:ring-0 w-36 bg-transparent" id="input-amount" max="10000000" min="1000" onChange={(event) => run(event, (c) => { c.onAmountInput(event.currentTarget.value); })} step="1000" type="number" defaultValue="259000" />
{" "}
<span className="text-xs font-bold text-[#4E5968]">
원
</span>
</div>
</div>
</div>
{/* 빠른 프리셋 칩 */}
<div className="flex items-center space-x-1.5 mt-3 pt-3 border-t border-[#F2F4F6] overflow-x-auto no-scrollbar">
<span className="text-[10px] text-[#8B95A1] font-semibold shrink-0">
빠른 금액:
</span>
{" "}
<button className="text-[11px] font-semibold px-2.5 py-1 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] rounded-xl text-[#4E5968] transition-colors shrink-0" onClick={(event) => run(event, (c) => { c.setBaseAmount(100000); })}>
+10만
</button>
{" "}
<button className="text-[11px] font-bold px-2.5 py-1 bg-[#E8F3FF] text-[#3182F6] border border-blue-200/80 rounded-xl transition-colors shrink-0" onClick={(event) => run(event, (c) => { c.setBaseAmount(259000); })}>
+25.9만
</button>
{" "}
<button className="text-[11px] font-semibold px-2.5 py-1 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] rounded-xl text-[#4E5968] transition-colors shrink-0" onClick={(event) => run(event, (c) => { c.setBaseAmount(500000); })}>
+50만
</button>
{" "}
<button className="text-[11px] font-semibold px-2.5 py-1 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] rounded-xl text-[#4E5968] transition-colors shrink-0" onClick={(event) => run(event, (c) => { c.setBaseAmount(1000000); })}>
+100만
</button>
</div>
</div>
{/* 3. 미래 궤도 분기 (Divergence Path) & 인터랙티브 타임라인 탭 */}
<div className="bg-white rounded-3xl p-4 border border-[#E5E8EB] shadow-sm space-y-3">
<div className="flex items-center justify-between">
<div className="flex items-center space-x-1.5">
<span className="w-2 h-2 rounded-full bg-[#3182F6] animate-pulse" />
<h2 className="text-xs font-bold text-[#191F28]">
미래 궤도 분기 (Divergence)
</h2>
</div>
<span className="text-[10px] text-[#8B95A1] font-medium" id="time-horizon-label">
1년 뒤 기준 시뮬레이션
</span>
</div>
{/* Interactive Time Horizon Selector [1년] [3년] [5년] [10년] */}
<div className="grid grid-cols-4 gap-1.5 bg-[#F2F4F6] p-1 rounded-2xl">
<button className="time-tab py-1.5 rounded-xl text-[11px] font-bold bg-white text-[#3182F6] shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.setTimeHorizonYears(1); })}>
1년
</button>
{" "}
<button className="time-tab py-1.5 rounded-xl text-[11px] font-semibold text-[#6B7684] hover:text-[#191F28] transition-all" onClick={(event) => run(event, (c) => { c.setTimeHorizonYears(3); })}>
3년
</button>
{" "}
<button className="time-tab py-1.5 rounded-xl text-[11px] font-semibold text-[#6B7684] hover:text-[#191F28] transition-all" onClick={(event) => run(event, (c) => { c.setTimeHorizonYears(5); })}>
5년
</button>
{" "}
<button className="time-tab py-1.5 rounded-xl text-[11px] font-semibold text-[#6B7684] hover:text-[#191F28] transition-all" onClick={(event) => run(event, (c) => { c.setTimeHorizonYears(10); })}>
10년
</button>
</div>
{/* A vs B Split Divergence Cards */}
<div className="grid grid-cols-2 gap-2.5 pt-1">
{/* 미래 A: 지금 구매한 나 */}
<div className="bg-[#F9FAFB] rounded-2xl p-3 border border-slate-200/90 flex flex-col justify-between">
<div>
<div className="flex items-center space-x-1.5 mb-1.5">
<span className="w-2 h-2 rounded-full bg-[#F04452]" />
{" "}
<span className="text-[11px] font-bold text-[#4E5968]">
A. 지금 구매한 나
</span>
</div>
<p className="text-xs font-bold text-[#191F28] leading-snug">
즉각적인 소비 효용
</p>
<p className="text-[11px] text-[#6B7684] mt-1 leading-relaxed">
통장 잔액{" "}
<span className="sync-amount-text font-bold text-[#F04452]">
-259,000원
</span>
{" "}차감, 이후 남는 금융 자산은{" "}
<span className="font-bold text-[#191F28]">
0원
</span>
입니다.
</p>
</div>
<div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
<span className="text-[#8B95A1] font-medium" id="label-horizon-a">
1년 뒤 자산
</span>
{" "}
<span className="font-bold text-[#191F28]">
0원
</span>
</div>
</div>
{/* 미래 B: 평행세계에 투자한 나 */}
<div className="bg-[#E8F3FF]/70 rounded-2xl p-3 border border-blue-200/80 flex flex-col justify-between">
<div>
<div className="flex items-center space-x-1.5 mb-1.5">
<span className="w-2 h-2 rounded-full bg-[#3182F6]" />
{" "}
<span className="text-[11px] font-bold text-[#3182F6]">
B. 평행세계 투자
</span>
</div>
<p className="text-xs font-bold text-[#191F28] leading-snug">
기회비용의 완전한 자산화
</p>
<p className="text-[11px] text-[#4E5968] mt-1 leading-relaxed">
원금{" "}
<span className="sync-base-amt font-semibold text-[#191F28]">
259,000원
</span>
{" "}+ 복리 수익{" "}
<span className="sync-interest-gain font-bold text-[#059669]">
+18,648원
</span>
</p>
</div>
<div className="mt-3 pt-2 border-t border-blue-200/70 flex items-center justify-between text-[11px]">
<span className="text-[#3182F6] font-medium" id="label-horizon-b">
1년 뒤 자산
</span>
{" "}
<span className="sync-saved-future font-extrabold text-[#3182F6]">
+277,648원
</span>
</div>
</div>
</div>
{/* 두 세계의 격차 요약 Ribbon */}
<div className="bg-gradient-to-r from-blue-50 to-indigo-50/70 rounded-2xl p-3 border border-blue-100 flex items-center justify-between">
<div className="flex items-center space-x-1.5">
<span className="material-symbols-outlined text-[#3182F6] text-base">
trending_up
</span>
{" "}
<span className="text-xs font-bold text-[#191F28]" id="diff-ribbon-label">
1년 후 예상 자산 격차
</span>
</div>
<div className="text-right">
<span className="text-sm font-black text-[#3182F6] sync-diff-val tracking-tight">
+277,648원
</span>
{" "}
<span className="text-[10px] text-[#059669] font-bold block" id="diff-rate-label">
+7.2% (연 7.2% 가정)
</span>
</div>
</div>
</div>
{/* 핵심 CTA 버튼 (6개 세계 탐험으로 이동) */}
<button className="w-full py-3.5 bg-[#3182F6] hover:bg-blue-600 active:scale-98 text-white font-extrabold rounded-2xl text-xs shadow-floating flex items-center justify-center space-x-2 transition-all" onClick={(event) => run(event, (c) => { c.switchView('B'); })}>
<span>
6개의 미래 세계선 탐험하기
</span>
{" "}
<span className="material-symbols-outlined text-base">
arrow_forward
</span>
</button>
</section>
{/* ========================================================================= */}
{/* [VIEW B: 6개의 세계 탐험 - 포트폴리오 자산 배분] */}
{/* ========================================================================= */}
<section className="p-4 space-y-3 hidden fade-enter" id="view-B">
<div className="flex items-center justify-between">
<div>
<h2 className="text-base font-extrabold text-[#191F28] tracking-tight">
6대 미래 세계선 선택
</h2>
<p className="text-[11px] text-[#8B95A1] mt-0.5">
선택한 세계를 탭하면 금융 디지털 트윈이 즉시 반응합니다.
</p>
</div>
<span className="text-[10px] font-bold text-[#3182F6] bg-[#E8F3FF] px-2 py-1 rounded-full" id="view-b-badge">
WORLD 05 선택됨
</span>
</div>
{/* Selected World Highlight Banner */}
<div className="bg-gradient-to-tr from-[#191F28] via-[#1E293B] to-[#0F172A] rounded-2xl p-4 text-white shadow-md border border-slate-700/80">
<div className="flex items-center justify-between">
<div className="flex items-center space-x-1.5">
<span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
{" "}
<span className="text-xs font-bold text-blue-200" id="b-hero-world-tag">
WORLD 05 · 글로벌 투자
</span>
</div>
<span className="text-[10px] text-slate-300 bg-white/10 px-2 py-0.5 rounded-md font-semibold" id="b-hero-horizon">
1년 후 예상 자산
</span>
</div>
<div className="mt-2 flex items-baseline justify-between">
<div>
<h3 className="text-2xl font-black text-white tracking-tight" id="b-hero-world-val">
+277,648원
</h3>
<p className="text-[11px] text-blue-200/90 mt-0.5" id="b-hero-world-desc">
글로벌 지수 ETF 연 7.2% 복리 운용 가정 (손실위험 안내 필독)
</p>
</div>
<div className="text-right shrink-0">
<span className="text-xs font-bold text-emerald-400" id="b-hero-world-diff">
+277,648원
</span>
{" "}
<span className="text-[10px] text-slate-400 block">
소비 대비 방어
</span>
</div>
</div>
</div>
{/* 6 Interactive World Cards */}
<div className="grid grid-cols-2 gap-2" id="world-select-grid">
{/* World 1 */}
<div className="world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300" onClick={(event) => run(event, (c) => { c.chooseWorld(1); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#8B95A1]">
WORLD 01
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-[#F04452]" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
지금 구매
</div>
<div className="text-[11px] text-[#F04452] font-extrabold mt-0.5" id="wcard-amt-1">
-259,000원
</div>
<div className="text-[10px] text-[#8B95A1] mt-1">
즉각 만족 · 현금 감소
</div>
</div>
{/* World 2 */}
<div className="world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300" onClick={(event) => run(event, (c) => { c.chooseWorld(2); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#8B95A1]">
WORLD 02
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-[#3182F6]" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
구매하지 않기
</div>
<div className="text-[11px] text-[#3182F6] font-extrabold mt-0.5" id="wcard-amt-2">
+259,000원
</div>
<div className="text-[10px] text-[#8B95A1] mt-1">
원금 현금 전액 보존
</div>
</div>
{/* World 3 */}
<div className="world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300" onClick={(event) => run(event, (c) => { c.chooseWorld(3); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#8B95A1]">
WORLD 03
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-amber-500" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
구매 연기 (3개월)
</div>
<div className="text-[11px] text-amber-600 font-extrabold mt-0.5" id="wcard-amt-3">
+176,120원
</div>
<div className="text-[10px] text-[#8B95A1] mt-1">
구매 전까지 받은 이자만 남아요
</div>
</div>
{/* World 4 */}
<div className="world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300" onClick={(event) => run(event, (c) => { c.chooseWorld(4); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#8B95A1]">
WORLD 04
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-[#059669]" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
저축하기
</div>
<div className="text-[11px] text-[#059669] font-extrabold mt-0.5" id="wcard-amt-4">
+268,842원
</div>
<div className="text-[10px] text-[#8B95A1] mt-1">
안전 파킹 연 3.8%
</div>
</div>
{/* World 5 (Default Active) */}
<div className="world-option-card p-3 rounded-2xl border-2 border-[#3182F6] bg-[#E8F3FF]/60 cursor-pointer transition-all active:scale-97 shadow-sm" onClick={(event) => run(event, (c) => { c.chooseWorld(5); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#3182F6]">
WORLD 05
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-indigo-600" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
투자하기
</div>
<div className="text-[11px] text-indigo-700 font-extrabold mt-0.5" id="wcard-amt-5">
+277,648원
</div>
<div className="text-[10px] text-[#4E5968] mt-1">
지수 ETF 연 7.2%
</div>
</div>
{/* World 6 */}
<div className="world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300" onClick={(event) => run(event, (c) => { c.chooseWorld(6); })}>
<div className="flex items-center justify-between">
<span className="text-[10px] font-extrabold text-[#8B95A1]">
WORLD 06
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-purple-500" />
</div>
<div className="text-xs font-bold text-[#191F28] mt-1">
혼합 자산 배분
</div>
<div className="text-[11px] text-purple-700 font-extrabold mt-0.5" id="wcard-amt-6">
+182,163원
</div>
<div className="text-[10px] text-[#8B95A1] mt-1">
소비·저축·투자 분할
</div>
</div>
</div>
{/* CTA to Comparison */}
<button className="w-full py-3.5 bg-[#3182F6] hover:bg-blue-600 active:scale-98 text-white font-extrabold rounded-2xl text-xs shadow-md flex items-center justify-center space-x-2 transition-all mt-1" onClick={(event) => run(event, (c) => { c.switchView('C'); })}>
<span>
선택한 세계와 1:1 맞비교하기
</span>
{" "}
<span className="material-symbols-outlined text-base">
compare_arrows
</span>
</button>
</section>
{/* ========================================================================= */}
{/* [VIEW C: 미래 맞비교 - 1:1 비교 매트릭스] */}
{/* ========================================================================= */}
<section className="p-4 space-y-3.5 hidden fade-enter" id="view-C">
<div className="bg-white rounded-3xl p-4 border border-[#E5E8EB] shadow-sm space-y-3">
<div className="flex items-center justify-between">
<h2 className="text-xs font-extrabold text-[#191F28]">
선택 경로 1:1 맞비교
</h2>
<span className="text-[10px] text-[#3182F6] font-bold bg-[#E8F3FF] px-2 py-0.5 rounded">
시뮬레이션 비교표
</span>
</div>
{/* Selector Pair */}
<div className="grid grid-cols-2 gap-2 text-xs">
<div className="p-2.5 bg-[#F9FAFB] rounded-xl border border-slate-200">
<div className="text-[10px] text-[#8B95A1] font-bold">
기준 [A] 고정
</div>
<div className="font-extrabold text-[#191F28] mt-0.5 flex items-center space-x-1">
<span className="w-2 h-2 rounded-full bg-[#F04452]" />
{" "}
<span className="text-xs">
WORLD 01 지금 구매
</span>
</div>
</div>
<div className="p-2.5 bg-[#E8F3FF]/80 rounded-xl border border-blue-200">
<div className="text-[10px] text-[#3182F6] font-bold">
비교 대상 [B]
</div>
<select className="w-full mt-0.5 p-0 bg-transparent border-none text-xs font-extrabold text-[#191F28] focus:ring-0 cursor-pointer" id="select-comp-b" onChange={(event) => run(event, (c) => { c.onCompareTargetChange(event.currentTarget.value); })} defaultValue="5">
<option value="2">
WORLD 02 구매하지 않기
</option>
<option value="3">
WORLD 03 구매 연기 (3개월)
</option>
<option value="4">
WORLD 04 저축하기 (연 3.8%)
</option>
<option value="5">
WORLD 05 투자하기 (연 7.2%)
</option>
<option value="6">
WORLD 06 혼합 자산 배분 (1:1:1)
</option>
</select>
</div>
</div>
{/* Comparison Table Card */}
<div className="bg-[#F9FAFB] rounded-2xl p-3 border border-slate-200 space-y-2.5 text-xs">
<div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
<span className="text-[#8B95A1] font-medium text-[11px]">
항목
</span>
{" "}
<span className="text-[#F04452] font-bold text-[11px] w-24 text-right">
미래 A (소비)
</span>
{" "}
<span className="text-[#3182F6] font-bold text-[11px] w-28 text-right" id="th-b-name">
미래 B (투자)
</span>
</div>
<div className="flex items-center justify-between text-[11px]">
<span className="text-[#4E5968] font-medium" id="td-horizon-label">
1년 후 총자산
</span>
{" "}
<span className="font-bold text-[#191F28] w-24 text-right">
0원
</span>
{" "}
<span className="font-extrabold text-[#3182F6] w-28 text-right" id="td-b-asset">
+277,648원
</span>
</div>
<div className="flex items-center justify-between text-[11px]">
<span className="text-[#4E5968] font-medium">
즉시 가용 현금
</span>
{" "}
<span className="font-bold text-[#F04452] w-24 text-right sync-amount-text">
-259,000원
</span>
{" "}
<span className="font-bold text-[#059669] w-28 text-right" id="td-b-cash">
259,000원 보존
</span>
</div>
<div className="flex items-center justify-between text-[11px]">
<span className="text-[#4E5968] font-medium">
카드 결제 청구액
</span>
{" "}
<span className="font-bold text-[#191F28] w-24 text-right sync-base-amt">
259,000원 청구
</span>
{" "}
<span className="font-bold text-[#4E5968] w-28 text-right">
0원 (청구 없음)
</span>
</div>
<div className="flex items-center justify-between text-[11px]">
<span className="text-[#4E5968] font-medium">
목표 달성 기여
</span>
{" "}
<span className="text-[#8B95A1] w-24 text-right">
변동 없음
</span>
{" "}
<span className="font-bold text-amber-600 w-28 text-right">
+2.4개월 단축
</span>
</div>
</div>
</div>
{/* 핵심 비교 지표 4선 */}
<div className="space-y-2">
<h3 className="text-xs font-black text-[#191F28] px-1">
핵심 비교 지표 4선
</h3>
{/* 1. 미래 예상 총자산 차이 */}
<div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<div className="w-7 h-7 rounded-lg bg-blue-50 text-[#3182F6] flex items-center justify-center font-bold">
1
</div>
<span className="font-bold text-[#4E5968]">
미래 예상 총자산 격차
</span>
</div>
<div className="text-right">
<span className="font-black text-[#3182F6] text-sm" id="metric-asset-diff">
+277,648원
</span>
{" "}
<span className="text-[10px] text-[#8B95A1] block" id="metric-b-total">
B세계: 277,648원
</span>
</div>
</div>
{/* 2. 사용 가능한 현금 여력 */}
<div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<div className="w-7 h-7 rounded-lg bg-emerald-50 text-[#059669] flex items-center justify-center font-bold">
2
</div>
<span className="font-bold text-[#4E5968]">
사용 가능한 현금 여력
</span>
</div>
<div className="text-right">
<span className="font-bold text-[#191F28]" id="metric-cash">
259,000원 즉시 가용
</span>
{" "}
<span className="text-[10px] text-[#059669] block font-semibold">
비상금 유동성 확보
</span>
</div>
</div>
{/* 3. 필수지출 차감 후 여력 */}
<div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
3
</div>
<span className="font-bold text-[#4E5968]">
필수지출 차감 후 여력
</span>
</div>
<div className="text-right">
<span className="font-bold text-[#191F28]">
안정권 유지
</span>
{" "}
<span className="text-[10px] text-[#8B95A1] block">
카드 청구 리스크 0건
</span>
</div>
</div>
{/* 4. 저축 목표 달성 속도 */}
<div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
4
</div>
<span className="font-bold text-[#4E5968]">
저축 목표 달성 속도
</span>
</div>
<div className="text-right">
<span className="font-black text-amber-600">
+2.4개월 단축
</span>
{" "}
<span className="text-[10px] text-[#8B95A1] block">
목표 500만 기준
</span>
</div>
</div>
</div>
<button className="w-full py-3 bg-[#191F28] hover:bg-slate-800 active:scale-98 text-white font-bold rounded-2xl text-xs flex items-center justify-center space-x-1.5 transition-all" onClick={(event) => run(event, (c) => { c.switchView('D'); })}>
<span>
상세 리포트 및 AI 진단 확인
</span>
{" "}
<span className="material-symbols-outlined text-base">
analytics
</span>
</button>
</section>
{/* ========================================================================= */}
{/* [VIEW D: 상세 리포트 & AI 온디맨드 진단] */}
{/* ========================================================================= */}
<section className="p-4 space-y-3.5 hidden fade-enter" id="view-D">
{/* 금융 마일스톤 타임라인 */}
<div className="bg-white rounded-3xl p-4 border border-[#E5E8EB] shadow-sm space-y-3">
<div className="flex items-center justify-between">
<h3 className="text-xs font-black text-[#191F28]">
선택한 세계의 금융 마일스톤
</h3>
<span className="text-[10px] text-[#3182F6] font-bold bg-[#E8F3FF] px-2 py-0.5 rounded" id="d-world-badge">
WORLD 05 투자 기준
</span>
</div>
<div className="space-y-3 relative pl-4 border-l-2 border-blue-200 ml-2 mt-2 text-xs">
<div className="relative">
<span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-[#3182F6] ring-4 ring-white" />
{" "}
<span className="text-[10px] font-bold text-[#3182F6]">
오늘 (결정 시점)
</span>
<p className="font-bold text-[#191F28] text-[11px] mt-0.5">
충동 소비 방어 성공 및 씨앗 자산 형성
</p>
</div>
<div className="relative">
<span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-slate-300 ring-4 ring-white" />
{" "}
<span className="text-[10px] font-bold text-[#8B95A1]">
3개월 차 (쿨다운 완료)
</span>
<p className="font-bold text-[#191F28] text-[11px] mt-0.5">
단기 물욕 소멸 및 복리 효과 첫 발현 시점
</p>
</div>
<div className="relative">
<span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-slate-300 ring-4 ring-white" />
{" "}
<span className="text-[10px] font-bold text-[#8B95A1]">
6개월 차 (중간 점검)
</span>
<p className="font-bold text-[#191F28] text-[11px] mt-0.5">
예상 평가액{" "}
<span className="sync-saved-6m font-extrabold text-[#3182F6]">
268,324원
</span>
{" "}돌파
</p>
</div>
<div className="relative">
<span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-[#059669] ring-4 ring-white" />
{" "}
<span className="text-[10px] font-bold text-[#059669]" id="tl-horizon">
1년 차
</span>
<p className="font-bold text-[#191F28] text-[11px] mt-0.5">
완전한 자산화 달성:{" "}
<span className="sync-saved-future font-extrabold text-[#059669]">
+277,648원
</span>
</p>
</div>
</div>
</div>
{/* 투명 금융 고지 카드 */}
<div className="bg-slate-100/90 rounded-2xl p-3 border border-slate-200 text-[11px] text-[#4E5968] space-y-1">
<div className="flex items-center space-x-1 font-bold text-[#191F28]">
<span className="material-symbols-outlined text-[15px] text-[#3182F6]">
shield
</span>
{" "}
<span>
투명한 금융 기준 및 위험 고지
</span>
</div>
<p className="leading-relaxed text-[10px] text-[#8B95A1]">
• 투자 수익률은 화면에서 선택한 가정값이며, 실제 종목의 과거 수익률이나 미래 성과를 의미하지 않습니다. 원금 손실이 발생할 수 있어요.
<br />
{" "}• 본 서비스는 절약한 기회비용을 명확히 인지하도록 돕는 디지털 트윈 시뮬레이션입니다.
</p>
</div>
{/* On-Demand AI Financial Coaching */}
<div className="bg-gradient-to-br from-[#191F28] to-[#1E293B] text-white rounded-3xl p-4 shadow-lg border border-slate-800">
<div className="flex items-center justify-between text-xs mb-1">
<span className="text-blue-300 font-bold flex items-center space-x-1">
<span className="material-symbols-outlined text-sm">
psychology
</span>
{" "}
<span>
AI 금융 코칭 엔진
</span>
</span>
{" "}
<span className="text-[10px] text-slate-400">
온디맨드 분석
</span>
</div>
<h4 className="text-sm font-extrabold text-white mt-1">
행동금융학 맞춤 미래 진단
</h4>
<p className="text-xs text-slate-300 mt-1 leading-relaxed">
이번 달 필수 결제와 선택한 경로를 바탕으로 쓸 수 있는 현금과 위험을 정리해 드려요.
</p>
<button className="mt-3.5 w-full py-3 bg-[#3182F6] hover:bg-blue-500 active:scale-98 text-white font-extrabold rounded-2xl text-xs flex items-center justify-center space-x-2 transition-all shadow-md" id="ai-trigger-btn" onClick={(event) => run(event, (c) => { c.triggerAiCoaching(); })}>
<span className="material-symbols-outlined text-base">
smart_toy
</span>
{" "}
<span>
내 조건으로 진단받기
</span>
</button>
{/* AI Response Box (Hidden Initially) */}
<div className="hidden mt-3 pt-3 border-t border-slate-700/80 transition-all duration-300" id="ai-insight-box">
<div className="bg-white/10 rounded-2xl p-3 border border-white/10 space-y-2">
<div className="flex items-center justify-between text-[11px] font-bold text-emerald-400">
<span>
입력한 조건으로 계산했어요
</span>
{" "}
<span className="text-[10px] text-slate-400">
수익률은 가정값이에요
</span>
</div>
<p className="text-xs text-slate-200 leading-relaxed" id="ai-insight-text">
현재 금액{" "}
<strong className="text-white sync-base-amt">
259,000원
</strong>
을 '투자' 혹은 '저축'으로 전환할 경우, 다가오는 14일 카드 결제 후 남는{" "}
<strong className="text-blue-300">
잉여 유동성이 42% 증가
</strong>
할 수 있어요. 이 계산은 등록된 필수 결제 일정과 가정 수익률에 근거한 시뮬레이션이며, 실제 지출과 투자 수익은 달라질 수 있어요.
</p>
</div>
</div>
</div>
{/* Final Plan Save CTA */}
<button className="w-full py-3.5 bg-[#3182F6] hover:bg-blue-600 active:scale-98 text-white font-extrabold rounded-2xl text-xs shadow-floating flex items-center justify-center space-x-1.5 transition-all" onClick={(event) => run(event, (c) => { c.savePlanToBudget(); })}>
<span className="material-symbols-outlined text-base">
bookmark_added
</span>
{" "}
<span>
이 실험을 보관함에 저장하기
</span>
</button>
</section>
{/* ========================================================================= */}
{/* [VIEW E: 기록 보관함 - 이전 소비 방어 내역] */}
{/* ========================================================================= */}
<section className="p-4 space-y-3.5 hidden fade-enter" id="view-E">
<div className="flex items-center justify-between">
<div>
<h2 className="text-base font-extrabold text-[#191F28] tracking-tight">
이전 실험 기록 보관함
</h2>
<p className="text-[11px] text-[#8B95A1] mt-0.5">
저장한 실험을 다시 불러와 비교할 수 있어요.
</p>
</div>
<span className="text-xs font-bold text-[#3182F6] bg-[#E8F3FF] px-2 py-0.5 rounded-full">
총 3건 방어 완료
</span>
</div>
{/* History Card 1: 헤드폰 25.9만 */}
<div className="bg-white rounded-2xl p-3.5 border border-[#E5E8EB] shadow-sm space-y-2.5">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-2.5">
<div className="w-10 h-10 rounded-xl bg-blue-50 text-[#3182F6] flex items-center justify-center text-xl shrink-0">
🎧
</div>
<div>
<h3 className="text-xs font-black text-[#191F28]">
소니 노이즈캔슬링 헤드폰
</h3>
<p className="text-[11px] text-[#8B95A1] mt-0.5">
259,000원 방어 성공 · 2일 전
</p>
</div>
</div>
<span className="text-[10px] font-bold text-[#059669] bg-emerald-50 px-2 py-0.5 rounded-md">
방어 완료
</span>
</div>
<div className="bg-[#F9FAFB] rounded-xl p-2 flex items-center justify-between text-xs">
<span className="text-[#8B95A1] text-[11px]">
1년 후 복리 예상액
</span>
{" "}
<span className="font-extrabold text-[#3182F6]">
+277,648원
</span>
</div>
<button className="w-full py-2 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] text-[#4E5968] font-bold rounded-xl text-xs transition-colors flex items-center justify-center space-x-1" onClick={(event) => run(event, (c) => { c.reloadSavedExperiment('소니 노이즈캔슬링 헤드폰', 259000); })}>
<span>
이 돈으로 재실험
</span>
{" "}
<span className="material-symbols-outlined text-sm">
refresh
</span>
</button>
</div>
{/* History Card 2: 야식 3.4만 */}
<div className="bg-white rounded-2xl p-3.5 border border-[#E5E8EB] shadow-sm space-y-2.5">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-2.5">
<div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl shrink-0">
🍗
</div>
<div>
<h3 className="text-xs font-black text-[#191F28]">
심야 배달 야식 & 음료
</h3>
<p className="text-[11px] text-[#8B95A1] mt-0.5">
34,000원 방어 성공 · 4일 전
</p>
</div>
</div>
<span className="text-[10px] font-bold text-[#059669] bg-emerald-50 px-2 py-0.5 rounded-md">
방어 완료
</span>
</div>
<div className="bg-[#F9FAFB] rounded-xl p-2 flex items-center justify-between text-xs">
<span className="text-[#8B95A1] text-[11px]">
1년 후 복리 예상액
</span>
{" "}
<span className="font-extrabold text-[#3182F6]">
+36,448원
</span>
</div>
<button className="w-full py-2 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] text-[#4E5968] font-bold rounded-xl text-xs transition-colors flex items-center justify-center space-x-1" onClick={(event) => run(event, (c) => { c.reloadSavedExperiment('심야 배달 야식', 34000); })}>
<span>
이 돈으로 재실험
</span>
{" "}
<span className="material-symbols-outlined text-sm">
refresh
</span>
</button>
</div>
{/* History Card 3: 셔츠 6.8만 */}
<div className="bg-white rounded-2xl p-3.5 border border-[#E5E8EB] shadow-sm space-y-2.5">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-2.5">
<div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xl shrink-0">
👔
</div>
<div>
<h3 className="text-xs font-black text-[#191F28]">
디자이너 오버핏 셔츠
</h3>
<p className="text-[11px] text-[#8B95A1] mt-0.5">
68,000원 방어 성공 · 1주일 전
</p>
</div>
</div>
<span className="text-[10px] font-bold text-[#059669] bg-emerald-50 px-2 py-0.5 rounded-md">
방어 완료
</span>
</div>
<div className="bg-[#F9FAFB] rounded-xl p-2 flex items-center justify-between text-xs">
<span className="text-[#8B95A1] text-[11px]">
1년 후 복리 예상액
</span>
{" "}
<span className="font-extrabold text-[#3182F6]">
+72,896원
</span>
</div>
<button className="w-full py-2 bg-[#F2F4F6] hover:bg-[#E8F3FF] hover:text-[#3182F6] text-[#4E5968] font-bold rounded-xl text-xs transition-colors flex items-center justify-center space-x-1" onClick={(event) => run(event, (c) => { c.reloadSavedExperiment('디자이너 셔츠', 68000); })}>
<span>
이 돈으로 재실험
</span>
{" "}
<span className="material-symbols-outlined text-sm">
refresh
</span>
</button>
</div>
</section>
</main>
{/* END: Scrollable Content Container */}
{/* BEGIN: GlobalBottomNavigation */}
{/* END: GlobalBottomNavigation */}
</div>
{/* BEGIN: Interactive Logic Script */}
{/* END: Interactive Logic Script */}
    </div>
  );
}

export default memo(WorldScreen);
