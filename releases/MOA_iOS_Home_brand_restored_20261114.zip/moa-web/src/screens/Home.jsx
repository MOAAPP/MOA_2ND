import { memo, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { APP_TODAY, useStore, won, skippedTotal } from '../lib/store';
import { beforePayday, cashTimeline, totals, monthlyBudget, dday, md } from '../lib/finance';
import { lessonById, pickToday } from '../lib/learning';
import AppHeader from '../components/AppHeader';
import './Home.css';

/* The screen follows iOS large-title/inset-group conventions. It is still a web app. */
const fmt = (n) => Math.round(n || 0).toLocaleString('ko-KR');
const pct = (n) => Math.max(0, Math.min(100, n));

const paths = {
  chevron: <path d="m9 18 6-6-6-6" />,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 6-2 7-2 9h16c0-2-2-3-2-9"/><path d="M10 21h4"/></>,
  person: <><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></>,
  wallet: <><rect x="2.8" y="5" width="18.4" height="14" rx="3"/><path d="M3 9.5h18M16.5 14.5h2"/></>,
  shield: <><path d="m12 2.5 8 3.4V12c0 4.4-3.2 7.9-8 9.5C7.2 19.9 4 16.4 4 12V5.9L12 2.5Z"/><path d="m8.7 12.2 2.1 2.1 4.7-4.7"/></>,
  chart: <><path d="M3.5 19.5h17"/><path d="m5 16 5-5 3 2 5-7"/><path d="M15 6h3v3"/></>,
  edit: <><path d="m4 16.8 10.6-10.6 3.2 3.2L7.2 20H4z"/><path d="m13.4 7.4 3.2 3.2M3.5 20.5h17"/></>,
  calendar: <><rect x="3.5" y="5.5" width="17" height="15.5" rx="3"/><path d="M7.7 3.3v4.1m8.6-4.1v4.1M4 10h16"/></>,
  flask: <><path d="M9 3h6M10 3v6l-5.6 9A2.5 2.5 0 0 0 6.5 22h11a2.5 2.5 0 0 0 2.1-4L14 9V3"/><path d="M8 15h8"/></>,
  bag: <><path d="M5 8h14l1 13H4L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></>,
  arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
  book: <><path d="M12 6c-2-1.7-5-2.2-8-1v14c3-1.2 6-.7 8 1 2-1.7 5-2.2 8-1V5c-3-1.2-6-.7-8 1Z"/><path d="M12 6v14"/></>,
  layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  circle: <circle cx="12" cy="12" r="8.5" />,
  down: <path d="m6 9 6 6 6-6" />,
};
function Symbol({ name, size=19, stroke=1.8 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.circle}</svg>;
}

const shortcuts = [
  { icon: 'edit', label:'소비 기록', detail:'지출과 수입 기록', tone:'blue', to:'/record' },
  { icon: 'calendar', label:'결제 일정', detail:'월세·카드값 확인', tone:'orange', to:'/bills' },
  { icon: 'flask', label:'금융 실험실', detail:'저축과 모의투자', tone:'teal', to:'/lab' },
  { icon: 'bag', label:'소비 고민', detail:'살까, 미룰까, 안 살까', tone:'purple', to:'/wishlist' },
];
function GroupRow({icon, tone, label, detail, value, onClick, separated=false, trailing=true}) {
  return <button className={'native-row'+(separated?' native-row-separated':'')} type="button" onClick={onClick}>
    <span className={'native-row-icon native-icon-'+tone}><Symbol name={icon} size={19}/></span>
    <span className="native-row-copy"><strong>{label}</strong>{detail&&<small>{detail}</small>}</span>
    {value&&<span className="native-row-value">{value}</span>}
    {trailing&&<span className="native-disclosure"><Symbol name="chevron" size={16} stroke={1.9}/></span>}
  </button>;
}
function Section({heading, subtitle, action, onAction, children}) {
  return <section className="native-section">
    <div className="native-section-heading"><div><h2>{heading}</h2>{subtitle&&<p>{subtitle}</p>}</div>{action&&<button type="button" onClick={onAction}>{action}</button>}</div>
    {children}
  </section>;
}
function Home() {
  const navigate = useNavigate();
  const state = useStore(s=>s);
  const summary = useMemo(() => {
    const payment = beforePayday(state);
    const month = totals(undefined,state);
    const budget = monthlyBudget(state);
    const events = cashTimeline(35,state);
    const learnPick=pickToday(state,APP_TODAY);
    return {payment,month,budget,events,lesson:lessonById(learnPick.id),reason:learnPick.reason,
      pending:state.wishes.filter(w=>w.status==='thinking'||w.status==='later').length,skipped:skippedTotal(state)};
  },[state]);
  const {payment,month,budget,events,lesson,pending,skipped}=summary;
  const dateLabel=new Intl.DateTimeFormat('ko-KR',{month:'long',day:'numeric',weekday:'long'}).format(new Date(APP_TODAY+'T00:00:00'));
  const used = budget>0 ? pct(month.expense/budget*100) : 0;
  const remainder=budget-month.expense;
  const safe=payment.spendable;
  const shortfall=safe<0;
  const bank=state.profile.bank || '선택된 은행 없음';
  const name=state.profile.name || '모아';

  return <div className="ios-native-home">
    <AppHeader profileTo="/more" />

    <div className="native-home-main">
      <header className="native-home-title"><span className="native-home-date">{dateLabel}</span><h1>홈</h1><p>{state.profile.name ? `${state.profile.name}님의 오늘 금융 현황` : "오늘의 금융 현황"}</p></header>

      <Section heading="내 계좌">
        <div className="native-inset-group native-account-group">
          <button className="native-account-overview" type="button" onClick={()=>navigate('/settings')} aria-label="계좌 설정하기">
            <div className="native-account-heading">
              <span className="native-account-mark"><Symbol name="wallet" size={20}/></span>
              <span className="native-account-bank"><strong>{bank}</strong><small>주거래은행 · 직접 입력</small></span>
              <span className="native-disclosure"><Symbol name="chevron" size={16}/></span>
            </div>
            <span className="native-account-caption">현재 잔액</span>
            <span className="native-account-amount">{fmt(state.finance.balance)}<small>원</small></span>
          </button>
          <button className="native-finance-row native-inner-divider" type="button" onClick={()=>navigate(shortfall?'/bills':'/world')}>
            <span className="native-finance-text"><strong>오늘 쓸 수 있는 돈</strong><small>필수 결제·최소 잔액 반영</small></span>
            <span className={'native-finance-value'+(shortfall?' native-negative':'')}>{shortfall?`${fmt(-safe)}원 부족`:won(safe)}</span>
            <span className="native-disclosure"><Symbol name="chevron" size={16}/></span>
          </button>
          <button className="native-budget-area native-inner-divider" type="button" onClick={()=>navigate('/budget')}>
            <span className="native-budget-copy"><span>이번 달 지출</span><strong>{won(month.expense)} <small>/ {won(budget)}</small></strong></span>
            <span className="native-budget-track" role="progressbar" aria-label="이번 달 예산 사용률" aria-valuenow={Math.round(used)} aria-valuemin="0" aria-valuemax="100"><span style={{width:used+'%'}}/></span>
            <span className="native-budget-foot"><span>예산의 {Math.round(used)}% 사용</span><span className={remainder<0?'native-negative':''}>{remainder<0?`${won(-remainder)} 초과`:`${won(remainder)} 남음`}</span></span>
          </button>
        </div>
        <p className="native-section-note"><Symbol name="shield" size={13}/> 은행 자동 연결 전에는 직접 입력한 잔액을 기준으로 계산해요.</p>
      </Section>

      <Section heading="빠른 실행">
        <div className="native-inset-group">
          {shortcuts.map((a,i)=><GroupRow key={a.to} icon={a.icon} tone={a.tone} label={a.label} detail={a.detail} separated={i>0} onClick={()=>navigate(a.to)} />)}
        </div>
      </Section>

      <Section heading="예정된 거래" action="모두 보기" onAction={()=>navigate('/bills')}>
        <div className="native-inset-group native-events">
          {events.length>0 ? events.slice(0,3).map((e,i)=><button className={'native-event native-inner-divider'+(i===0?' native-event-first':'')} type="button" key={e.date+e.label+i} onClick={()=>navigate('/bills')}>
            <span className="native-event-date">{md(e.date)}<small>{dday(e.date)}</small></span>
            <span className="native-event-description"><strong>{e.label}</strong><small>{e.risk?'잔액 확인 필요':e.kind==='salary'?'예정 수입':'예정 지출'}</small></span>
            <span className={'native-event-amount'+(e.amount>0?' native-positive':'')}>{e.amount>0?'+':'−'}{won(Math.abs(e.amount))}</span>
          </button>): <button type="button" className="native-empty-row" onClick={()=>navigate('/bills')}>등록된 일정이 없어요 <span>일정 추가 <Symbol name="chevron" size={14}/></span></button>}
          {payment.firstRisk&&<p className="native-event-warning"><Symbol name="circle" size={14}/>{md(payment.firstRisk.date)} 이후 예정된 결제로 잔액이 부족할 수 있어요.</p>}
        </div>
      </Section>

      <Section heading="나를 위한 추천">
        <div className="native-inset-group">
          <GroupRow icon="layers" tone="indigo" label="평행세계 비교" detail="샀을 때와 사지 않았을 때의 미래" onClick={()=>navigate('/world')} />
          {lesson&&<GroupRow icon="book" tone="green" label="오늘의 금융 학습" detail={lesson.title} value={state.learning.done.includes(lesson.id)?'완료':`약 ${lesson.minutes}분`} separated onClick={()=>navigate('/learn/'+lesson.id)}/>}
          {(pending>0 || skipped>0)&&<GroupRow icon="bag" tone="pink" label="소비 결정 보관함" detail={pending?`${pending}건 고민 중`:`사지 않기로 한 금액 ${won(skipped)}`} separated onClick={()=>navigate('/wishlist')}/>}
        </div>
      </Section>
      <p className="native-footer-note">MOA의 계산은 시뮬레이션 결과이며 실제 금융계좌·투자 수익을 보장하지 않아요.</p>
    </div>
  </div>;
}
export default memo(Home);
