/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s09 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Ledger.controller';
import './Ledger.css';



import AppHeader from '../components/AppHeader';

function LedgerScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {"SCREEN_1":"/ledger/report"});
  return (
    <div ref={rootRef} className="stitch-screen scr-ledger flex justify-center items-start min-h-full text-slate-900 selection:bg-blue-100 selection:text-blue-900">
{/* BEGIN: Main Mobile Container */}
<main className="w-full max-w-[390px] min-h-full bg-[#F8FAFC] relative flex flex-col aurora-bg mx-auto" data-purpose="mobile-screen-wrapper">
{/* BEGIN: Top Sticky Header (Unified with Home Screen SCREEN_19) */}
<AppHeader profileTo="/more" />
{/* END: Top Sticky Header */}
{/* Scrollable Content Container with Bottom Padding for Navigation Bar */}
<div className="flex-1 px-4 pt-3 pb-28 space-y-4" data-purpose="scrollable-content">
{/* BEGIN: Month & Account Selector Bar */}
<section className="space-y-3" data-purpose="month-account-selector">
{/* Page Title & Month Selector Dropdown Trigger */}
<div className="pt-1">
<h1 className="text-2xl font-bold text-slate-900 tracking-tight">
가계부
</h1>
</div>
<div className="flex items-center justify-between">
<button className="inline-flex items-center space-x-1.5 py-1 text-[18px] font-extrabold text-slate-900 tracking-tight hover:opacity-80 active:scale-95 cursor-pointer transition-all group max-w-full truncate" id="month-picker-trigger" onClick={(event) => run(event, (c) => { c.openMonthPicker(); })} type="button">
<span className="truncate" id="selected-month-display">
2026년 11월
</span>
{" "}
<svg className="w-4 h-4 text-slate-500 stroke-[2.5] transition-transform duration-200 group-hover:translate-y-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="m19 9-7 7-7-7" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</button>
</div>
{/* Quick Pill Filter Tabs (전체 / 지출 / 예적금) */}
<nav aria-label="내역 카테고리 필터" className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-0.5">
<button className="cat-tab shrink-0 px-3.5 py-1.5 bg-white text-slate-600 text-xs font-medium rounded-full border border-slate-200/90 shadow-sm hover:bg-slate-50 transition-all" id="cat-filter-all" onClick={(event) => run(event, (c) => { c.filterCategory('all'); })} type="button">
전체
</button>
{" "}
<button className="cat-tab shrink-0 px-3.5 py-1.5 bg-white text-slate-600 text-xs font-medium rounded-full border border-slate-200/90 shadow-sm hover:bg-slate-50 transition-all" id="cat-filter-expense" onClick={(event) => run(event, (c) => { c.filterCategory('expense'); })} type="button">
지출
</button>
{" "}
<button className="cat-tab shrink-0 px-3.5 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-full shadow-sm transition-all" id="cat-filter-savings" onClick={(event) => run(event, (c) => { c.filterCategory('savings'); })} type="button">
예적금
</button>
</nav>
</section>
{/* END: Month & Account Selector Bar */}
{/* BEGIN: Monthly Summary Hero Card */}
<section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] relative overflow-hidden space-y-4" data-purpose="monthly-summary-hero">
<div className="flex justify-between items-start">
<div>
<div className="flex items-center space-x-1.5">
<span className="text-xs font-semibold text-slate-500" id="summary-title">
11월 모은 돈
</span>
</div>
<div className="flex items-baseline space-x-1 mt-1.5">
<span className="text-2xl font-extrabold text-slate-900 tracking-tight" id="summary-amount">
400,000
</span>
{" "}
<span className="text-base font-bold text-slate-700">
원
</span>
</div>
</div>
<div className="flex items-center space-x-1.5">
<button aria-label="지출 분석 리포트 화면으로 이동" className="inline-flex items-center space-x-1 text-xs font-bold text-blue-600 bg-blue-50/80 hover:bg-blue-100 px-3 py-1.5 rounded-full transition-all active:scale-95 border border-blue-100 shadow-sm cursor-pointer" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_1'); })} type="button">
<span className="material-symbols-outlined text-[15px]">
donut_large
</span>
{" "}
<span>
분석
</span>
</button>
</div>
</div>
<div className="bg-slate-50 rounded-2xl p-3 border border-slate-100/80 flex items-center justify-between text-xs" id="summary-budget-box">
<div className="flex items-center space-x-2">
<div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" id="budget-status-dot" />
<span className="text-slate-600 font-medium" id="summary-budget-text">
목표 저축액{" "}
<strong className="text-teal-600 font-bold">
500,000원
</strong>
{" "}달성중
</span>
</div>
<span className="text-[11px] font-semibold text-blue-600 bg-white px-2 py-0.5 rounded-full border border-slate-200/70 shadow-sm" id="summary-badge-sub">
달성률 80%
</span>
</div>
<div className="space-y-1.5 pt-1">
<div className="flex justify-between items-center text-xs">
<span className="text-slate-500 font-medium" id="summary-progress-label">
목표 500,000원 중{" "}
<strong className="text-teal-600 font-bold">
80.0%
</strong>
{" "}달성
</span>
{" "}
<span className="text-slate-400 text-[11px]" id="summary-progress-target">
목표 100%
</span>
</div>
<div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden flex">
<div className="h-full bg-gradient-to-r from-blue-500 to-teal-400 rounded-full transition-all duration-300" id="summary-progress-bar" style={{ width: "80%" }} />
</div>
</div>
</section>
{/* Motivation Banner */}
<section className="bg-white/80 backdrop-blur-sm rounded-2xl p-3 border border-slate-200/80 flex items-center justify-between shadow-sm cursor-pointer hover:bg-white transition-all" data-purpose="planet-saving-banner" onClick={(event) => run(event, (c) => { c.showToast('평행세계 행성 에너지를 획득했습니다! (+5 에너지)'); })}>
<div className="flex items-center space-x-2.5">
<div className="w-7 h-7 rounded-full bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
<svg className="w-3.5 h-3.5 text-blue-600 stroke-[2]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<circle cx="12" cy="12" r="9" />
<path d="M12 6v6l4 2" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<p className="text-xs text-slate-700 font-medium leading-tight">
직접 지출을 기록하고{" "}
<span className="font-bold text-blue-600">
평행세계 행성 에너지
</span>
를 모아보세요
</p>
</div>
<svg className="w-3.5 h-3.5 text-slate-400 stroke-[2] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="m9 5 7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</section>
{/* END: Monthly Summary Hero Card */}
{/* BEGIN: MOA Smart Ledger Insight Card & Toggle Controls */}
<div className="space-y-3" id="ledger-main-container">
{/* View Toggle Header Bar: [목록] / [달력] */}
<div className="flex items-center justify-between pt-1">
<div className="inline-flex bg-slate-100/80 p-0.5 rounded-full border border-slate-200/70">
<button className="inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold text-slate-600 transition-all hover:text-slate-900" id="tab-btn-list" onClick={(event) => run(event, (c) => { c.switchLedgerView('list'); })} type="button">
<span className="material-symbols-outlined text-[14px]">
format_list_bulleted
</span>
{" "}
<span>
목록
</span>
</button>
{" "}
<button className="inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold text-white bg-slate-900 shadow-sm transition-all" id="tab-btn-calendar" onClick={(event) => run(event, (c) => { c.switchLedgerView('calendar'); })} type="button">
<span className="material-symbols-outlined text-[14px]">
calendar_month
</span>
{" "}
<span>
달력
</span>
</button>
</div>
</div>
{/* CALENDAR VIEW SECTION (Toggled via [달력] button) */}
<section className="rounded-3xl border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3 pb-5" id="calendar-view-container">
<div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3 pb-5" id="calendar-main-card">
<div className="mt-1 mb-1 flex items-center justify-between bg-gradient-to-r from-emerald-50 to-blue-50 rounded-2xl p-3.5 border border-emerald-100/80 shadow-[0_4px_16px_rgba(15,23,42,0.03)] cursor-pointer hover:opacity-95 transition-all active:scale-[0.99]" onClick={(event) => run(event, (c) => { c.showToast('무지출 챌린지 5일 달성 완료!'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-emerald-100/80 border border-emerald-200/60 flex items-center justify-center shrink-0 text-emerald-600 shadow-sm">
<svg className="w-5 h-5 text-emerald-600 stroke-[2]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M12 22v-9" strokeLinecap="round" strokeLinejoin="round" />
<path d="M12 13c-3.5 0-6-3-6-6 3.5 0 6 2.5 6 6z" fill="currentColor" fillOpacity="0.15" strokeLinecap="round" strokeLinejoin="round" />
<path d="M12 10c3-3 6.5-2 6.5 1 0 3-3.5 5-6.5 5" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-xs font-bold text-slate-800">
무지출 챌린지
</span>
<span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700 text-[10px] font-bold border border-emerald-200/60">
5일 달성
</span>
</div>
<p className="text-[10px] text-slate-500 font-medium mt-0.5">
평행세계 씨앗{" "}
<span className="font-bold text-emerald-600">
+5개 획득
</span>
</p>
</div>
</div>
<button className="inline-flex items-center space-x-0.5 text-xs font-medium text-slate-500 hover:text-slate-800 px-2 py-1 rounded-lg hover:bg-white/60 transition-colors shrink-0" type="button">
<span className="text-[11px]">
내역보기
</span>
<svg className="w-3 h-3 text-slate-400 stroke-[2]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="m9 5 7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</button>
</div>
<div className="grid grid-cols-7 text-center pb-2 border-b border-slate-100 text-[11px] font-semibold">
<div className="text-red-500">
일
</div>
<div className="text-slate-500">
월
</div>
<div className="text-slate-500">
화
</div>
<div className="text-slate-500">
수
</div>
<div className="text-slate-500">
목
</div>
<div className="text-slate-500">
금
</div>
<div className="text-slate-500">
토
</div>
</div>
<div className="space-y-1">
<div className="grid grid-cols-7 gap-1 text-center py-1 border-b border-slate-50">
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-bold text-red-500">
1
</span>
<span className="text-[9px] text-slate-400 mt-1.5">
무지출
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
2
</span>
<span className="text-[9px] text-slate-700 font-medium mt-1">
-15,400
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
3
</span>
<span className="text-[9px] text-slate-700 font-medium mt-1">
-8,500
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
4
</span>
<span className="text-[9px] text-slate-700 font-medium mt-1">
-32,000
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
5
</span>
<span className="text-[9px] text-emerald-600 font-bold mt-0.5">
+150만
</span>
<span className="text-[9px] text-slate-700 font-medium">
-104,250
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
6
</span>
<span className="text-[9px] text-slate-700 font-medium mt-1">
-4,500
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
7
</span>
<span className="text-[9px] text-slate-400 mt-1.5">
무지출
</span>
</div>
</div>
<div className="grid grid-cols-7 gap-1 text-center py-1 border-b border-slate-50">
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-bold text-red-500">
8
</span>
<span className="text-[9px] text-emerald-600 font-bold mt-1">
+50,000
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
9
</span>
<span className="text-[9px] text-slate-700 font-medium mt-1">
-48,200
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl bg-blue-600 text-white flex flex-col justify-start items-center cursor-pointer shadow-md shadow-blue-500/35 relative transform scale-105 transition-all">
<span className="text-[11px] font-extrabold text-white">
10
</span>
<span className="w-1 h-1 rounded-full bg-white mt-0.5" />
<span className="text-[9px] text-blue-100 font-bold mt-0.5">
-34,500
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
11
</span>
<span className="text-[9px] text-slate-300 mt-1">
-
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
12
</span>
<span className="text-[9px] text-slate-300 mt-1">
-
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
13
</span>
<span className="text-[9px] text-slate-300 mt-1">
-
</span>
</div>
<div className="p-1 min-h-[52px] rounded-xl flex flex-col justify-start items-center hover:bg-slate-50 cursor-pointer">
<span className="text-[11px] font-semibold text-slate-800">
14
</span>
<span className="text-[9px] text-slate-300 mt-1">
-
</span>
</div>
</div>
<div className="grid grid-cols-7 gap-1 text-center py-1 border-b border-slate-50 text-slate-400">
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(15, event.currentTarget); })}>
<span className="text-[11px] text-red-300">
15
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(16, event.currentTarget); })}>
<span className="text-[11px]">
16
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(17, event.currentTarget); })}>
<span className="text-[11px]">
17
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(18, event.currentTarget); })}>
<span className="text-[11px]">
18
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(19, event.currentTarget); })}>
<span className="text-[11px]">
19
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(20, event.currentTarget); })}>
<span className="text-[11px]">
20
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(21, event.currentTarget); })}>
<span className="text-[11px]">
21
</span>
</div>
</div>
<div className="grid grid-cols-7 gap-1 text-center py-1 border-b border-slate-50 text-slate-400">
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(22, event.currentTarget); })}>
<span className="text-[11px] text-red-300">
22
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(23, event.currentTarget); })}>
<span className="text-[11px]">
23
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(24, event.currentTarget); })}>
<span className="text-[11px]">
24
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(25, event.currentTarget); })}>
<span className="text-[11px]">
25
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(26, event.currentTarget); })}>
<span className="text-[11px]">
26
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(27, event.currentTarget); })}>
<span className="text-[11px]">
27
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(28, event.currentTarget); })}>
<span className="text-[11px]">
28
</span>
</div>
</div>
<div className="grid grid-cols-7 gap-1 text-center py-1 text-slate-400">
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(29, event.currentTarget); })}>
<span className="text-[11px] text-red-300">
29
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center cursor-pointer hover:bg-slate-50 rounded-xl" onClick={(event) => run(event, (c) => { c.selectCalendarDay(30, event.currentTarget); })}>
<span className="text-[11px]">
30
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center text-slate-200">
<span className="text-[11px]">
1
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center text-slate-200">
<span className="text-[11px]">
2
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center text-slate-200">
<span className="text-[11px]">
3
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center text-slate-200">
<span className="text-[11px]">
4
</span>
</div>
<div className="p-1 min-h-[44px] flex flex-col items-center text-slate-200">
<span className="text-[11px]">
5
</span>
</div>
</div>
</div>
<div className="flex items-center justify-between pt-3 border-t border-slate-100 text-xs">
<span className="text-slate-500 font-medium text-sm">
11월 누적 지출 합계
</span>
<span className="text-base font-extrabold text-slate-900">
-270,447원
</span>
</div>
</div>
<div className="flex items-center space-x-2 px-1 pt-2 pb-0.5" id="calendar-selected-date-header">
<span className="w-2.5 h-2.5 rounded-full bg-[#3182F6] shrink-0" />
<span className="text-[15px] font-bold text-slate-900 leading-none" id="cal-detail-date-title">
11월 10일 화요일
</span>
<span className="text-xs font-normal text-slate-400 leading-none ml-1" id="cal-detail-tx-count">
내역 4건 · 총 670,447원
</span>
</div>
<div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3 pb-5">
<div className="space-y-3" id="cal-detail-tx-list">
<div className="flex items-start justify-between py-1 transition-all">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5">
<svg className="w-4 h-4 text-emerald-600 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8zM6 1v3M10 1v3M14 1v3" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
스타벅스 역삼점
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
카페/간식 • 생활비 통장
</p>
<span className="inline-block mt-1 text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
평행 자산 +1,500원 효과
</span>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-6,500원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
14:20
</p>
</div>
</div>
<div className="flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 mt-0.5">
<svg className="w-4 h-4 text-blue-600 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
마켓컬리 장보기
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
식비 • 생활비 통장
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-28,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
08:15
</p>
</div>
</div>
<div className="flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0 mt-0.5 text-teal-600">
<span className="material-symbols-outlined text-[18px]">
savings
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
청년도약적금 자동이체
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-teal-700 bg-teal-50 rounded">
예적금
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
비상금 파킹통장 • 국민은행
</p>
<span className="inline-block mt-1 text-[10px] font-semibold text-teal-600 bg-teal-50 px-1.5 py-0.5 rounded">
목돈 모으기 11회차 달성
</span>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-emerald-600">
+300,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
09:00
</p>
</div>
</div>
<div className="flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0 mt-0.5 text-teal-600">
<span className="material-symbols-outlined text-[18px]">
home_work
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
주택청약 종합저축
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-teal-700 bg-teal-50 rounded">
예적금
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
청약통장 • 우리은행
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-emerald-600">
+100,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
09:30
</p>
</div>
</div>
</div>
</div>
</section>
{/* OUTSIDE / BETWEEN BLOCKS: Selected Date Subtitle */}
{/* BLOCK 2: Transaction History Block (Single White Card) */}
</div>
{/* BEGIN: Daily Transaction Timeline (Default List View) */}
<section className="space-y-3 hidden" data-purpose="daily-transactions-timeline" id="list-view-container">
{/* 11월 10일 화요일 Block */}
<div className="space-y-2.5">
<div className="flex items-center space-x-2 px-1 pt-1 pb-0.5">
<span className="w-2.5 h-2.5 rounded-full bg-[#3182F6] shrink-0" />
{" "}
<span className="text-[15px] font-bold text-slate-900 leading-none" id="daily-timeline-header">
11월 10일 화요일
</span>
{" "}
<span className="text-xs font-normal text-slate-400 leading-none ml-1" id="daily-tx-count">
내역 4건 · 총 670,447원
</span>
</div>
<div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3">
<div className="space-y-3">
{/* 스타벅스 */}
<div className="tx-item flex items-start justify-between py-1 transition-all" data-category="expense">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5">
<svg className="w-4 h-4 text-emerald-600 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8zM6 1v3M10 1v3M14 1v3" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
스타벅스 역삼점
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
카페/간식 • 생활비 통장
</p>
<span className="inline-block mt-1 text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
평행 자산 +1,500원 효과
</span>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-6,500원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
14:20
</p>
</div>
</div>
{/* 마켓컬리 */}
<div className="tx-item flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5" data-category="expense">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 mt-0.5">
<svg className="w-4 h-4 text-blue-600 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
마켓컬리 장보기
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
식비 • 생활비 통장
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-28,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
08:15
</p>
</div>
</div>
{/* 청년도약적금 */}
<div className="tx-item flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5" data-category="savings">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0 mt-0.5 text-teal-600">
<span className="material-symbols-outlined text-[18px]">
savings
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
청년도약적금 자동이체
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-teal-700 bg-teal-50 rounded">
예적금
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
비상금 파킹통장 • 국민은행
</p>
<span className="inline-block mt-1 text-[10px] font-semibold text-teal-600 bg-teal-50 px-1.5 py-0.5 rounded">
목돈 모으기 11회차 달성
</span>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-emerald-600">
+300,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
09:00
</p>
</div>
</div>
{/* 주택청약 */}
<div className="tx-item flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5" data-category="savings">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0 mt-0.5 text-teal-600">
<span className="material-symbols-outlined text-[18px]">
home_work
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
주택청약 종합저축
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-teal-700 bg-teal-50 rounded">
예적금
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
청약통장 • 우리은행
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-emerald-600">
+100,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
09:30
</p>
</div>
</div>
</div>
</div>
</div>
{/* 11월 9일 월요일 Block */}
<div className="space-y-2.5 pt-2">
<div className="flex items-center space-x-2 px-1 pt-1 pb-0.5">
<span className="w-2.5 h-2.5 rounded-full bg-[#3182F6] shrink-0" />
{" "}
<span className="text-[15px] font-bold text-slate-900 leading-none">
11월 9일 월요일
</span>
{" "}
<span className="text-xs font-normal text-slate-400 leading-none ml-1">
내역 2건 · 총 -48,200원
</span>
</div>
<div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3">
<div className="space-y-3">
<div className="tx-item flex items-start justify-between py-1 transition-all" data-category="expense">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 mt-0.5">
<svg className="w-4 h-4 text-blue-600 stroke-[1.8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
올리브영 강남본점
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
생활/쇼핑 • 생활비 통장
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-32,200원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
13:10
</p>
</div>
</div>
<div className="tx-item flex items-start justify-between py-1 transition-all border-t border-slate-50 pt-2.5" data-category="expense">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 mt-0.5">
<span className="material-symbols-outlined text-[18px] text-blue-600">
menu_book
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
교보문고 서적 구매
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-red-500 bg-red-50 rounded">
지출
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
문화/취미 • 체크카드
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-slate-900">
-16,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
18:50
</p>
</div>
</div>
</div>
</div>
</div>
{/* 11월 8일 일요일 Block */}
<div className="space-y-2.5 pt-2">
<div className="flex items-center space-x-2 px-1 pt-1 pb-0.5">
<span className="w-2.5 h-2.5 rounded-full bg-[#3182F6] shrink-0" />
{" "}
<span className="text-[15px] font-bold text-slate-900 leading-none">
11월 8일 일요일
</span>
{" "}
<span className="text-xs font-normal text-slate-400 leading-none ml-1">
수입 1건 · 총 +50,000원
</span>
</div>
<div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_8px_24px_rgba(15,23,42,0.04)] space-y-3">
<div className="space-y-3">
<div className="tx-item flex items-start justify-between py-1 transition-all" data-category="savings">
<div className="flex items-start space-x-3">
<div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5 text-emerald-600">
<span className="material-symbols-outlined text-[18px]">
payments
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 leading-tight">
중고거래 당근마켓 판매
</p>
<span className="px-1.5 py-0.5 text-[9px] font-bold text-emerald-700 bg-emerald-50 rounded">
수입
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
기타수입 • 카카오페이
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-bold text-emerald-600">
+50,000원
</span>
<p className="text-[10px] text-slate-400 mt-0.5">
15:30
</p>
</div>
</div>
</div>
</div>
</div>
</section>
{/* END: Daily Transaction Timeline */}
</div>
{/* END: Scrollable Content Container */}
{/* BEGIN: Interactive Month/Year Bottomsheet Picker Modal */}
<div className="fixed inset-0 z-50 transition-all duration-300 max-w-[390px] mx-auto hidden" id="month-picker-modal">
{/* Backdrop */}
<div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={(event) => run(event, (c) => { c.closeMonthPicker(); })} />
{/* Bottom Sheet Container */}
<div className="fixed bottom-0 left-0 right-0 max-w-[390px] mx-auto bg-white rounded-t-3xl shadow-2xl z-10 p-5 space-y-4 border-t border-slate-100 transform transition-transform duration-300 ease-out max-h-[calc(var(--app-h)*0.85)] overflow-y-auto no-scrollbar">
<div className="w-11 h-1.5 bg-slate-200 rounded-full mx-auto -mt-1" />
<div className="flex items-center justify-between pt-1">
<div className="flex flex-col">
<h3 className="text-base font-bold text-slate-900 tracking-tight">
조회 기간 설정
</h3>
<p className="text-xs text-slate-400 mt-0.5">
가계부를 조회할 기간을 선택하세요
</p>
</div>
<button aria-label="닫기" className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors" onClick={(event) => run(event, (c) => { c.closeMonthPicker(); })} type="button">
<span className="material-symbols-outlined text-[20px]">
close
</span>
</button>
</div>
{/* Mode Switch Tab Buttons: [월별 선택] / [직접 설정] */}
<div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl text-xs font-bold">
<button className="py-2.5 rounded-xl text-slate-500 hover:text-slate-900 font-medium transition-all text-center cursor-pointer" id="picker-tab-month" onClick={(event) => run(event, (c) => { c.switchPickerMode('month'); })} type="button">
월별 선택
</button>
{" "}
<button className="py-2.5 rounded-xl bg-white text-slate-900 shadow-sm transition-all text-center font-bold cursor-pointer" id="picker-tab-custom" onClick={(event) => run(event, (c) => { c.switchPickerMode('custom'); })} type="button">
직접 설정
</button>
</div>
{/* Tab 1: Monthly Grid View */}
<div className="space-y-4 hidden" id="month-grid-container">
<div className="flex items-center justify-between bg-slate-50 rounded-2xl px-4 py-2 border border-slate-100">
<button className="p-1.5 rounded-xl text-slate-600 hover:bg-white hover:text-slate-900 transition-all active:scale-95" onClick={(event) => run(event, (c) => { c.changePickerYear(-1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
chevron_left
</span>
</button>
<div className="flex items-center space-x-1">
<span className="material-symbols-outlined text-[16px] text-blue-600">
calendar_today
</span>
{" "}
<span className="text-base font-bold text-slate-900 tracking-tight" id="picker-current-year">
2026년
</span>
</div>
<button className="p-1.5 rounded-xl text-slate-600 hover:bg-white hover:text-slate-900 transition-all active:scale-95" onClick={(event) => run(event, (c) => { c.changePickerYear(1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
chevron_right
</span>
</button>
</div>
<div className="grid grid-cols-4 gap-2 pt-1" id="picker-month-grid">
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(1); })} type="button">
1월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(2); })} type="button">
2월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(3); })} type="button">
3월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(4); })} type="button">
4월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(5); })} type="button">
5월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(6); })} type="button">
6월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(7); })} type="button">
7월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(8); })} type="button">
8월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(9); })} type="button">
9월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(10); })} type="button">
10월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-bold bg-[#3182F6] text-white shadow-md shadow-blue-500/35 transition-all scale-[1.02] cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(11); })} type="button">
11월
</button>
{" "}
<button className="py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer" onClick={(event) => run(event, (c) => { c.selectPickerMonth(12); })} type="button">
12월
</button>
</div>
<div className="pt-2 flex items-center space-x-2">
<button className="py-3 px-4 bg-slate-100 text-slate-700 font-bold text-xs rounded-2xl hover:bg-slate-200 transition-all active:scale-95 shrink-0" onClick={(event) => run(event, (c) => { c.setPickerToday(); })} type="button">
이번 달
</button>
{" "}
<button className="flex-1 py-3 bg-slate-900 text-white font-bold text-sm rounded-2xl shadow-sm hover:opacity-95 active:scale-[0.99] transition-all" onClick={(event) => run(event, (c) => { c.applyMonthPicker(); })} type="button">
선택 완료
</button>
</div>
</div>
{/* Tab 2: Custom Fintech Range Calendar View */}
<div className="space-y-3.5" id="custom-range-container">
{/* Selected Range Highlight Box: Start & End Card with Active Focus */}
<div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
{/* Start Date Box */}
<button className="flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white shadow-xs border-[#3182F6] ring-2 ring-blue-500/10 cursor-pointer" id="box-start-date" onClick={(event) => run(event, (c) => { c.setSelectingTarget('start'); })} type="button">
<span className="text-[10px] font-bold uppercase tracking-wider text-[#3182F6]" id="label-start-date">
시작일 선택 중
</span>
{" "}
<span className="text-sm font-extrabold text-slate-900 mt-0.5 tracking-tight" id="display-custom-start">
2026.11.01
</span>
</button>
{/* End Date Box */}
<button className="flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white border-transparent hover:border-slate-200 cursor-pointer" id="box-end-date" onClick={(event) => run(event, (c) => { c.setSelectingTarget('end'); })} type="button">
<span className="text-[10px] font-bold uppercase tracking-wider text-slate-400" id="label-end-date">
종료일
</span>
{" "}
<span className="text-sm font-extrabold text-slate-900 mt-0.5 tracking-tight" id="display-custom-end">
2026.11.18
</span>
</button>
</div>
{/* Custom Calendar Header: Year/Month Switcher */}
<div className="flex items-center justify-between px-2 pt-1">
<button className="p-1 rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-all active:scale-95" onClick={(event) => run(event, (c) => { c.changeCustomMonth(-1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
chevron_left
</span>
</button>
{" "}
<span className="text-sm font-bold text-slate-900 tracking-tight" id="custom-cal-header-label">
2026년 11월
</span>
{" "}
<button className="p-1 rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-all active:scale-95" onClick={(event) => run(event, (c) => { c.changeCustomMonth(1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
chevron_right
</span>
</button>
</div>
{/* Calendar Days of Week Header */}
<div className="grid grid-cols-7 text-center text-[11px] font-semibold text-slate-400 pb-1 border-b border-slate-100">
<span className="text-rose-500">
일
</span>
{" "}
<span>
월
</span>
{" "}
<span>
화
</span>
{" "}
<span>
수
</span>
{" "}
<span>
목
</span>
{" "}
<span>
금
</span>
{" "}
<span>
토
</span>
</div>
{/* Custom Calendar Date Grid */}
<div className="grid grid-cols-7 gap-y-1 text-center" id="custom-calendar-grid">
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 right-0 left-1/2 bg-blue-50" />
<button type="button" data-day="1" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all bg-[#3182F6] text-white font-bold shadow-md shadow-blue-500/30 scale-105">
1
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="2" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
2
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="3" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
3
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="4" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
4
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="5" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
5
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="6" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
6
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="7" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
7
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="8" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
8
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="9" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
9
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="10" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
10
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="11" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
11
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="12" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
12
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="13" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
13
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="14" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
14
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="15" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
15
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="16" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
16
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 inset-x-0 bg-blue-50" />
<button type="button" data-day="17" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-700 font-bold hover:bg-blue-100/70">
17
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<div className="absolute inset-y-1 left-0 right-1/2 bg-blue-50" />
<button type="button" data-day="18" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all bg-[#3182F6] text-white font-bold shadow-md shadow-blue-500/30 scale-105">
18
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="19" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
19
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="20" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
20
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="21" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-500 hover:bg-slate-100">
21
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="22" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-rose-500 hover:bg-slate-100">
22
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="23" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
23
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="24" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
24
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="25" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
25
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="26" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
26
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="27" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
27
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="28" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-blue-500 hover:bg-slate-100">
28
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="29" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-rose-500 hover:bg-slate-100">
29
</button>
</div>
<div className="h-9 relative flex items-center justify-center">
<button type="button" data-day="30" className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all text-slate-800 hover:bg-slate-100">
30
</button>
</div>
</div>
{/* Range Length Summary */}
<div className="flex items-center justify-between text-xs px-2 py-1 text-slate-500 bg-slate-50/80 rounded-xl border border-slate-100">
<span className="flex items-center space-x-1">
<span className="material-symbols-outlined text-[15px] text-blue-600">
event_note
</span>
{" "}
<span>
선택 기간
</span>
</span>
{" "}
<span className="font-extrabold text-[#3182F6]" id="custom-range-summary-text">
총 18일간 조회 (11.01 ~ 11.18)
</span>
</div>
{/* Apply Range Button */}
<div className="pt-1">
<button className="w-full py-3.5 bg-[#3182F6] hover:bg-blue-600 active:scale-[0.99] text-white font-bold text-sm rounded-2xl shadow-md shadow-blue-500/30 transition-all text-center flex items-center justify-center space-x-1.5 cursor-pointer" onClick={(event) => run(event, (c) => { c.applyCustomDateRange(); })} type="button">
<span className="material-symbols-outlined text-[18px]">
check_circle
</span>
{" "}
<span>
선택한 기간 적용하기
</span>
</button>
</div>
</div>
</div>
</div>
{/* END: Interactive Month/Year Bottomsheet Picker Modal */}
{/* Interactive Toast Alert */}
<div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 transition-all duration-300 max-w-[340px] w-full px-4 hidden" id="toast-notification">
<div className="bg-slate-900/90 text-white backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-xl flex items-center justify-between text-xs font-medium space-x-2 border border-slate-700/50">
<div className="flex items-center space-x-2 truncate">
<span className="w-2 h-2 rounded-full bg-blue-400 shrink-0 animate-ping" />
{" "}
<span className="truncate" id="toast-text">
무지출 챌린지 5일 달성 완료!
</span>
</div>
<button className="text-slate-400 hover:text-white shrink-0" onClick={(event) => run(event, (c) => { c.hideToast(); })}>
<span className="material-symbols-outlined text-[16px]">
close
</span>
</button>
</div>
</div>
{/* BEGIN: Bottom Fixed Navigation Bar (Identical Layout to SCREEN_19 with '가계부' active) */}
{/* END: Bottom Fixed Navigation Bar */}
</main>
{/* END: Main Mobile Container */}
{/* Interactive Scripts */}
    </div>
  );
}

export default memo(LedgerScreen);
