/* MOA 홈: iOS 스타일, 가계부 공통 상태로 실시간 계산하는 대시보드 */
import { memo, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore, won, skippedTotal } from '../lib/store';
import { beforePayday, cashTimeline, totals, monthlyBudget, dday, md } from '../lib/finance';
import { lessonById, pickToday } from '../lib/learning';
import './Home.css';

const fmt = (n) => Math.round(n).toLocaleString('ko-KR');
const clamp = (n) => Math.max(0, Math.min(100, n));

const PATHS = {
  chevron: <path d="m9 18 6-6-6-6" />,
  arrow: <path d="M5 12h14m-6-6 6 6-6 6" />,
  wallet: <><rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 10h18"/></>,
  journal: <><path d="M7 3.5h11a2 2 0 0 1 2 2v15H7a3 3 0 0 1-3-3v-11a3 3 0 0 1 3-3zm0 0v17m3-12h6m-6 4h6"/></>,
  chart: <><path d="M4 19h16M6 15l4-5 4 3 4-7"/><path d="m15 6 3 0 0 3"/></>,
  bag: <><rect x="4" y="8" width="16" height="13" rx="3"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></>,
  sparkles: <><path d="m12 2 1.7 5.3L19 9l-5.3 1.7L12 16l-1.7-5.3L5 9l5.3-1.7L12 2Z"/><path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></>,
  book: <><path d="M12 6a7 7 0 0 0-8-2v15a7 7 0 0 1 8 2m0-15a7 7 0 0 1 8-2v15a7 7 0 0 0-8 2V6z"/></>,
  shield: <><path d="M12 2.5 20 6v6c0 5-3.4 8.3-8 9.5C7.4 20.3 4 17 4 12V6l8-3.5Z"/><path d="m9 12 2 2 4-4"/></>,
};
function Icon({name, size=20}) { return (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{PATHS[name] || PATHS.chevron}</svg>
); }

const ACTIONS = [
  {label:'소비 기록',to:'/record',icon:'journal',color:'blue'},
  {label:'결제 일정',to:'/bills',icon:'calendar',color:'violet'},
  {label:'금융 실험',to:'/lab',icon:'chart',color:'mint'},
  {label:'살까 말까',to:'/wishlist',icon:'bag',color:'peach'},
];

function HomeScreen() {
  const navigate = useNavigate();
  const state = useStore(s => s);
  const data = useMemo(() => {
    const plan = beforePayday(state);
    const monthly = totals(undefined, state);
    const budget = monthlyBudget(state);
    const events = cashTimeline(40, state);
    const today = pickToday(state, APP_TODAY);
    return { plan, monthly, budget, events, lesson: lessonById(today.id), reason: today.reason,
      pending: state.wishes.filter(w => w.status === 'thinking' || w.status === 'later').length,
      skipped: skippedTotal(state) };
  }, [state]);
  const { plan, monthly, budget, events, lesson, pending, skipped } = data;
  const { finance, profile, learning } = state;
  const dateText = new Intl.DateTimeFormat('ko-KR', {month:'long',day:'numeric',weekday:'long'}).format(new Date(APP_TODAY+'T00:00:00'));
  const usedPct = budget > 0 ? clamp(100 * monthly.expense / budget) : 0;
  const remaining = budget - monthly.expense;
  const shortfall = Math.max(0, -plan.spendable);
  const risk = plan.firstRisk;
  const lessonProgress = lesson ? Math.min(100, 100 * (learning.progress[lesson.id] || 0) / Math.max(1, lesson.cards.length)) : 0;

  return <div className="ios-home">
    <AppHeader profileTo="/more" />
    <div className="ios-home-content">
      <section className="ios-welcome" aria-label="오늘의 금융 상태">
        <p className="ios-welcome-date">{dateText}</p>
        <h1>안녕하세요, {profile.name || '모아'}님 <span aria-hidden="true" className="ios-welcome-star">✳</span></h1>
        <p>오늘의 돈 흐름을 한눈에 살펴봐요.</p>
      </section>

      <section className="ios-account" aria-label="주거래은행 잔액">
        <div className="ios-account-top">
          <div className="ios-bank-meta">
            <span className="ios-bank-icon"><Icon name="wallet" size={22}/></span>
            <span className="ios-bank-info"><span className="ios-bank-overline">주거래은행 · 직접 입력</span><strong>{profile.bank || '내 생활비 통장'}</strong></span>
          </div>
          <button type="button" className="ios-small-link" onClick={() => navigate('/settings')}>관리 <Icon name="chevron" size={14}/></button>
        </div>
        <div className="ios-account-balance">
          <p>현재 통장 잔액</p>
          <div><strong>{fmt(finance.balance)}</strong><span>원</span></div>
        </div>
        <div className="ios-account-divider"/>
        <div className="ios-budget-label"><span>이번 달 생활비</span><strong>{fmt(monthly.expense)} <em>/ {fmt(budget)}원</em></strong></div>
        <div className="ios-budget-track" role="progressbar" aria-label="이번 달 생활비 사용률" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(usedPct)}><span style={{width:usedPct+'%'}}/></div>
        <div className="ios-budget-bottom"><span>예산의 {Math.round(usedPct)}% 사용</span><button type="button" onClick={() => navigate('/budget')}>{remaining>=0 ? `${won(remaining)} 남음` : `${won(-remaining)} 초과`} <Icon name="chevron" size={13}/></button></div>
      </section>

      <section className={'ios-available'+(shortfall?' ios-available-warning':'')} aria-label="현재 지출 여유">
        <span className="ios-orbit ios-orbit-one" aria-hidden="true"/><span className="ios-orbit ios-orbit-two" aria-hidden="true"/>
        <div className="ios-available-top"><Icon name="sparkles" size={17}/> <span>지금 쓸 수 있는 여유</span><span className="ios-available-pill">결제일 반영</span></div>
        <strong className="ios-available-number">{shortfall ? `${fmt(shortfall)}원 부족` : won(Math.max(0,plan.spendable))}</strong>
        <p>{shortfall ? '필수 결제와 최소 잔액을 유지하려면 여유 자금이 부족해요.' : `다음 월급 전 필수 결제 ${won(plan.essential)}와 최소 잔액을 고려했어요.`}</p>
        <button type="button" onClick={() => navigate(shortfall?'/bills':'/world')}>{shortfall?'결제 일정 확인하기':'다른 선택 비교하기'} <Icon name="arrow" size={16}/></button>
      </section>

      <section className="ios-quick" aria-label="자주 사용하는 기능">
        {ACTIONS.map(action => <button type="button" key={action.to} onClick={()=>navigate(action.to)} className="ios-quick-action">
          <span className={'ios-quick-icon ios-color-'+action.color}><Icon name={action.icon} size={23}/></span><span>{action.label}</span>
        </button>)}
      </section>

      <section className="ios-section" aria-label="다가오는 결제 및 입금">
        <div className="ios-section-heading"><div><h2>다가오는 일정</h2><p>앞으로의 입출금을 미리 확인해요</p></div><button type="button" onClick={()=>navigate('/bills')}>전체 <Icon name="chevron" size={15}/></button></div>
        <div className="ios-schedule-card">
          {events.length ? events.slice(0,3).map((event,index) => <button type="button" key={event.date+event.label+index} className="ios-schedule-row" onClick={()=>navigate('/bills')}>
            <span className={'ios-schedule-icon'+(event.risk?' ios-schedule-risk':event.amount>0?' ios-schedule-income':'')}><Icon name={event.kind==='salary'?'wallet':'calendar'} size={19}/></span>
            <span className="ios-schedule-info"><strong>{event.label}</strong><small>{md(event.date)} · {dday(event.date)}{event.risk?' · 잔액 부족 예상':''}</small></span>
            <strong className={'ios-schedule-amount'+(event.amount>0?' ios-money-plus':'')}>{event.amount>0?'+':'-'}{fmt(Math.abs(event.amount))}원</strong>
          </button>):<p className="ios-empty">등록된 일정이 없어요. <button type="button" onClick={()=>navigate('/bills')}>일정 추가</button></p>}
          <p className={'ios-schedule-note'+(risk?' ios-schedule-note-risk':'')}><Icon name={risk?'calendar':'shield'} size={16}/><span>{risk ? `${md(risk.date)} ${risk.label} 이후 최소 잔액을 밑돌 수 있어요.` : '등록된 일정 기준, 다음 월급 전 최소 잔액을 지킬 수 있어요.'}</span></p>
        </div>
      </section>

      <section className="ios-world" aria-label="평행세계 시뮬레이터">
        <div className="ios-world-content"><span className="ios-world-kicker"><Icon name="sparkles" size={14}/> MOA PARALLEL</span><h2>같은 돈,<br/>다른 미래를 만나봐요.</h2><p>구매한 나와 사지 않은 나의<br/>다음 결제일을 비교해요.</p><button type="button" onClick={()=>navigate('/world')}>선택 비교하기 <Icon name="arrow" size={16}/></button></div>
        <div className="ios-world-art" aria-hidden="true"><span className="ios-world-ring"/><span className="ios-world-planet ios-planet-a"/><span className="ios-world-planet ios-planet-b"/><span className="ios-world-spark">✦</span></div>
      </section>

      {lesson && <section className="ios-section" aria-label="오늘의 금융 학습">
        <div className="ios-section-heading"><div><h2>오늘의 작은 배움</h2><p>내 금융 경험에 맞게 하나씩</p></div><button type="button" onClick={()=>navigate('/learn')}>전체 <Icon name="chevron" size={15}/></button></div>
        <button type="button" className="ios-learning" onClick={()=>navigate('/learn/'+lesson.id)}><span className="ios-learning-icon"><Icon name="book" size={24}/></span><span className="ios-learning-content"><small>{learning.done.includes(lesson.id)?'학습 완료':`약 ${lesson.minutes}분 · ${lesson.topic}`}</small><strong>{lesson.title}</strong><span>{data.reason}</span><span className="ios-learning-track"><span style={{width:lessonProgress+'%'}}/></span></span><Icon name="chevron" size={17}/></button>
      </section>}

      {(pending>0 || skipped>0) && <button type="button" className="ios-wishlist" onClick={()=>navigate('/wishlist')}><span className="ios-wishlist-icon"><Icon name="bag" size={19}/></span><span><strong>소비 결정 보관함</strong><small>{pending?`${pending}건 고민 중`:`사지 않은 금액 ${won(skipped)}`}</small></span><Icon name="chevron" size={16}/></button>}
      <p className="ios-footnote"><Icon name="shield" size={15}/> 시연용 서비스예요. 잔액은 직접 입력한 값으로 실제 은행과 연결되지 않았어요.</p>
    </div>
  </div>;
}
export default memo(HomeScreen);
