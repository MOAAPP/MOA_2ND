/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s03 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Home.controller';
import './Home.css';


import { HomeLearnLab } from '../components/MoaWidgets';
import AppHeader from '../components/AppHeader';

function HomeScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {});
  return (
    <div ref={rootRef} className="stitch-screen scr-home bg-[#F1F5F9] text-[#0F172A] min-h-full font-sans antialiased selection:bg-[#3B82F6]/20">
<main className="w-full max-w-[390px] mx-auto min-h-full bg-[#F8FAFC] text-[#0F172A] flex flex-col relative pb-[96px]" style={{ paddingBottom: "96px", minHeight: "calc(var(--app-h) * 1.00)", position: "relative" }}>
{/* 1. HEADER */}
<AppHeader profileTo="/more" />
{/* CONTENT BODY */}
<div className="flex flex-col space-y-4 relative">
{/* Ethereal Light Cosmic Aurora / Orbit Lines (Light Mode Dreamy Parallel Aesthetic) */}
<div className="absolute top-0 left-1/2 -translate-x-1/2 w-[390px] h-[480px] pointer-events-none overflow-hidden z-0">
<div className="absolute -top-16 -left-12 w-[300px] h-[300px] rounded-full bg-gradient-to-br from-teal-300/35 via-cyan-400/25 to-emerald-200/25 blur-[48px]" />
<div className="absolute -top-10 -right-10 w-[320px] h-[320px] rounded-full bg-gradient-to-bl from-indigo-300/35 via-purple-300/25 to-cyan-200/20 blur-[52px]" />
<div className="absolute top-40 left-8 w-[280px] h-[240px] rounded-full bg-gradient-to-tr from-cyan-400/20 via-blue-200/25 to-teal-200/20 blur-[46px]" />
<svg className="absolute top-0 left-1/2 -translate-x-1/2 w-[390px] h-[320px]" fill="none" viewBox="0 0 390 320">
<ellipse cx="195" cy="115" rx="185" ry="72" stroke="url(#orbitGradA)" strokeDasharray="4 4" strokeWidth="1.2" transform="rotate(-12 195 115)" />
<ellipse cx="195" cy="142" rx="165" ry="54" stroke="url(#orbitGradB)" strokeDasharray="3 5" strokeWidth="1" transform="rotate(8 195 142)" />
<ellipse cx="325" cy="58" rx="34" ry="11" stroke="url(#satOrbit)" strokeWidth="1.4" transform="rotate(-18 325 58)" opacity="0.85" />
<circle cx="325" cy="58" r="16" fill="url(#planet3D)" filter="drop-shadow(0 6px 14px rgba(6,182,212,0.4))" />
<ellipse cx="325" cy="58" rx="24" ry="7.5" stroke="rgba(255,255,255,0.7)" strokeWidth="1.2" transform="rotate(-18 325 58)" fill="none" />
<circle cx="320" cy="53" r="3.5" fill="#FFFFFF" opacity="0.55" />
<circle cx="68" cy="105" r="4.5" fill="#2DD4BF" filter="drop-shadow(0 0 6px rgba(45,212,191,0.8))" />
<circle cx="68" cy="105" r="1.8" fill="#FFFFFF" />
<circle cx="145" cy="42" r="2" fill="#38BDF8" opacity="0.75" />
<circle cx="245" cy="180" r="3" fill="#818CF8" opacity="0.8" />
<circle cx="362" cy="112" r="2.5" fill="#34D399" opacity="0.85" />
<path d="M295 24L297 30L303 32L297 34L295 40L293 34L287 32L293 30Z" fill="#38BDF8" opacity="0.75" />
<path d="M88 64L89.5 68L93.5 69.5L89.5 71L88 75L86.5 71L82.5 69.5L86.5 68Z" fill="#2DD4BF" opacity="0.8" />
<defs>
<linearGradient id="orbitGradA" x1="20" y1="30" x2="370" y2="200" gradientUnits="userSpaceOnUse">
<stop stopColor="#00D2D3" stopOpacity="0.6" />
<stop offset="0.5" stopColor="#3B82F6" stopOpacity="0.7" />
<stop offset="1" stopColor="#A855F7" stopOpacity="0.3" />
</linearGradient>
<linearGradient id="orbitGradB" x1="30" y1="70" x2="360" y2="210" gradientUnits="userSpaceOnUse">
<stop stopColor="#10B981" stopOpacity="0.45" />
<stop offset="0.5" stopColor="#06B6D4" stopOpacity="0.65" />
<stop offset="1" stopColor="#6366F1" stopOpacity="0.35" />
</linearGradient>
<linearGradient id="satOrbit" x1="290" y1="50" x2="360" y2="65" gradientUnits="userSpaceOnUse">
<stop stopColor="#38BDF8" stopOpacity="0.9" />
<stop offset="1" stopColor="#C084FC" stopOpacity="0.4" />
</linearGradient>
<radialGradient id="planet3D" cx="35%" cy="35%" r="65%">
<stop offset="0%" stopColor="#A5F3FC" />
<stop offset="25%" stopColor="#38BDF8" />
<stop offset="60%" stopColor="#2563EB" />
<stop offset="90%" stopColor="#7C3AED" />
<stop offset="100%" stopColor="#4C1D95" />
</radialGradient>
</defs>
</svg>
</div>
{/* 1. PARALLEL WORLD BANNER & STATUS CHIP */}
<section className="relative z-10 px-5 pt-3">
{/* 2. STREAMLINED HERO BANK CARD (Clean Light Fintech) */}
<div className="relative overflow-hidden rounded-[26px] p-5 bg-white border border-slate-200/70 shadow-[0_10px_30px_rgba(15,23,42,0.04)] backdrop-blur-xl">
<div className="absolute top-0 right-0 w-36 h-36 bg-gradient-to-bl from-blue-50/70 via-teal-50/30 to-transparent pointer-events-none rounded-tr-[26px]" />
<div className="flex items-center justify-between mb-2 relative z-10">
<div className="flex items-center space-x-2">
<div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-600 to-teal-400 flex items-center justify-center text-white text-[11px] font-black shadow-[0_2px_6px_rgba(37,99,235,0.25)]">
M
</div>
<div className="flex items-center space-x-1.5">
<span className="text-[15px] font-bold text-slate-900">
생활비 통장
</span>
<span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded font-semibold border border-slate-200/50">
메인
</span>
</div>
</div>
<button className="px-2.5 py-1 rounded-[10px] bg-slate-50 hover:bg-slate-100 active:scale-95 text-slate-600 hover:text-slate-900 font-semibold text-[12px] border border-slate-200/80 transition-all flex items-center gap-0.5" data-nav="/bills">
<span>
관리
</span>
<svg className="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M8.25 4.5l7.5 7.5-7.5 7.5" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</button>
</div>
<div className="mb-3.5 relative z-10">
<div className="flex items-baseline space-x-1.5">
<span className="text-[32px] font-black tracking-tight text-slate-900 leading-none">
4,120,300
</span>
<span className="text-[20px] font-bold text-slate-700">
원
</span>
</div>
</div>
<div className="p-3 rounded-[18px] bg-slate-50/90 border border-slate-100/90 relative z-10">
<div className="flex items-center justify-between mb-2">
<span className="text-[12.5px] font-medium text-slate-600">
오늘 쓸 수 있는 여유
</span>
<span className="text-[13.5px] font-bold text-blue-600">
412,300원
</span>
</div>
<div className="w-full h-1.5 rounded-full bg-slate-200/70 overflow-hidden flex mb-2 p-[1px]">
<div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-l-full w-[52%]" />
<div className="h-full bg-emerald-500 w-[33%]" />
<div className="h-full bg-amber-400 rounded-r-full w-[15%]" />
</div>
<div className="flex items-center justify-between text-[10.5px] text-slate-500 font-medium tracking-tight">
<span className="flex items-center space-x-1">
<span className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_4px_rgba(59,130,246,0.5)] shrink-0" />
<span className="truncate">
소비 52% (21.4만)
</span>
</span>
<span className="flex items-center space-x-1">
<span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.5)] shrink-0" />
<span className="truncate">
저축 33% (13.6만)
</span>
</span>
<span className="flex items-center space-x-1">
<span className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_4px_rgba(251,191,36,0.5)] shrink-0" />
<span className="truncate">
투자 15% (6.2만)
</span>
</span>
</div>
</div>
</div>
</section>
{/* 3. AI MORNING BRIEFING (Praised Layout in Crisp Pure White) */}
<section className="px-5 pt-0.5 relative z-10">
<div className="rounded-[24px] bg-white p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] border border-slate-200/70">
{/* Header */}
<div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
<div className="flex items-center space-x-2.5">
<div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-[12px] shrink-0 shadow-[0_2px_6px_rgba(37,99,235,0.3)]">
Y
</div>
<h3 className="text-[16px] font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
모아 모닝 브리핑
</h3>
</div>
<button className="flex items-center text-[11.5px] text-slate-400 hover:text-slate-700 transition-colors font-medium" data-nav="/ledger">
<span>
오늘 08:00 · 내 가계부 기준 {'>'}
</span>
</button>
</div>
{/* 모닝 브리핑 — 의미 없는 장식 점 대신 정보 중심의 행으로 표시 */}
<div className="py-1 divide-y divide-slate-100" aria-label="오늘의 금융 브리핑">
  <div className="flex items-start gap-3 py-3 text-left">
    <span data-briefing-label className="w-[65px] shrink-0 pt-0.5 text-[11px] font-semibold text-slate-500">결제 일정</span>
    <span data-briefing-message className="min-w-0 flex-1 text-[13px] leading-[1.55] text-slate-800 font-medium">
      14일 카드값 날 38,000원이 모자랄 수 있어요
    </span>
  </div>
  <div className="flex items-start gap-3 py-3 text-left">
    <span className="w-[65px] shrink-0 pt-0.5 text-[11px] font-semibold text-slate-500">이번 달</span>
    <span data-briefing-message className="min-w-0 flex-1 text-[13px] leading-[1.55] text-slate-800 font-medium">
      이번 달 예산 사용 현황을 확인해요
    </span>
  </div>
  <div className="flex items-start gap-3 py-3 text-left">
    <span className="w-[65px] shrink-0 pt-0.5 text-[11px] font-semibold text-slate-500">주요 지출</span>
    <span data-briefing-message className="min-w-0 flex-1 text-[13px] leading-[1.55] text-slate-800 font-medium">
      이번 달 지출 기록을 확인해요
    </span>
  </div>
</div>
{/* Bottom CTA Button */}
<div className="pt-1">
<button className="w-full py-3 rounded-[16px] bg-slate-50 hover:bg-slate-100 active:scale-[0.99] text-slate-800 font-bold text-[13.5px] border border-slate-200 transition-all text-center flex items-center justify-center gap-1.5 shadow-xs" data-nav="/world">
<span>
해결 방법 보기
</span>
{" "}
<svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</button>
</div>
</div>
</section>
<HomeLearnLab />
{/* 4. UPCOMING PAYMENTS TIMELINE & SAFETY NET */}
<section className="px-5 pt-0.5">
<div className="flex items-center justify-between mb-2.5 px-1">
<div className="flex items-center space-x-2">
<h3 className="text-[16px] font-bold text-slate-900 tracking-tight">
다가오는 결제
</h3>
<span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 border border-rose-200 text-[10.5px] font-bold">
1건 주의
</span>
</div>
<a className="text-[12px] font-medium text-slate-400 hover:text-slate-700 flex items-center space-x-0.5" href="#" data-nav="/bills">
<span>
전체 일정
</span>
{" "}
<svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
</div>
{/* Horizontal Flowing Timeline Cards */}
<div className="grid grid-cols-3 gap-2">
{/* Step 1: Warning (Card bill) */}
<div className="relative bg-white rounded-[20px] p-3 border border-rose-200 shadow-xs flex flex-col justify-between min-h-[126px] select-none">
<div>
<div className="flex items-center justify-between mb-1.5">
<span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded-md border border-rose-200">
D-1
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_5px_rgba(244,63,94,0.6)]" />
</div>
<span className="text-[11.5px] font-bold text-slate-700 block truncate">
11/14 카드값
</span>
{" "}
<span className="text-[13px] font-black text-rose-600 block mt-0.5">
-290,000
</span>
</div>
<span className="text-[9.5px] font-bold text-rose-600 bg-rose-50/80 border border-rose-200 text-center py-1 rounded-[8px] mt-2">
잔액 부족 예상
</span>
</div>
{/* Step 2: Salary */}
<div className="relative bg-white rounded-[20px] p-3 border border-slate-200/80 shadow-xs flex flex-col justify-between min-h-[126px] select-none">
<div>
<div className="flex items-center justify-between mb-1.5">
<span className="text-[10px] font-bold text-blue-600 bg-blue-50 border border-blue-200 px-1.5 py-0.5 rounded-md">
D-12
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-blue-500" />
</div>
<span className="text-[11.5px] font-bold text-slate-700 block truncate">
11/25 월급
</span>
{" "}
<span className="text-[13px] font-black text-blue-600 block mt-0.5">
+2,450,000
</span>
</div>
<span className="text-[9.5px] font-medium text-slate-500 bg-slate-50 border border-slate-100 text-center py-1 rounded-[8px] mt-2">
정기 입금
</span>
</div>
{/* Step 3: Rent */}
<div className="relative bg-white rounded-[20px] p-3 border border-slate-200/80 shadow-xs flex flex-col justify-between min-h-[126px] select-none">
<div>
<div className="flex items-center justify-between mb-1.5">
<span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-md border border-slate-200/50">
D-18
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-slate-300" />
</div>
<span className="text-[11.5px] font-bold text-slate-700 block truncate">
12/1 월세
</span>
{" "}
<span className="text-[13px] font-black text-slate-900 block mt-0.5">
-520,000
</span>
</div>
<span className="text-[9.5px] font-medium text-slate-500 bg-slate-50 border border-slate-100 text-center py-1 rounded-[8px] mt-2">
자동 이체
</span>
</div>
</div>
{/* Safety Net Info Bar */}
<div className="mt-2.5 p-3 rounded-[16px] bg-sky-50/70 border border-sky-100 flex items-center justify-between text-[12px]">
<div className="flex items-center space-x-2 text-slate-700">
<span className="text-base">
🛡️
</span>
{" "}
<span className="font-medium">
결제 후에도{" "}
<strong className="text-blue-600 font-bold">
비상금 85만원
</strong>
이 안전하게 유지돼요
</span>
</div>
<span className="text-blue-600 font-bold text-[10.5px] px-2 py-0.5 rounded-full bg-white border border-blue-200 shadow-xs shrink-0">
안심 ON
</span>
</div>
</section>
{/* 5. PARALLEL WORLD QUICK ACTIONS & SIMULATOR */}
<section className="px-5 pt-0.5">
<div className="rounded-[24px] bg-white p-4 border border-slate-200/70 shadow-[0_4px_20px_rgba(15,23,42,0.03)]">
{/* 4 Quick Action Ledger Grid */}
<div className="grid grid-cols-4 gap-2 pb-3.5 border-b border-slate-100">
<button className="flex flex-col items-center justify-center p-2 rounded-[14px] active:scale-95 transition-transform group text-center" data-nav="/record?tab=record">
<div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-105 mb-1.5 transition-transform border border-blue-100 shadow-xs">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</div>
<span className="text-[11.5px] font-bold text-slate-700 block text-center">
가계부 쓰기
</span>
</button>
<button className="flex flex-col items-center justify-center p-2 rounded-[14px] active:scale-95 transition-transform group text-center" data-nav="/budget">
<div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-105 mb-1.5 transition-transform border border-indigo-100 shadow-xs">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</div>
<span className="text-[11.5px] font-bold text-slate-700 block text-center">
예산 설정
</span>
</button>
<button className="flex flex-col items-center justify-center p-2 rounded-[14px] active:scale-95 transition-transform group text-center" data-nav="/invest">
<div className="w-10 h-10 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-1.5 border border-rose-100 shadow-xs">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
<path d="M12 3c0 4.97-4.03 9-9 9 4.97 0 9 4.03 9 9 0-4.97 4.03-9 9-9-4.97 0-9-4.03-9-9z" />
</svg>
</div>
<span className="text-[11.5px] font-bold text-slate-700 block text-center">
가상 자산
</span>
</button>
<button className="flex flex-col items-center justify-center p-2 rounded-[14px] active:scale-95 transition-transform group text-center" data-nav="/ledger/report">
<div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 mb-1.5 transition-transform border border-emerald-100 shadow-xs">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M10.5 6a7.5 7.5 0 107.5 7.5h-7.5V6z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
<path d="M13.5 10.5H21A7.5 7.5 0 0013.5 3v7.5z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</div>
<span className="text-[11.5px] font-bold text-slate-700 block text-center">
소비 분석
</span>
</button>
</div>
{/* Parallel Universe Asset Simulator Banner */}
<div className="pt-3 flex items-center justify-between">
<div className="flex items-center space-x-2.5">
<div className="w-9 h-9 rounded-[14px] bg-gradient-to-tr from-blue-600 via-cyan-500 to-teal-400 flex items-center justify-center text-white shrink-0 font-bold shadow-[0_2px_8px_rgba(6,182,212,0.35)]">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[13px] font-bold text-slate-900">
평행세계 시뮬레이터
</span>
</div>
<p className="text-[11.5px] text-slate-500 mt-0.5">
커피 2번 아꼈을 때 평행 자산{" "}
<span className="text-blue-600 font-bold">
+124,000원
</span>
</p>
</div>
</div>
<button className="px-2.5 py-1.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] transition-all shadow-xs shrink-0 active:scale-95" data-nav="/world">
실험하기
</button>
</div>
</div>
</section>
{/* 6. TODAY'S FINANCIAL KNOWLEDGE */}
<section className="px-5 pb-2">
<div className="rounded-[22px] bg-white p-4 border border-slate-200/70 shadow-xs transition-colors cursor-pointer active:scale-[0.99]" data-nav="/savings">
<div className="flex items-center justify-between mb-2">
<span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 border border-blue-200/60 text-[10.5px] font-bold">
🪐 내 평행 행성 키우기
</span>
<span className="text-slate-400 text-[11px] font-semibold">
Lv.3 오아시스 {'>'}
</span>
</div>
<div className="flex items-center space-x-3 pt-1">
<div className="w-10 h-10 rounded-[14px] bg-gradient-to-tr from-cyan-400/20 via-blue-200/25 to-teal-200/20 flex items-center justify-center shrink-0 text-blue-600 border border-cyan-200/60 shadow-xs">
<svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<circle cx="12" cy="12" r="6" strokeWidth="1.8" fill="none" />
<ellipse cx="12" cy="12" rx="10" ry="3.5" strokeWidth="1.5" transform="rotate(-20 12 12)" />
<circle cx="10" cy="10" r="1.5" fill="currentColor" />
</svg>
</div>
<div className="flex-1 min-w-0">
<h4 className="text-[14px] font-bold text-slate-900 leading-snug tracking-tight truncate">
오늘 소비를 아끼면 내 평행 행성이 자라나요
</h4>
<p className="text-[11.5px] text-slate-500 mt-0.5 font-medium flex items-center space-x-1.5">
<span className="text-blue-600 font-semibold">
남은 여유 자산으로 행성 씨앗 심기
</span>
<span className="text-slate-300">
·
</span>
<span className="text-emerald-600 font-medium">
에너지 +20
</span>
</p>
</div>
</div>
</div>
</section>
</div>
{/* 9. BOTTOM TAB BAR (Fixed bottom, exact praised layout with elevated floating + button) */}
</main>
    </div>
  );
}

export default memo(HomeScreen);
