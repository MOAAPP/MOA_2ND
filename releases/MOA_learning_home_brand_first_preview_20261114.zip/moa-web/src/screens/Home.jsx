import { memo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore } from '../lib/store';
import { GENERAL_LESSONS, lessonById, pickToday } from '../lib/learning';
import './Home.css';

const koreanDate = new Intl.DateTimeFormat('ko-KR', {
  month: 'long', day: 'numeric', weekday: 'long',
}).format(new Date(`${APP_TODAY}T00:00:00`));

function Chevron({ size = 18 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6" /></svg>;
}
function Arrow({ size = 18 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14m-6-6 6 6-6 6" /></svg>;
}

// 금융 학습 콘텐츠에 실제로 등장하는 개념을 표지의 큰 글자로 보여줍니다.
// 임의의 3D 이미지나 장식 아이콘, 다른 브랜드의 UI 패턴을 사용하지 않습니다.
function CoverConcept({ lesson }) {
  const concepts = {
    emergency: { headline: '3~6개월', label: '비상금의 기준', foot: '필요할 때 바로 꺼낼 수 있도록' },
    compound: { headline: '이자 + 이자', label: '복리의 원리', foot: '시간이 길어질수록 달라지는 돈' },
    etf: { headline: '하나로\n나눠 담기', label: 'ETF의 구조', foot: '여러 종목에 나눠 투자하는 방법' },
    'order-type': { headline: '시장가\n지정가', label: '주문의 차이', foot: '내가 정한 가격, 지금 체결되는 가격' },
  };
  const concept = concepts[lesson.id] || { headline: '내 돈,\n내 선택', label: lesson.topic, foot: '오늘 알아둘 금융 기본기' };
  return <div className="moa-brand-story-cover" aria-hidden="true">
    <div className="moa-brand-story-cover-top"><span>{lesson.topic}</span><span>{lesson.minutes}분이면 읽어요</span></div>
    <div className="moa-brand-story-concept">
      <small>{concept.label}</small>
      <strong>{concept.headline}</strong>
      <span>{concept.foot}</span>
    </div>
    <div className="moa-brand-story-cover-bottom"><span>모아 금융 공부</span><span className="moa-brand-cover-rule" /></div>
  </div>;
}

function StoryCard({ lesson, featured, reason, done, onOpen }) {
  return <button type="button" className={`moa-brand-story ${featured ? 'moa-brand-story-featured' : ''}`}
    onClick={() => onOpen(`/learn/${lesson.id}`)} aria-label={`${lesson.title} 카드뉴스 읽기`}>
    <CoverConcept lesson={lesson} />
    <div className="moa-brand-story-info">
      <div className="moa-brand-story-meta"><span>{featured ? '오늘 나에게 추천' : '금융 카드뉴스'}</span><span>{done ? '읽음' : `${lesson.cards.length}장`}</span></div>
      <h3>{lesson.title}</h3>
      <p>{lesson.summary}</p>
      <div className="moa-brand-story-bottom"><span>{done ? '다시 읽기' : '카드뉴스 읽기'}</span><Arrow size={17}/></div>
    </div>
  </button>;
}

function HomeScreen() {
  const navigate = useNavigate();
  const state = useStore((current) => current);
  const trackRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const recommended = pickToday(state, APP_TODAY);
  const todayLesson = lessonById(recommended.id) || GENERAL_LESSONS[0];
  const suggested = GENERAL_LESSONS.filter((item) => item.id !== todayLesson.id).slice(0, 3);
  const stories = [todayLesson, ...suggested];
  const done = state.learning.done.includes(todayLesson.id);
  const quizDone = (state.learning.quizDone || []).includes(todayLesson.id);
  const unfinished = state.wishes.filter((item) => item.status === 'thinking' || item.status === 'later').length;
  const reviewRoute = done ? `/learn/${todayLesson.id}/quiz` : `/learn/${todayLesson.id}`;

  const updateActive = () => {
    const track = trackRef.current;
    if (!track || !track.children.length) return;
    const card = track.children[0];
    const extent = card.getBoundingClientRect().width + 12;
    setActiveIndex(Math.min(stories.length - 1, Math.max(0, Math.round(track.scrollLeft / extent))));
  };
  const nextStory = () => {
    const track = trackRef.current;
    if (!track || !track.children.length) return;
    const index = (activeIndex + 1) % stories.length;
    const target = track.children[index];
    track.scrollTo({ left: target.offsetLeft - track.children[0].offsetLeft, behavior: 'smooth' });
    setActiveIndex(index);
  };

  return <div className="moa-brand-home" data-testid="moa-learning-home">
    <AppHeader profileTo="/more" />
    <main className="moa-brand-main">
      <header className="moa-brand-intro">
        <p className="moa-brand-date">{koreanDate}</p>
        <h1>오늘은 이걸<br />배워봐요<span className="moa-brand-title-stop">.</span></h1>
        <p className="moa-brand-intro-sub">내 소비와 학습 기록을 바탕으로<br />오늘 알아두면 좋을 이야기를 골랐어요.</p>
      </header>

      <section className="moa-brand-featured" aria-label="오늘의 맞춤 금융 학습">
        <div className="moa-brand-section-heading">
          <h2>오늘의 카드뉴스</h2>
          <button type="button" onClick={() => navigate('/learn')}>전체 보기 <Chevron size={16}/></button>
        </div>
        <div className="moa-brand-carousel-wrap">
          <div ref={trackRef} className="moa-brand-carousel" onScroll={updateActive} role="group" aria-label="추천 금융 카드뉴스 목록">
            {stories.map((lesson, index) => <StoryCard key={lesson.id} lesson={lesson} featured={index === 0}
              reason={recommended.reason} done={state.learning.done.includes(lesson.id)} onOpen={navigate} />)}
          </div>
        </div>
        <div className="moa-brand-story-status">
          <p><span className="moa-brand-recommend-line" />{recommended.reason}</p>
          <button type="button" aria-label="다음 카드뉴스 보기" onClick={nextStory}>
            <span>{String(activeIndex + 1).padStart(2,'0')} / {String(stories.length).padStart(2,'0')}</span><Arrow size={16}/>
          </button>
        </div>
      </section>

      <section className="moa-brand-continuation" aria-label="배운 내용 이어가기">
        <div className="moa-brand-section-heading"><h2>배운 다음에는</h2></div>
        <button type="button" className="moa-brand-action" onClick={() => navigate(reviewRoute)}>
          <div><span>01 · 학습</span><strong>{quizDone ? '오늘 배운 내용 다시 보기' : done ? '1분 퀴즈로 확인하기' : '오늘의 카드뉴스 읽기'}</strong><p>{quizDone ? '틀린 문제도 다시 복습해 보세요' : done ? '읽은 내용을 한 문제로 확인해요' : '한 장씩 읽고 간단한 문제를 풀어요'}</p></div>
          <span className="moa-brand-action-arrow"><Chevron size={20}/></span>
        </button>
        <button type="button" className="moa-brand-action" onClick={() => navigate('/world')}>
          <div><span>02 · 평행통장</span><strong>내 소비 선택, 미래에서 비교하기</strong><p>같은 돈으로 달라지는 두 가지 미래</p></div>
          <span className="moa-brand-action-arrow"><Chevron size={20}/></span>
        </button>
      </section>

      <section className="moa-brand-more" aria-label="내 금융 생활">
        <div className="moa-brand-section-heading"><h2>내 돈 관리하기</h2></div>
        <div className="moa-brand-shortcuts">
          <button type="button" onClick={() => navigate('/ledger')}><span>가계부</span><strong>이번 달 소비<br/>확인하기</strong><Arrow size={17}/></button>
          <button type="button" onClick={() => navigate(unfinished ? '/wishlist' : '/record')}><span>소비 기록</span><strong>{unfinished ? `${unfinished}건의 고민` : '오늘의 소비'}<br/>{unfinished ? '이어보기' : '기록하기'}</strong><Arrow size={17}/></button>
        </div>
      </section>
      <p className="moa-brand-note">카드뉴스는 앱에 준비된 금융 학습 콘텐츠예요. 추천은 현재 소비·학습 기록을 바탕으로 하며 실시간 AI 생성 콘텐츠는 아니에요.</p>
    </main>
  </div>;
}

export default memo(HomeScreen);
