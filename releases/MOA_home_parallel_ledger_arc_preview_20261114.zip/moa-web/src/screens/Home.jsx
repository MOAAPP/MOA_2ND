/* MOA preview: ledger clarity + parallel-account decisions. */
import { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore, won } from '../lib/store';
import { beforePayday, totals, monthlyBudget, cashTimeline, byCategory, md } from '../lib/finance';
import './Home.css';

const money = (n) => Math.max(0,Math.round(Number.isFinite(n)?n:0)).toLocaleString('ko-KR');
const percent = (spent, limit) => limit > 0 ? Math.round((spent/limit)*100) : 0;
const Arrow = () => <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="18" height="18"><path d="M5 12h14m-6-6 6 6-6 6" /></svg>;
const Chevron = () => <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="18" height="18"><path d="m9 18 6-6-6-6"/></svg>;

function HomeScreen() {
  const navigate = useNavigate();
  const state = useStore((s) => s);
  const expense = totals(undefined, state).expense;
  const budget = monthlyBudget(state);
  const remainingBudget = Math.max(0, budget - expense);
  const over = Math.max(0, expense - budget);
  const ratio = percent(expense, budget);
  const spendable = beforePayday(state).spendable;
  const upcoming = cashTimeline(36, state).find((ev) => ev.kind === 'bill');
  const openWishes = state.wishes.filter((w) => w.status === 'thinking' || w.status === 'later');
  const topExpense = Object.entries(byCategory(undefined, state)).sort((a,b)=>b[1].amount-a[1].amount)[0];
  const month = Number(APP_TODAY.slice(5,7));

  return <div className="moa-preview-home" data-testid="moa-preview-home">
    <AppHeader profileTo="/more" />
    <main className="moa-preview-scroll">
      <div className="moa-preview-intro"><span>내 돈의 오늘과 내일</span><h1>내 돈, 지금 어디쯤 있을까?</h1></div>

      <section className="moa-preview-hero" aria-label="이번 달 남은 생활비">
        <div className="moa-preview-hero-head"><span>{month}월 생활비 현황</span><button type="button" onClick={()=>navigate('/budget')}>예산 관리 <Chevron/></button></div>
        <div className="moa-preview-hero-label">이번 달 {over>0?'예산 초과 금액':'남은 생활비'}</div>
        <div className="moa-preview-hero-value">{money(over>0?over:remainingBudget)}<span>원</span></div>
        <div className="moa-preview-hero-summary">{budget>0? `${ratio}% 사용했어요 · 월 예산 ${won(budget)}`:'예산을 설정하면 남은 금액을 보여드려요.'}</div>
        <div className="moa-preview-meter" role="progressbar" aria-label="이번 달 생활비 사용률" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.min(100,ratio)}><span style={{width:`${Math.max(0,Math.min(100,ratio))}%`}}/></div>
        <div className="moa-preview-ledger-stats"><span><small>지금까지 지출</small><strong>{won(expense)}</strong></span><span><small>월 예산</small><strong>{won(budget)}</strong></span></div>
        <div className="moa-preview-hero-bottom"><span>가계부에서 소비 내역과 사용률을 더 자세히 볼 수 있어요.</span><button onClick={()=>navigate('/ledger')} aria-label="가계부 자세히 보기"><Arrow/></button></div>
      </section>

      <section className="moa-preview-choice" aria-label="평행통장 선택 비교">
        <div className="moa-preview-choice-kicker"><span className="moa-preview-choice-line"/>MOA 평행통장</div>
        <h2>이 돈을 쓰면,<br/>다음 달 나는 어떨까?</h2>
        <p>구매한 나와 사지 않은 나의 잔액을 비교해 보세요. 오늘의 선택이 미래에 남기는 차이를 볼 수 있어요.</p>
        <div className="moa-preview-choice-split" aria-hidden="true"><span>구매한 나</span><i/><span>사지 않은 나</span></div>
        <button type="button" className="moa-preview-choice-cta" onClick={()=>navigate('/world')}>소비 선택 비교하기 <Arrow/></button>
        <button type="button" className="moa-preview-choice-sub" onClick={()=>navigate('/wishlist')}>
          {openWishes.length? `고민 중인 소비 ${openWishes.length}건 이어보기` : '고민 중인 소비 기록하기'} <Chevron/>
        </button>
      </section>

      <section className="moa-preview-quick" aria-label="가계부와 평행통장 빠른 시작">
        <div className="moa-preview-section-heading"><h2>지금 필요한 기능</h2><span>두 가지부터 시작해 보세요</span></div>
        <div className="moa-preview-two-actions">
          <button type="button" onClick={()=>navigate('/record')}><span className="moa-preview-action-label">가계부</span><strong>오늘의 지출<br/>기록하기</strong><small>돈의 흐름 남기기</small><Arrow/></button>
          <button type="button" onClick={()=>navigate('/world')}><span className="moa-preview-action-label">평행통장</span><strong>소비 전후<br/>미래 비교</strong><small>두 가지 미래 확인</small><Arrow/></button>
        </div>
      </section>

      <section className="moa-preview-detail" aria-label="지금 챙길 금융 정보">
        <div className="moa-preview-section-heading"><h2>오늘 확인하면 좋은 것</h2></div>
        <button type="button" className="moa-preview-detail-row" onClick={()=>navigate('/bills')}>
          <span><small>다음 결제 일정</small><strong>{upcoming?`${md(upcoming.date)} ${upcoming.label}`:'등록된 결제 일정이 없어요'}</strong></span>
          <span className="moa-preview-detail-right">{upcoming?won(Math.abs(upcoming.amount)): '추가하기'} <Chevron/></span>
        </button>
        <button type="button" className="moa-preview-detail-row" onClick={()=>navigate('/ledger')}>
          <span><small>이번 달 주요 지출</small><strong>{topExpense?topExpense[0]:'아직 지출 기록이 없어요'}</strong></span>
          <span className="moa-preview-detail-right">{topExpense?won(topExpense[1].amount):'기록하기'} <Chevron/></span>
        </button>
        <button type="button" className="moa-preview-detail-row" onClick={()=>navigate('/world')}>
          <span><small>다음 월급 전 결제·최소 잔액 반영</small><strong>{spendable>=0?'안전하게 쓸 수 있는 돈':'예정 결제 후 부족 예상'}</strong></span>
          <span className={`moa-preview-detail-right ${spendable<0?'is-warning':''}`}>{spendable>=0?won(spendable):`${won(-spendable)} 부족`} <Chevron/></span>
        </button>
      </section>
      <p className="moa-preview-disclaimer">입력한 가상 데이터 기반 시뮬레이션이에요. 실제 은행 계좌와 연결된 금액은 아니에요.</p>
    </main>
  </div>;
}
export default memo(HomeScreen);
