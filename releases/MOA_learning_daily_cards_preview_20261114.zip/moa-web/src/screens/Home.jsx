import { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore, won } from '../lib/store';
import { beforePayday, monthlyBudget, totals } from '../lib/finance';
import { GENERAL_LESSONS, lessonById, pickToday } from '../lib/learning';
import './Home.css';

const clamp = (n) => Math.min(100, Math.max(0, n));
const currency = (n) => Math.round(Math.abs(n || 0)).toLocaleString('ko-KR');
const dateLabel = new Intl.DateTimeFormat('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' }).format(new Date(`${APP_TODAY}T00:00:00`));

function Chevron({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>;
}
function Arrow({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>;
}

function HomeScreen() {
  const navigate = useNavigate();
  const state = useStore((s) => s);
  const budget = monthlyBudget(state);
  const expense = totals(undefined, state).expense;
  const difference = budget - expense;
  const usage = budget > 0 ? Math.round(expense / budget * 100) : 0;
  const safeMoney = beforePayday(state).spendable;
  const recommendation = pickToday(state, APP_TODAY);
  const lesson = lessonById(recommendation.id) || GENERAL_LESSONS[0];
  const finished = state.learning.done.includes(lesson.id);
  const quizFinished = (state.learning.quizDone || []).includes(lesson.id);
  const count = state.learning.progress[lesson.id] || 0;
  const learningPercent = Math.round(clamp(count / Math.max(lesson.cards.length, 1) * 100));
  const moreLessons = GENERAL_LESSONS.filter((item) => item.id !== lesson.id).slice(0, 2);
  const thinking = state.wishes.filter((item) => item.status === 'thinking' || item.status === 'later').length;
  const lessonButtonText = quizFinished ? '다시 읽기' : finished ? '퀴즈 풀러 가기' : count ? '이어서 읽기' : '카드뉴스 읽기';

  return <div className="moa-learning-home" data-testid="moa-learning-home">
    <AppHeader profileTo="/more" />
    <main className="moa-learning-scroll">
      <section className="moa-learning-greeting">
        <p className="moa-learning-date">{dateLabel}</p>
        <div className="moa-learning-greeting-line"><h1>오늘은 이걸 배워봐요</h1><span className="moa-learning-today-count">오늘의 추천 1개</span></div>
        <p className="moa-learning-greeting-sub">내 소비와 학습 기록을 바탕으로 골랐어요.</p>
      </section>

      <section className="moa-learning-balance" aria-label="이번 달 생활비 요약">
        <button type="button" className="moa-learning-balance-content" onClick={() => navigate('/ledger')}>
          <span className="moa-learning-balance-text"><span className="moa-learning-label">이번 달 {difference < 0 ? '예산 초과' : '남은 생활비'}</span><span className="moa-learning-balance-value">{currency(difference)}<small>원</small></span></span>
          <span className="moa-learning-balance-side"><span>가계부</span><Chevron/></span>
        </button>
        <div className="moa-learning-budget-meter" role="progressbar" aria-label="이번 달 예산 사용률" aria-valuemin={0} aria-valuemax={100} aria-valuenow={clamp(usage)}><span style={{ width: `${clamp(usage)}%` }}/></div>
        <p className="moa-learning-balance-foot">월 예산 {won(budget)} 중 {won(expense)} 사용 <span>{usage}%</span></p>
      </section>

      <section className="moa-learning-featured" aria-label="오늘의 맞춤 금융 카드뉴스">
        <div className="moa-learning-section-top"><h2>오늘의 카드뉴스</h2><button type="button" onClick={() => navigate('/learn')}>전체 보기 <Chevron size={15}/></button></div>
        <button type="button" className="moa-learning-cover" onClick={() => navigate(`/learn/${lesson.id}`)} aria-label={`${lesson.title} 카드뉴스 읽기`}>
          <div className="moa-learning-cover-top"><span>MOA FINANCE NOTE</span><span>01 / {String(lesson.cards.length).padStart(2,'0')}</span></div>
          <div className="moa-learning-cover-body">
            <span className="moa-learning-cover-category">{lesson.topic} · {lesson.minutes}분 읽기</span>
            <strong>{lesson.title}</strong>
            <p>{lesson.summary}</p>
          </div>
          <div className="moa-learning-cover-bottom"><span>{lessonButtonText}</span><span className="moa-learning-arrow"><Arrow size={20}/></span></div>
          <div className="moa-learning-cover-number" aria-hidden="true">01</div>
        </button>
        <div className="moa-learning-reason"><span className="moa-learning-reason-label">추천 이유</span><p>{recommendation.reason}</p></div>
        {(count > 0 || quizFinished) && <div className="moa-learning-completion" aria-label="오늘의 학습 진행률"><span>{quizFinished ? '퀴즈까지 완료했어요' : `${lesson.cards.length}장 중 ${Math.min(count, lesson.cards.length)}장 읽었어요`}</span><div><span style={{width:`${quizFinished ? 100 : learningPercent}%`}}/></div></div>}
      </section>

      <section className="moa-learning-more" aria-label="더 읽을 금융 지식">
        <div className="moa-learning-section-top"><h2>다음에 읽을 이야기</h2><button type="button" onClick={() => navigate('/learn')}>금융 학습 <Chevron size={15}/></button></div>
        <div className="moa-learning-more-grid">
          {moreLessons.map((item, index) => <button type="button" className={`moa-learning-more-card more-card-${index + 1}`} key={item.id} onClick={() => navigate(`/learn/${item.id}`)}>
            <span className="moa-learning-more-topic">{item.topic} · {item.minutes}분</span>
            <strong>{item.title}</strong>
            <span className="moa-learning-more-action">읽어보기 <Chevron size={15}/></span>
          </button>)}
        </div>
      </section>

      <section className="moa-learning-apply" aria-label="오늘 배운 것을 금융 생활에 적용하기">
        <div className="moa-learning-section-top"><h2>배운 것을 내 돈에 적용해요</h2></div>
        <button type="button" className="moa-learning-apply-row" onClick={() => navigate('/world')}>
          <span><strong>평행통장</strong><small>같은 돈을 썼을 때와 남겼을 때의 미래 비교</small></span><Chevron/>
        </button>
        <button type="button" className="moa-learning-apply-row" onClick={() => navigate('/record')}>
          <span><strong>오늘의 소비 기록</strong><small>기록으로 나만의 소비 흐름 만들기</small></span><Chevron/>
        </button>
        <button type="button" className="moa-learning-apply-row" onClick={() => navigate('/wishlist')}>
          <span><strong>고민 중인 소비{thinking ? ` · ${thinking}건` : ''}</strong><small>살지 말지 결정하기 전에 비교하기</small></span><Chevron/>
        </button>
        <div className="moa-learning-safe-row"><span>결제일·최소 잔액을 고려하면</span><strong>{safeMoney >= 0 ? `사용 가능 ${won(safeMoney)}` : `${won(-safeMoney)} 부족 예상`}</strong></div>
      </section>
      <p className="moa-learning-disclaimer">현재 시연 버전의 추천은 학습 이력·가상 거래·관심 분야를 반영한 규칙 기반 추천이에요. 카드 콘텐츠는 앱에 저장된 금융 학습 노트이며 AI 실시간 생성 콘텐츠는 아직 연결되지 않았어요. 금액도 실제 은행 계좌와 연동되지 않은 시연 데이터예요.</p>
    </main>
  </div>;
}

export default memo(HomeScreen);
