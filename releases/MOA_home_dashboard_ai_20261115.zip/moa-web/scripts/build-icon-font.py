"""
Regenerates src/assets/fonts/material-symbols-outlined-moa.woff2 with only the icons used in src/.
Usage: pip install fonttools brotli && npm pack material-symbols && tar xzf material-symbols-*.tgz
       python3 scripts/build-icon-font.py package/material-symbols-outlined.woff2
"""
import glob, os, re, sys
from fontTools.ttLib import TTFont
from fontTools import subset

src = sys.argv[1]
font = TTFont(src)
names = set(font.getGlyphOrder())
tokens = set()
for p in glob.glob('src/**/*.*', recursive=True):
    if p.endswith(('.jsx', '.js', '.tsx', '.ts')):
        tokens |= set(re.findall(r'[a-z][a-z0-9_]{2,}', open(p, encoding='utf-8').read()))
icons = {t for t in tokens if t in names}
cmap = font.getBestCmap()
basic = {cmap[c] for c in cmap if chr(c) in '_ ' or chr(c).isascii() and chr(c).isalnum()}
glyphs = icons | {g + '.fill' for g in icons if g + '.fill' in names} | basic | {'.notdef'}
opts = subset.Options(); opts.layout_closure = False; opts.flavor = 'woff2'; opts.layout_features = ['*']; opts.name_IDs = ['*']
s = subset.Subsetter(opts); s.populate(glyphs=sorted(glyphs)); s.subset(font)
os.makedirs('src/assets/fonts', exist_ok=True)
font.save('src/assets/fonts/material-symbols-outlined-moa.woff2')
print(f'{len(icons)} icons ->', os.path.getsize('src/assets/fonts/material-symbols-outlined-moa.woff2'), 'bytes')
