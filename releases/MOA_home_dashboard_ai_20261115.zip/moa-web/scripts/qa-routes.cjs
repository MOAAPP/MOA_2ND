// Checks static route strings in source against routes declared by App.tsx.
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../src');const app=fs.readFileSync(path.join(root,'App.tsx'),'utf8');
const routes=[...app.matchAll(/path="([^"*]+)"/g)].map(x=>x[1]);
const patterns=routes.map(p=>new RegExp('^'+p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/:[a-zA-Z0-9_]+/g,'[^/]+')+'$'));
const invalid=[],seen=[];
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())walk(file);else if(/\.(tsx?|jsx?)$/.test(file)){const code=fs.readFileSync(file,'utf8');let m;const reg=/(?:navigate\s*\(|data-nav=|app\.go\s*\(|profileTo=)\s*[`"'](\/[a-zA-Z0-9/_:-]+)/g;
while((m=reg.exec(code))){const raw=m[1],route=raw.split('?')[0],line=code.slice(0,m.index).split('\n').length;seen.push(raw);if(!patterns.some(r=>r.test(route)) && !(route==='/learn/' && routes.some(r=>r.startsWith('/learn/:'))) && !(path.basename(file)==='useLegacyScreen.js' && route==='/path'))invalid.push(`${path.relative(root,file)}:${line} ${raw}`);}}}}
walk(root);
console.log('ROUTES',routes.length,'static references',seen.length,'unresolved',invalid.length);
invalid.forEach(x=>console.log('FAIL',x));if(invalid.length)process.exitCode=1;
