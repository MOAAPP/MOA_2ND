// Deterministic React component smoke tests without network/npm installs.
// Transpiles actual TSX/JSX and invokes each screen function with a minimal hook and router shim.
// This is NOT a visual browser E2E; it catches render-time exceptions and broken data assumptions.
const fs=require('fs'),path=require('path'),vm=require('vm'),ts=require('typescript');
const root=path.resolve(__dirname,'../src'),cache=new Map();
const noop=()=>{},fakeApp={toast:noop,scroller:()=>null,frame:()=>null};
const react={
 useSyncExternalStore:(_s,read)=>read(),useState:(v)=>[typeof v==='function'?v():v,noop],
 useMemo:(fn)=>fn(),useEffect:noop,useLayoutEffect:noop,useCallback:(fn)=>fn,
 useRef:(v)=>({current:v}),useId:()=>':qa:',useContext:()=>fakeApp,
 createContext:()=>({Provider:({children})=>children}),memo:(x)=>x,forwardRef:(fn)=>fn,
 lazy:(fn)=>function Lazy(){return null;},Suspense:({children})=>children,
 Fragment:Symbol.for('react.fragment'),createElement:(type,props,...children)=>({type,props:{...props,children}})
};
const jsx={jsx:(type,props,key)=>({type,props:props||{},key}),jsxs:(type,props,key)=>({type,props:props||{},key}),Fragment:react.Fragment};
const router={useNavigate:()=>noop,useLocation:()=>({pathname:'/',search:''}),useSearchParams:()=>[new URLSearchParams(''),noop],useParams:()=>({id:'etf'}),Link:'a',NavLink:'a',Navigate:'div',Route:'div',Routes:'div',BrowserRouter:'div'};
const storage={store:{},getItem(k){return this.store[k]||null},setItem(k,v){this.store[k]=v},removeItem(k){delete this.store[k]}};
function load(rel){let file=path.isAbsolute(rel)?rel:path.resolve(root,rel);if(!fs.existsSync(file)){for(const ext of ['.ts','.tsx','.jsx','.js'])if(fs.existsSync(file+ext)){file+=ext;break;}}
 if(/\.(css|woff2|webp|png|jpg|svg)$/.test(file))return file;
 if(cache.has(file))return cache.get(file).exports;
 if(!fs.existsSync(file))throw Error('missing module '+file);
 const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
 const mod={exports:{}};cache.set(file,mod);
 const req=(name)=>name==='react'?react:name==='react/jsx-runtime'?jsx:name==='react-router-dom'?router:name==='three'?{}:name.startsWith('.')?load(path.resolve(path.dirname(file),name)):require(name);
 vm.runInNewContext(code,{module:mod,exports:mod.exports,require:req,localStorage:storage,window:{},navigator:{},URL,URLSearchParams,Date,Math,console,Set,Map,Intl,setTimeout,clearTimeout},{filename:file});return mod.exports;}
const pages=['pages/Onboarding','pages/Lab','pages/WorldChoice','pages/Learn','pages/Wishlist','pages/Bills','pages/Growth','pages/Savings','pages/Agent','pages/Budget','pages/Settings','pages/Notifications','pages/Support','screens/Home','screens/Ledger','screens/Record','screens/World','screens/Invest','screens/Portfolio','screens/More','screens/Report'];
let passed=0,failed=0;
function visit(el,max=30000){let count=0;function walk(n){if(++count>max)throw Error('too many JSX elements');if(n==null||typeof n==='boolean'||typeof n==='string'||typeof n==='number')return;
 if(Array.isArray(n)){n.forEach(walk);return;}if(n.props?.children!==undefined)walk(n.props.children);
 }walk(el);return count;}
for(const p of pages){try{const m=load(p),func=m.default||m.LearnHub;if(typeof func!=='function')throw Error('no React page export');const tree=func({});let elems=visit(tree);if(p==='pages/Learn'){for(const e of ['LessonCards','LessonQuiz']){if(typeof m[e]==='function')elems+=visit(m[e]({}));}}
 console.log('PASS',p,elems,'nodes');passed++;}catch(e){console.log('FAIL',p, e.message);failed++;}}
console.log('RESULT',passed+'/'+(passed+failed));if(failed)process.exitCode=1;
