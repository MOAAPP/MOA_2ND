import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// 로컬 개발: /api/v4 → MOA_2ND_BE(FastAPI, 기본 8000), /api/* → 프론트 Node 서버(기본 8787)
// 배포(Vercel)에서는 vercel.json rewrites가 같은 경로를 처리해요.
const be = process.env.MOA_BE_ORIGIN || 'http://localhost:8000';
const node = process.env.MOA_NODE_ORIGIN || 'http://localhost:8787';
const proxy = {
  '/api/v4': { target: be, changeOrigin: true },
  '/api': { target: node, changeOrigin: true },
};

export default defineConfig({
  plugins: [react()],
  server: { host: true, port: 5173, proxy },
  preview: { proxy },
  build: { chunkSizeWarningLimit: 900 },
});
