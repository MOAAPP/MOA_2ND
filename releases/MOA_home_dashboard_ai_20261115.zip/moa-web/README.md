# 모아 MOA — 웹 앱 (React)

Google Stitch 「모아 Design System Guideboard」에서 고른 화면을 그대로 옮긴 React 앱입니다.
로고, 3D 행성 효과(three.js), 화면별 인터랙션까지 Stitch 디자인과 똑같이 동작하고, Stitch에 없던 화면은 같은 디자인 언어로 새로 만들었습니다.

## 실행

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # dist/ 생성 (타입체크 포함)
```

Vercel에 그대로 올리면 됩니다 (`vercel.json`에 SPA 라우팅 설정 포함).

## 화면 구성

| 경로 | 화면 | 출처 |
|---|---|---|
| `/onboarding` | 온보딩 (서비스 소개 → 월급일·예산 → 통장 연결) | 신규 |
| `/` | 홈 (생활비 통장, 모닝 브리핑, 다가오는 결제) | Stitch 홈 (가상세계 배경 강화) |
| `/ledger` | 가계부 (달력/목록, 기간 설정) | Stitch 가계부 |
| `/ledger/report` | 지출 분석 리포트 (+3D 평행세계 카드) | Stitch 지출 분석 리포트 |
| `/record` | 기록 · 구매 고민하기 (+3D 흡수 연출) | Stitch 구매 고민하기 |
| `/world` | 평행세계 (3D 디지털 트윈, 6개 세계, 미래 비교) | Stitch 평행세계 |
| `/invest` | 가상 거래소 (호가·차트 시트, 체결 팝업) | Stitch 가상 거래소 |
| `/invest/portfolio` | 투자 포트폴리오 | Stitch 포트폴리오 |
| `/savings` | 가상 예·적금 + 행성 키우기 (3D) | 신규 |
| `/more` | 더보기 | Stitch 더보기 |
| `/notifications` | 알림 | 신규 |
| `/budget` | 예산 설정 | 신규 |
| `/settings` | 설정 | 신규 |
| `/support` | 고객센터 · FAQ · 약관 | 신규 |
| `/bills` | 잔액·필수 결제 관리 (부족 위험 타임라인) | 신규 |
| `/wishlist` | 내 소비 결정 보관함 | 신규 |
| `/lab` | 금융 실험실 | 신규 |
| `/learn`, `/learn/:id`, `/learn/:id/quiz` | 오늘의 금융 학습 · 개념 카드 · 퀴즈 | 신규 |
| `/growth` | 나의 금융 성장 기록 (복습 일정·개념별 이해도) | 신규 |

하단 탭: 홈 · 가계부 · (+)기록 · 평행세계 · 더보기. 폰 크기(최대 390px) 전용이라 컴퓨터에서도 가운데에 폰 너비로만 보입니다 (테두리·반응형 없음).

## 폴더

```
src/
  screens/        Stitch 화면 (자동 변환: *.jsx 마크업, *.controller.js 인터랙션, *.css 스코프 스타일)
  pages/          신규 화면 (TypeScript, 직접 작성)
  three/          3D 장면 — WorldTwinScene, ReportPortalScene(Stitch), PlanetGrowthScene(신규)
  components/     탭바, 공통 UI(헤더·카드·토글·바텀시트)
  lib/            앱 상태(store.ts, localStorage), 토스트, Stitch 스크립트 실행 환경
design/stitch/    Stitch에서 내보낸 원본 HTML (화면별)
tools/            Stitch → React 변환기
```

## Stitch 화면을 다시 가져올 때

1. Stitch에서 화면 HTML을 받아 `design/stitch/`의 같은 파일에 덮어씁니다.
2. `npm run stitch` — `src/screens/`가 다시 생성됩니다.
3. 화면 간 이동, 문구 수정, 초기 상태 같은 앱 연결 부분은 `tools/stitch-convert.mjs`의 `SCREENS` 설정(navMap / jsxReplace / patch)에 있어서 재생성해도 유지됩니다.
   → `src/screens/*`를 직접 고치면 다음 변환 때 덮어써지니 설정 쪽을 고쳐주세요.

## 데이터 · 백엔드 연결

- 지금은 `src/lib/store.ts`(브라우저 localStorage)의 공통 상태로 동작합니다. 거래·구매 고민·모의투자·평행세계 실험·학습 기록·잔액·필수 결제가 모두 여기 있어요.
- 합계·결제 일정·쓸 수 있는 여유는 `src/lib/finance.ts` 한 곳에서 계산하고, 홈·가계부·예산·리포트·기록·평행세계가 같은 값을 씁니다.
- 앱의 '오늘'은 `store.ts`의 `APP_TODAY`에서 사용자 로컬 날짜로 계산해요. 초기 가계부 자료는 2026년 11월의 **샘플 데이터**입니다.
- Stitch 화면과 공통 상태 연결은 `src/lib/bridge.js`에 있고, `tools/stitch-convert.mjs`의 `patch`/`codeReplace`에서 불러 씁니다.
- 서버 API가 준비되면 `store.ts`의 `getState/setState`와 각 controller의 초기값을 API 호출로 바꾸면 됩니다.
- 아이콘은 사용하는 것만 담은 Material Symbols 서브셋 폰트(165KB)를 직접 서빙합니다. 새 아이콘을 쓰면 `npm run icons`로 다시 만드세요 (방법은 스크립트 상단 주석).


## 최종 프론트 보완 및 QA (2026-11-14)

- 신용카드 승인·보유 현금 지출은 계좌에서 즉시 출금되지 않음. 사용자가 직접 입력한 새 신용카드 승인액은 다음 **등록된** 카드 결제일에 추가 반영하는 간이 추정 방식임(이용기간/청구 확정값과 다름).
- 실제 구매는 거래 기록으로 연결, 구매 포기·보류는 실제 잔액에 가산하지 않음. 구매 고민의 금액 변경은 연결된 기록에도 적용.
- 평행세계 구매 연기는 오늘 현금이 빠지지 않도록 고쳤고, 미래 구매일 예상 잔액·등록된 일정 기준 위험을 별도로 표시.
- 모의 지정가 주문 예약금과 체결 실제 가상 시세 차액을 정산하고 주문 내역에도 체결가를 기록.
- 더보기의 가상 예적금·모의투자 금액, 구매 포기액, 행성 레벨은 공통 store를 사용. 투자·저축 시나리오 가정 및 위험 성향 설정이 저장됨.
- 금융 실험실에서 직전 거래로 학습 진입 시 주문 ID 전달. 성장 기록의 복습 대상 문항 직접 풀기. 문의는 전송을 가장하지 않고 로컬 초안으로만 저장.
- **가상 시세·가상 수익률·샘플 카드뉴스·오프라인 문의**는 실제 시장 데이터·백엔드 기능과 명확히 구분함.
- `npm run qa:logic`은 상태·재무 로직의 단위 QA를 수행. `npm run build`는 패키지 설치 후 개발 환경에서 실행해 확인해야 함.
- 화면의 Stitch 원본을 다시 변환하면 수동 수정한 `src/screens` 코드가 덮어써질 수 있으니, 이 버전을 기준으로 변경 사항을 보존해야 합니다.
- 자세한 검증과 미연동 범위는 `FRONTEND_QA.md` 참조.


## 코드 실행 기반 QA (2026-11-14)

기획서 대비 프론트 로직 점검 및 수정 결과는 [FRONTEND_QA.md](FRONTEND_QA.md)를 확인하세요.

```bash
npm run qa:all      # 금융/상태 로직 + 초기 렌더 함수 + 라우트 정적 검사
npm run qa:logic    # 회귀 테스트 49개
npm run qa:render   # 컴포넌트 초기 렌더 스모크 20개
npm run qa:routes   # 22개 라우트·89개 정적 이동 참조 검사
```

QA 통과는 이 테스트 범위에만 해당합니다. 실제 브라우저 클릭·반응형·전체 Vite 빌드는 별도 검증 대상입니다.
