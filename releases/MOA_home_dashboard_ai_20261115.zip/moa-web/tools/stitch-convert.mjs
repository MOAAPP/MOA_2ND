// Stitch HTML -> React (JSX markup + legacy controller + scoped CSS)
import { parse } from 'parse5';
import postcss from 'postcss';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const SRC = path.join(ROOT, 'design/stitch');
const OUT = path.join(ROOT, 'src/screens');

// ---------- screen config ----------
const SCREENS = [
  { file: 's03', name: 'Home', appHeader: '/more', scripts: [], drop: [isBottomTabNav],
    navMap: [[/^@알림$/, '/notifications'], [/^@프로필$/, '/more'], [/^관리$/, '/bills'], [/내 가계부 기준/, '/ledger'],
      [/^해결 방법 보기$/, '/world'], [/^전체 일정$/, '/bills'], [/^가계부 쓰기$/, '/record?tab=record'], [/^예산 설정$/, '/budget'],
      [/^가상 자산$/, '/invest'], [/^소비 분석$/, '/ledger/report'], [/^실험하기$/, '/world']],
    jsxReplace: [
      ['<div className="rounded-[22px] bg-white p-4 border border-slate-200/70 shadow-xs transition-colors">', '<div className="rounded-[22px] bg-white p-4 border border-slate-200/70 shadow-xs transition-colors cursor-pointer active:scale-[0.99]" data-nav="/savings">'],
      ["Lv.2 테라 {'>'}", "Lv.3 오아시스 {'>'}"],
      // 오늘의 금융 학습 · 금융 실험실 · 소비 결정 보관함 진입
      ['{/* 4. UPCOMING PAYMENTS TIMELINE & SAFETY NET */}', '<HomeLearnLab />\n{/* 4. UPCOMING PAYMENTS TIMELINE & SAFETY NET */}'],
    ],
    imports: ["import { HomeLearnLab } from '../components/MoaWidgets';"],
    patch: `
  // MOA: 잔액·여유·브리핑·결제 일정을 공통 금융 상태로 표시 (src/lib/bridge.js homeBridge)
  const __home = app.moa.homeBridge({ document });
  document.addEventListener('DOMContentLoaded', () => __home.init());
` },
  { file: 's02', name: 'More', appHeader: '/settings', scripts: ['b1d139'], drop: [isBottomTabNav],
    imports: ["import { ProfileName, WishBadge } from '../components/MoaWidgets';"],
    jsxReplace: [['Lv.4 사파이어 탐험가', 'Lv.3 오아시스 탐험가'], ['김모아 님', '<ProfileName />'], ['3건 보류', '<WishBadge />'],
      ['냉정 쿨다운 타이머', '구매·보류·포기 결정'], ['10월 소비 카테고리', '이번 달 소비 카테고리'], ['가상 복리 시뮬레이션', '저장한 미래 비교']],
    // 핵심 카드 4개에 실제 이동 연결
    jsxRegex: [
      [/(\{\/\* Item 1: Parallel Universe Asset Vault \*\/\}\n<div [^>]*?)role="button">/, '$1role="button" data-nav="/world?view=E">'],
      [/(\{\/\* Item 2: Monthly Expenditure Report \*\/\}\n<div [^>]*?)role="button">/, '$1role="button" data-nav="/ledger/report">'],
      [/(\{\/\* Item 3: Purchase Wishlist \(Pending\) \*\/\}\n<div [^>]*?)role="button">/, '$1role="button" data-nav="/wishlist">'],
      [/(\{\/\* Item 4: Zero-Spend Challenge Status \*\/\}\n<div [^>]*?)role="button">/, '$1role="button" data-nav="/ledger">'],
    ],
    navMap: [[/^@알림$/, '/notifications'], [/^@설정$/, '/settings'], [/^@프로필 정보 보기$/, '/settings'], [/내 프로필 및 연결 계좌/, '/settings'],
      [/^상세 〉$/, '/savings'], [/^운용 〉$/, '/invest'], [/연결된 계좌/, '/settings'], [/카테고리 \/ 예산/, '/budget'], [/정기 결제/, '/bills'],
      [/내보내기/, '/settings'], [/행성 테마/, '/savings'], [/고객센터/, '/support'], [/자주 묻는/, '/support'], [/공지사항/, '/notifications'],
      [/^로그아웃$/, '/onboarding'], [/^이용약관$/, '/support'], [/^개인정보처리방침$/, '/support']] },
  { file: 's09', name: 'Ledger', appHeader: '/more', scripts: ['6ed5fe', '897027'], drop: [isBottomTabNav], links: { SCREEN_1: '/ledger/report' },
    navMap: [[/^@내 프로필$/, '/more']],
    // 직접 설정 탭의 빠른 선택 칩(최근 7일·이번 달·지난 달·최근 30일) 제거 — 월별 선택 탭과 겹치고 화면이 복잡해짐
    jsxRegex: [[/\{\/\* Quick Preset Chips \*\/\}\n<div className="flex items-center space-x-1\.5 overflow-x-auto no-scrollbar py-0\.5">[\s\S]*?<\/div>\n/, '']],
    patch: `
  // MOA: 직접 기록한 내역을 달력·목록·합계에 반영 (src/lib/bridge.js ledgerBridge)
  const __led = app.moa.ledgerBridge({
    document, app, root, data: calendarTxMockData,
    get: { day: () => currentSelectedCalDay, filter: () => currentFilter, year: () => currentSelectedYear, month: () => currentSelectedMonth,
      rangeStart: () => rangeStartDate, rangeEnd: () => rangeEndDate, target: () => selectingTarget },
    set: { day: (d) => { currentSelectedCalDay = d; } },
    orig: { renderCalendarDayDetails, filterCategory, applyMonthPicker, applyCustomDateRange, onDateCellClick, setSelectingTarget, updateRangeBoxUI },
  });
  renderCalendarDayDetails = __led.api.renderCalendarDayDetails; filterCategory = __led.api.filterCategory;
  applyMonthPicker = __led.api.applyMonthPicker; applyCustomDateRange = __led.api.applyCustomDateRange;
  onDateCellClick = __led.api.onDateCellClick; setSelectingTarget = __led.api.setSelectingTarget; updateRangeBoxUI = __led.api.updateRangeBoxUI;
  document.addEventListener('DOMContentLoaded', () => __led.init());
` },
  { file: 's11', name: 'Report', scripts: ['380f91', 'cadf43', 'a12745'], drop: [isThreeWrapper], links: { SCREEN_10: -1 },
    patch: `
  showToast = (m) => app.toast(m || '완료했어요');
  // MOA: 가계부 직접 기록을 합계·카테고리에 반영 (src/lib/bridge.js reportBridge)
  const __rep = app.moa.reportBridge({ document, meta: categoryMeta, tabs: tabConfig, orig: { updateDonutCenter } });
  updateDonutCenter = __rep.api.updateDonutCenter;
  document.addEventListener('DOMContentLoaded', () => __rep.init());
`,
    imports: ["import ReportPortalScene from '../three/ReportPortalScene';"],
    jsxReplace: [['text-white relative overflow-hidden" data-purpose="parallel-savings-simulator">', 'text-white relative overflow-hidden isolate" data-purpose="parallel-savings-simulator">\n<ReportPortalScene className="absolute -right-20 -top-12 w-[300px] h-[260px] opacity-70 pointer-events-none -z-10" />']],
    navMap: [[/커피 2회 절약/, '/invest', 'div'], [/배달 1회 절약/, '/savings', 'div'], [/^수입 /, '/ledger', 'div']] },
  { file: 's04', name: 'Portfolio', scripts: ['380f91', 'ee413f'], drop: [], links: { SCREEN_10: -1 },
    patch: `
  showToast = (m) => app.toast(m || '완료했어요');
  // MOA: 보유 현황·목표 비중 저장 (src/lib/bridge.js portfolioBridge)
  const __pf = app.moa.portfolioBridge({ document, orig: { openAddAssetModal, updateSliderVal, applyRebalance, closeRebalanceModal, showToast } });
  openAddAssetModal = __pf.api.openAddAssetModal; updateSliderVal = __pf.api.updateSliderVal; applyRebalance = __pf.api.applyRebalance;
  document.addEventListener('DOMContentLoaded', () => __pf.init());
`,
    jsxReplace: [['11월 지출 분석', '투자 포트폴리오'], ['가계부 화면으로 돌아가기', '거래소로 돌아가기']] },
  { file: 's06', name: 'Invest', scripts: ['fbd079', '746489', 'd6513a'], drop: [], links: { SCREEN_10: -1 },
    navMap: [[/방어머니 내역/, '/invest/portfolio'], [/^@알림$/, '/notifications']],
    jsxReplace: [
      ['transition-opacity duration-300 flex items-end justify-center" id="order-modal-backdrop"', 'transition-opacity duration-300 flex items-end justify-center opacity-0 pointer-events-none" id="order-modal-backdrop"'],
      ['overflow-hidden transform translate-y-0 transition-transform duration-300" id="order-modal-content"', 'overflow-hidden transform translate-y-full transition-transform duration-300" id="order-modal-content"'],
      ['justify-center px-5 transition-opacity duration-300" id="order-complete-modal"', 'justify-center px-5 transition-opacity duration-300 hidden" id="order-complete-modal"'],
      ["c.showToast('종목 검색창을 열었습니다');", 'c.openStockSearch();'],
    ],
    jsxRegex: [
      [/(<div className="w-full bg-slate-50 rounded-2xl p-3\.5 mt-4 mb-5 border border-slate-100 text-left space-y-2 text-xs">)[\s\S]*?<\/div>\n(<div className="w-full space-y-2">)/,
        '$1\n<div className="flex justify-between"><span className="text-slate-500">체결 수량</span><b className="text-slate-900" id="complete-shares">1주</b></div>\n<div className="flex justify-between"><span className="text-slate-500">체결 금액</span><b className="text-slate-900" id="complete-amount">62,100원</b></div>\n<div className="flex justify-between"><span className="text-slate-500">사용한 자금</span><b className="text-blue-600">방어 머니</b></div>\n</div>\n$2'],
      // 주문 방식(시장가/지정가) 선택 + 주문 제한 안내
      [/(\{\/\* 주문 수량 조절 및 방어머니 연동 주문 패널 \(항상 유지\) \*\/\}\n<div className="bg-white rounded-2xl p-3\.5 border border-slate-200\/70 shadow-xs space-y-2\.5">)/,
        '$1\n<div className="flex items-center justify-between text-xs">\n<span className="font-bold text-slate-700">주문 방식</span>\n<div className="flex bg-slate-100 rounded-lg p-0.5 text-[11px] font-bold">\n<button className="px-2.5 py-1 rounded-md bg-white text-slate-900 shadow-xs" id="btn-type-market" onClick={(event) => run(event, (c) => { c.setOrderType(\'market\'); })} type="button">시장가</button>\n<button className="px-2.5 py-1 rounded-md text-slate-500" id="btn-type-limit" onClick={(event) => run(event, (c) => { c.setOrderType(\'limit\'); })} type="button">지정가</button>\n</div>\n</div>\n<div className="hidden items-center justify-between text-xs" id="limit-price-row">\n<span className="font-bold text-slate-700">지정 가격</span>\n<div className="flex items-center gap-1">\n<button className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700" id="limit-minus" type="button" aria-label="50원 내리기">−</button>\n<input className="w-24 h-8 text-center rounded-lg border border-slate-200 font-bold tabular-nums text-sm outline-none focus:border-blue-500" id="limit-price-input" inputMode="numeric" aria-label="지정 가격" />\n<button className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700" id="limit-plus" type="button" aria-label="50원 올리기">+</button>\n<span className="text-slate-500 ml-0.5">원</span>\n</div>\n</div>'],
      [/(\{\/\* Fixed Bottom Dual Action Order Buttons \*\/\}\n<div className="p-3\.5 bg-white border-t border-slate-100 flex items-center space-x-2 shrink-0">)\n<button className="flex-1 /,
        '<p className="hidden px-4 pt-2 text-[11.5px] font-semibold text-rose-500 bg-white" id="order-limit-hint" />\n$1\n<button id="btn-quick-sell" className="disabled:cursor-not-allowed flex-1 '],
      [/<button className="flex-\[1\.5\] py-3\.5 bg-rose-500/, '<button id="btn-quick-buy" className="disabled:cursor-not-allowed flex-[1.5] py-3.5 bg-rose-500'],
      // 차트 기간 버튼(1일·1주·1달·1년) 동작
      [/<button className="px-2 py-0\.5 rounded bg-slate-900 text-white text-\[11px\]" type="button">\n1일\n<\/button>/, '<button className="px-2 py-0.5 rounded bg-slate-900 text-white text-[11px]" data-chart-range="1d" type="button">\n1일\n</button>'],
      [/<button className="px-2 py-0\.5 rounded text-slate-500 hover:text-slate-900 text-\[11px\]" type="button">\n1주\n<\/button>/, '<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1w" type="button">\n1주\n</button>'],
      [/<button className="px-2 py-0\.5 rounded text-slate-500 hover:text-slate-900 text-\[11px\]" type="button">\n1달\n<\/button>/, '<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1m" type="button">\n1달\n</button>'],
      [/<button className="px-2 py-0\.5 rounded text-slate-500 hover:text-slate-900 text-\[11px\]" type="button">\n1년\n<\/button>/, '<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1y" type="button">\n1년\n</button>'],
      [/(<span className="text-\[11px\] text-rose-500 font-bold tabular-nums")>\n최고 62,600 \/ 최저 61,200/, '$1 id="chart-hilo">\n최고 62,600 / 최저 61,200'],
      [/(<div className="w-full h-44 relative flex items-center justify-center bg-slate-50\/50 rounded-xl overflow-hidden p-1">\n<svg className="w-full h-full")/, '$1 id="stock-chart-svg"'],
      // 매수 후 '이번 거래로 배우기'
      [/(<button className="w-full py-2\.5 text-slate-500 hover:text-slate-800 text-xs font-semibold rounded-xl transition-all" onClick=\{\(event\) => run\(event, \(c\) => \{ c\.closeCompleteModal\(\); \}\)\} type="button">\n계속 거래하기)/,
        '<button className="w-full py-3.5 bg-slate-900 active:scale-[0.98] text-white font-extrabold rounded-2xl text-[14px] transition-all flex items-center justify-center gap-1.5" id="complete-learn-btn" data-nav="/learn" type="button">\n<span className="material-symbols-outlined text-[18px]">school</span>\n<span>이번 거래로 배우기</span>\n</button>\n$1'],
    ],
    patch: `
  // MOA: 보유 수량·방어 머니·주문 내역을 공통 상태로 관리 (src/lib/bridge.js investBridge)
  const __inv = app.moa.investBridge({
    document, app, root, setInterval,
    get: { order: () => ({ mode: currentOrderMode, shares: orderShares, type: orderType }), stock: () => currentStock },
    set: { cash: (v) => { defenseMoney = v; }, mode: (m) => { currentOrderMode = m; } },
    orig: { openOrderModal, updateOrderSummary, setOrderType, closeOrderModal, openCompleteModal, showToast },
  });
  openOrderModal = __inv.api.openOrderModal; updateOrderSummary = __inv.api.updateOrderSummary; setOrderType = __inv.api.setOrderType;
  submitVirtualOrder = __inv.api.submitVirtualOrder; executeOrderQuick = __inv.api.executeOrderQuick;
  function openStockSearch() { __inv.api.openStockSearch(); }
  const __goToExecutionHistory = goToExecutionHistory;
  goToExecutionHistory = function () {
    __goToExecutionHistory();
    const b = document.getElementById('order-modal-backdrop'), ct = document.getElementById('order-modal-content');
    b.classList.remove('opacity-0', 'pointer-events-none'); b.classList.add('opacity-100');
    ct.classList.remove('translate-y-full'); ct.classList.add('translate-y-0');
  };
  try { delete globalThis.window.executeOrderQuick; } catch (e) {}
  document.addEventListener('DOMContentLoaded', () => __inv.init());
` },
  { file: 's07', name: 'World', appHeader: '/more', scripts: ['b6ed53'], drop: [isBottomTabNav], replaceThree: { 'threejs-container-ANIMATION_147': 'WorldTwinScene' },
    jsxReplace: [
      ['Lv.4 사파이어 행성', 'Lv.3 오아시스 행성'],
      // 검증되지 않은 수치·표현 정리
      ['+107.2% 가치 보존', '+7.2% (연 7.2% 가정)'],
      ['충동 68% 방어 성공', '구매 전까지 받은 이자만 남아요'],
      ['신뢰도 98.4%', '수익률은 가정값이에요'],
      ['✨ AI 진단 완료 (지출 성향 정밀 매칭)', '입력한 조건으로 계산했어요'],
      ['AI 미래 진단받기 (1.5초)', '내 조건으로 진단받기'],
      ['카드 결제일, 비상금 목표, 최근 30일 지출 속도를 종합 분석해 최적의 선택을 안내합니다.', '이번 달 필수 결제와 선택한 경로를 바탕으로 쓸 수 있는 현금과 위험을 정리해 드려요.'],
      ['이 미래 계획을 내 MOA 예산에 저장하기', '이 실험을 보관함에 저장하기'],
      ['터치 한 번으로 해당 금액의 미래를 다시 시뮬레이션합니다.', '저장한 실험을 다시 불러와 비교할 수 있어요.'],
      ['1년 차 (만기 결실)', '1년 차'],
    ],
    jsxRegex: [
      [/(rounded-md font-semibold")>\n1년 후 예상 자산\n/, '$1 id="b-hero-horizon">\n1년 후 예상 자산\n'],
      [/(<span className="text-\[#4E5968\] font-medium")>\n1년 후 총자산/, '$1 id="td-horizon-label">\n1년 후 총자산'],
      [/(<span className="text-\[10px\] font-bold text-\[#059669\]")>\n1년 차/, '$1 id="tl-horizon">\n1년 차'],
    ],
    patch: `
  // MOA: 기간·조건 반영 계산, 보관함 저장 (src/lib/bridge.js worldBridge)
  const __world = app.moa.worldBridge({
    document, app, root, meta: worldMeta,
    get: { amount: () => currentAmount, years: () => selectedYears, selected: () => selectedWorldId, compare: () => compareTargetWorldId },
    set: { amount: (v) => { currentAmount = v; } },
    orig: { reloadSavedExperiment, switchView, chooseWorld, onCompareTargetChange, setTimeHorizonYears },
  });
  calculateWorldAssets = __world.api.calculateWorldAssets; refreshCalculations = __world.api.refreshCalculations;
  updateViewBHero = __world.api.updateViewBHero; updateComparisonView = __world.api.updateComparisonView;
  triggerAiCoaching = __world.api.triggerAiCoaching; savePlanToBudget = __world.api.savePlanToBudget; handleRecordAdd = __world.api.handleRecordAdd;
  const __chooseWorld = chooseWorld;
  chooseWorld = function (id) { __chooseWorld(id); refreshCalculations(); };
  const __onCompare = onCompareTargetChange;
  onCompareTargetChange = function (v) { __onCompare(v); refreshCalculations(); };
  window.addEventListener('DOMContentLoaded', () => __world.init());
` },
  { file: 's08', name: 'Record', scripts: ['640594', 'dee09c'], drop: [isBottomTabNav],
    // 기준 잔액·필수 결제·최소 잔액은 공통 금융 상태(필수 결제 관리 화면)에서 가져옴
    codeReplace: [
      ['const BASE_BALANCE = 420000;', 'const __fin = app.moa.financeSnapshot();\n  const BASE_BALANCE = __fin.balance;'],
      ['const ESSENTIAL_SCHEDULED = 121887;', 'const ESSENTIAL_SCHEDULED = __fin.essential;'],
      ['const MIN_BASELINE = 100000;', 'const MIN_BASELINE = __fin.minBalance;'],
    ],
    jsxReplace: [
      ['pb-32 transition-opacity duration-300 hidden" id="formScreen"', 'pb-32 transition-opacity duration-300" id="formScreen"'],
      ['pb-20 transition-opacity duration-300" id="ledgerScreen"', 'pb-20 transition-opacity duration-300 hidden" id="ledgerScreen"'],
      ['🪐 MOA 평행세계 포털 연동 중', '🪐 평행세계로 옮기는 중'],
      ['모아 홈 화면으로 전환 중... (3.8초)', '잠시 후 평행세계로 이동해요'],
      ['확인하고 모아 홈으로 이동 →', '평행세계에서 비교하기 →'],
      // 구매 포기(사지 않을래요) 연출 문구 — 실제 잔액에 더해지지 않는다는 점을 분명히
      ['{" "}소비 방어 성공!', '{" "}지켜냈어요!'],
      ['평행세계 통장에 적립 완료! 259,000원이 가상 투자 자산으로 무사히 흡수되었습니다.', '실제 잔액은 그대로예요. 이 돈을 저축하거나 투자했다면 어떻게 달라지는지 평행세계에서 비교해 볼게요.'],
      ['누적 방어 자산\n</span>', '지금까지 참은 금액\n</span>'],
      ['평행 복리 예측{" "}', '1년 뒤 가정 평가액{" "}'],
      ['(연 7.2%)\n</span>', '(연 7.2% 가정)\n</span>'],
      ['통장 잔액에서 차감되지 않으며, [구매 고민 탭]에서 언제든 확인할 수 있어요.', '통장 잔액에서 차감되지 않아요. 담은 뒤 구매·보류·포기를 정할 수 있어요.'],
    ],
    // 고민 목록 바로가기
    jsxRegex: [[/(<span id="considerCtaText">\n[^\n]*\n<\/span>\n<\/button>)/, '$1\n<button className="mt-2 text-[12px] font-semibold text-blue-600 underline underline-offset-2" data-nav="/wishlist" type="button">\n내 소비 결정 보관함 보기\n</button>']],
    patch: `
  // MOA: this screen is the "기록" page. Leaving it goes back to the real ledger / parallel world screens.
  returnToLedgerView = function (message) {
    const m = message || '';
    if (/돌아왔|취소/.test(m)) return app.go('back');
    app.go(/평행세계/.test(m) ? '/world' : '/ledger');
  };
  returnToFormView = function () {};
  // MOA: 공통 상태 연결 (src/lib/bridge.js recordBridge)
  const __toast = showToast; let __mute = false;
  showToast = function (m, i) { if (!__mute) __toast(m, i); };
  const __rec = app.moa.recordBridge({
    document, app,
    mute: (fn) => { __mute = true; try { fn(); } finally { __mute = false; } },
    get: { considerAmount: () => currentConsiderAmount, expenseAmount: () => currentExpenseAmount, dateUndecided: () => isConsiderDateUndecided, savedDate: () => lastSavedConsiderDate },
    set: { expenseAmount: (v) => { currentExpenseAmount = v; } },
    orig: { selectRecordType, selectRecordCategory, selectRecordPayment, selectConsiderCategory, selectConsiderPayment, selectNecessity, updateExpenseState, submitConsideration, switchTab, showToast: __toast,
      clearCelebrationTimer: () => { if (fullscreenTransitionTimer) { clearTimeout(fullscreenTransitionTimer); fullscreenTransitionTimer = null; } } },
  });
  selectRecordType = __rec.api.selectRecordType; selectRecordCategory = __rec.api.selectRecordCategory; selectRecordPayment = __rec.api.selectRecordPayment;
  selectConsiderCategory = __rec.api.selectConsiderCategory; selectConsiderPayment = __rec.api.selectConsiderPayment; selectNecessity = __rec.api.selectNecessity;
  updateExpenseState = __rec.api.updateExpenseState; submitRecord = __rec.api.submitRecord; submitConsideration = __rec.api.submitConsideration;
  finishCelebrationAndReturn = __rec.api.finishCelebrationAndReturn;
  document.addEventListener('DOMContentLoaded', () => {
    const tab = new URLSearchParams(app.search || '').get('tab');
    if (tab === 'record') { __mute = true; switchTab('record'); __mute = false; }
    __rec.init();
  });
  cleanup.add(() => {
    try { if (absorptionAnimId) globalThis.cancelAnimationFrame(absorptionAnimId); } catch (e) {}
    try { if (absorptionRenderer) { absorptionRenderer.dispose(); absorptionRenderer.forceContextLoss && absorptionRenderer.forceContextLoss(); } } catch (e) {}
  });
`,
    navMap: [[/^@알림$/, '/notifications'], [/분석리포트/, '/ledger/report'], [/평행행성/, '/savings']] },
];

function attr(n, k) { return (n.attrs || []).find(a => a.name === k)?.value; }
function cls(n) { return attr(n, 'class') || ''; }
function isBottomTabNav(n) {
  if (n.nodeName !== 'nav') return false;
  const c = cls(n);
  return /fixed/.test(c) && /bottom-0/.test(c);
}
function isThreeWrapper(n) {
  return n.nodeName === 'div' && (n.childNodes || []).some(c => attr(c, 'id')?.startsWith('threejs-container-ANIMATION'));
}

// ---------- helpers ----------
const SVG_ATTR = {
  'stroke-width': 'strokeWidth', 'stroke-linecap': 'strokeLinecap', 'stroke-linejoin': 'strokeLinejoin',
  'stroke-dasharray': 'strokeDasharray', 'stroke-dashoffset': 'strokeDashoffset', 'stroke-miterlimit': 'strokeMiterlimit',
  'stroke-opacity': 'strokeOpacity', 'fill-rule': 'fillRule', 'clip-rule': 'clipRule', 'fill-opacity': 'fillOpacity',
  'stop-color': 'stopColor', 'stop-opacity': 'stopOpacity', 'clip-path': 'clipPath', 'text-anchor': 'textAnchor',
  'dominant-baseline': 'dominantBaseline', 'font-size': 'fontSize', 'font-weight': 'fontWeight', 'font-family': 'fontFamily',
  'xlink:href': 'xlinkHref', 'xml:space': 'xmlSpace', 'xmlns:xlink': 'xmlnsXlink', 'vector-effect': 'vectorEffect',
  'shape-rendering': 'shapeRendering', 'color-interpolation-filters': 'colorInterpolationFilters', 'flood-color': 'floodColor',
  'flood-opacity': 'floodOpacity', 'letter-spacing': 'letterSpacing', 'paint-order': 'paintOrder', 'mask-type': 'maskType',
};
const HTML_ATTR = {
  class: 'className', for: 'htmlFor', tabindex: 'tabIndex', readonly: 'readOnly', maxlength: 'maxLength', minlength: 'minLength',
  colspan: 'colSpan', rowspan: 'rowSpan', autocomplete: 'autoComplete', inputmode: 'inputMode', contenteditable: 'contentEditable',
  spellcheck: 'spellCheck', enterkeyhint: 'enterKeyHint', autofocus: 'autoFocus', crossorigin: 'crossOrigin', frameborder: 'frameBorder',
  allowfullscreen: 'allowFullScreen', novalidate: 'noValidate', srcset: 'srcSet', datetime: 'dateTime', autoplay: 'autoPlay',
  playsinline: 'playsInline', 'accept-charset': 'acceptCharset', viewbox: 'viewBox', preserveaspectratio: 'preserveAspectRatio',
};
const EVENT_ATTR = { onclick: 'onClick', oninput: 'onInput', onchange: 'onChange', onkeyup: 'onKeyUp', onkeydown: 'onKeyDown', onsubmit: 'onSubmit', onfocus: 'onFocus', onblur: 'onBlur', onmouseover: 'onMouseOver', onmouseenter: 'onMouseEnter', onmouseleave: 'onMouseLeave', ontouchstart: 'onTouchStart', onscroll: 'onScroll' };
const BOOL_ATTR = new Set(['disabled', 'checked', 'selected', 'readonly', 'required', 'multiple', 'hidden', 'autofocus', 'novalidate', 'open']);
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr']);
const INLINE = new Set(['span', 'b', 'strong', 'a', 'em', 'i', 'small', 'sup', 'sub', 'label', 'br', 'u', 'mark', 'code', 'img', 'svg', 'button', 'input', 'select']);

const JS_GLOBALS = new Set(['parseInt', 'parseFloat', 'Number', 'String', 'Math', 'Boolean', 'isNaN', 'setTimeout', 'if', 'for', 'while', 'switch', 'return', 'function', 'typeof', 'new', 'Date', 'JSON', 'Array', 'Object', 'encodeURIComponent']);

// fix classes for phone-frame app
function fixClass(c) {
  // Stitch frames each screen as a bordered card for desktop preview — the app frame already does that
  const isScreenWrapper = /max-w-\[(390|420|430|480)px\]/.test(c) && /min-h-(screen|full|\[100dvh\])|h-screen|h-\[100dvh\]/.test(c);
  return c.split(/\s+/).filter(Boolean)
    .filter(t => !isScreenWrapper || !/^(border|border-x|border-y|border-(slate|gray)-\d+(\/\d+)?|shadow-2xl|shadow-xl|sm:.*)$/.test(t))
    .filter(t => !/^(sm|md|lg|xl|2xl):/.test(t))
    .map(t => t
      .replace(/^min-h-screen$/, 'min-h-full')
      .replace(/^h-screen$/, 'h-full')
      .replace(/^h-\[100dvh\]$/, 'h-full')
      .replace(/^min-h-\[100dvh\]$/, 'min-h-full')
      .replace(/\[(\d+(?:\.\d+)?)d?vh\]/g, (_, v) => `[calc(var(--app-h)*${(+v / 100).toFixed(2)})]`)
    ).join(' ');
}

function styleToObj(s) {
  const out = [];
  for (const decl of s.split(';')) {
    const i = decl.indexOf(':');
    if (i < 0) continue;
    let k = decl.slice(0, i).trim(); let v = decl.slice(i + 1).trim();
    if (!k) continue;
    v = v.replace(/(\d+(?:\.\d+)?)d?vh/g, (_, n) => `calc(var(--app-h) * ${(+n / 100).toFixed(2)})`);
    const key = k.startsWith('--') ? JSON.stringify(k) : k.replace(/^-ms-/, 'ms-').replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    out.push(`${key}: ${JSON.stringify(v)}`);
  }
  return `{{ ${out.join(', ')} }}`;
}

const handlerNames = new Set();
function convertHandler(code) {
  let c = code.trim().replace(/;\s*$/, '');
  c = c.replace(/window\.location\.href\s*=\s*'\{\{DATA:SCREEN:(\w+)\}\}'/g, "c.__nav('$1')");
  c = c.replace(/\bthis\b/g, 'event.currentTarget');
  // prefix bare calls
  c = c.replace(/(^|[^.\w$])([A-Za-z_$][\w$]*)\s*\(/g, (m, pre, name) => {
    if (JS_GLOBALS.has(name) || name === 'c') return m;
    handlerNames.add(name);
    return `${pre}c.${name}(`;
  });
  // bare identifiers like `event` stay
  return `{(event) => run(event, (c) => { ${c}; })}`;
}

function escText(t) {
  return t.replace(/[{}<>]/g, ch => `{'${ch}'}`);
}

let logoUsed = false;
function convertNode(n, ctx, depth, siblings, idx) {
  if (n.nodeName === '#comment') {
    const d = n.data.trim().replace(/\*\//g, '* /');
    if (!d || d.startsWith('STITCH_THREEJS')) return '';
    return `{/* ${d} */}`;
  }
  if (n.nodeName === '#text') {
    const v = n.value;
    if (!v.trim()) {
      const prev = siblings[idx - 1], next = siblings[idx + 1];
      if (prev && next && INLINE.has(prev.nodeName) && INLINE.has(next.nodeName) && v.length) return '{" "}';
      if (prev && next && (prev.nodeName === '#text' || next.nodeName === '#text')) return '{" "}';
      return '';
    }
    const collapsed = v.replace(/\s+/g, ' ');
    const lead = /^\s/.test(v) && idx > 0;
    const trail = /\s$/.test(v) && idx < siblings.length - 1;
    let body = collapsed.trim();
    let out = escText(body);
    if (lead) out = '{" "}' + out;
    if (trail) out = out + '{" "}';
    return out;
  }
  const tag = n.nodeName;
  if (['script', 'style', 'link', 'meta', 'title', 'head'].includes(tag)) return '';
  if (tag === 'svg' && cls(n).includes('inline-defs-container') && !(n.childNodes || []).length) return '';
  for (const d of ctx.drop) if (d(n)) return '';
  const id = attr(n, 'id');
  if (id && ctx.replaceThree?.[id]) {
    ctx.usedComponents.add(ctx.replaceThree[id]);
    return `<${ctx.replaceThree[id]} className="w-full h-full" />`;
  }
  if (tag === 'template') return '';
  if (tag === 'header' && ctx.appHeader && !ctx.headerDone) {
    ctx.headerDone = true;
    ctx.usedHeader = true;
    return `<AppHeader profileTo=${JSON.stringify(ctx.appHeader)} />`;
  }
  let navTo = null;
  if ((tag === 'button' || tag === 'a' || tag === 'div') && ctx.navMap) {
    const t = textOf(n).replace(/\s+/g, ' ').trim();
    const al = attr(n, 'aria-label') || '';
    for (const [re, to, tagOnly] of ctx.navMap) {
      if (tagOnly && tagOnly !== tag) continue;
      if (tag === 'div' && (tagOnly !== 'div' || t.length > 90 || !/cursor-pointer/.test(cls(n)))) continue;
      if (re.test(t) || (al && re.test('@' + al))) { navTo = to; break; }
    }
  }

  const parts = [];
  let isSelectWithSelected = null;
  if (tag === 'select') {
    const sel = (n.childNodes || []).find(o => o.nodeName === 'option' && (o.attrs || []).some(a => a.name === 'selected'));
    if (sel) isSelectWithSelected = attr(sel, 'value') ?? sel.childNodes?.map(x => x.value || '').join('').trim();
  }
  for (const a of n.attrs || []) {
    let k = a.name; let v = a.value;
    if (EVENT_ATTR[k]) { parts.push(`${EVENT_ATTR[k]}=${convertHandler(v)}`); continue; }
    if (k.startsWith('on')) continue;
    if (k === 'style') { if (v.trim()) parts.push(`style=${styleToObj(v)}`); continue; }
    if (k === 'class') { const fc = fixClass(v); if (fc) parts.push(`className=${JSON.stringify(fc)}`); continue; }
    if (tag === 'img' && k === 'src' && /lh3\.googleusercontent\.com/.test(v)) { logoUsed = true; parts.push('src={logoUrl}'); continue; }
    if (tag === 'option' && k === 'selected') continue;
    if ((tag === 'input' || tag === 'textarea') && k === 'value') { parts.push(`defaultValue=${JSON.stringify(v)}`); continue; }
    if (tag === 'input' && k === 'checked') { parts.push('defaultChecked'); continue; }
    if (SVG_ATTR[k]) k = SVG_ATTR[k];
    else if (HTML_ATTR[k]) k = HTML_ATTR[k];
    else if (k.includes(':')) continue;
    if (BOOL_ATTR.has(a.name) && (v === '' || v === a.name)) { parts.push(k); continue; }
    if (k === 'href' && v.includes('{{DATA:SCREEN')) { parts.push(`href="#"`); continue; }
    parts.push(`${k}=${JSON.stringify(v)}`);
  }
  if (navTo) { const i = parts.findIndex(p => p.startsWith('onClick=')); if (i >= 0) parts.splice(i, 1); parts.push(`data-nav=${JSON.stringify(navTo)}`); }
  if (isSelectWithSelected != null) parts.push(`defaultValue=${JSON.stringify(isSelectWithSelected)}`);
  if (tag === 'textarea') {
    const txt = (n.childNodes || []).map(x => x.value || '').join('');
    if (txt) parts.push(`defaultValue=${JSON.stringify(txt)}`);
    return `<textarea ${parts.join(' ')} />`;
  }
  const open = `<${tag}${parts.length ? ' ' + parts.join(' ') : ''}`;
  const kids = n.content ? n.content.childNodes : (n.childNodes || []);
  if (VOID.has(tag) || !kids.length) return `${open} />`;
  const inner = kids.map((c, i) => convertNode(c, ctx, depth + 1, kids, i)).filter(Boolean).join('\n');
  if (!inner.trim()) return `${open} />`;
  return `${open}>\n${inner}\n</${tag}>`;
}

function textOf(n) { return n.nodeName === '#text' ? n.value : (n.childNodes || []).map(textOf).join(' '); }
function findNode(n, t) { if (n.nodeName === t) return n; for (const c of n.childNodes || []) { const r = findNode(c, t); if (r) return r; } }
function collect(n, t, acc = []) { if (n.nodeName === t) acc.push(n); for (const c of n.childNodes || []) collect(c, t, acc); return acc; }

function scopeCss(css, scope) {
  const root = postcss.parse(css);
  root.walkRules(rule => {
    if (rule.parent && rule.parent.type === 'atrule' && /keyframes/.test(rule.parent.name)) return;
    rule.selectors = rule.selectors.map(sel => {
      sel = sel.trim();
      if (/^(html|body|:root)$/.test(sel)) return `.${scope}`;
      if (/^(html|body)\s*,/.test(sel)) return `.${scope}`;
      const m = sel.match(/^(html|body)([.#:\[].*|\s+.*)$/);
      if (m) return /^\s/.test(m[2]) ? `.${scope}${m[2]}` : `.${scope}${m[2]}`;
      if (sel.startsWith('*')) return `.${scope} ${sel}`;
      return `.${scope} ${sel}`;
    });
  });
  root.walkAtRules('import', r => r.remove());
  root.walkDecls(d => { d.value = d.value.replace(/(\d+(?:\.\d+)?)d?vh/g, (_, n) => `calc(var(--app-h) * ${(+n / 100).toFixed(2)})`); });
  return root.toString();
}

function scriptBodies(fileHtml, wanted) {
  const all = [...fileHtml.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  return all;
}

import crypto from 'crypto';
function h6(s) { return crypto.createHash('md5').update(s).digest('hex').slice(0, 6); }

fs.mkdirSync(OUT, { recursive: true });
const report = [];
for (const sc of SCREENS) {
  handlerNames.clear(); logoUsed = false;
  const html = fs.readFileSync(path.join(SRC, sc.file + '.html'), 'utf8');
  const doc = parse(html);
  const body = findNode(doc, 'body');
  const scope = `scr-${sc.name.toLowerCase()}`;
  const ctx = { appHeader: sc.appHeader, navMap: sc.navMap, drop: sc.drop, replaceThree: sc.replaceThree, usedComponents: new Set() };
  const kids = body.childNodes;
  let jsx = kids.map((c, i) => convertNode(c, ctx, 1, kids, i)).filter(Boolean).join('\n');
  for (const [from, to] of sc.jsxReplace || []) {
    if (!jsx.includes(from)) console.warn('!! jsxReplace miss', sc.name, from.slice(0, 60));
    jsx = jsx.replace(from, to);
  }
  for (const [re, to] of sc.jsxRegex || []) {
    if (!re.test(jsx)) console.warn('!! jsxRegex miss', sc.name, String(re).slice(0, 60));
    jsx = jsx.replace(re, to);
  }
  // css
  const styles = collect(doc, 'style').map(s => s.childNodes.map(x => x.value).join('')).filter(t => !/\*\s*\{\s*margin:\s*0;\s*padding:\s*0;/.test(t)).join('\n');
  fs.writeFileSync(path.join(OUT, `${sc.name}.css`), `/* scoped from Stitch ${sc.file} */\n` + scopeCss(styles, scope));
  // scripts
  const bodies = scriptBodies(html);
  const chosen = [];
  for (const b of bodies) { const h = h6(b); if (sc.scripts.includes(h)) chosen.push(b); }
  // dedupe same hash order per config
  const ordered = sc.scripts.map(h => bodies.find(b => h6(b) === h)).filter(Boolean);
  let code = ordered.join('\n\n/* ---- */\n\n');
  // codeReplace: Stitch 스크립트 안의 고정값을 앱 상태로 바꿀 때 사용
  for (const [from, to] of sc.codeReplace || []) {
    if (!code.includes(from)) console.warn('!! codeReplace miss', sc.name, from.slice(0, 60));
    code = code.split(from).join(to);
  }
  // exported fn names: declared functions
  const declared = new Set([...(code + '\n' + (sc.patch || '')).matchAll(/(?:^|\n)\s{0,4}(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/g)].map(m => m[1]));
  for (const m of code.matchAll(/(?:^|\n)\s{0,4}(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/g)) declared.add(m[1]);
  const exportNames = [...new Set([...declared, ...handlerNames])];
  const missing = [...handlerNames].filter(n => !declared.has(n));
  const ctrl = `/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen ${sc.file}. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);

${code}
${sc.patch || ''}
  const api = {};
${exportNames.map(n => `  if (typeof ${n} === 'function') api.${n} = ${n};`).join('\n')}
  return { api, cleanup };
}
`;
  fs.writeFileSync(path.join(OUT, `${sc.name}.controller.js`), ctrl);
  const bodyCls = fixClass(cls(body));
  const bodyStyle = attr(body, 'style');
  const imports = [...ctx.usedComponents].map(c => `import ${c} from '../three/${c}';`).join('\n');
  const comp = `/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen ${sc.file} — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './${sc.name}.controller';
import './${sc.name}.css';
${logoUsed ? "import logoUrl from '../assets/moa-logo.webp';" : ''}
${imports}
${(sc.imports || []).join('\n')}
${ctx.usedHeader ? "import AppHeader from '../components/AppHeader';" : ''}

function ${sc.name}Screen() {
  const { rootRef, run } = useLegacyScreen(mount, ${JSON.stringify(sc.links || {})});
  return (
    <div ref={rootRef} className=${JSON.stringify(`stitch-screen ${scope} ${bodyCls}`.trim())}${bodyStyle ? ` style=${styleToObj(bodyStyle)}` : ''}>
${jsx}
    </div>
  );
}

export default memo(${sc.name}Screen);
`;
  fs.writeFileSync(path.join(OUT, `${sc.name}.jsx`), comp);
  report.push({ screen: sc.name, jsxBytes: jsx.length, js: code.length, handlers: handlerNames.size, missing });
}
console.log(JSON.stringify(report, null, 1));
