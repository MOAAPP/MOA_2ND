/** @type {import('tailwindcss').Config} */
// Theme merged from every Stitch screen config (모아 Design System Guideboard).
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Pretendard Variable"', 'Pretendard', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'Roboto', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', 'sans-serif'],
      },
      colors: {
        brand: {
          DEFAULT: '#3182F6', primary: '#3182F6', light: '#E8F3FF', dark: '#1B64DA', subtle: '#F2F8FF',
          mint: '#10B981', cyan: '#06B6D4', surface: '#FFFFFF', bgLight: '#F8FAFC',
          textPrimary: '#0F172A', textSecondary: '#475569', textMuted: '#94A3B8', cardBorder: '#E2E8F0',
        },
        moa: {
          title: '#191F28', body: '#4E5968', caption: '#8B95A1', border: '#F2F4F6', bg: '#F8FAFC', card: '#FFFFFF',
          blue: '#3182F6', lightBlue: '#E8F3FF', navy: '#191F28', slate: '#333D4B', grayDark: '#4E5968', sub: '#8B95A1',
          green: '#059669', emeraldBg: '#ECFDF5', amber: '#D97706', rose: '#F04452', deepBlue: '#1D4ED8', mint: '#00D09E',
          emerald: '#10B981', dark: '#0F172A', muted: '#64748B', lightMuted: '#94A3B8', bgLight: '#F8FAFC', red: '#EF4444',
        },
        toss: {
          blue: '#3182F6', blueDark: '#1B64DA', lightBlue: '#E8F3FF',
          gray50: '#F9FAFB', gray100: '#F2F4F6', gray200: '#E5E8EB', gray300: '#D1D6DB', gray400: '#B0B8C1',
          gray500: '#8B95A1', gray600: '#6B7684', gray700: '#4E5968', gray800: '#333D4B', gray900: '#191F28',
          teal: '#00B493', red: '#F04452', redLight: '#FEECEE', blueStock: '#3182F6', blueStockLight: '#EFF5FF',
        },
        tossBlue: '#3182F6',
        tossBg: '#F2F4F6',
      },
      boxShadow: {
        card: '0 2px 14px 0 rgba(0, 0, 0, 0.04)',
        floating: '0 8px 24px -4px rgba(49, 130, 246, 0.35)',
        bottomNav: '0 -1px 8px rgba(0, 0, 0, 0.03)',
        order: '0 -4px 20px 0 rgba(0, 0, 0, 0.08)',
        subtle: '0 2px 10px rgba(0, 0, 0, 0.03)',
      },
    },
  },
  plugins: [],
};
