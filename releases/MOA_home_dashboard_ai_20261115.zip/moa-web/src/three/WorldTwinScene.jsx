// @ts-nocheck
// 3D scene ported from the Stitch design (three.js). Mounted/unmounted with the component.
import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export function mountWorldTwinScene(containerEl) {

  // Three.js Scene: Elegant Financial Digital Twin Holographic Planet & Divergence Orbits
const width = containerEl.clientWidth || 390;
const height = containerEl.clientHeight || 260;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
camera.position.set(0, 0.2, 8.8);

const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "high-performance" });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
containerEl.appendChild(renderer.domElement);

// Clean Studio Lighting for FinTech Trust
const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
scene.add(ambientLight);

const mainKeyLight = new THREE.DirectionalLight(0x3b82f6, 2.8);
mainKeyLight.position.set(5, 6, 8);
scene.add(mainKeyLight);

const rimLight = new THREE.PointLight(0x06b6d4, 2.2, 25);
rimLight.position.set(-6, -3, 6);
scene.add(rimLight);

const softWarmFill = new THREE.PointLight(0x818cf8, 1.5, 20);
softWarmFill.position.set(0, -4, 4);
scene.add(softWarmFill);

// Main Core Group
const twinGroup = new THREE.Group();
twinGroup.position.set(0, 0.05, 0);
scene.add(twinGroup);

// 1. Crystal Sapphire Core (Clean FinTech Identity)
const coreGeo = new THREE.SphereGeometry(1.42, 48, 48);
const coreMat = new THREE.MeshPhongMaterial({
  color: 0x1e40af,
  emissive: 0x1d4ed8,
  specular: 0x93c5fd,
  shininess: 90,
  transparent: true,
  opacity: 0.94
});
const corePlanet = new THREE.Mesh(coreGeo, coreMat);
twinGroup.add(corePlanet);

// 2. Latitude/Longitude Digital Twin Wire Grid (Subtle, High-tech FinTech Blueprint)
const wireGeo = new THREE.SphereGeometry(1.58, 24, 24);
const wireMat = new THREE.MeshBasicMaterial({
  color: 0x60a5fa,
  wireframe: true,
  transparent: true,
  opacity: 0.32
});
const wirePlanet = new THREE.Mesh(wireGeo, wireMat);
twinGroup.add(wirePlanet);

// 3. Glowing Atmospheric Aura
const auraGeo = new THREE.SphereGeometry(1.78, 32, 32);
const auraMat = new THREE.MeshBasicMaterial({
  color: 0xbfdbfe,
  transparent: true,
  opacity: 0.12
});
const auraMesh = new THREE.Mesh(auraGeo, auraMat);
twinGroup.add(auraMesh);

// 4. Divergence Trajectory Rings (2 Intersecting Financial Worlds: Current Decision & Future Orbit)
const ring1Geo = new THREE.TorusGeometry(2.35, 0.024, 16, 80);
const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.8 });
const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
ring1.rotation.x = Math.PI / 3.2;
ring1.rotation.y = 0.2;
twinGroup.add(ring1);

const ring2Geo = new THREE.TorusGeometry(2.7, 0.018, 16, 80);
const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x818cf8, transparent: true, opacity: 0.65 });
const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
ring2.rotation.x = -Math.PI / 4;
ring2.rotation.z = Math.PI / 6;
twinGroup.add(ring2);

// 5. Orbiting Capital Gold Orbs (Digital Twin Savings & Asset Points)
const orbs = [];
const orbGeo = new THREE.SphereGeometry(0.13, 16, 16);
const orbMat = new THREE.MeshPhongMaterial({
  color: 0xf59e0b,
  emissive: 0xd97706,
  shininess: 95
});

for (let i = 0; i < 6; i++) {
  const orb = new THREE.Mesh(orbGeo, orbMat);
  const angle = (i / 6) * Math.PI * 2;
  orb.userData = {
    angle: angle,
    radius: 2.35,
    speed: 0.012 + (i % 2) * 0.004,
    yOffset: Math.sin(angle) * 0.35
  };
  twinGroup.add(orb);
  orbs.push(orb);
}

// 6. Minimal Clean Floating Sparkles
const particleCount = 45;
const partGeo = new THREE.BufferGeometry();
const partPositions = new Float32Array(particleCount * 3);
for (let i = 0; i < particleCount * 3; i += 3) {
  partPositions[i] = (Math.random() - 0.5) * 12;
  partPositions[i + 1] = (Math.random() - 0.5) * 8;
  partPositions[i + 2] = (Math.random() - 0.5) * 6;
}
partGeo.setAttribute('position', new THREE.BufferAttribute(partPositions, 3));
const partMat = new THREE.PointsMaterial({
  color: 0x93c5fd,
  size: 0.09,
  transparent: true,
  opacity: 0.55
});
const particles = new THREE.Points(partGeo, partMat);
scene.add(particles);

// Interaction: Smooth Mouse/Touch Reaction
let targetRotX = 0;
let targetRotY = 0;
function onPointerMove(e) {
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const clientY = e.touches ? e.touches[0].clientY : e.clientY;
  const rect = containerEl.getBoundingClientRect();
  const x = ((clientX - rect.left) / (rect.width || 390)) * 2 - 1;
  const y = -(((clientY - rect.top) / (rect.height || 260)) * 2 - 1);
  targetRotY = x * 0.45;
  targetRotX = -y * 0.35;
}
window.addEventListener('mousemove', onPointerMove, { passive: true });
window.addEventListener('touchmove', onPointerMove, { passive: true });

// Animation Loop
let animId;
let clock = new THREE.Clock();

function animate() {
  animId = requestAnimationFrame(animate);
  const time = clock.getElapsedTime();

  // Subtle natural twin rotation
  corePlanet.rotation.y += 0.005;
  wirePlanet.rotation.y -= 0.003;
  wirePlanet.rotation.x = Math.sin(time * 0.5) * 0.08;

  // Gentle breathing scale
  const breathe = 1.0 + Math.sin(time * 1.8) * 0.025;
  corePlanet.scale.set(breathe, breathe, breathe);

  // Smooth pointer following
  twinGroup.rotation.y += (targetRotY - twinGroup.rotation.y) * 0.05;
  twinGroup.rotation.x += (targetRotX - twinGroup.rotation.x) * 0.05;

  ring1.rotation.z += 0.006;
  ring2.rotation.z -= 0.005;

  // Orbiting Asset Orbs
  orbs.forEach((orb) => {
    orb.userData.angle += orb.userData.speed;
    orb.position.x = Math.cos(orb.userData.angle) * orb.userData.radius;
    orb.position.z = Math.sin(orb.userData.angle) * orb.userData.radius;
    orb.position.y = Math.sin(orb.userData.angle * 2 + time) * 0.35;
  });

  particles.rotation.y = time * 0.015;

  renderer.render(scene, camera);
}
animate();

// Resize
function onResize() {
  const newWidth = containerEl.clientWidth || 390;
  const newHeight = containerEl.clientHeight || 260;
  camera.aspect = newWidth / newHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(newWidth, newHeight);
}
window.addEventListener('resize', onResize);

return () => {
  cancelAnimationFrame(animId);
  window.removeEventListener('resize', onResize);
  window.removeEventListener('mousemove', onPointerMove);
  window.removeEventListener('touchmove', onPointerMove);
  renderer.dispose(); renderer.forceContextLoss && renderer.forceContextLoss();
  if (containerEl.contains(renderer.domElement)) {
    containerEl.removeChild(renderer.domElement);
  }
};

}

export default function WorldTwinScene({ className = '', style = undefined }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let dispose;
    try { dispose = mountWorldTwinScene(el); } catch (e) { console.warn('[moa] 3D unavailable', e); }
    return () => { if (typeof dispose === 'function') dispose(); };
  }, []);
  return <div ref={ref} className={className} style={{ ...style }} aria-hidden="true" />;
}
