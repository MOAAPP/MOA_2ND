// @ts-nocheck
// "내 행성" — grows with virtual savings/investment. Same visual language as the Stitch digital-twin planet.
import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function PlanetGrowthScene({ growth = 0.3, orbs = 3, className = '', style = undefined }) {
  const ref = useRef(null);
  const live = useRef({ growth, orbs });
  live.current = { growth, orbs };

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    } catch (e) {
      console.warn('[moa] WebGL unavailable', e);
      return;
    }
    const w = el.clientWidth || 350, h = el.clientHeight || 260;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 100);
    camera.position.set(0, 0.4, 9.2);
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    el.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const key = new THREE.DirectionalLight(0x3b82f6, 2.6); key.position.set(5, 6, 8); scene.add(key);
    const rim = new THREE.PointLight(0x06b6d4, 2.0, 25); rim.position.set(-6, -3, 6); scene.add(rim);
    const fill = new THREE.PointLight(0x818cf8, 1.4, 20); fill.position.set(0, -4, 4); scene.add(fill);

    const group = new THREE.Group();
    scene.add(group);

    const core = new THREE.Mesh(
      new THREE.SphereGeometry(1, 48, 48),
      new THREE.MeshPhongMaterial({ color: 0x1e40af, emissive: 0x1d4ed8, specular: 0x93c5fd, shininess: 90, transparent: true, opacity: 0.95 }),
    );
    group.add(core);
    // continents: soft bright patches
    const landMat = new THREE.MeshPhongMaterial({ color: 0x67e8f9, emissive: 0x0891b2, transparent: true, opacity: 0.55, shininess: 30 });
    const lands = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const m = new THREE.Mesh(new THREE.SphereGeometry(0.22 + (i % 3) * 0.08, 16, 16), landMat);
      const phi = Math.acos(1 - 2 * ((i + 0.5) / 7)); const th = i * 2.4;
      m.position.setFromSphericalCoords(0.93, phi, th);
      m.scale.set(1, 0.35, 1); m.lookAt(0, 0, 0);
      lands.add(m);
    }
    core.add(lands);
    const wire = new THREE.Mesh(new THREE.SphereGeometry(1.12, 24, 24), new THREE.MeshBasicMaterial({ color: 0x60a5fa, wireframe: true, transparent: true, opacity: 0.22 }));
    group.add(wire);
    const aura = new THREE.Mesh(new THREE.SphereGeometry(1.26, 32, 32), new THREE.MeshBasicMaterial({ color: 0xbfdbfe, transparent: true, opacity: 0.12 }));
    group.add(aura);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.022, 16, 100), new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.75 }));
    ring.rotation.x = Math.PI / 2.6; ring.rotation.y = 0.25;
    scene.add(ring);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.75, 0.016, 16, 100), new THREE.MeshBasicMaterial({ color: 0x818cf8, transparent: true, opacity: 0.55 }));
    ring2.rotation.x = -Math.PI / 4; ring2.rotation.z = Math.PI / 6;
    scene.add(ring2);

    const orbGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const orbMat = new THREE.MeshPhongMaterial({ color: 0xf59e0b, emissive: 0xd97706, shininess: 95 });
    const orbList = [];
    for (let i = 0; i < 10; i++) {
      const o = new THREE.Mesh(orbGeo, orbMat);
      o.userData = { a: (i / 10) * Math.PI * 2, s: 0.01 + (i % 3) * 0.003, r: i % 2 ? 2.3 : 2.75 };
      scene.add(o); orbList.push(o);
    }

    const n = 60; const pos = new Float32Array(n * 3);
    for (let i = 0; i < n * 3; i += 3) { pos[i] = (Math.random() - 0.5) * 12; pos[i + 1] = (Math.random() - 0.5) * 8; pos[i + 2] = (Math.random() - 0.5) * 6; }
    const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const stars = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0x93c5fd, size: 0.08, transparent: true, opacity: 0.6 }));
    scene.add(stars);

    let tx = 0, ty = 0, cur = 0.6;
    const onMove = (e) => {
      const p = e.touches ? e.touches[0] : e; const r = el.getBoundingClientRect();
      ty = (((p.clientX - r.left) / r.width) * 2 - 1) * 0.5;
      tx = -(-(((p.clientY - r.top) / r.height) * 2 - 1)) * 0.3;
    };
    el.addEventListener('pointermove', onMove, { passive: true });
    el.addEventListener('touchmove', onMove, { passive: true });

    const clock = new THREE.Clock();
    let raf;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      const t = clock.getElapsedTime();
      const { growth: g, orbs: count } = live.current;
      const target = 0.75 + Math.min(1, Math.max(0, g)) * 0.75; // 0.75 → 1.5
      cur += (target - cur) * 0.04;
      const breathe = 1 + Math.sin(t * 1.6) * 0.02;
      group.scale.setScalar(cur * breathe);
      core.rotation.y += 0.004; wire.rotation.y -= 0.0025;
      group.rotation.y += (ty - group.rotation.y) * 0.05;
      group.rotation.x += (tx - group.rotation.x) * 0.05;
      ring.rotation.z += 0.005; ring2.rotation.z -= 0.004;
      orbList.forEach((o, i) => {
        o.visible = i < count;
        o.userData.a += o.userData.s;
        o.position.set(Math.cos(o.userData.a) * o.userData.r, Math.sin(o.userData.a * 2 + t) * 0.35, Math.sin(o.userData.a) * o.userData.r);
      });
      stars.rotation.y = t * 0.015;
      renderer.render(scene, camera);
    };
    tick();

    const ro = new ResizeObserver(() => {
      const W = el.clientWidth, H = el.clientHeight; if (!W || !H) return;
      camera.aspect = W / H; camera.updateProjectionMatrix(); renderer.setSize(W, H);
    });
    ro.observe(el);

    return () => {
      cancelAnimationFrame(raf); ro.disconnect();
      el.removeEventListener('pointermove', onMove); el.removeEventListener('touchmove', onMove);
      scene.traverse((o) => { o.geometry?.dispose?.(); o.material?.dispose?.(); });
      renderer.dispose(); renderer.forceContextLoss?.();
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={ref} className={className} style={style} aria-hidden="true" />;
}
