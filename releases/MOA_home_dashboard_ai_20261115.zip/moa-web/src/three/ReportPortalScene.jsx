// @ts-nocheck
// 3D scene ported from the Stitch design (three.js). Mounted/unmounted with the component.
import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export function mountReportPortalScene(containerEl) {

const width = containerEl.clientWidth || window.innerWidth || 390;
const height = containerEl.clientHeight || window.innerHeight || 844;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
camera.position.set(0, 0.8, 12.5);

const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
containerEl.appendChild(renderer.domElement);

// 은은하고 고급스러운 무드 조명
const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
scene.add(ambientLight);

const blueLight = new THREE.PointLight(0x3b82f6, 2.5, 30);
blueLight.position.set(3, 4, 8);
scene.add(blueLight);

const indigoLight = new THREE.PointLight(0x6366f1, 2.0, 30);
indigoLight.position.set(-4, -2, 7);
scene.add(indigoLight);

const cyanLight = new THREE.PointLight(0x38bdf8, 1.8, 25);
cyanLight.position.set(0, 5, 6);
scene.add(cyanLight);

// Portal Master Group
const portalGroup = new THREE.Group();
portalGroup.position.set(0, 0.6, 0);
scene.add(portalGroup);

// 1. 차분하고 부드러운 코어 행성
const planetGeo = new THREE.SphereGeometry(1.5, 36, 36);
const planetMat = new THREE.MeshPhongMaterial({
  color: 0x1d4ed8,
  emissive: 0x1e3a8a,
  shininess: 60,
  transparent: true,
  opacity: 0.90
});
const planet = new THREE.Mesh(planetGeo, planetMat);
portalGroup.add(planet);

// 부드러운 안개/헤일로 대기 글로우 (와이어프레임 대신 소프트 레이어)
const haloGeo = new THREE.SphereGeometry(1.8, 32, 32);
const haloMat = new THREE.MeshBasicMaterial({
  color: 0x60a5fa,
  transparent: true,
  opacity: 0.18
});
const halo = new THREE.Mesh(haloGeo, haloMat);
portalGroup.add(halo);

// 미세한 2차 아우라
const auraGeo = new THREE.SphereGeometry(2.15, 32, 32);
const auraMat = new THREE.MeshBasicMaterial({
  color: 0x818cf8,
  transparent: true,
  opacity: 0.08
});
const aura = new THREE.Mesh(auraGeo, auraMat);
portalGroup.add(aura);

// 2. 우아하고 얇은 궤도 링 (회전속도 대폭 감속)
const ring1Geo = new THREE.TorusGeometry(2.6, 0.025, 16, 80);
const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.55 });
const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
ring1.rotation.x = Math.PI / 3.2;
portalGroup.add(ring1);

const ring2Geo = new THREE.TorusGeometry(3.3, 0.02, 16, 80);
const ring2Mat = new THREE.MeshBasicMaterial({ color: 0xc4b5fd, transparent: true, opacity: 0.45 });
const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
ring2.rotation.y = Math.PI / 4.5;
ring2.rotation.x = -Math.PI / 5.5;
portalGroup.add(ring2);

// 3. 3D 골드 코인 (개수 최적화 14개, 부드러운 나선 흡수)
const coins = [];
const coinGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.06, 24);
const coinMat = new THREE.MeshPhongMaterial({
  color: 0xf59e0b,
  emissive: 0xb45309,
  shininess: 70
});

for (let i = 0; i < 14; i++) {
  const coin = new THREE.Mesh(coinGeo, coinMat);
  const angle = (i / 14) * Math.PI * 2;
  const radius = 3.2 + (i % 3) * 0.9;
  const yOffset = ((i % 5) - 2) * 0.8;
  
  coin.userData = {
    angle: angle,
    initialRadius: radius,
    radius: radius,
    speed: 0.007 + (i % 4) * 0.002, // 속도를 1/3 수준으로 대폭 감속하여 우아하게 흐름
    y: yOffset,
    rotX: 0.015,
    rotY: 0.012,
    progress: (i / 14)
  };
  
  portalGroup.add(coin);
  coins.push(coin);
}

// 4. 미니멀 홀로그램 머니 카드 (8개)
const banknotes = [];
const noteGeo = new THREE.BoxGeometry(0.75, 0.01, 0.42);
const noteMat = new THREE.MeshPhongMaterial({
  color: 0x10b981,
  emissive: 0x047857,
  shininess: 50,
  transparent: true,
  opacity: 0.75
});

for (let j = 0; j < 8; j++) {
  const note = new THREE.Mesh(noteGeo, noteMat);
  const angle = (j / 8) * Math.PI * 2 + 0.4;
  const radius = 3.6 + (j % 2) * 1.0;
  const yOffset = ((j % 4) - 1.5) * 0.7;
  
  note.userData = {
    angle: angle,
    initialRadius: radius,
    speed: 0.006 + (j % 3) * 0.002,
    y: yOffset,
    rotX: 0.012,
    rotY: 0.01,
    rotZ: 0.008,
    progress: (j / 8)
  };
  portalGroup.add(note);
  banknotes.push(note);
}

// 5. 부드럽게 흐르는 우주 미세 스타더스트 (70개)
const particleCount = 70;
const partGeo = new THREE.BufferGeometry();
const partPositions = new Float32Array(particleCount * 3);
for (let i = 0; i < particleCount * 3; i += 3) {
  partPositions[i] = (Math.random() - 0.5) * 18;
  partPositions[i + 1] = (Math.random() - 0.5) * 18;
  partPositions[i + 2] = (Math.random() - 0.5) * 14;
}
partGeo.setAttribute('position', new THREE.BufferAttribute(partPositions, 3));
const partMat = new THREE.PointsMaterial({
  color: 0xdbeafe,
  size: 0.10,
  transparent: true,
  opacity: 0.65
});
const particles = new THREE.Points(partGeo, partMat);
scene.add(particles);

// 애니메이션 루프 (매우 부드럽고 차분한 유속)
let animId;
let clock = new THREE.Clock();

function animate() {
  animId = requestAnimationFrame(animate);
  const time = clock.getElapsedTime();

  // 은은한 행성 호흡 & 자전 (극도로 부드러움)
  planet.rotation.y += 0.005;
  halo.rotation.y += 0.003;
  aura.rotation.y -= 0.002;
  const pulse = 1.0 + Math.sin(time * 1.2) * 0.025; // 맥동 크기 축소 (0.06 -> 0.025)
  planet.scale.set(pulse, pulse, pulse);
  halo.scale.set(pulse * 1.03, pulse * 1.03, pulse * 1.03);

  // 미세 궤도 링 회전
  ring1.rotation.z += 0.004;
  ring1.rotation.y += 0.003;
  ring2.rotation.z -= 0.003;
  ring2.rotation.x += 0.004;

  // 코인 흡수 물리: 매우 자연스럽고 부드러운 이징(Ease-in-out) 나선
  coins.forEach((coin) => {
    coin.userData.progress += coin.userData.speed;
    if (coin.userData.progress > 1) {
      coin.userData.progress = 0;
    }
    const p = coin.userData.progress;
    
    // 부드러운 스무스스텝 감속 및 이징
    const smoothP = p * p * (3 - 2 * p);
    const currentRadius = THREE.MathUtils.lerp(coin.userData.initialRadius, 0.25, smoothP);
    coin.userData.angle += 0.018 * (1.0 + p * 0.8); // 급격한 스핀 제거

    coin.position.x = Math.cos(coin.userData.angle) * currentRadius;
    coin.position.z = Math.sin(coin.userData.angle) * currentRadius;
    coin.position.y = THREE.MathUtils.lerp(coin.userData.y, 0, smoothP);

    // 크기 축소 및 투명도 감쇄
    const scale = THREE.MathUtils.lerp(1.0, 0.08, smoothP);
    coin.scale.set(scale, scale, scale);

    coin.rotation.x += coin.userData.rotX;
    coin.rotation.y += coin.userData.rotY;
  });

  // 지폐 흡수 물리
  banknotes.forEach((note) => {
    note.userData.progress += note.userData.speed;
    if (note.userData.progress > 1) {
      note.userData.progress = 0;
    }
    const p = note.userData.progress;
    const smoothP = p * p * (3 - 2 * p);
    const currentRadius = THREE.MathUtils.lerp(note.userData.initialRadius, 0.25, smoothP);
    note.userData.angle += 0.015 * (1.0 + p * 0.8);

    note.position.x = Math.cos(note.userData.angle) * currentRadius;
    note.position.z = Math.sin(note.userData.angle) * currentRadius;
    note.position.y = THREE.MathUtils.lerp(note.userData.y, 0, smoothP);

    const scale = THREE.MathUtils.lerp(0.9, 0.08, smoothP);
    note.scale.set(scale, scale, scale);

    note.rotation.x += note.userData.rotX;
    note.rotation.y += note.userData.rotY;
    note.rotation.z += note.userData.rotZ;
  });

  // 미세한 별빛 표류
  particles.rotation.y = time * 0.008;

  renderer.render(scene, camera);
}
animate();

// Resize
function onResize() {
  const newWidth = containerEl.clientWidth || window.innerWidth || 390;
  const newHeight = containerEl.clientHeight || window.innerHeight || 844;
  camera.aspect = newWidth / newHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(newWidth, newHeight);
}
window.addEventListener('resize', onResize);

return () => {
  cancelAnimationFrame(animId);
  window.removeEventListener('resize', onResize);
  renderer.dispose(); renderer.forceContextLoss && renderer.forceContextLoss();
  if (containerEl.contains(renderer.domElement)) {
    containerEl.removeChild(renderer.domElement);
  }
};

}

export default function ReportPortalScene({ className = '', style = undefined }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let dispose;
    try { dispose = mountReportPortalScene(el); } catch (e) { console.warn('[moa] 3D unavailable', e); }
    return () => { if (typeof dispose === 'function') dispose(); };
  }, []);
  return <div ref={ref} className={className} style={{ ...style }} aria-hidden="true" />;
}
