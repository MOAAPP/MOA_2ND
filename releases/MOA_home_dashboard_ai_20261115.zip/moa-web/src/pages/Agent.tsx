import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { PageHeader } from '../components/ui';
import { impactOf } from '../lib/finance';
import { worldOutflow } from '../lib/bridge';
import { useStore, won } from '../lib/store';
import { DEMO_AS_OF, v4, type AgentRoute, type AgentSearch, type AgentToolLog, type GoalConditions } from '../lib/api';
import snapshot from '../data/agent-snapshot.json';
import './Agent.css';

const PERSONAS = [
  { id: 'S08', label: '가상 사용자 A', sub: '잔액 여유 있음' },
  { id: 'S01', label: '가상 사용자 B', sub: '결제일이 빠듯함' },
];
const CHIPS = ['월세 지키면서 3개월 안에 60만 원 모으기', 'ETF도 10만 원 정도 경험하고 싶어', '6만 7천 원짜리 참고서를 언제 살까?'];
const REJECT: Record<string, string> = {
  essential_bills: '월세·카드값 같은 필수 결제를 못 지켜요',
  minimum_balance: '최소 잔액 아래로 내려가요',
  'financial_engine_error:allocation_exceeds_available_payment_cash': '쓸 수 있는 현금보다 많이 배분해요',
  purchase_requirement: '꼭 사야 하는 조건을 못 지켜요',
  required_savings: '저축 목표 금액을 못 채워요',
  investment_permission: '허용한 투자 범위를 넘어요',
  purchase_deadline: '구매 기한을 넘겨요',
};
const CHECK: Record<string, string> = { essential_bills: '필수 결제', minimum_balance: '최소 잔액', purchase_requirement: '구매 조건', required_savings: '저축 목표', investment_permission: '투자 한도', purchase_deadline: '구매 기한' };
const TOOL: Record<string, string> = {
  extract_conditions: '목표 문장에서 조건 추출', get_financial_state: '결제계좌 상태 조회', get_spending_forecast: '변동 지출 전망 조회 (ML)',
  get_purchase_candidate: '구매 후보 조회', simulate_cashflow: '현금흐름 계산', simulate_savings: '가상 저축 계산', simulate_investment: '가상 투자 계산',
  validate_constraints: '필수 결제·최소 잔액 검증', search_paths: '경로 탐색·검증', llm_tool_planning: 'AI 도구 계획',
};

/** 목표 문장에서 금액·조건을 읽는 규칙 (AI 서버를 못 쓸 때) */
function parseGoal(goal: string, user: string): GoalConditions {
  const man = [...goal.matchAll(/(\d+)\s*만\s*(?:(\d)\s*천)?\s*원?/g)].map((m) => Number(m[1]) * 10000 + (m[2] ? Number(m[2]) * 1000 : 0));
  const amt = man[0] || Number((goal.match(/(\d{4,})\s*원/) || [])[1]) || 0;
  const invest = /ETF|투자|주식/.test(goal);
  const buy = /사|구매|살까/.test(goal) && !/모으/.test(goal);
  return {
    user_id: user, as_of: DEMO_AS_OF, allowed_payment_methods: ['debit'], protect_essential_bills: true,
    investment_allowed: invest, maximum_investment_amount: invest ? (amt || 100000) : 0,
    ...(buy ? { purchase_amount: amt || 50000, acceptable_purchase_delay_days: 30 } : {}),
    ...(!buy && !invest && amt ? { required_savings_amount: amt } : {}),
  };
}

type Result = { source: 'ai' | 'engine' | 'saved'; model?: string; conditions: Record<string, unknown>; search: AgentSearch; log: AgentToolLog[] };

function Svg({ d, size = 18 }: { d: React.ReactNode; size?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>;
}

export default function Agent() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const state = useStore((s) => s);
  const [goal, setGoal] = useState(params.get('goal') || '');
  const [user, setUser] = useState('S08');
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<Result | null>(null);
  const [step, setStep] = useState(0);
  const auto = useRef(false);

  const run = async (text = goal) => {
    const g = text.trim();
    if (g.length < 3 || busy) return;
    setGoal(g); setBusy(true); setRes(null); setStep(0);
    let out: Result | null = null;
    const ai = await v4.agentAnalyze(user, g);
    if (ai) out = { source: 'ai', model: ai.llm_model, conditions: ai.conditions, search: ai.search, log: ai.tool_execution_log };
    if (!out) {
      const c = parseGoal(g, user);
      const sr = await v4.agentSearch(c);
      if (sr) out = { source: 'engine', conditions: c, search: sr, log: engineLog(c, sr) };
    }
    if (!out) {
      const snap = (snapshot as Record<string, AgentSearch & { _conditions: Record<string, unknown> }>)[user];
      out = { source: 'saved', conditions: snap._conditions, search: snap, log: engineLog(snap._conditions as GoalConditions, snap) };
    }
    setRes(out); setBusy(false);
  };
  useEffect(() => { if (params.get('goal') && !auto.current) { auto.current = true; run(params.get('goal')!); } }, []); // eslint-disable-line

  // 도구 실행 단계를 하나씩 보여주기
  useEffect(() => {
    if (!res) return;
    if (step >= res.log.length + 1) return;
    const t = window.setTimeout(() => setStep((v) => v + 1), 380);
    return () => window.clearTimeout(t);
  }, [res, step]);
  const revealed = res ? step > res.log.length : false;

  return (
    <div className="ag">
      <PageHeader title="AI 경로 탐색" />
      <main className="ag-main">
        <section className="ag-intro">
          <span className="ag-badge"><Svg d={<path d="M12 3.5l1.6 4.4 4.4 1.6-4.4 1.6L12 15.5l-1.6-4.4L6 9.5l4.4-1.6L12 3.5Z" />} size={14} />AI 에이전트</span>
          <h1>목표를 말하면, 필수 결제를 지키는 경로만 찾아드려요</h1>
          <p>AI는 조건을 읽고 도구를 실행해요. 금액 계산과 결제 검증은 모아 계산 엔진이 해요.</p>
        </section>

        <div className="ag-persona" role="radiogroup" aria-label="분석할 계정">
          {PERSONAS.map((p) => (
            <button key={p.id} type="button" role="radio" aria-checked={user === p.id} className={user === p.id ? 'on' : ''} onClick={() => { setUser(p.id); setRes(null); }}>
              <b>{p.label}</b><small>{p.sub}</small>
            </button>
          ))}
        </div>

        <form className="ag-input" onSubmit={(e) => { e.preventDefault(); run(); }}>
          <textarea value={goal} onChange={(e) => setGoal(e.target.value)} rows={2} maxLength={300} placeholder="예: 월세는 지키면서 3개월 안에 여행비 60만 원 모으기" aria-label="금융 목표" />
          <button type="submit" disabled={busy || goal.trim().length < 3} aria-label="경로 찾기">
            {busy ? <span className="ag-spin" /> : <Svg d={<path d="M5 12h14m-6-6 6 6-6 6" />} size={20} />}
          </button>
        </form>
        <div className="ag-chips">
          {CHIPS.map((c) => <button key={c} type="button" onClick={() => run(c)} disabled={busy}>{c}</button>)}
        </div>

        {busy && <div className="ag-thinking"><span /><span /><span /><p>조건을 읽고 도구를 실행하고 있어요</p></div>}

        {res && (
          <>
            <section className="ag-card">
              <div className="ag-card-head">
                <h2>AI가 실행한 과정</h2>
                <span className={`ag-src ${res.source}`}>{res.source === 'ai' ? `${res.model} · 실시간` : res.source === 'engine' ? '모아 엔진 · 실시간' : '저장된 분석'}</span>
              </div>
              <ol className="ag-trace">
                {res.log.map((l, i) => (
                  <li key={i} className={`${i < step ? 'show' : ''} ${l.status}`}>
                    <span className="ag-dot">{l.status === 'ok' ? <Svg d={<path d="M5 12.5 10 17.5 19 7" />} size={12} /> : '!'}</span>
                    <div><b>{TOOL[l.tool] || l.tool}</b>{l.error && <small>{l.error}</small>}{!l.error && l.arguments && <small>{argText(l.arguments)}</small>}</div>
                  </li>
                ))}
              </ol>
              <div className={`ag-cond ${step > 0 ? 'show' : ''}`}>
                {condChips(res.conditions).map((c) => <span key={c}>{c}</span>)}
              </div>
            </section>

            {revealed && (
              <section className="ag-card ag-result">
                <div className="ag-sum">
                  <div><small>살펴본 경로</small><b>{res.search.evaluated_count}개</b></div>
                  <div><small>검증 통과</small><b className="ok">{res.search.valid_count}개</b></div>
                  <div><small>제외</small><b className="no">{Math.max(0, res.search.evaluated_count - res.search.valid_count)}개</b></div>
                </div>
                {res.search.routes.length > 0 ? (
                  <ul className="ag-routes">
                    {res.search.routes.map((r, i) => <RouteCard key={r.id} r={r} rank={i + 1} />)}
                  </ul>
                ) : (
                  <div className="ag-none">
                    <b>{res.search.status === 'needs_confirmation' ? '확인이 필요해요' : '지금 조건을 지키는 경로가 없어요'}</b>
                    <p>{res.search.confirmations_required[0] || '아래 이유로 모든 경로를 제외했어요. 금액이나 기간을 바꿔 다시 물어보세요.'}</p>
                  </div>
                )}
                {Object.keys(res.search.rejection_counts).length > 0 && (
                  <div className="ag-reject">
                    <p>제외한 이유</p>
                    {Object.entries(res.search.rejection_counts).map(([k, n]) => <div key={k}><span>{REJECT[k] || k}</span><b>{n}개</b></div>)}
                  </div>
                )}
                <p className="ag-foot">가상 사용자의 금융 데이터({Number(DEMO_AS_OF.slice(5, 7))}월 {Number(DEMO_AS_OF.slice(8))}일 기준)로 계산했어요. 수익률이 높다는 이유만으로 안전한 경로로 고르지 않아요.</p>
              </section>
            )}
          </>
        )}

        <MyAccountCheck amount={100000} navigate={navigate} opts={state.simSettings} state={state} />
      </main>
    </div>
  );
}

function RouteCard({ r, rank }: { r: AgentRoute; rank: number }) {
  return (
    <li className="ag-route" style={{ animationDelay: `${rank * 90}ms` }}>
      <div className="ag-route-top"><span className="ag-rank">{rank}</span><b>{r.label}</b>{rank === 1 && <span className="ag-best">추천</span>}</div>
      <div className="ag-route-nums">
        {r.purchase_amount > 0 && <div><small>구매</small><b>{won(r.purchase_amount)}</b><i>{r.purchase_date ? `${Number(r.purchase_date.slice(5, 7))}/${Number(r.purchase_date.slice(8))}` : ''}{r.purchase_delay_days ? ` · ${r.purchase_delay_days}일 연기` : ''}</i></div>}
        {r.savings_amount > 0 && <div><small>저축</small><b>{won(r.savings_amount)}</b></div>}
        {r.investment_amount > 0 && <div><small>투자</small><b>{won(r.investment_amount)}</b></div>}
        <div><small>가장 낮은 잔액</small><b>{won(r.minimum_balance)}</b></div>
      </div>
      <div className="ag-checks">{Object.entries(r.checks).filter(([k]) => CHECK[k]).map(([k, ok]) => <span key={k} className={ok ? 'ok' : 'no'}>{ok ? '✓' : '✕'} {CHECK[k]}</span>)}</div>
    </li>
  );
}

/** 내 생활비 통장(앱 데이터)으로도 같은 금액을 바로 검증 */
function MyAccountCheck({ amount, navigate, opts, state }: { amount: number; navigate: ReturnType<typeof useNavigate>; opts: any; state: any }) {
  const rows = useMemo(() => {
    const names: Record<number, string> = { 1: '지금 구매', 2: '현금 보유', 3: '구매 연기', 4: '가상 저축', 5: '가상 투자', 6: '혼합 배분' };
    return [1, 2, 3, 4, 5, 6].map((id) => {
      const imp = impactOf(worldOutflow(id, amount, 1, opts) as number, state);
      return { id, name: names[id], value: imp.spendable, ok: imp.spendable >= 0 && !imp.risk };
    });
  }, [amount, opts, state]);
  return (
    <section className="ag-card">
      <div className="ag-card-head"><h2>내 생활비 통장으로 보면</h2><span className="ag-src engine">10만 원 기준 · 결제 후 여유</span></div>
      <ul className="ag-mine">
        {rows.map((r) => <li key={r.id}><span className={r.ok ? 'ok' : 'no'}>{r.ok ? '가능' : '부족'}</span><b>{r.name}</b><i>{won(r.value)}</i></li>)}
      </ul>
      <button type="button" className="ag-more" onClick={() => navigate('/world/explore?view=B&amount=100000')}>6개 평행세계로 자세히 보기</button>
    </section>
  );
}

function engineLog(c: GoalConditions | Record<string, unknown>, s: AgentSearch): AgentToolLog[] {
  return [
    { tool: 'extract_conditions', status: 'ok', arguments: c as Record<string, unknown> },
    { tool: 'get_financial_state', status: 'ok' },
    { tool: 'get_spending_forecast', status: 'ok', arguments: { model: s.forecast_source || 'weekday baseline' } },
    { tool: 'search_paths', status: 'ok', arguments: { evaluated: s.evaluated_count, ms: Math.round(s.elapsed_ms) } },
    { tool: 'validate_constraints', status: 'ok', arguments: { valid: s.valid_count } },
  ];
}
function argText(a: Record<string, unknown>) {
  if ('evaluated' in a) return `${a.evaluated}개 경로 · ${a.ms}ms`;
  if ('valid' in a) return `통과 ${a.valid}개`;
  if ('model' in a) return String(a.model).replace('weekday:baseline-weekday-v1', '요일별 기준선 v1');
  if ('available_cash' in a) return `가용 현금 ${won(Number(a.available_cash))}`;
  if ('amount' in a) return `${won(Number(a.amount))}`;
  return '';
}
function condChips(c: Record<string, unknown>) {
  const out: string[] = [];
  if (c.protect_essential_bills) out.push('필수 결제 보호');
  if (c.required_savings_amount) out.push(`저축 ${won(Number(c.required_savings_amount))}`);
  if (c.purchase_amount) out.push(`구매 ${won(Number(c.purchase_amount))}`);
  if (c.acceptable_purchase_delay_days) out.push(`최대 ${c.acceptable_purchase_delay_days}일 연기`);
  if (c.investment_allowed) out.push(`투자 최대 ${won(Number(c.maximum_investment_amount || 0))}`);
  if (Array.isArray(c.allowed_payment_methods)) out.push((c.allowed_payment_methods as string[]).map((m) => ({ debit: '체크카드', credit: '신용카드', transfer: '계좌이체' }[m] || m)).join('·'));
  return out;
}
