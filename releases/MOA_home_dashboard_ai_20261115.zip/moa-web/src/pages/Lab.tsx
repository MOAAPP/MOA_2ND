import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { LearnHub } from './Learn';
import { placeOrder, setState, useStore, APP_TODAY, type SavingsProduct } from '../lib/store';
import { STOCKS, changeRate, livePrice, TICK } from '../lib/market';
import { stockLessonId } from '../lib/learning';
import { useApp } from '../lib/app';
import './Lab.css';

type Tab = 'learn' | 'invest' | 'save';
const TABS: { id: Tab; label: string }[] = [{ id: 'learn', label: '학습' }, { id: 'invest', label: '투자' }, { id: 'save', label: '적금' }];
const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
const META: Record<string, { logo: string; color: string; bg: string; tag: string }> = {
  SP500: { logo: 'S&P', color: '#2563EB', bg: '#EAF1FF', tag: '미국 500대 기업 ETF' },
  QQQ: { logo: 'NDX', color: '#0891B2', bg: '#E6F7FB', tag: '미국 기술주 ETF' },
  SPACE: { logo: 'AI', color: '#6D28D9', bg: '#F1EBFF', tag: '변동이 큰 테마형' },
  DIVIDEND: { logo: '배당', color: '#059669', bg: '#E7F7F0', tag: '매달 배당 ETF' },
};

/** /lab — 금융 실험실: 학습 · 가상 투자 · 가상 적금을 한 화면의 세그먼트로 */
export default function Lab() {
  const [params, setParams] = useSearchParams();
  const tab = (params.get('tab') as Tab) || 'learn';
  const set = (t: Tab) => setParams(t === 'learn' ? {} : { tab: t }, { replace: true });
  return (
    <div className="lb">
      <AppHeader profileTo="/more" transparent />
      <main className="lb-main">
        <header className="lb-title">
          <h1>실험실</h1>
          <p>배우고, 실제 돈 없이 바로 해봐요</p>
        </header>
        <div className="lb-seg" role="tablist" aria-label="실험실 메뉴">
          <span className="lb-seg-thumb" style={{ transform: `translateX(${TABS.findIndex((t) => t.id === tab) * 100}%)` }} />
          {TABS.map((t) => <button key={t.id} type="button" role="tab" aria-selected={tab === t.id} className={tab === t.id ? 'on' : ''} onClick={() => set(t.id)}>{t.label}</button>)}
        </div>
        {tab === 'learn' && <LearnHub embedded />}
        {tab === 'invest' && <InvestPanel />}
        {tab === 'save' && <SavePanel />}
      </main>
    </div>
  );
}

/* ───────── 가상 투자 ───────── */
function InvestPanel() {
  const navigate = useNavigate();
  const inv = useStore((s) => s.invest);
  const [, setTick] = useState(0);
  const [sheet, setSheet] = useState<string | null>(null);
  useEffect(() => { const id = window.setInterval(() => setTick((v) => v + 1), TICK * 1000); return () => window.clearInterval(id); }, []);
  const value = STOCKS.reduce((a, st) => a + (inv.holdings[st.name] || 0) * (livePrice(st.name) || st.price), 0);
  const cost = STOCKS.reduce((a, st) => a + (inv.holdings[st.name] || 0) * (inv.avgPrice[st.name] || st.price), 0);
  const pl = value - cost;
  return (
    <>
      <section className="lb-card lb-sum">
        <span className="lb-sum-label">가상 투자 평가금액</span>
        <strong className="lb-sum-num">{won(value)}</strong>
        <span className={`lb-chip ${pl >= 0 ? 'up' : 'down'}`}>{pl >= 0 ? '+' : ''}{won(pl)} ({cost ? ((pl / cost) * 100).toFixed(1) : '0.0'}%)</span>
        <p className="lb-sum-foot">주문 가능 방어 머니 {won(inv.cash)} · 실제 통장과 분리돼요</p>
      </section>
      <p className="lb-hint">종목을 누르면 바로 살 수 있어요. 사면 그 종목 AI 카드뉴스가 만들어져요.</p>
      <ul className="lb-list">
        {STOCKS.map((st) => {
          const m = META[st.code];
          const price = livePrice(st.name) || st.price;
          const rate = changeRate(st.name);
          const sh = inv.holdings[st.name] || 0;
          return (
            <li key={st.code}>
              <button type="button" onClick={() => setSheet(st.name)}>
                <span className="lb-logo" style={{ color: m.color, background: m.bg }}>{m.logo}</span>
                <span className="lb-name"><b>{st.name}</b><small>{sh > 0 ? `${Math.round(sh * 100) / 100}주 보유` : m.tag}</small></span>
                <span className="lb-price"><b>{won(price)}</b><small className={rate >= 0 ? 'up' : 'down'}>{rate >= 0 ? '+' : ''}{(rate * 100).toFixed(1)}%</small></span>
              </button>
            </li>
          );
        })}
      </ul>
      <button type="button" className="lb-link" onClick={() => navigate('/invest')}>호가·차트가 있는 거래소 열기 ›</button>
      {sheet && <TradeSheet name={sheet} onClose={() => setSheet(null)} />}
    </>
  );
}

/** 매수·매도 바텀시트 — 수량 고르고 한 번 누르면 체결, 체결 후 AI 종목 카드로 */
function TradeSheet({ name, onClose }: { name: string; onClose: () => void }) {
  const navigate = useNavigate();
  const { toast } = useApp();
  const inv = useStore((s) => s.invest);
  const discordOn = useStore((s) => s.learnAlert.discord && s.learnAlert.discordConsent);
  const st = STOCKS.find((x) => x.name === name)!;
  const m = META[st.code];
  const price = livePrice(name) || st.price;
  const have = inv.holdings[name] || 0;
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [qty, setQty] = useState(1);
  const [done, setDone] = useState<{ id: string; total: number; side: 'buy' | 'sell' } | null>(null);
  const maxQty = side === 'buy' ? Math.floor(inv.cash / price) : Math.floor(have);
  const total = qty * price;
  const ok = qty >= 1 && qty <= maxQty;
  const submit = () => {
    const r = placeOrder({ name, side, shares: qty, price, type: 'market' });
    if (!r.ok || !r.order) { toast(r.reason || '주문하지 못했어요', 'error'); return; }
    setDone({ id: r.order.id, total, side });
  };
  return (
    <div className="lb-sheet-bg" onClick={onClose}>
      <div className="lb-sheet" role="dialog" aria-label={`${name} 주문`} onClick={(e) => e.stopPropagation()}>
        <span className="lb-grabber" />
        {!done ? (
          <>
            <div className="lb-sheet-head">
              <span className="lb-logo" style={{ color: m.color, background: m.bg }}>{m.logo}</span>
              <span className="lb-name"><b>{name}</b><small>{m.tag}</small></span>
              <span className="lb-price"><b>{won(price)}</b><small>가상 시세</small></span>
            </div>
            <div className="lb-seg lb-seg-sm">
              <span className="lb-seg-thumb" style={{ width: '50%', transform: `translateX(${side === 'buy' ? 0 : 100}%)` }} />
              <button type="button" className={side === 'buy' ? 'on' : ''} onClick={() => { setSide('buy'); setQty(1); }}>사기</button>
              <button type="button" className={side === 'sell' ? 'on' : ''} disabled={have < 1} onClick={() => { setSide('sell'); setQty(1); }}>팔기</button>
            </div>
            <div className="lb-stepper">
              <button type="button" aria-label="1주 빼기" disabled={qty <= 1} onClick={() => setQty((v) => Math.max(1, v - 1))}>−</button>
              <span><b>{qty}</b>주</span>
              <button type="button" aria-label="1주 더하기" disabled={qty >= maxQty} onClick={() => setQty((v) => Math.min(maxQty, v + 1))}>+</button>
            </div>
            <p className="lb-total">{side === 'buy' ? '결제' : '받을'} 금액 <b>{won(total)}</b></p>
            <button type="button" className={`lb-cta ${side}`} disabled={!ok} onClick={submit}>
              {!ok ? (side === 'buy' ? '방어 머니가 부족해요' : '팔 수 있는 수량이 없어요') : `${qty}주 ${side === 'buy' ? '사기' : '팔기'}`}
            </button>
          </>
        ) : (
          <div className="lb-done">
            <span className="lb-done-check">✓</span>
            <h3>{qty}주 {done.side === 'buy' ? '샀어요' : '팔았어요'}</h3>
            <p>{name} · {won(done.total)}</p>
            {done.side === 'buy' ? (
              <>
                <button type="button" className="lb-cta buy" onClick={() => navigate(`/learn/${stockLessonId(st.code)}?from=trade&order=${done.id}&amount=${Math.round(done.total)}`)}>이 종목 AI 카드뉴스 보기</button>
                <p className="lb-done-note">{discordOn ? 'Discord 채널에도 같은 카드뉴스를 보냈어요' : '설정에서 Discord 받기를 켜면 채널로도 보내드려요'}</p>
              </>
            ) : <button type="button" className="lb-cta buy" onClick={onClose}>확인</button>}
            <button type="button" className="lb-ghost" onClick={onClose}>닫기</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ───────── 가상 적금 ───────── */
function SavePanel() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const savings = useStore((s) => s.savings);
  const total = savings.reduce((a, p) => a + (p.history?.length ? p.history.reduce((x, h) => x + h.amount, 0) : p.principal), 0);
  const put = (p: SavingsProduct) => {
    const add = p.monthly || 100000;
    setState((s) => ({ savings: s.savings.map((x) => (x.id === p.id ? { ...x, principal: x.principal + add, history: [...(x.history?.length ? x.history : [{ date: x.startedAt, amount: x.principal, kind: 'join' as const }]), { date: APP_TODAY, amount: add, kind: 'deposit' as const }] } : x)) }));
    toast(`${p.name}에 ${won(add)}을 넣었어요`, 'savings');
  };
  return (
    <>
      <section className="lb-card lb-sum">
        <span className="lb-sum-label">가상 예·적금에 모은 돈</span>
        <strong className="lb-sum-num">{won(total)}</strong>
        <p className="lb-sum-foot">이자는 연 금리 가정으로 계산해요 · 실제 통장과 분리돼요</p>
      </section>
      <ul className="lb-list">
        {savings.map((p) => {
          const paid = p.history?.length ? p.history.reduce((x, h) => x + h.amount, 0) : p.principal;
          const goal = p.kind === 'saving' ? p.monthly * p.months : p.principal;
          const pct = Math.min(100, Math.round((paid / Math.max(1, goal)) * 100));
          return (
            <li key={p.id} className="lb-save">
              <div className="lb-save-top">
                <span className="lb-name"><b>{p.name}</b><small>{p.kind === 'saving' ? '적금' : '예금'} · 연 {p.rate}%</small></span>
                {p.kind === 'saving' && <button type="button" className="lb-put" onClick={() => put(p)}>{won(p.monthly)} 넣기</button>}
              </div>
              <div className="lb-bar"><i style={{ width: `${pct}%` }} /></div>
              <small className="lb-save-foot">{won(paid)} 모음 · 목표의 {pct}%</small>
            </li>
          );
        })}
        {savings.length === 0 && <li className="lb-empty">아직 가입한 상품이 없어요</li>}
      </ul>
      <button type="button" className="lb-link" onClick={() => navigate('/savings')}>새 상품 둘러보기 ›</button>
    </>
  );
}
