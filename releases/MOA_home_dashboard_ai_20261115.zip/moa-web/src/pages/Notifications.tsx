import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon, PageHeader } from '../components/ui';
import { setState, useStore } from '../lib/store';

type Noti = { id: string; cat: 'pay' | 'world' | 'invest' | 'notice'; icon: string; tone: string; title: string; body: string; time: string; group: '오늘' | '이번 주' | '지난 알림'; to: string };

const NOTIS: Noti[] = [
  { id: 'n1', cat: 'pay', icon: 'warning', tone: 'bg-rose-50 text-rose-500', title: '내일 카드값 결제 전 잔액이 부족해요', body: '11/14 카드값 290,000원 결제 후 38,000원이 모자랄 수 있어요.', time: '08:00', group: '오늘', to: '/ledger' },
  { id: 'n2', cat: 'world', icon: 'auto_awesome', tone: 'bg-toss-lightBlue text-toss-blue', title: '헤드폰 고민, 평행세계에 흡수됐어요', body: '259,000원을 안 사고 투자했다면 1년 뒤 +18,648원이에요.', time: '07:42', group: '오늘', to: '/world' },
  { id: 'n3', cat: 'invest', icon: 'trending_up', tone: 'bg-rose-50 text-rose-500', title: 'TIGER 미국S&P500 +1.8%', body: '보유 중인 가상 종목의 평가 수익이 4,810원이 됐어요.', time: '어제', group: '이번 주', to: '/invest' },
  { id: 'n4', cat: 'world', icon: 'public', tone: 'bg-indigo-50 text-indigo-500', title: '행성이 Lv.3 오아시스로 성장했어요', body: '우주여행 적금 납입으로 행성 자산이 70만원이 됐어요.', time: '11/11', group: '이번 주', to: '/savings' },
  { id: 'n5', cat: 'pay', icon: 'event_repeat', tone: 'bg-amber-50 text-amber-500', title: '넷플릭스 정기결제 17,000원 예정', body: '11/14에 생활비 통장에서 빠져나가요.', time: '11/10', group: '이번 주', to: '/ledger' },
  { id: 'n6', cat: 'notice', icon: 'campaign', tone: 'bg-toss-gray100 text-toss-gray600', title: '모아 v2.4 업데이트 안내', body: '가상 예·적금과 행성 키우기가 새로 생겼어요.', time: '11/03', group: '지난 알림', to: '/savings' },
];

const TABS = [
  { key: 'all', label: '전체' },
  { key: 'pay', label: '결제' },
  { key: 'world', label: '평행세계' },
  { key: 'invest', label: '투자' },
  { key: 'notice', label: '공지' },
] as const;

export default function Notifications() {
  const navigate = useNavigate();
  const read = useStore((s) => s.readNoti);
  const [tab, setTab] = useState<(typeof TABS)[number]['key']>('all');
  const list = NOTIS.filter((n) => tab === 'all' || n.cat === tab);
  const groups = ['오늘', '이번 주', '지난 알림'] as const;

  const open = (n: Noti) => {
    if (!read.includes(n.id)) setState((s) => ({ readNoti: [...s.readNoti, n.id] }));
    navigate(n.to);
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader
        title="알림"
        right={<button type="button" onClick={() => setState({ readNoti: NOTIS.map((n) => n.id) })} className="text-[13px] font-semibold text-toss-gray500 whitespace-nowrap">모두 읽음</button>}
      />
      <div className="px-4 pt-3 flex gap-1.5 overflow-x-auto no-scrollbar">
        {TABS.map((t) => (
          <button key={t.key} type="button" onClick={() => setTab(t.key)} className={`shrink-0 px-3.5 py-1.5 rounded-full text-[13px] transition-all ${tab === t.key ? 'bg-toss-gray900 text-white font-bold' : 'bg-white text-toss-gray600 font-medium shadow-card'}`}>{t.label}</button>
        ))}
      </div>
      <div className="px-4 pt-4 space-y-5">
        {groups.map((g) => {
          const items = list.filter((n) => n.group === g);
          if (!items.length) return null;
          return (
            <section key={g}>
              <h2 className="px-1 mb-2 text-[13px] font-bold text-toss-gray500">{g}</h2>
              <ul className="bg-white rounded-[22px] shadow-card overflow-hidden divide-y divide-toss-gray100">
                {items.map((n) => {
                  const unread = !read.includes(n.id);
                  return (
                    <li key={n.id}>
                      <button type="button" onClick={() => open(n)} className="w-full flex gap-3 px-4 py-4 text-left active:bg-toss-gray50 transition-colors">
                        <span className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${n.tone}`}><Icon name={n.icon} fill className="text-[20px]" /></span>
                        <span className="flex-1 min-w-0">
                          <span className="flex items-start justify-between gap-2">
                            <span className={`text-[14px] leading-snug ${unread ? 'font-bold text-toss-gray900' : 'font-semibold text-toss-gray700'}`}>{n.title}</span>
                            <span className="text-[11px] text-toss-gray400 shrink-0 mt-0.5">{n.time}</span>
                          </span>
                          <span className="block mt-1 text-[12.5px] text-toss-gray500 leading-relaxed">{n.body}</span>
                        </span>
                        {unread && <span className="w-1.5 h-1.5 rounded-full bg-toss-blue mt-2 shrink-0" aria-label="읽지 않음" />}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })}
        {!list.length && <p className="text-center text-[13px] text-toss-gray500 py-16">새 알림이 없어요</p>}
      </div>
    </div>
  );
}
