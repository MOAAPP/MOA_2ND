import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { LESSONS, lessonById, pickToday, type Lesson } from '../lib/learning';
import { finishQuiz, fmtShares, getState, recordQuiz, setLessonProgress, useStore, won, APP_TODAY, type LessonCardLike } from '../lib/store';
import { learningStats } from '../lib/insights';
import { useRemote, v4 } from '../lib/api';
import './Learn.css';

const UNITS: { id: string; title: string; sub: string; color: string; lessons: string[] }[] = [
  { id: 'u1', title: '1단원 · 생활비 지키기', sub: '비상금과 이자부터', color: '#3182F6', lessons: ['emergency', 'compound'] },
  { id: 'u2', title: '2단원 · 투자 첫걸음', sub: 'ETF와 주문 방법', color: '#7C3AED', lessons: ['etf', 'order-type'] },
  { id: 'u3', title: '3단원 · 내가 산 종목 알기', sub: '가상 거래와 연결된 학습', color: '#0E9F8E', lessons: LESSONS.filter((l) => l.id.startsWith('stock-')).map((l) => l.id) },
];
const ORDER = UNITS.flatMap((u) => u.lessons);
const OFFSETS = [0, 46, 70, 46, 0, -46, -70, -46];

function Svg({ d, size = 20, w = 2 }: { d: React.ReactNode; size?: number; w?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">{d}</svg>;
}
const P = {
  flame: <path d="M12 21c4 0 6.5-2.6 6.5-6.3 0-3.3-2.3-5.6-3.6-7.7-.3 1.9-1.2 3-2.3 3.6.2-2.9-1.1-5.6-3.4-7.1.2 3.1-1.6 4.9-2.8 6.6C5.4 11.6 5.5 13 5.5 14.7 5.5 18.4 8 21 12 21Z" />,
  bolt: <path d="M13 3 5 13.5h6L10 21l8-10.5h-6L13 3Z" />,
  target: <><circle cx="12" cy="12" r="8.5" /><circle cx="12" cy="12" r="4.5" /><circle cx="12" cy="12" r="1" /></>,
  check: <path d="M5 12.5 10 17.5 19 7" />,
  lock: <><rect x="5" y="11" width="14" height="9" rx="2.5" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
  star: <path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8L12 3.5Z" />,
  close: <path d="M6 6l12 12M18 6 6 18" />,
  back: <path d="M15 18 9 12l6-6" />,
  refresh: <><path d="M20 11a8 8 0 1 0-2.3 5.7" /><path d="M20 5v6h-6" /></>,
  spark: <path d="M12 3.5l1.6 4.4 4.4 1.6-4.4 1.6L12 15.5l-1.6-4.4L6 9.5l4.4-1.6L12 3.5Z" />,
};

/* ───────── /learn — 학습 경로 ───────── */
export function LearnHub() {
  const navigate = useNavigate();
  const s = useStore((x) => x);
  const st = learningStats(s);
  const today = pickToday(getState(), APP_TODAY);
  const done = new Set(s.learning.done);
  const quizDone = new Set(s.learning.quizDone || []);
  const unlocked = (id: string) => { const i = ORDER.indexOf(id); return i <= 0 || done.has(ORDER[i - 1]) || done.has(id); };
  const current = ORDER.find((id) => unlocked(id) && !quizDone.has(id)) || ORDER[0];
  const [open, setOpen] = useState<string | null>(null);
  const openLesson = open ? lessonById(open) : null;

  return (
    <div className="ln">
      <header className="ln-top">
        <button type="button" className="ln-icon-btn" aria-label="뒤로" onClick={() => navigate(-1)}><Svg d={P.back} size={22} /></button>
        <div className="ln-stats">
          <span className="ln-stat is-fire"><Svg d={P.flame} size={19} w={1.8} />{st.streak}</span>
          <span className="ln-stat is-xp"><Svg d={P.bolt} size={18} w={1.8} />{st.xp}</span>
          <span className="ln-stat is-acc"><Svg d={P.target} size={18} w={1.8} />{st.accuracy == null ? '-' : `${Math.round(st.accuracy * 100)}%`}</span>
        </div>
        <button type="button" className="ln-link" onClick={() => navigate('/growth')}>기록</button>
      </header>

      <main className="ln-main">
        <DailyQuestion />

        {st.reviews.length > 0 && (
          <button type="button" className="ln-review" onClick={() => navigate(`/learn/${st.reviews[0].lessonId}/quiz?review=${st.reviews[0].questionId}`)}>
            <span className="ln-review-icon"><Svg d={P.refresh} size={20} /></span>
            <span><b>틀린 문제 {st.reviews.length}개 복습할 때예요</b><small>1·3·7일 간격으로 다시 풀면 오래 기억해요</small></span>
          </button>
        )}

        {UNITS.map((u) => (
          <section key={u.id} className="ln-unit">
            <div className="ln-unit-head" style={{ background: u.color }}>
              <div><b>{u.title}</b><small>{u.sub}</small></div>
              <span>{u.lessons.filter((id) => quizDone.has(id)).length}/{u.lessons.length}</span>
            </div>
            <div className="ln-path">
              {u.lessons.map((id, i) => {
                const l = lessonById(id)!;
                const state = quizDone.has(id) ? 'done' : id === current ? 'now' : unlocked(id) ? 'open' : 'lock';
                return (
                  <div key={id} className="ln-node-wrap" style={{ transform: `translateX(${OFFSETS[(ORDER.indexOf(id)) % OFFSETS.length]}px)` }}>
                    {state === 'now' && <span className="ln-bubble">{id === today.id ? '오늘 추천' : '시작'}</span>}
                    <button type="button" aria-label={`${l.title} ${state === 'lock' ? '잠김' : ''}`} disabled={state === 'lock'}
                      className={`ln-node is-${state}`} style={state === 'now' || state === 'open' ? { ['--c' as string]: u.color } : undefined}
                      onClick={() => setOpen(id)}>
                      {state === 'done' ? <Svg d={P.check} size={30} w={3.2} /> : state === 'lock' ? <Svg d={P.lock} size={26} /> : <span className="ln-node-emoji">{l.emoji}</span>}
                    </button>
                    <span className="ln-node-label">{l.title.length > 12 ? `${l.title.slice(0, 12)}…` : l.title}</span>
                    {i === u.lessons.length - 1 && <span className="ln-sep" />}
                  </div>
                );
              })}
            </div>
          </section>
        ))}
      </main>

      {openLesson && (
        <div className="ln-sheet-bg" onClick={() => setOpen(null)}>
          <div className="ln-sheet" role="dialog" aria-label={openLesson.title} onClick={(e) => e.stopPropagation()}>
            <span className="ln-sheet-emoji">{openLesson.emoji}</span>
            <p className="ln-sheet-topic">{openLesson.topic} · 약 {openLesson.minutes}분</p>
            <h2>{openLesson.title}</h2>
            <p className="ln-sheet-sum">{openLesson.id === today.id ? today.reason : openLesson.summary}</p>
            <div className="ln-sheet-meta"><span>카드 {openLesson.cards.length}장</span><span>퀴즈 {openLesson.quiz.length}문제</span><span>+{15 + openLesson.quiz.length * 10} XP</span></div>
            <button type="button" className="ln-btn" onClick={() => navigate(`/learn/${openLesson.id}`)}>{done.has(openLesson.id) ? '다시 배우기' : '배우기 시작'}</button>
            {done.has(openLesson.id) && <button type="button" className="ln-btn is-ghost" onClick={() => navigate(`/learn/${openLesson.id}/quiz`)}>퀴즈만 풀기</button>}
          </div>
        </div>
      )}
    </div>
  );
}

/** 서버(MOA_2ND_BE)의 오늘의 1문제. 서버를 못 쓰면 앱 안의 문제로 대신해요. */
function DailyQuestion() {
  const remote = useRemote(`daily-quiz:${APP_TODAY}`, () => v4.dailyQuiz('S01'));
  const local = (() => {
    const all = LESSONS.flatMap((l) => l.quiz.map((q) => ({ ...q, lessonId: l.id })));
    const k = Number(APP_TODAY.replace(/-/g, '')) % all.length;
    return all[k];
  })();
  const q = remote.data ? { question: remote.data.question, options: remote.data.options } : { question: local.q, options: local.options };
  const [pick, setPick] = useState<number | null>(remote.data?.answer_record?.choice ?? null);
  const [result, setResult] = useState<{ correct: boolean; answer: number; explain: string } | null>(null);
  useEffect(() => {
    const r = remote.data;
    if (r?.answer_record && r.correct_answer != null) setResult({ correct: r.answer_record.correct, answer: r.correct_answer, explain: r.explanation || '' });
  }, [remote.data]);

  const answer = async (k: number) => {
    if (result) return;
    setPick(k);
    if (remote.data) {
      const r = await v4.answerQuiz('S01', remote.data.id, k);
      if (r && r.correct_answer != null) { setResult({ correct: !!r.answer_record?.correct, answer: r.correct_answer, explain: r.explanation || '' }); return; }
    }
    const correct = k === local.answer;
    recordQuiz({ questionId: local.id, lessonId: local.lessonId, correct });
    setResult({ correct, answer: local.answer, explain: local.explain });
  };

  return (
    <section className="ln-daily">
      <div className="ln-daily-top"><span><Svg d={P.spark} size={14} w={1.7} />오늘의 1문제</span><small>{remote.data ? '내 기록으로 고른 문제' : remote.loading ? '불러오는 중' : '복습 문제'}</small></div>
      <p className="ln-daily-q">{q.question}</p>
      <div className="ln-daily-opts">
        {q.options.map((o, k) => {
          const cls = !result ? (pick === k ? 'is-pick' : '') : k === result.answer ? 'is-right' : pick === k ? 'is-wrong' : 'is-dim';
          return <button key={k} type="button" className={cls} onClick={() => answer(k)} disabled={!!result}>{o}</button>;
        })}
      </div>
      {result && <p className={`ln-daily-res ${result.correct ? 'ok' : 'no'}`}><b>{result.correct ? '정답! +10 XP' : '아쉬워요'}</b> {result.explain}</p>}
    </section>
  );
}

/* ───────── /learn/:id — 카드 ───────── */
export function LessonCards() {
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const lesson = lessonById(id);
  const fromTrade = params.get('from') === 'trade';
  const amount = Number(params.get('amount')) || 0;
  const [i, setI] = useState(0);
  const order = getState().invest.orders.find((o) => o.id === params.get('order'));
  const cards: LessonCardLike[] = !lesson ? [] : fromTrade ? [
    ...(order ? [{ emoji: '🧾', title: '방금 체결된 주문', body: `${order.name}\n${fmtShares(order.shares)}주 × ${won(order.price)} = ${won(order.price * order.shares)}\n${order.type === 'limit' ? `지정가 ${won(order.limitPrice || order.price)}` : '시장가'} 주문 · 남은 방어 머니 ${won(getState().invest.cash)}`, point: '이 거래에 맞춰 아래 카드를 골랐어요' }] : []),
    ...lesson.cards,
    ...(amount ? [{ emoji: '⚖️', title: '같은 돈, 다른 선택이었다면', body: `${won(amount)}을 1년 동안 두었을 때(가정)\n· 적금 연 3.8%: ${won(amount * 1.038)}\n· 이 ETF 기준 연 7.2%: ${won(amount * 1.072)}\n· 시장이 10% 하락하면: ${won(amount * 0.9)}`, point: '투자는 더 벌 수도, 원금보다 줄어들 수도 있어요' }] : []),
  ] : lesson.cards;

  useEffect(() => { if (lesson) setLessonProgress(lesson.id, i + 1, cards.length); }, [i, lesson, cards.length]);
  if (!lesson) return <NotFound />;
  const card = cards[i];
  const last = i === cards.length - 1;
  const qs = params.toString();

  return (
    <div className="ln ln-play">
      <header className="ln-play-top">
        <button type="button" className="ln-icon-btn" aria-label="닫기" onClick={() => navigate('/learn')}><Svg d={P.close} size={22} w={2.4} /></button>
        <div className="ln-bar"><i style={{ width: `${((i + 1) / cards.length) * 100}%` }} /></div>
        <span className="ln-count">{i + 1}/{cards.length}</span>
      </header>
      <main className="ln-play-main">
        <p className="ln-play-topic">{fromTrade ? '이번 거래로 배우기' : lesson.topic} · {lesson.title}</p>
        <section key={i} className="ln-card">
          <span className="ln-card-emoji">{card.emoji}</span>
          <h2>{card.title}</h2>
          <p>{card.body}</p>
          {card.point && <span className="ln-card-point">{card.point}</span>}
        </section>
        <p className="ln-source">{lesson.source} · {Number(lesson.updated.slice(5, 7))}월 {Number(lesson.updated.slice(8, 10))}일 확인</p>
      </main>
      <footer className="ln-play-foot">
        {i > 0 && <button type="button" className="ln-btn is-ghost is-small" onClick={() => setI((v) => v - 1)}>이전</button>}
        {last
          ? <button type="button" className="ln-btn" onClick={() => navigate(`/learn/${lesson.id}/quiz${qs ? `?${qs}` : ''}`)}>퀴즈 {lesson.quiz.length}문제 풀기</button>
          : <button type="button" className="ln-btn" onClick={() => setI((v) => v + 1)}>계속</button>}
      </footer>
    </div>
  );
}

/* ───────── /learn/:id/quiz — 퀴즈 ───────── */
export function LessonQuiz() {
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const lesson = lessonById(id);
  const [n, setN] = useState(0);
  const [pick, setPick] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  if (!lesson) return <NotFound />;
  const reviewId = params.get('review');
  const questions = reviewId ? lesson.quiz.filter((item) => item.id === reviewId) : lesson.quiz;
  if (!questions.length) return <NotFound />;
  const q = questions[n];
  const amount = Number(params.get('amount')) || 0;
  const practice = practiceTarget(lesson, amount);
  const correct = submitted && pick === q.answer;

  const submit = () => {
    if (pick == null) return;
    const ok = pick === q.answer;
    setSubmitted(true);
    if (ok) setScore((v) => v + 1);
    recordQuiz({ questionId: q.id, lessonId: lesson.id, correct: ok });
  };
  const next = () => {
    if (n === questions.length - 1) { if (!reviewId) finishQuiz(lesson.id); setFinished(true); return; }
    setN((v) => v + 1); setPick(null); setSubmitted(false);
  };

  if (finished) {
    const all = score === questions.length;
    const nx = pickToday(getState(), APP_TODAY);
    const nl = lessonById(nx.id);
    const xp = score * 10 + (reviewId ? 0 : 20);
    return (
      <div className="ln ln-play">
        <main className="ln-done">
          <div className={`ln-done-badge ${all ? 'gold' : ''}`}><Svg d={all ? P.star : P.check} size={46} w={2.4} /></div>
          <h1>{all ? '완벽해요!' : '학습 완료!'}</h1>
          <p>{questions.length}문제 중 {score}문제를 맞혔어요</p>
          <div className="ln-done-stats">
            <div className="xp"><small>얻은 XP</small><b>+{xp}</b></div>
            <div className="acc"><small>정답률</small><b>{Math.round((score / questions.length) * 100)}%</b></div>
          </div>
          {!all && <p className="ln-done-note">틀린 문제는 1일 뒤 복습 목록에 다시 나와요. 다음 추천 학습도 이 결과에 맞춰 바뀌어요.</p>}
          {nl && nl.id !== lesson.id && (
            <button type="button" className="ln-next" onClick={() => navigate(`/learn/${nl.id}`)}>
              <span className="ln-next-emoji">{nl.emoji}</span>
              <span><small>다음 추천 · {nx.reason}</small><b>{nl.title}</b></span>
            </button>
          )}
        </main>
        <footer className="ln-play-foot is-col">
          <button type="button" className="ln-btn" onClick={() => navigate(practice.to)}>{practice.label}</button>
          <button type="button" className="ln-btn is-ghost" onClick={() => navigate('/learn')}>학습 경로로</button>
        </footer>
      </div>
    );
  }

  return (
    <div className="ln ln-play">
      <header className="ln-play-top">
        <button type="button" className="ln-icon-btn" aria-label="닫기" onClick={() => navigate('/learn')}><Svg d={P.close} size={22} w={2.4} /></button>
        <div className="ln-bar is-green"><i style={{ width: `${((n + (submitted ? 1 : 0)) / questions.length) * 100}%` }} /></div>
        <span className="ln-count">{n + 1}/{questions.length}</span>
      </header>
      <main className="ln-play-main">
        <p className="ln-play-topic">{reviewId ? '복습 문제' : '알맞은 답을 고르세요'}</p>
        <h1 className="ln-q">{q.q}</h1>
        <div className="ln-opts" role="radiogroup">
          {q.options.map((o, k) => {
            const cls = !submitted ? (pick === k ? 'is-pick' : '') : k === q.answer ? 'is-right' : pick === k ? 'is-wrong' : 'is-dim';
            return <button key={k} type="button" role="radio" aria-checked={pick === k} disabled={submitted} className={cls} onClick={() => setPick(k)}>
              <span className="ln-opt-key">{k + 1}</span>{o}
            </button>;
          })}
        </div>
      </main>
      <footer className={`ln-play-foot ${submitted ? (correct ? 'is-ok' : 'is-no') : ''}`}>
        {submitted && (
          <div className="ln-feedback">
            <b>{correct ? '정답이에요!' : `정답: ${q.options[q.answer]}`}</b>
            <p>{q.explain}</p>
          </div>
        )}
        {submitted
          ? <button type="button" className={`ln-btn ${correct ? 'is-green' : 'is-red'}`} onClick={next}>{n === questions.length - 1 ? '결과 보기' : '계속'}</button>
          : <button type="button" className="ln-btn is-green" disabled={pick == null} onClick={submit}>확인</button>}
      </footer>
    </div>
  );
}

function practiceTarget(lesson: Lesson, amount: number) {
  if (lesson.practice.to === '/world' && amount) return { label: lesson.practice.label, to: `/world/compare?amount=${amount}&title=${encodeURIComponent(lesson.title)}` };
  return lesson.practice;
}

function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="ln ln-play">
      <main className="ln-done"><h1>학습을 찾을 수 없어요</h1><p>목록에서 다시 골라 주세요.</p></main>
      <footer className="ln-play-foot"><button type="button" className="ln-btn" onClick={() => navigate('/learn')}>학습 경로로</button></footer>
    </div>
  );
}
