import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PlanetGrowthScene from '../three/PlanetGrowthScene';
import { BottomSheet, Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { setState, todayDate, useStore, won, type SavingsDeposit, type SavingsProduct } from '../lib/store';
import { useApp } from '../lib/app';
import { addMonthsClamped } from '../lib/finance';

// 앱 전체 기준일(store.APP_TODAY)과 같은 날짜
const TODAY = todayDate();

const SHELF = [
  { key: 'free', kind: 'saving' as const, name: '자유 적금', rate: 3.2, months: 6, desc: '원할 때 아낀 만큼 자유롭게', badge: '부담 없이', monthly: 50000 },
  { key: 'space', kind: 'saving' as const, name: '우주여행 적금', rate: 4.5, months: 12, desc: '매달 정해진 금액을 꾸준히', badge: '최고 금리', monthly: 100000 },
  { key: 'parking', kind: 'deposit' as const, name: '파킹 예금', rate: 3.8, months: 6, desc: '목돈을 한 번에 맡겨두기', badge: '목돈', monthly: 0 },
];

const LEVELS = [
  { lv: 1, name: '먼지 행성', need: 0 },
  { lv: 2, name: '테라', need: 300000 },
  { lv: 3, name: '오아시스', need: 700000 },
  { lv: 4, name: '사파이어', need: 1200000 },
  { lv: 5, name: '네뷸라', need: 2000000 },
  { lv: 6, name: '갤럭시 코어', need: 3500000 },
];

function monthsSince(d: string) {
  const s = new Date(d);
  return Math.max(0, (TODAY.getFullYear() - s.getFullYear()) * 12 + (TODAY.getMonth() - s.getMonth()));
}
function maturity(p: SavingsProduct) {
  const s = addMonthsClamped(new Date(p.startedAt), p.months);
  return `${s.getFullYear()}.${String(s.getMonth() + 1).padStart(2, '0')}.${String(s.getDate()).padStart(2, '0')}`;
}
function expectedInterest(kind: 'deposit' | 'saving', principal: number, monthly: number, months: number, rate: number) {
  const r = rate / 100;
  if (kind === 'deposit') return principal * r * (months / 12);
  // 적금 단리: 매월 납입액 × 이율 × (n(n+1)/2)/12
  return monthly * r * ((months * (months + 1)) / 2) / 12;
}

const TAX = 0.154; // 이자소득세(지방세 포함)
const EARLY_RATE = 1.0; // 중도 해지 시 적용 금리(연 %) 가정
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const shortDate = (s: string) => `${Number(s.slice(5, 7))}월 ${Number(s.slice(8, 10))}일`;
function historyOf(p: SavingsProduct): SavingsDeposit[] {
  return p.history?.length ? p.history : [{ date: p.startedAt, amount: p.principal, kind: 'join' }];
}
function monthsBetween(a: string, b: Date) {
  const s = new Date(a);
  return Math.max(0, (b.getFullYear() - s.getFullYear()) * 12 + (b.getMonth() - s.getMonth()) + (b.getDate() >= s.getDate() ? 0 : -1));
}
/** 만기 원금: 적금은 남은 회차까지 매달 넣는다고 가정 */
function maturityPrincipal(p: SavingsProduct) {
  if (p.kind === 'deposit') return p.principal;
  const left = Math.max(0, p.months - historyOf(p).filter((h) => h.kind !== 'deposit' || h.amount === p.monthly).length);
  return p.principal + left * p.monthly;
}
function maturityDate(p: SavingsProduct) { return addMonthsClamped(new Date(p.startedAt), p.months); }
/** 만기 예상 이자(세전) — 실제 납입 날짜·금액 기준 + 적금은 남은 회차를 매달 넣는다고 가정 */
function projectedInterest(p: SavingsProduct) {
  const r = p.rate / 100;
  const end = maturityDate(p);
  const mLeft = (date: string) => { const d = new Date(date); return Math.max(0, (end.getFullYear() - d.getFullYear()) * 12 + (end.getMonth() - d.getMonth())); };
  const paid = historyOf(p).reduce((a, h) => a + h.amount * r * (mLeft(h.date) / 12), 0);
  if (p.kind === 'deposit') return paid;
  const regular = historyOf(p).filter((h) => h.kind === 'join' || h.amount === p.monthly).length;
  let future = 0;
  for (let j = regular; j < p.months; j++) future += p.monthly * r * ((p.months - j) / 12);
  return paid + future;
}
/** 지금 해지하면: 넣은 날부터 오늘까지 중도해지 금리로 이자 계산 */
function earlyClose(p: SavingsProduct) {
  const interest = historyOf(p).reduce((a, h) => a + h.amount * (EARLY_RATE / 100) * (monthsBetween(h.date, TODAY) / 12), 0);
  return { interest, net: p.principal + interest * (1 - TAX) };
}

export default function Savings() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const savings = useStore((s) => s.savings);
  const [sheet, setSheet] = useState<(typeof SHELF)[number] | null>(null);
  const [amount, setAmount] = useState(100000);
  const [months, setMonths] = useState(12);
  const [detail, setDetail] = useState<SavingsProduct | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);

  const total = useMemo(() => savings.reduce((a, p) => a + p.principal, 0), [savings]);
  const level = [...LEVELS].reverse().find((l) => total >= l.need) ?? LEVELS[0];
  const next = LEVELS.find((l) => l.need > total);
  const progress = next ? (total - level.need) / (next.need - level.need) : 1;
  const growth = Math.min(1, total / LEVELS[LEVELS.length - 1].need);
  const totalInterest = savings.reduce((a, p) => a + projectedInterest(p), 0);

  const openSheet = (item: (typeof SHELF)[number]) => {
    setSheet(item);
    setAmount(item.kind === 'deposit' ? 300000 : item.monthly);
    setMonths(item.months);
  };
  const preview = sheet ? expectedInterest(sheet.kind, sheet.kind === 'deposit' ? amount : 0, amount, months, sheet.rate) : 0;

  const join = () => {
    if (!sheet || !Number.isFinite(amount) || amount <= 0 || months < 1) { toast('납입 금액과 기간을 확인해 주세요', 'info'); return; }
    const p: SavingsProduct = {
      id: `s${Date.now()}`,
      kind: sheet.kind,
      name: sheet.name,
      rate: sheet.rate,
      months,
      monthly: sheet.kind === 'saving' ? amount : 0,
      principal: amount,
      startedAt: iso(TODAY),
      history: [{ date: iso(TODAY), amount, kind: 'join' }],
    };
    setState((s) => ({ savings: [p, ...s.savings] }));
    setSheet(null);
    toast(`${sheet.name}에 가입했어요. 행성이 자라고 있어요`, 'public');
  };

  const deposit = (p: SavingsProduct) => {
    const add = p.kind === 'saving' ? p.monthly : 50000;
    if (add <= 0 || new Date(`${maturity(p).replace(/\./g, '-')}T00:00:00`) < TODAY) { toast('납입 조건 또는 만기일을 확인해 주세요', 'info'); return; }
    setState((s) => ({ savings: s.savings.map((x) => (x.id === p.id ? { ...x, principal: x.principal + add, history: [...historyOf(x), { date: iso(TODAY), amount: add, kind: 'deposit' }] } : x)) }));
    toast(`${won(add)}을 ${p.name}에 넣었어요`, 'savings');
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader title="가상 예·적금" right={<button type="button" aria-label="알림" onClick={() => navigate('/notifications')} className="w-9 h-9 flex items-center justify-center text-toss-gray700"><Icon name="notifications" className="text-[22px]" /></button>} />

      <div className="px-4 pt-3 space-y-3.5">
        {/* Planet hero */}
        <section className="relative rounded-[28px] overflow-hidden bg-gradient-to-b from-[#0B1533] via-[#132257] to-[#1E3A8A] text-white shadow-card">
          <div className="absolute inset-0 opacity-60 bg-[radial-gradient(circle_at_70%_20%,rgba(56,189,248,0.35),transparent_45%),radial-gradient(circle_at_20%_80%,rgba(129,140,248,0.35),transparent_50%)]" />
          <div className="relative px-5 pt-5 flex items-start justify-between">
            <div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-white/10 border border-white/15 rounded-full px-2.5 py-1">
                <Icon name="public" className="text-[14px] text-cyan-300" /> Lv.{level.lv} {level.name}
              </span>
              <p className="mt-3 text-[12px] text-blue-100/80">행성에 모은 자산</p>
              <p className="text-[28px] font-extrabold tracking-tight tabular-nums">{won(total)}</p>
            </div>
            <div className="text-right">
              <p className="text-[11px] text-blue-100/70">만기 예상 이자</p>
              <p className="text-[15px] font-bold text-amber-300 tabular-nums">+{won(totalInterest)}</p>
            </div>
          </div>
          <PlanetGrowthScene growth={growth} orbs={Math.min(10, savings.length * 2 + 1)} className="relative w-full h-[230px] -mt-2" />
          <div className="relative px-5 pb-5">
            <div className="flex justify-between text-[11px] text-blue-100/80 mb-1.5">
              <span>{next ? `Lv.${next.lv} ${next.name}까지` : '최고 레벨 달성'}</span>
              <span className="tabular-nums">{next ? `${won(next.need - total)} 남음` : '100%'}</span>
            </div>
            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-400 transition-all duration-700" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <p className="mt-3 text-[12px] text-blue-100/80 leading-relaxed">독립된 가상 예·적금 연습 자산이에요. 실제 통장 및 모의투자 지갑에서는 차감되지 않아요.</p>
          </div>
        </section>

        {/* My products */}
        <Card>
          <SectionTitle action={<span className="text-[12px] text-toss-gray500">{savings.length}개 운용 중</span>}>내 예·적금</SectionTitle>
          {savings.length === 0 && <p className="text-[13px] text-toss-gray500 py-6 text-center">아직 가입한 상품이 없어요</p>}
          <ul className="space-y-3">
            {savings.map((p) => {
              const done = Math.min(p.months, monthsSince(p.startedAt));
              return (
                <li key={p.id} className="rounded-2xl border border-toss-gray100 p-4">
                  <button type="button" onClick={() => { setDetail(p); setConfirmClose(false); }} className="w-full text-left flex items-start justify-between" aria-label={`${p.name} 자세히 보기`}>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${p.kind === 'saving' ? 'bg-toss-lightBlue text-toss-blue' : 'bg-emerald-50 text-emerald-600'}`}>{p.kind === 'saving' ? '적금' : '예금'}</span>
                        <span className="text-[14px] font-bold text-toss-gray900">{p.name}</span>
                      </div>
                      <p className="text-[12px] text-toss-gray500 mt-1">연 {p.rate}% · {p.months}개월 · 만기 {maturity(p)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[16px] font-extrabold text-toss-gray900 tabular-nums">{won(p.principal)}</p>
                      <p className="text-[11px] text-toss-gray500 mt-0.5">넣은 돈 · 만기 원금 {won(maturityPrincipal(p))}</p>
                    </div>
                  </button>
                  <div className="mt-3 h-1.5 rounded-full bg-toss-gray100 overflow-hidden">
                    <div className="h-full bg-toss-blue rounded-full" style={{ width: `${Math.max(4, (done / p.months) * 100)}%` }} />
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <button type="button" onClick={() => { setDetail(p); setConfirmClose(false); }} className="text-[11px] text-toss-gray500 text-left">{done}/{p.months}개월 · 납입 {historyOf(p).length}회 · <u>내역</u></button>
                    <button type="button" onClick={() => deposit(p)} className="text-[12px] font-bold text-toss-blue bg-toss-lightBlue px-3 py-1.5 rounded-full active:scale-95 transition-transform">
                      {p.kind === 'saving' ? `${(p.monthly / 10000).toLocaleString()}만원 넣기` : '추가 예치'}
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>

        {/* Product shelf */}
        <Card>
          <SectionTitle>새 상품 둘러보기</SectionTitle>
          <div className="space-y-2.5">
            {SHELF.map((it) => (
              <button key={it.key} type="button" onClick={() => openSheet(it)} className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-toss-gray50 hover:bg-toss-gray100 active:scale-[0.99] transition-all text-left">
                <span className={`w-11 h-11 rounded-2xl flex items-center justify-center ${it.kind === 'deposit' ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-toss-blue'}`}>
                  <Icon name={it.kind === 'deposit' ? 'account_balance' : 'savings'} fill />
                </span>
                <span className="flex-1">
                  <span className="flex items-center gap-1.5">
                    <span className="text-[14px] font-bold text-toss-gray900">{it.name}</span>
                    <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-md">{it.badge}</span>
                  </span>
                  <span className="block text-[12px] text-toss-gray500 mt-0.5">{it.desc}</span>
                </span>
                <span className="text-right">
                  <span className="block text-[11px] text-toss-gray500">최고</span>
                  <span className="block text-[16px] font-extrabold text-toss-blue">연 {it.rate}%</span>
                </span>
              </button>
            ))}
          </div>
          <p className="mt-3 text-[11px] text-toss-gray400 leading-relaxed">모아의 예·적금은 실제 돈이 오가지 않는 가상 상품이에요. 실제 금리는 금융사마다 다를 수 있어요.</p>
        </Card>

        <button type="button" onClick={() => navigate('/invest')} className="w-full flex items-center justify-between bg-white rounded-[20px] px-5 py-4 shadow-card active:scale-[0.99] transition-transform">
          <span className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center"><Icon name="candlestick_chart" /></span>
            <span className="text-left">
              <span className="block text-[14px] font-bold text-toss-gray900">가상 투자로 더 키우기</span>
              <span className="block text-[12px] text-toss-gray500">방어 머니로 ETF를 모의 매수해요</span>
            </span>
          </span>
          <Icon name="chevron_right" className="text-toss-gray400" />
        </button>
      </div>

      <BottomSheet open={!!detail} onClose={() => setDetail(null)} title={detail?.name ?? ''}>
        {detail && (() => {
          const p = savings.find((x) => x.id === detail.id) ?? detail;
          const hist = historyOf(p);
          const matP = maturityPrincipal(p);
          const matI = projectedInterest(p);
          const early = earlyClose(p);
          return (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-2xl bg-toss-gray50 p-3.5"><p className="text-[11px] text-toss-gray500">지금까지 넣은 돈</p><p className="text-[17px] font-extrabold tabular-nums mt-0.5">{won(p.principal)}</p></div>
                <div className="rounded-2xl bg-toss-lightBlue/60 p-3.5"><p className="text-[11px] text-toss-blue">만기 예상 원금</p><p className="text-[17px] font-extrabold text-toss-blue tabular-nums mt-0.5">{won(matP)}</p></div>
              </div>
              <div className="rounded-2xl border border-toss-gray100 p-4 space-y-2 text-[13px]">
                <div className="flex justify-between"><span className="text-toss-gray600">만기일</span><b>{maturity(p)}</b></div>
                <div className="flex justify-between"><span className="text-toss-gray600">만기 예상 이자 (세전, 연 {p.rate}%)<span className="block text-[10.5px] text-toss-gray400">실제 납입일 기준 계산</span></span><b className="text-emerald-600 tabular-nums">+{won(matI)}</b></div>
                <div className="flex justify-between"><span className="text-toss-gray600">만기 예상 수령액 (세후)</span><b className="tabular-nums">{won(matP + matI * (1 - TAX))}</b></div>
              </div>
              <div>
                <p className="text-[13px] font-bold text-toss-gray900 mb-2">납입 내역</p>
                <ul className="rounded-2xl bg-toss-gray50 divide-y divide-white max-h-48 overflow-y-auto no-scrollbar">
                  {[...hist].reverse().map((h, i) => (
                    <li key={i} className="flex justify-between px-4 py-2.5 text-[13px]">
                      <span className="text-toss-gray700">{shortDate(h.date)} · {h.kind === 'join' ? '가입' : p.kind === 'saving' && h.amount === p.monthly ? '정기 납입' : '추가 납입'}</span>
                      <b className="tabular-nums">+{won(h.amount)}</b>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl bg-amber-50 p-4 text-[13px] space-y-1.5">
                <p className="font-bold text-amber-800">지금 해지하면</p>
                <div className="flex justify-between text-amber-900"><span>중도 해지 이자 (연 {EARLY_RATE}% 가정)</span><b className="tabular-nums">+{won(early.interest)}</b></div>
                <div className="flex justify-between text-amber-900"><span>받는 금액 (세후)</span><b className="tabular-nums">{won(early.net)}</b></div>
                <p className="text-[11px] text-amber-700/80">만기까지 두면 이자를 {won(Math.max(0, matI - early.interest))} 더 받을 수 있어요.</p>
              </div>
              {confirmClose ? (
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => setConfirmClose(false)} className="py-3.5 rounded-2xl bg-toss-gray100 text-[14px] font-bold text-toss-gray700">유지할게요</button>
                  <button type="button" onClick={() => { setState((s) => ({ savings: s.savings.filter((x) => x.id !== p.id) })); setDetail(null); toast(`${p.name}을 해지했어요 · ${won(early.net)} 수령`, 'savings'); }} className="py-3.5 rounded-2xl bg-rose-500 text-white text-[14px] font-bold">해지하기</button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => setConfirmClose(true)} className="py-3.5 rounded-2xl bg-toss-gray100 text-[14px] font-bold text-toss-gray700">중도 해지</button>
                  <PrimaryButton onClick={() => deposit(p)}>{p.kind === 'saving' ? `${(p.monthly / 10000).toLocaleString()}만원 넣기` : '5만원 추가 예치'}</PrimaryButton>
                </div>
              )}
            </div>
          );
        })()}
      </BottomSheet>

      <BottomSheet open={!!sheet} onClose={() => setSheet(null)} title={sheet ? `${sheet.name} 가입` : ''}>
        {sheet && (
          <div className="space-y-5">
            <div>
              <p className="text-[13px] text-toss-gray600 mb-2">{sheet.kind === 'deposit' ? '맡길 금액' : '매달 넣을 금액'}</p>
              <div className="flex items-end gap-1 border-b-2 border-toss-blue pb-2">
                <input
                  inputMode="numeric"
                  value={amount ? amount.toLocaleString('ko-KR') : ''}
                  onChange={(e) => setAmount(Math.min(10000000, Number(e.target.value.replace(/\D/g, '')) || 0))}
                  className="flex-1 text-[28px] font-extrabold text-toss-gray900 outline-none bg-transparent tabular-nums"
                  aria-label="금액"
                />
                <span className="text-[18px] font-bold text-toss-gray700 pb-1">원</span>
              </div>
              <div className="flex gap-2 mt-3">
                {[10000, 50000, 100000].map((v) => (
                  <button key={v} type="button" onClick={() => setAmount((a) => a + v)} className="px-3 py-1.5 rounded-full bg-toss-gray100 text-[12px] font-semibold text-toss-gray700 active:scale-95">+{v / 10000}만</button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[13px] text-toss-gray600 mb-2">기간</p>
              <div className="grid grid-cols-4 gap-2">
                {[3, 6, 12, 24].map((m) => (
                  <button key={m} type="button" onClick={() => setMonths(m)} className={`py-2.5 rounded-xl text-[13px] font-bold transition-all ${months === m ? 'bg-toss-blue text-white shadow-sm' : 'bg-toss-gray100 text-toss-gray600'}`}>{m}개월</button>
                ))}
              </div>
            </div>
            <div className="rounded-2xl bg-toss-gray50 p-4 space-y-2 text-[13px]">
              <div className="flex justify-between"><span className="text-toss-gray600">적용 금리</span><b className="text-toss-gray900">연 {sheet.rate}%</b></div>
              <div className="flex justify-between"><span className="text-toss-gray600">만기 원금</span><b className="text-toss-gray900 tabular-nums">{won(sheet.kind === 'deposit' ? amount : amount * months)}</b></div>
              <div className="flex justify-between"><span className="text-toss-gray600">예상 이자 (세전)</span><b className="text-emerald-600 tabular-nums">+{won(preview)}</b></div>
            </div>
            <PrimaryButton onClick={join} disabled={amount < 1000}>가입하고 행성 키우기</PrimaryButton>
          </div>
        )}
      </BottomSheet>
    </div>
  );
}
