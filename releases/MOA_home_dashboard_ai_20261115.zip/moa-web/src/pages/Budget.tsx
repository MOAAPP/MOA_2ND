import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { APP_TODAY, EXPENSE_CATEGORIES, getState, setState, useStore, won } from '../lib/store';
import { byCategory } from '../lib/finance';
import { useApp } from '../lib/app';

const META: Record<string, { icon: string; tone: string }> = {
  식비: { icon: 'restaurant', tone: 'bg-orange-50 text-orange-500' },
  '카페/간식': { icon: 'local_cafe', tone: 'bg-amber-50 text-amber-600' },
  교통: { icon: 'directions_bus', tone: 'bg-emerald-50 text-emerald-600' },
  쇼핑: { icon: 'shopping_bag', tone: 'bg-pink-50 text-pink-500' },
  '생활/마트': { icon: 'local_mall', tone: 'bg-sky-50 text-sky-600' },
  '의료/건강': { icon: 'medical_services', tone: 'bg-rose-50 text-rose-500' },
  '디지털/가전': { icon: 'devices', tone: 'bg-indigo-50 text-indigo-500' },
  기타: { icon: 'more_horiz', tone: 'bg-toss-gray100 text-toss-gray600' },
};

export default function Budget() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const [budgets, setBudgets] = useState<Record<string, number>>(() => Object.fromEntries(EXPENSE_CATEGORIES.map((k) => [k, getState().budgets[k] ?? 0])));
  // 가계부·리포트와 같은 거래 목록으로 이번 달 카테고리 지출 계산
  const cats = useStore((s) => s.txs) && byCategory();
  const SPENT: Record<string, number> = Object.fromEntries(Object.entries(cats).map(([k, v]) => [k, v.amount]));
  const month = Number(APP_TODAY.slice(5, 7));
  const total = Object.values(budgets).reduce((a, b) => a + b, 0);
  const spent = Object.values(SPENT).reduce((a, b) => a + b, 0);
  const nearFull = EXPENSE_CATEGORIES.filter((k) => budgets[k] > 0 && (SPENT[k] ?? 0) / budgets[k] >= 0.8);
  const pct = Math.min(100, Math.round((spent / Math.max(1, total)) * 100));

  const step = (k: string, d: number) => setBudgets((b) => ({ ...b, [k]: Math.max(0, (b[k] ?? 0) + d) }));
  const save = () => {
    setState((s) => ({ budgets, profile: { ...s.profile, monthlyBudget: total } }));
    toast('이번 달 예산을 저장했어요');
    navigate(-1);
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-28">
      <PageHeader title="예산 설정" />
      <div className="px-4 pt-3 space-y-3.5">
        <Card>
          <p className="text-[13px] text-toss-gray500">{month}월 전체 예산</p>
          <p className="mt-1 text-[28px] font-extrabold tracking-tight text-toss-gray900 tabular-nums">{won(total)}</p>
          <div className="mt-4 h-2.5 rounded-full bg-toss-gray100 overflow-hidden">
            <div className={`h-full rounded-full transition-all ${pct >= 90 ? 'bg-toss-red' : 'bg-toss-blue'}`} style={{ width: `${pct}%` }} />
          </div>
          <div className="mt-2 flex justify-between text-[12px]">
            <span className="text-toss-gray500">지금까지 {won(spent)} 썼어요 ({pct}%)</span>
            <span className="font-bold text-toss-blue tabular-nums">{won(Math.max(0, total - spent))} 남음</span>
          </div>
        </Card>

        <Card className="!px-0">
          <div className="px-5"><SectionTitle action={<span className="text-[12px] text-toss-gray500">1만원 단위</span>}>카테고리별 예산</SectionTitle></div>
          <ul className="divide-y divide-toss-gray100">
            {Object.keys(budgets).map((k) => {
              const b = budgets[k]; const s = SPENT[k] ?? 0; const over = s > b;
              return (
                <li key={k} className="px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <span className={`w-10 h-10 rounded-2xl flex items-center justify-center ${META[k]?.tone}`}><Icon name={META[k]?.icon ?? 'category'} fill className="text-[20px]" /></span>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-toss-gray900">{k}</p>
                      <p className={`text-[12px] ${over ? 'text-toss-red font-semibold' : 'text-toss-gray500'}`}>{won(s)} 사용{over ? ' · 예산 초과' : ''}</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button type="button" aria-label={`${k} 예산 줄이기`} onClick={() => step(k, -10000)} className="w-8 h-8 rounded-full bg-toss-gray100 text-toss-gray700 flex items-center justify-center active:scale-90"><Icon name="remove" className="text-[18px]" /></button>
                      <span className="w-[78px] text-right text-[14px] font-bold text-toss-gray900 tabular-nums">{won(b)}</span>
                      <button type="button" aria-label={`${k} 예산 늘리기`} onClick={() => step(k, 10000)} className="w-8 h-8 rounded-full bg-toss-lightBlue text-toss-blue flex items-center justify-center active:scale-90"><Icon name="add" className="text-[18px]" /></button>
                    </div>
                  </div>
                  <div className="mt-2.5 ml-[52px] h-1.5 rounded-full bg-toss-gray100 overflow-hidden">
                    <div className={`h-full rounded-full ${over ? 'bg-toss-red' : 'bg-toss-blue/70'}`} style={{ width: `${Math.min(100, (s / Math.max(1, b)) * 100)}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>

        <div className="flex gap-2 rounded-2xl bg-white/70 border border-toss-gray200 p-4">
          <Icon name="tips_and_updates" className="text-amber-500 text-[20px]" fill />
          <p className="text-[12px] text-toss-gray600 leading-relaxed">예산은 가계부·지출 리포트·홈에 같은 금액으로 쓰여요.{nearFull.length ? ` ${nearFull.join(', ')} 예산을 80% 넘게 썼어요.` : ' 아직 80%를 넘긴 카테고리는 없어요.'}</p>
        </div>
      </div>
      <div className="fixed bottom-0 inset-x-0 px-4 pt-3 pb-5 bg-gradient-to-t from-[#F2F4F6] via-[#F2F4F6] to-transparent">
        <PrimaryButton onClick={save}>저장하기</PrimaryButton>
      </div>
    </div>
  );
}
