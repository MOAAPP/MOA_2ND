import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { useStore, getState } from '../lib/store';
import { impactOf } from '../lib/finance';
import { worldAssets } from '../lib/bridge';
import { branchGap, collectBranches, KIND_META, worldSeries, worldSummary, type Branch } from '../lib/worldRecords';
import './WorldRecords.css';

const num = (n: number) => Math.round(n).toLocaleString('ko-KR');
const signed = (n: number) => (Math.round(n) === 0 ? '0' : `${n > 0 ? '+' : '-'}${num(Math.abs(n))}`);
const md = (iso: string) => `${Number(iso.slice(5, 7))}월 ${Number(iso.slice(8, 10))}일`;
const STOPS = [0, 1, 3, 5, 10];

/** 숫자가 바뀔 때 부드럽게 따라가는 카운터 */
function useCount(target: number, ms = 650) {
  const [v, setV] = useState(target);
  const from = useRef(target);
  useEffect(() => {
    const start = performance.now();
    const a = from.current;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / ms);
      const e = 1 - Math.pow(1 - p, 3);
      const cur = a + (target - a) * e;
      setV(cur);
      from.current = cur;
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

function Chart({ branches, years, flipped, cursor }: { branches: Branch[]; years: number; flipped: Set<string>; cursor: number }) {
  const data = useMemo(() => worldSeries(branches, 10, flipped, 40), [branches, flipped]);
  const max = Math.max(...data.map((p) => Math.max(p.mine, p.other)), 1);
  const W = 320; const H = 150;
  const x = (t: number) => 12 + (t / 10) * (W - 24);
  const y = (v: number) => H - 18 - (v / max) * (H - 34);
  const line = (k: 'mine' | 'other') => data.map((p, i) => `${i ? 'L' : 'M'}${x(p.t).toFixed(1)},${y(p[k]).toFixed(1)}`).join(' ');
  const area = `${line('mine')} ${[...data].reverse().map((p) => `L${x(p.t).toFixed(1)},${y(p.other).toFixed(1)}`).join(' ')} Z`;
  const at = data.reduce((best, p) => (Math.abs(p.t - cursor) < Math.abs(best.t - cursor) ? p : best), data[0]);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="wr-chart" role="img" aria-label={`${years}년 동안 지금의 나와 평행세계의 나 자산 비교`}>
      <defs>
        <linearGradient id="wrFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#6D6DF6" stopOpacity=".28" /><stop offset="1" stopColor="#6D6DF6" stopOpacity="0" /></linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((g) => <line key={g} x1="12" x2={W - 12} y1={18 + g * (H - 36)} y2={18 + g * (H - 36)} stroke="rgba(255,255,255,.07)" />)}
      <path d={area} fill="url(#wrFill)" className="wr-area" />
      <path d={line('other')} fill="none" stroke="rgba(255,255,255,.45)" strokeWidth="2" strokeDasharray="4 4" strokeLinecap="round" />
      <path key={[...flipped].join()} d={line('mine')} fill="none" stroke="#9EA3FF" strokeWidth="3" strokeLinecap="round" className="wr-line" />
      <line x1={x(cursor)} x2={x(cursor)} y1="10" y2={H - 16} stroke="rgba(255,255,255,.55)" strokeWidth="1.2" className="wr-cursor" />
      <circle cx={x(at.t)} cy={y(at.other)} r="4.5" fill="#fff" fillOpacity=".7" className="wr-dot" />
      <circle cx={x(at.t)} cy={y(at.mine)} r="6" fill="#9EA3FF" stroke="#fff" strokeWidth="2" className="wr-dot" />
      {STOPS.filter((t) => t !== 1).map((t) => <text key={t} x={x(t)} y={H - 3} fontSize="9.5" textAnchor="middle" fill="rgba(255,255,255,.55)">{t === 0 ? '지금' : `${t}년`}</text>)}
    </svg>
  );
}

export default function WorldRecords() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const s = useStore((x) => x);
  const branches = useMemo(() => collectBranches(s), [s.savings, s.wishes, s.txs, s.invest, s.simSettings]); // eslint-disable-line
  const [years, setYears] = useState(5);
  const [flipped, setFlipped] = useState<Set<string>>(new Set());
  const [showAll, setShowAll] = useState(false);
  const [filter, setFilter] = useState<'all' | 'plus' | 'minus'>('all');

  // 예전 링크(/world?amount=…, ?wish=…)는 소비 비교 화면으로
  useEffect(() => {
    if (params.get('amount') || params.get('wish') || params.get('title')) navigate(`/world/compare?${params.toString()}`, { replace: true });
  }, [params, navigate]);

  const sum = worldSummary(branches, years, flipped);
  const gapAnim = useCount(sum.gap);
  const gainedAnim = useCount(sum.gained);
  const missedAnim = useCount(sum.missed);
  const ratio = Math.min(1, Math.abs(sum.gap) / Math.max(1, sum.gained + sum.missed));
  const spread = 14 + ratio * 20; // 두 세계 구슬 사이 거리(%)

  const toggle = (id: string) => setFlipped((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const list = branches
    .map((b) => ({ b, g: branchGap(b, years) * (flipped.has(b.id) ? -1 : 1) }))
    .filter(({ g }) => (filter === 'all' ? true : filter === 'plus' ? g >= 0 : g < 0));
  const shown = showAll ? list : list.slice(0, 6);

  return (
    <div className="wr">
      <AppHeader profileTo="/more" />
      <section className="wr-hero">
        <div className="wr-stars" aria-hidden="true" />
        <p className="wr-kicker">내 기록이 만든 평행세계</p>
        <h1 className="wr-gap">{signed(gapAnim)}<small>원</small></h1>
        <p className="wr-sub">{years === 0 ? '지금' : `${years}년 뒤`}, 기록 속의 나는 반대로 선택한 나보다 {sum.gap >= 0 ? '이만큼 더 가져요' : '이만큼 덜 가져요'}</p>

        <div className="wr-orbs" aria-hidden="true">
          <div className="wr-orb is-other" style={{ left: `${50 - spread}%` }}><span /><b>평행세계의 나</b></div>
          <div className="wr-link" style={{ left: `${50 - spread}%`, right: `${50 - spread}%` }} />
          <div className="wr-orb is-mine" style={{ left: `${50 + spread}%` }}><span /><b>기록 속의 나</b></div>
        </div>

        <Chart branches={branches} years={years} flipped={flipped} cursor={years} />

        <div className="wr-scrub">
          <input type="range" min={0} max={10} step={1} value={years} onChange={(e) => setYears(Number(e.target.value))} aria-label="비교 시점" />
          <div className="wr-stops">
            {STOPS.map((t) => <button key={t} type="button" className={years === t ? 'on' : ''} onClick={() => setYears(t)}>{t === 0 ? '지금' : `${t}년`}</button>)}
          </div>
        </div>
      </section>

      <main className="wr-main">
        <div className="wr-split">
          <button type="button" className={filter === 'plus' ? 'on' : ''} onClick={() => setFilter(filter === 'plus' ? 'all' : 'plus')}>
            <small>지킨 선택</small><b className="plus">{signed(gainedAnim)}원</b>
          </button>
          <button type="button" className={filter === 'minus' ? 'on' : ''} onClick={() => setFilter(filter === 'minus' ? 'all' : 'minus')}>
            <small>다르게 할 수 있었던 선택</small><b className="minus">{signed(-missedAnim)}원</b>
          </button>
        </div>

        <section className="wr-card">
          <div className="wr-card-head">
            <div><h2>갈림길이 된 기록 {list.length}개</h2><small>눌러서 그때 선택을 뒤집어 보세요</small></div>
            {flipped.size > 0 && <button type="button" onClick={() => setFlipped(new Set())}>되돌리기</button>}
          </div>
          {branches.length === 0 && <p className="wr-empty">가계부·구매 고민·예적금을 기록하면 여기에 갈림길이 생겨요.</p>}
          <ul className="wr-list">
            {shown.map(({ b, g }) => {
              const meta = KIND_META[b.kind];
              const flip = flipped.has(b.id);
              return (
                <li key={b.id} className={flip ? 'is-flip' : ''}>
                  <button type="button" onClick={() => toggle(b.id)} aria-pressed={flip}>
                    <span className="wr-kind" style={{ color: meta.color, background: meta.bg }}>{meta.label}</span>
                    <span className="wr-item">
                      <b>{b.title}</b>
                      <small>{md(b.date)} · {num(b.amount)}원 · {flip ? b.other : b.mine}</small>
                    </span>
                    <span className={`wr-g ${g >= 0 ? 'plus' : 'minus'}`}>{signed(g)}</span>
                    <span className={`wr-switch ${flip ? 'on' : ''}`}><i /></span>
                  </button>
                </li>
              );
            })}
          </ul>
          {list.length > 6 && <button type="button" className="wr-more" onClick={() => setShowAll((v) => !v)}>{showAll ? '접기' : `${list.length - 6}개 더 보기`}</button>}
        </section>

        <button type="button" className="wr-ai" onClick={() => navigate('/agent')}>
          <span className="wr-ai-icon">AI</span>
          <span className="wr-ai-text"><b>이 기록을 바탕으로 다음 경로 묻기</b><small>목표를 말하면 필수 결제를 지키는 경로만 골라줘요</small></span>
          <span className="wr-ai-go">›</span>
        </button>

        <h3 className="wr-h3">새 선택을 미리 실험해 보기</h3>
        <PreviewBuy onOpen={(q) => navigate(`/world/compare${q}`)} />
        <PreviewSix onOpen={() => navigate('/world/explore?view=B&amount=100000')} />

        <p className="wr-note">적금 연 {s.simSettings.saveRate}% · 투자 연 {s.simSettings.investRate}% 가정으로 계산했어요. 투자는 원금보다 줄어들 수 있고, 가상 자산은 실제 통장 잔액과 분리돼요.</p>
      </main>
    </div>
  );
}

/** 사기 전에: 산 나 vs 안 산 나의 월급 전 여유를 막대로 미리 보여줌 */
function PreviewBuy({ onOpen }: { onOpen: (q: string) => void }) {
  const s = getState();
  const wish = s.wishes.find((w) => w.status === 'thinking' || w.status === 'later');
  const name = wish?.name || '노이즈캔슬링 헤드폰';
  const amount = wish?.amount || 259000;
  const kept = impactOf(0, s).spendable;
  const bought = impactOf(amount, s).spendable;
  const max = Math.max(1, Math.abs(kept), Math.abs(bought));
  const w = (v: number) => `${Math.max(4, (Math.max(0, v) / max) * 100)}%`;
  return (
    <button type="button" className="wr-pv" onClick={() => onOpen(wish ? `?wish=${wish.id}` : `?amount=${amount}&title=${encodeURIComponent(name)}`)}>
      <div className="wr-pv-head">
        <span className="wr-pv-tag buy">사기 전 확인</span>
        <b>이걸 사도 월급날까지 괜찮을까?</b>
        <small>{name} · {num(amount)}원{wish ? '' : ' (예시)'}</small>
      </div>
      <div className="wr-pv-bars">
        <div><span>안 산 나</span><i style={{ width: w(kept), background: '#3B82F6' }} /><b>{num(kept)}원</b></div>
        <div><span>산 나</span><i style={{ width: w(bought), background: bought < 0 ? '#F04452' : '#FF8A8A' }} /><b className={bought < 0 ? 'bad' : ''}>{bought < 0 ? '-' : ''}{num(Math.abs(bought))}원</b></div>
      </div>
      <p className="wr-pv-foot">{bought < 0 ? '사면 필수 결제 전에 잔액이 모자라요' : `사도 필수 결제는 지켜요 · 여유가 ${num(kept - bought)}원 줄어요`}<span>비교하기 ›</span></p>
    </button>
  );
}

/** 같은 10만 원을 6가지로 썼을 때 3년 뒤 가정 금액 */
function PreviewSix({ onOpen }: { onOpen: () => void }) {
  const opts = getState().simSettings;
  const v = worldAssets(100000, 3, opts) as Record<number, number>;
  const labels = ['지금 사기', '현금 보유', '나중에 사기', '저축', '투자', '나눠서'];
  const vals = [1, 2, 3, 4, 5, 6].map((i) => Math.max(0, v[i] || 0));
  const max = Math.max(...vals, 1);
  const best = vals.indexOf(max);
  return (
    <button type="button" className="wr-pv" onClick={onOpen}>
      <div className="wr-pv-head">
        <span className="wr-pv-tag six">6개 세계선</span>
        <b>같은 10만 원, 3년 뒤엔 얼마일까?</b>
        <small>쓰기·두기·미루기·저축·투자·나누기를 한 번에 비교</small>
      </div>
      <div className="wr-six">
        {vals.map((x, i) => (
          <div key={i} className={i === best ? 'best' : ''}>
            <em>{x >= 10000 ? `${(x / 10000).toFixed(1)}만` : `${num(x)}원`}</em>
            <i style={{ height: `${Math.max(6, (x / max) * 100)}%` }} />
            <span>{labels[i]}</span>
          </div>
        ))}
      </div>
      <p className="wr-pv-foot">투자는 연 {opts.investRate}% 가정이라 줄어들 수도 있어요<span>탐험하기 ›</span></p>
    </button>
  );
}
