import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BottomSheet, Card, Icon, PageHeader, PrimaryButton } from '../components/ui';
import { useApp } from '../lib/app';
import {
  APP_TODAY, WISH_LABEL, decideWish, removeWish, updateWish, useStore, won,
  type Necessity, type Wish, type WishStatus,
} from '../lib/store';

const FILTERS: { key: 'all' | WishStatus; label: string }[] = [
  { key: 'all', label: '전체' },
  { key: 'thinking', label: '고민 중' },
  { key: 'later', label: '보류 중' },
  { key: 'bought', label: '구매 완료' },
  { key: 'skipped', label: '구매 포기' },
];
const NEED: Record<Necessity, string> = { must: '꼭 필요해요', delay: '급하지 않아요', want: '선택적 소비' };
const BADGE: Record<WishStatus, string> = {
  thinking: 'bg-blue-50 text-blue-600',
  later: 'bg-amber-50 text-amber-700',
  bought: 'bg-slate-100 text-slate-600',
  skipped: 'bg-emerald-50 text-emerald-700',
};

function addDays(iso: string, days: number) {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
const shortDate = (iso: string | null) => (iso ? `${Number(iso.slice(5, 7))}월 ${Number(iso.slice(8, 10))}일` : '날짜 미정');

export default function Wishlist() {
  const navigate = useNavigate();
  const { toast } = useApp();
  const [params, setParams] = useSearchParams();
  const wishes = useStore((s) => s.wishes);
  const [filter, setFilter] = useState<'all' | WishStatus>('all');
  const [q, setQ] = useState('');
  const [decide, setDecide] = useState<Wish | null>(null);
  const [laterFor, setLaterFor] = useState<Wish | null>(null);
  const [edit, setEdit] = useState<Wish | null>(null);
  const [editName, setEditName] = useState('');
  const [editAmount, setEditAmount] = useState('');
  const newId = params.get('new');

  // 방금 담은 고민이면 결정 시트를 바로 띄움
  useEffect(() => {
    if (!newId) return;
    const w = wishes.find((x) => x.id === newId);
    if (w && w.status === 'thinking') setDecide(w);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [newId]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: wishes.length, thinking: 0, later: 0, bought: 0, skipped: 0 };
    wishes.forEach((w) => { c[w.status] += 1; });
    return c;
  }, [wishes]);
  const saved = wishes.filter((w) => w.status === 'skipped').reduce((a, w) => a + w.amount, 0);
  const pending = wishes.filter((w) => w.status === 'thinking' || w.status === 'later').reduce((a, w) => a + w.amount, 0);
  const list = wishes.filter((w) => (filter === 'all' || w.status === filter) && (!q.trim() || w.name.includes(q.trim())));

  const closeDecide = () => { setDecide(null); if (newId) setParams({}, { replace: true }); };

  const bought = (w: Wish) => {
    decideWish(w.id, 'bought', { date: APP_TODAY });
    closeDecide();
    toast(`${won(w.amount)} 지출로 가계부에 기록했어요`);
  };
  const skip = (w: Wish) => {
    decideWish(w.id, 'skipped');
    closeDecide();
    navigate(`/record?celebrate=${w.id}`);
  };
  const later = (w: Wish, days: number | null) => {
    decideWish(w.id, 'later', { date: days == null ? undefined : addDays(APP_TODAY, days) });
    if (days == null) updateWish(w.id, { plannedDate: null });
    setLaterFor(null);
    closeDecide();
    toast(days == null ? '보류 목록에 담았어요' : `${shortDate(addDays(APP_TODAY, days))}에 다시 고민해요`, 'schedule');
  };
  const openEdit = (w: Wish) => { setEdit(w); setEditName(w.name); setEditAmount(String(w.amount)); };
  const saveEdit = () => {
    if (!edit) return;
    const amount = Number(editAmount.replace(/[^0-9]/g, ''));
    if (!editName.trim() || !(amount > 0)) return toast('상품명과 금액을 확인해 주세요', 'error');
    updateWish(edit.id, { name: editName.trim(), amount });
    setEdit(null);
    toast('수정했어요');
  };

  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader title="내 소비 결정 보관함" right={<button type="button" aria-label="구매 고민 추가" onClick={() => navigate('/record')} className="w-9 h-9 flex items-center justify-center text-toss-gray700"><Icon name="add" className="text-[24px]" /></button>} />

      <div className="px-4 pt-3 space-y-3.5">
        <Card className="!p-4">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="rounded-2xl bg-emerald-50 p-3.5">
              <p className="text-[11px] font-semibold text-emerald-700">사지 않기로 한 금액</p>
              <p className="text-[18px] font-extrabold text-emerald-700 tabular-nums mt-0.5">{won(saved)}</p>
              <p className="text-[10.5px] text-emerald-700/70 mt-0.5">실제 잔액에는 더해지지 않아요</p>
            </div>
            <div className="rounded-2xl bg-toss-gray50 p-3.5">
              <p className="text-[11px] font-semibold text-toss-gray600">아직 고민 중인 금액</p>
              <p className="text-[18px] font-extrabold text-toss-gray900 tabular-nums mt-0.5">{won(pending)}</p>
              <p className="text-[10.5px] text-toss-gray500 mt-0.5">고민 {counts.thinking}건 · 보류 {counts.later}건</p>
            </div>
          </div>
        </Card>

        <div className="flex items-center gap-2 bg-white rounded-2xl px-3.5 py-2.5 shadow-card">
          <Icon name="search" className="text-[18px] text-toss-gray400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="상품 이름으로 찾기" className="flex-1 bg-transparent border-0 p-0 text-[14px] outline-none focus:ring-0" />
        </div>

        <div className="flex gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4">
          {FILTERS.map((f) => (
            <button key={f.key} type="button" onClick={() => setFilter(f.key)}
              className={`shrink-0 px-3.5 py-1.5 rounded-full text-[12px] font-bold transition-all ${filter === f.key ? 'bg-toss-gray900 text-white' : 'bg-white text-toss-gray600 shadow-card'}`}>
              {f.label} <span className="opacity-60">{counts[f.key]}</span>
            </button>
          ))}
        </div>

        {list.length === 0 && (
          <Card className="text-center !py-10">
            <div className="text-3xl">🛍️</div>
            <p className="mt-2 text-[14px] font-bold text-toss-gray900">{wishes.length ? '조건에 맞는 고민이 없어요' : '아직 담은 고민이 없어요'}</p>
            <p className="mt-1 text-[12px] text-toss-gray500">사고 싶은 게 생기면 먼저 담아두고 천천히 결정해요.</p>
            <button type="button" onClick={() => navigate('/record')} className="mt-4 px-4 py-2.5 rounded-xl bg-toss-lightBlue text-toss-blue text-[13px] font-bold">구매 고민 담기</button>
          </Card>
        )}

        <ul className="space-y-2.5">
          {list.map((w) => (
            <li key={w.id} className={`bg-white rounded-[22px] p-4 shadow-card ${w.id === newId ? 'ring-2 ring-toss-blue' : ''}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${BADGE[w.status]}`}>{WISH_LABEL[w.status]}</span>
                    <span className="text-[11px] text-toss-gray500">{w.category} · {NEED[w.necessity]}</span>
                  </div>
                  <p className="text-[15px] font-bold text-toss-gray900 mt-1 truncate">{w.name}</p>
                  <p className="text-[12px] text-toss-gray500 mt-0.5">
                    {w.status === 'later' ? `다시 고민할 날 ${shortDate(w.plannedDate)}` : w.status === 'bought' ? '가계부 지출로 기록됨' : `구매 예정 ${shortDate(w.plannedDate)}`} · {w.payment}
                  </p>
                </div>
                <p className="text-[16px] font-extrabold text-toss-gray900 tabular-nums shrink-0">{won(w.amount)}</p>
              </div>

              {(w.status === 'thinking' || w.status === 'later') && (
                <div className="grid grid-cols-3 gap-1.5 mt-3">
                  <button type="button" onClick={() => bought(w)} className="py-2.5 rounded-xl bg-toss-gray100 text-toss-gray800 text-[12px] font-bold">구매했어요</button>
                  <button type="button" onClick={() => setLaterFor(w)} className="py-2.5 rounded-xl bg-amber-50 text-amber-700 text-[12px] font-bold">나중에 살래요</button>
                  <button type="button" onClick={() => skip(w)} className="py-2.5 rounded-xl bg-toss-blue text-white text-[12px] font-bold">사지 않을래요</button>
                </div>
              )}
              {w.status === 'skipped' && (
                <button type="button" onClick={() => navigate(`/world?wish=${w.id}`)} className="mt-3 w-full py-2.5 rounded-xl bg-toss-lightBlue text-toss-blue text-[12px] font-bold flex items-center justify-center gap-1">
                  <Icon name="auto_awesome" className="text-[16px]" /> 이 돈으로 평행세계 비교하기
                </button>
              )}
              <div className="flex items-center justify-end gap-3 mt-2.5 text-[11.5px] font-semibold text-toss-gray500">
                {(w.status === 'bought' || w.status === 'skipped') && <button type="button" onClick={() => { decideWish(w.id, 'thinking'); toast('다시 고민 중으로 옮겼어요'); }}>고민 중으로 되돌리기</button>}
                {(w.status === 'thinking' || w.status === 'later') && <button type="button" onClick={() => openEdit(w)}>수정</button>}
                <button type="button" onClick={() => { removeWish(w.id); toast('삭제했어요'); }} className="text-rose-500">삭제</button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <BottomSheet open={!!decide} onClose={closeDecide} title="담았어요. 어떻게 할까요?">
        {decide && (
          <div className="space-y-3">
            <div className="rounded-2xl bg-toss-gray50 p-4 flex items-center justify-between">
              <div className="min-w-0"><p className="text-[14px] font-bold text-toss-gray900 truncate">{decide.name}</p><p className="text-[12px] text-toss-gray500 mt-0.5">{NEED[decide.necessity]} · {decide.payment}</p></div>
              <p className="text-[16px] font-extrabold tabular-nums">{won(decide.amount)}</p>
            </div>
            <button type="button" onClick={() => skip(decide)} className="w-full text-left rounded-2xl border-2 border-toss-blue bg-toss-lightBlue/50 p-4">
              <p className="text-[14px] font-bold text-toss-blue">사지 않을래요</p>
              <p className="text-[12px] text-toss-gray600 mt-0.5">이 금액을 저축·투자했다면 어떻게 될지 평행세계에서 비교해요</p>
            </button>
            <button type="button" onClick={() => setLaterFor(decide)} className="w-full text-left rounded-2xl border border-toss-gray200 p-4">
              <p className="text-[14px] font-bold text-toss-gray900">나중에 살래요</p>
              <p className="text-[12px] text-toss-gray500 mt-0.5">다시 고민할 날짜를 정하고 보류 목록에 둬요</p>
            </button>
            <button type="button" onClick={() => bought(decide)} className="w-full text-left rounded-2xl border border-toss-gray200 p-4">
              <p className="text-[14px] font-bold text-toss-gray900">구매했어요</p>
              <p className="text-[12px] text-toss-gray500 mt-0.5">가계부에 지출로 기록해요</p>
            </button>
            <button type="button" onClick={closeDecide} className="w-full py-3 text-[13px] font-semibold text-toss-gray500">일단 고민만 해둘게요</button>
          </div>
        )}
      </BottomSheet>

      <BottomSheet open={!!laterFor} onClose={() => setLaterFor(null)} title="언제 다시 고민할까요?">
        {laterFor && (
          <div className="grid grid-cols-2 gap-2">
            {[[7, '1주 뒤'], [30, '1개월 뒤'], [90, '3개월 뒤'], [null, '날짜 미정']].map(([d, l]) => (
              <button key={String(l)} type="button" onClick={() => later(laterFor, d as number | null)} className="py-4 rounded-2xl bg-toss-gray50 border border-toss-gray100 text-[14px] font-bold text-toss-gray800">
                {l}
                {d != null && <span className="block text-[11px] font-medium text-toss-gray500 mt-0.5">{shortDate(addDays(APP_TODAY, d as number))}</span>}
              </button>
            ))}
          </div>
        )}
      </BottomSheet>

      <BottomSheet open={!!edit} onClose={() => setEdit(null)} title="고민 수정하기">
        <div className="space-y-3">
          <label className="block"><span className="text-[12px] font-semibold text-toss-gray600">상품명</span>
            <input value={editName} onChange={(e) => setEditName(e.target.value)} className="mt-1 w-full rounded-xl border border-toss-gray200 px-3.5 py-3 text-[15px] outline-none focus:border-toss-blue" /></label>
          <label className="block"><span className="text-[12px] font-semibold text-toss-gray600">금액</span>
            <input inputMode="numeric" value={editAmount ? Number(editAmount.replace(/[^0-9]/g, '') || 0).toLocaleString('ko-KR') : ''} onChange={(e) => setEditAmount(e.target.value)} className="mt-1 w-full rounded-xl border border-toss-gray200 px-3.5 py-3 text-[15px] outline-none focus:border-toss-blue tabular-nums" /></label>
          <PrimaryButton onClick={saveEdit}>저장하기</PrimaryButton>
        </div>
      </BottomSheet>
    </div>
  );
}
