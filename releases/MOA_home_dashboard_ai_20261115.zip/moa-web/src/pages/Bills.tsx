import { useState } from 'react';
import { BottomSheet, Card, Icon, PageHeader, PrimaryButton, SectionTitle } from '../components/ui';
import { useApp } from '../lib/app';
import { beforePayday, cashTimeline, dday, md } from '../lib/finance';
import { removeBill, saveBill, setFinance, setState, useStore, won, type Bill, type BillKind } from '../lib/store';

const KINDS: { key: BillKind; label: string; icon: string }[] = [
  { key: 'card', label: '카드값', icon: 'credit_card' },
  { key: 'rent', label: '월세·관리비', icon: 'home' },
  { key: 'phone', label: '통신비', icon: 'smartphone' },
  { key: 'subscription', label: '구독', icon: 'subscriptions' },
  { key: 'loan', label: '대출·학자금', icon: 'account_balance' },
  { key: 'etc', label: '기타', icon: 'receipt_long' },
];
const kindOf = (k: BillKind) => KINDS.find((x) => x.key === k) ?? KINDS[5];
const num = (v: string) => Number(v.replace(/[^0-9]/g, '')) || 0;

/** /bills — 필수 결제 관리: 잔액·월급·최소 잔액을 직접 입력하고, 결제 일정과 부족 위험을 확인 */
export default function Bills() {
  const { toast } = useApp();
  const finance = useStore((s) => s.finance);
  const payday = useStore((s) => s.profile.payday);
  const bills = useStore((s) => s.bills);
  useStore((s) => s.txs);
  const bp = beforePayday();
  const timeline = cashTimeline(35);

  const [field, setField] = useState<null | 'balance' | 'salary' | 'minBalance' | 'payday'>(null);
  const [fieldVal, setFieldVal] = useState('');
  const [edit, setEdit] = useState<Partial<Bill> | null>(null);

  const FIELDS = {
    balance: { label: '생활비 통장 잔액', value: finance.balance, unit: '원', hint: '지금 통장에 있는 금액을 적어주세요. 가계부에 직접 기록하면 자동으로 바뀌어요.' },
    salary: { label: '월급(정기 입금)', value: finance.salary, unit: '원', hint: '매달 들어오는 금액이에요.' },
    minBalance: { label: '최소 잔액', value: finance.minBalance, unit: '원', hint: '결제 후에도 이만큼은 통장에 남기고 싶은 금액이에요.' },
    payday: { label: '월급일', value: payday, unit: '일', hint: '매달 월급이 들어오는 날이에요 (1~31).' },
  } as const;

  const openField = (k: keyof typeof FIELDS) => { setField(k); setFieldVal(String(FIELDS[k].value)); };
  const saveField = () => {
    if (!field) return;
    const v = num(fieldVal);
    if (field === 'payday') {
      if (v < 1 || v > 31) return toast('1~31 사이로 입력해 주세요', 'error');
      setState((s) => ({ profile: { ...s.profile, payday: v } }));
    } else setFinance({ [field]: v });
    setField(null);
    toast('저장했어요');
  };
  const saveEdit = () => {
    if (!edit) return;
    if (!edit.name?.trim() || !(edit.amount && edit.amount > 0) || !(edit.day && edit.day >= 1 && edit.day <= 31)) return toast('이름·금액·결제일을 확인해 주세요', 'error');
    saveBill({ id: edit.id, name: edit.name.trim(), amount: edit.amount, day: edit.day, kind: edit.kind ?? 'etc' });
    setEdit(null);
    toast(edit.id ? '결제 정보를 수정했어요' : '필수 결제를 추가했어요');
  };

  const risk = bp.firstRisk;
  return (
    <div className="min-h-full bg-[#F2F4F6] pb-10">
      <PageHeader title="필수 결제 관리" />
      <div className="px-4 pt-3 space-y-3.5">
        <Card className={risk ? '!bg-rose-50' : ''}>
          <p className={`text-[12px] font-bold ${risk ? 'text-rose-600' : 'text-emerald-600'}`}>{risk ? '결제일에 잔액이 부족할 수 있어요' : '등록된 일정에서 부족 위험은 확인되지 않았어요'}</p>
          <p className="mt-1 text-[13px] text-toss-gray600">오늘 쓸 수 있는 여유</p>
          <p className={`text-[28px] font-extrabold tracking-tight tabular-nums ${bp.spendable < 0 ? 'text-rose-600' : 'text-toss-gray900'}`}>{bp.spendable < 0 ? `-${won(-bp.spendable)}` : won(bp.spendable)}</p>
          <p className="text-[12px] text-toss-gray500 mt-1 leading-relaxed">
            잔액 {won(finance.balance)} − 월급({md(bp.payday)}) 전 필수 결제 {won(bp.essential)} − 최소 잔액 {won(finance.minBalance)}
          </p>
          {risk && <p className="mt-2 text-[12.5px] font-semibold text-rose-600">{md(risk.date)} {risk.label} 후 잔액이 {won(risk.balanceAfter)}으로 최소 잔액보다 {won(finance.minBalance - risk.balanceAfter)} 적어요.</p>}
        </Card>

        <Card className="!px-0 !py-2">
          {(Object.keys(FIELDS) as (keyof typeof FIELDS)[]).map((k) => (
            <button key={k} type="button" onClick={() => openField(k)} className="w-full flex items-center justify-between px-5 py-3 text-left active:bg-toss-gray50">
              <span className="text-[14px] text-toss-gray700">{FIELDS[k].label}</span>
              <span className="flex items-center gap-1 text-[14px] font-bold text-toss-gray900 tabular-nums">
                {k === 'payday' ? `매월 ${payday}일` : won(FIELDS[k].value)}
                <Icon name="chevron_right" className="text-toss-gray400 text-[18px]" />
              </span>
            </button>
          ))}
        </Card>

        <Card>
          <SectionTitle action={<button type="button" onClick={() => setEdit({ kind: 'etc', day: 1 })} className="text-[12px] font-bold text-toss-blue bg-toss-lightBlue px-3 py-1.5 rounded-full">+ 추가</button>}>매달 나가는 필수 결제</SectionTitle>
          {bills.length === 0 && <p className="text-[13px] text-toss-gray500 py-4 text-center">등록된 결제가 없어요</p>}
          <ul className="divide-y divide-toss-gray100 -mx-1">
            {[...bills].sort((a, b) => a.day - b.day).map((b) => (
              <li key={b.id}>
                <button type="button" onClick={() => setEdit(b)} className="w-full flex items-center gap-3 px-1 py-3 text-left">
                  <span className="w-10 h-10 rounded-2xl bg-toss-gray50 flex items-center justify-center text-toss-gray700"><Icon name={kindOf(b.kind).icon} className="text-[20px]" /></span>
                  <span className="flex-1 min-w-0"><span className="block text-[14px] font-bold text-toss-gray900">{b.name}</span><span className="block text-[12px] text-toss-gray500">매월 {b.day}일 · {kindOf(b.kind).label}</span></span>
                  <span className="text-[15px] font-extrabold tabular-nums">{won(b.amount)}</span>
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionTitle action={<span className="text-[12px] text-toss-gray500">최소 잔액 {won(finance.minBalance)}</span>}>앞으로 5주 일정</SectionTitle>
          {timeline.length === 0 ? <p className="text-[13px] text-toss-gray500">일정이 없어요</p> : (
            <ol className="relative border-l-2 border-toss-gray100 ml-2 space-y-3">
              {timeline.map((e, i) => (
                <li key={i} className="pl-4 relative">
                  <span className={`absolute -left-[7px] top-1.5 w-3 h-3 rounded-full ring-4 ring-white ${e.risk ? 'bg-rose-500' : e.kind === 'salary' ? 'bg-toss-blue' : 'bg-toss-gray300'}`} />
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-[12px] text-toss-gray500">{md(e.date)} · {dday(e.date)}</p>
                      <p className="text-[14px] font-bold text-toss-gray900">{e.label}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-[14px] font-extrabold tabular-nums ${e.amount > 0 ? 'text-toss-blue' : 'text-toss-gray900'}`}>{e.amount > 0 ? '+' : '-'}{won(Math.abs(e.amount))}</p>
                      <p className={`text-[11.5px] tabular-nums ${e.risk ? 'text-rose-600 font-bold' : 'text-toss-gray500'}`}>남는 돈 {won(e.balanceAfter)}{e.risk ? ' · 부족' : ''}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          )}
          <p className="mt-3 text-[11px] text-toss-gray400 leading-relaxed">계좌 자동 연결 전에는 직접 입력한 잔액과 결제 일정으로 계산해요. 새로 기록한 신용카드 승인액은 다음 등록 카드 청구일에 추가되는 것으로 추정하며, 실제 카드 이용기간·청구 확정금액과 다를 수 있어요. 변동 지출은 반영하지 않아요.</p>
        </Card>
      </div>

      <BottomSheet open={!!field} onClose={() => setField(null)} title={field ? FIELDS[field].label : ''}>
        {field && (
          <div className="space-y-4">
            <div className="flex items-end gap-1 border-b-2 border-toss-blue pb-2">
              <input inputMode="numeric" autoFocus value={field === 'payday' ? fieldVal : num(fieldVal).toLocaleString('ko-KR')} onChange={(e) => setFieldVal(e.target.value)} className="flex-1 text-[26px] font-extrabold outline-none bg-transparent tabular-nums" aria-label={FIELDS[field].label} />
              <span className="text-[18px] font-bold text-toss-gray700 pb-1">{FIELDS[field].unit}</span>
            </div>
            <p className="text-[12px] text-toss-gray500">{FIELDS[field].hint}</p>
            <PrimaryButton onClick={saveField}>저장하기</PrimaryButton>
          </div>
        )}
      </BottomSheet>

      <BottomSheet open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? '필수 결제 수정' : '필수 결제 추가'}>
        {edit && (
          <div className="space-y-3.5">
            <label className="block"><span className="text-[12px] font-semibold text-toss-gray600">이름</span>
              <input value={edit.name ?? ''} onChange={(e) => setEdit({ ...edit, name: e.target.value })} placeholder="예: 카드값, 월세" className="mt-1 w-full rounded-xl border border-toss-gray200 px-3.5 py-3 text-[15px] outline-none focus:border-toss-blue" /></label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block"><span className="text-[12px] font-semibold text-toss-gray600">금액</span>
                <input inputMode="numeric" value={edit.amount ? edit.amount.toLocaleString('ko-KR') : ''} onChange={(e) => setEdit({ ...edit, amount: num(e.target.value) })} className="mt-1 w-full rounded-xl border border-toss-gray200 px-3.5 py-3 text-[15px] outline-none focus:border-toss-blue tabular-nums" /></label>
              <label className="block"><span className="text-[12px] font-semibold text-toss-gray600">매월 결제일</span>
                <input inputMode="numeric" value={edit.day ?? ''} onChange={(e) => setEdit({ ...edit, day: Math.min(31, num(e.target.value)) })} className="mt-1 w-full rounded-xl border border-toss-gray200 px-3.5 py-3 text-[15px] outline-none focus:border-toss-blue tabular-nums" /></label>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {KINDS.map((k) => (
                <button key={k.key} type="button" onClick={() => setEdit({ ...edit, kind: k.key, name: edit.name || k.label })} className={`px-3 py-1.5 rounded-full text-[12px] font-bold ${edit.kind === k.key ? 'bg-toss-blue text-white' : 'bg-toss-gray100 text-toss-gray600'}`}>{k.label}</button>
              ))}
            </div>
            <PrimaryButton onClick={saveEdit}>저장하기</PrimaryButton>
            {edit.id && <button type="button" onClick={() => { removeBill(edit.id!); setEdit(null); toast('삭제했어요'); }} className="w-full py-3 text-[13px] font-semibold text-rose-500">삭제하기</button>}
          </div>
        )}
      </BottomSheet>
    </div>
  );
}
