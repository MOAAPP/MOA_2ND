// Stitch 화면(src/screens) 안에 끼워 넣는 작은 React 위젯들.
// tools/stitch-convert.mjs 의 jsxReplace / imports 로 들어가요.
import { useNavigate } from 'react-router-dom';
import { lessonById, pickToday } from '../lib/learning';
import { getState, setState, skippedTotal, useStore, won } from '../lib/store';
import { STOCKS, livePrice } from '../lib/market';
import { APP_TODAY } from '../lib/store';

export function ProfileName({ suffix = ' 님' }: { suffix?: string }) {
  const name = useStore((s) => s.profile.name);
  return <>{name}{suffix}</>;
}

export function WishBadge() {
  const n = useStore((s) => s.wishes.filter((w) => w.status === 'thinking' || w.status === 'later').length);
  return <>{n ? `${n}건 고민 중` : '새로 담기'}</>;
}

/** 홈: 오늘의 금융 학습 + 금융 실험실 + 소비 결정 보관함 */
export function HomeLearnLab() {
  const navigate = useNavigate();
  const learning = useStore((s) => s.learning);
  const pending = useStore((s) => s.wishes.filter((w) => w.status === 'thinking' || w.status === 'later').length);
  const today = pickToday(getState(), APP_TODAY);
  const lesson = lessonById(today.id)!;
  const read = learning.progress[lesson.id] || 0;
  const done = learning.done.includes(lesson.id);

  return (
    <section className="px-5 pt-0.5 relative z-10">
      <button type="button" onClick={() => navigate(`/learn/${lesson.id}`)} className="w-full text-left rounded-[24px] bg-white p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] border border-slate-200/70 active:scale-[0.99] transition-transform">
        <div className="flex items-center justify-between">
          <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 border border-blue-200/60 text-[10.5px] font-bold">📚 오늘의 금융 학습</span>
          <span className="text-[11px] font-semibold text-slate-400">{done ? '완료' : read ? `${read}/${lesson.cards.length} 읽음` : `약 ${lesson.minutes}분`} {'>'}</span>
        </div>
        <p className="mt-2.5 text-[16px] font-bold text-slate-900 tracking-tight">{lesson.emoji} {lesson.title}</p>
        <p className="mt-1 text-[12px] text-slate-500 leading-relaxed">{today.reason}</p>
        <div className="mt-3 h-1.5 rounded-full bg-slate-100 overflow-hidden">
          <div className="h-full bg-blue-600 rounded-full transition-all" style={{ width: `${(Math.min(read, lesson.cards.length) / lesson.cards.length) * 100}%` }} />
        </div>
      </button>
      <div className="grid grid-cols-2 gap-2.5 mt-2.5">
        <button type="button" onClick={() => navigate('/lab')} className="text-left rounded-[20px] bg-white p-3.5 border border-slate-200/70 active:scale-[0.98] transition-transform">
          <p className="text-[13.5px] font-bold text-slate-900">금융 실험실</p>
          <p className="text-[11px] text-slate-500">가상 예·적금 · 주식</p>
        </button>
        <button type="button" onClick={() => navigate('/wishlist')} className="text-left rounded-[20px] bg-white p-3.5 border border-slate-200/70 active:scale-[0.98] transition-transform">
          <p className="text-[13.5px] font-bold text-slate-900">소비 결정 보관함</p>
          <p className="text-[11px] text-slate-500">{pending ? `${pending}건 고민 중` : '살까 말까 담아두기'}</p>
        </button>
      </div>
    </section>
  );
}

/** 더보기: 모든 자산 수치는 같은 store에서 읽으며 시연용 가상 자산임을 표시 */
export function ProfileInitial() {
  const name = useStore((s) => s.profile.name);
  return <>{name.trim().slice(0, 1) || 'M'}</>;
}
export function MoreSavedSpending() {
  const amount = useStore((s) => skippedTotal(s));
  return <>총 {won(amount)}</>;
}
export function MoreSavingsAmount() {
  const amount = useStore((s) => s.savings.reduce((sum, p) => sum + p.principal, 0));
  return <>{won(amount)}</>;
}
export function MoreSavingsCount() {
  const count = useStore((s) => s.savings.length);
  return <>{count}건 연습 중</>;
}
export function MoreSavingsLevel() {
  const principal = useStore((s) => s.savings.reduce((a, p) => a + p.principal, 0));
  const levels = [[0, '먼지 행성'], [300000, '테라'], [700000, '오아시스'], [1200000, '사파이어'], [2000000, '네뷸라'], [3500000, '갤럭시 코어']] as const;
  const level = [...levels].reverse().find(([v]) => principal >= v) ?? levels[0];
  return <>Lv.{levels.indexOf(level) + 1} {level[1]} 탐험가 🪐</>;
}
export function MoreInvestAmount() {
  const invest = useStore((s) => s.invest);
  const amount = STOCKS.reduce((a, x) => a + (invest.holdings[x.name] || 0) * livePrice(x.name), 0);
  return <>{won(amount)}</>;
}
export function MoreInvestRate() {
  const invest = useStore((s) => s.invest);
  const total = STOCKS.reduce((a, x) => a + (invest.holdings[x.name] || 0) * livePrice(x.name), 0);
  const cost = STOCKS.reduce((a, x) => a + (invest.holdings[x.name] || 0) * (invest.avgPrice[x.name] || livePrice(x.name)), 0);
  const pct = cost > 0 ? (total / cost - 1) * 100 : 0;
  return <>평가손익 {pct >= 0 ? '+' : ''}{pct.toFixed(1)}%</>;
}
export function MoreSimulationSetting({ kind }: { kind: 'save' | 'invest' | 'risk' }) {
  const setting = useStore((s) => s.simSettings);
  if (kind === 'risk') return <select aria-label="모의 투자 위험 성향" value={setting.risk} onChange={(e) => setState((s) => ({ simSettings: { ...s.simSettings, risk: e.target.value as typeof setting.risk } }))} className="text-xs font-semibold text-purple-600 bg-purple-50 px-2 py-1 rounded-lg max-w-[125px]">
    <option value="stable">안정추구형</option><option value="balanced">위험중립형</option><option value="active">적극투자형</option>
  </select>;
  const rateField = kind === 'save' ? 'saveRate' : 'investRate';
  const options = kind === 'save' ? [3, 3.8, 4.5] : [5, 7.2, 10];
  return <select aria-label={kind === 'save' ? '가상 예적금 가정 금리' : '가상 투자 기대수익 가정'} value={setting[rateField]}
    onChange={(e) => setState((s) => ({ simSettings: { ...s.simSettings, [rateField]: Number(e.target.value) } }))}
    className={`text-xs font-semibold px-2 py-1 rounded-lg max-w-[130px] ${kind === 'save' ? 'text-emerald-600 bg-emerald-50' : 'text-blue-600 bg-blue-50'}`}>
    {options.map((r) => <option key={r} value={r}>연 {r}% 가정</option>)}
  </select>;
}

export function MoreSafetyAlert() {
  const on = useStore((s) => s.settings.payAlert);
  return <label className="relative inline-flex items-center cursor-pointer" aria-label="결제일 부족 알림">
    <input type="checkbox" className="sr-only peer" checked={on} onChange={(e) => setState((s) => ({ settings: { ...s.settings, payAlert: e.target.checked } }))} />
    <span className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand" />
  </label>;
}
