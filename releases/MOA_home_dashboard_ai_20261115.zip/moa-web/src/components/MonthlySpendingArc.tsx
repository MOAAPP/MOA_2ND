import { useEffect, useMemo, useState } from 'react';
import { APP_TODAY, useStore, won } from '../lib/store';
import { monthlyBudget, monthPeriod, totals } from '../lib/finance';

/** Simple half-donut showing real budget utilization for the currently selected month. */
export default function MonthlySpendingArc() {
  const state = useStore((s) => s);
  const [selected, setSelected] = useState(APP_TODAY.slice(0, 7));
  useEffect(() => {
    const target = document.getElementById('selected-month-display');
    if (!target) return;
    const sync = () => {
      const match = (target.textContent || '').match(/(\d{4})년\s*(\d{1,2})월/);
      if (match) setSelected(`${match[1]}-${match[2].padStart(2, '0')}`);
    };
    const observer = new MutationObserver(sync);
    observer.observe(target, {childList:true, characterData:true, subtree:true});
    sync();
    return () => observer.disconnect();
  }, []);
  const budget = monthlyBudget(state);
  const expense = useMemo(() => totals(monthPeriod(selected), state).expense, [selected, state]);
  const ratio = budget > 0 ? Math.round(expense / budget * 100) : 0;
  const shown = Math.min(100, Math.max(0, ratio));
  const remaining = budget - expense;
  const overspent = budget > 0 && remaining < 0;
  const monthNum = Number(selected.slice(5,7));
  return (
    <section className="moa-budget-preview bg-white rounded-[24px] px-4 pt-5 pb-5 border border-[#e9edf5]" aria-label={`${monthNum}월 예산 사용 현황`}>
      <div className="flex items-center justify-between px-1">
        <div><span className="text-[11px] font-semibold text-[#7d8ba0]">한 달 소비 현황</span><h2 className="text-[17px] font-extrabold text-[#1f293b] tracking-[-.04em] mt-1">{monthNum}월 예산, 얼마나 썼을까?</h2></div>
        <span className="text-[11px] font-semibold rounded-full bg-[#eef4ff] text-[#4172c9] px-2.5 py-1">{budget>0?'월 예산 기준':'예산 미설정'}</span>
      </div>
      <div className="relative mx-auto mt-4 max-w-[280px]" role="img" aria-label={budget>0?`이번 달 예산 ${won(budget)} 중 ${won(expense)} 사용, ${ratio}%`: '예산이 설정되지 않았습니다'}>
        <svg viewBox="0 0 280 169" width="100%" aria-hidden="true">
          <path d="M 23 147 A 117 117 0 0 1 257 147" fill="none" stroke="#e9edf4" strokeWidth="19" strokeLinecap="round" pathLength="100" />
          <path d="M 23 147 A 117 117 0 0 1 257 147" fill="none" stroke={overspent?'#e66b67':'#407bf0'} strokeWidth="19" strokeLinecap="round" strokeDasharray={`${shown} 100`} pathLength="100" />
          <text x="140" y="100" textAnchor="middle" fill="#1f293b" fontSize="38" fontWeight="800" letterSpacing="-2">{budget>0?`${ratio}%`:'—'}</text>
          <text x="140" y="126" textAnchor="middle" fill="#8793a5" fontSize="12" fontWeight="600">이번 달 사용률</text>
        </svg>
      </div>
      <div className="grid grid-cols-2 gap-3 mt-[-7px] px-1">
        <div className="border-r border-[#edf0f5]"><span className="block text-[11px] text-[#8c99aa]">지금까지 쓴 돈</span><strong className="block mt-1 text-[17px] font-extrabold tracking-tight text-[#1f293b]">{won(expense)}</strong></div>
        <div><span className="block text-[11px] text-[#8c99aa]">{overspent?'초과한 예산':'남은 예산'}</span><strong className={`block mt-1 text-[17px] font-extrabold tracking-tight ${overspent?'text-rose-600':'text-[#326ee0]'}`}>{won(Math.abs(remaining))}</strong></div>
      </div>
      <div className="text-[11px] text-[#8793a5] mt-4 px-1 leading-relaxed">{budget>0 ? `${won(budget)} 예산에서 기록된 지출만 계산했어요. 저축·이체는 제외돼요.` : '가계부 → 예산 관리에서 월 예산을 설정하면 사용률을 표시해요.'}</div>
    </section>
  );
}
