import { type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

export function Icon({ name, className = '', fill = false }: { name: string; className?: string; fill?: boolean }) {
  return (
    <span
      className={`material-symbols-outlined ${className}`}
      style={fill ? { fontVariationSettings: "'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24" } : undefined}
      aria-hidden="true"
    >
      {name}
    </span>
  );
}

export function PageHeader({ title, right, back = true, onBack }: { title: string; right?: ReactNode; back?: boolean; onBack?: () => void }) {
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-30 h-14 px-4 flex items-center justify-between bg-[#F2F4F6]/95 backdrop-blur-md border-b border-black/[0.04]">
      <div className="w-10">
        {back && (
          <button
            type="button"
            aria-label="이전 화면"
            onClick={() => (onBack ? onBack() : navigate(-1))}
            className="w-9 h-9 -ml-1 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all"
          >
            <Icon name="arrow_back_ios_new" className="text-[20px]" />
          </button>
        )}
      </div>
      <h1 className="text-[17px] font-bold text-toss-gray900 tracking-tight">{title}</h1>
      <div className="w-10 flex justify-end">{right}</div>
    </header>
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`bg-white rounded-[24px] p-5 shadow-card ${className}`}>{children}</section>;
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-[15px] font-bold text-toss-gray900 tracking-tight">{children}</h2>
      {action}
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative w-[46px] h-[28px] rounded-full transition-colors shrink-0 ${checked ? 'bg-toss-blue' : 'bg-toss-gray300'}`}
    >
      <span className={`absolute top-[3px] left-[3px] w-[22px] h-[22px] rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-[18px]' : ''}`} />
    </button>
  );
}

export function ListRow({ icon, iconBg = 'bg-toss-gray100', title, sub, right, onClick }: { icon: ReactNode; iconBg?: string; title: string; sub?: string; right?: ReactNode; onClick?: () => void }) {
  const Comp = onClick ? 'button' : 'div';
  return (
    <Comp
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className="w-full flex items-center gap-3 px-5 py-3.5 text-left active:bg-toss-gray50 transition-colors"
    >
      <span className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg shrink-0 ${iconBg}`}>{icon}</span>
      <span className="flex-1 min-w-0">
        <span className="block text-[14px] font-semibold text-toss-gray900 truncate">{title}</span>
        {sub && <span className="block text-[12px] text-toss-gray500 mt-0.5 truncate">{sub}</span>}
      </span>
      {right ?? (onClick ? <Icon name="chevron_right" className="text-toss-gray400 text-[20px]" /> : null)}
    </Comp>
  );
}

export function PrimaryButton({ children, onClick, disabled, className = '' }: { children: ReactNode; onClick?: () => void; disabled?: boolean; className?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`w-full py-4 rounded-2xl bg-toss-blue hover:bg-toss-blueDark disabled:bg-toss-gray200 disabled:text-toss-gray500 text-white font-bold text-[15px] shadow-floating disabled:shadow-none active:scale-[0.98] transition-all ${className}`}
    >
      {children}
    </button>
  );
}

export function BottomSheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return (
    <div
      className={`fixed inset-0 z-[90] flex items-end transition-opacity duration-300 ${open ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      aria-hidden={!open}
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" onClick={onClose} />
      <div
        role="dialog"
        aria-label={title}
        className={`relative w-full bg-white rounded-t-[28px] px-5 pt-3 pb-7 shadow-2xl transition-transform duration-300 max-h-[calc(var(--app-h)*0.9)] overflow-y-auto no-scrollbar ${open ? 'translate-y-0' : 'translate-y-full'}`}
      >
        <div className="w-10 h-1 rounded-full bg-toss-gray200 mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[18px] font-bold text-toss-gray900">{title}</h3>
          <button type="button" aria-label="닫기" onClick={onClose} className="w-8 h-8 rounded-full hover:bg-toss-gray100 flex items-center justify-center text-toss-gray500">
            <Icon name="close" className="text-[20px]" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
