import { useNavigate } from 'react-router-dom';
import logoUrl from '../assets/moa-logo.webp';
import { useStore } from '../lib/store';

// 탭 화면 공통 상단 헤더 — 로고 · 알림 · 프로필
export default function AppHeader({ profileTo = '/more', transparent = false }: { profileTo?: string; transparent?: boolean }) {
  const navigate = useNavigate();
  const name = useStore((s) => s.profile.name) || '나';
  return (
    <header className={`sticky top-0 z-50 px-5 pt-3 pb-2 select-none shrink-0 ${transparent ? 'bg-[#F2F4F6]/85 backdrop-blur-xl' : 'backdrop-blur-xl border-b border-slate-100 bg-white/90'}`}>
      <div className="flex items-center justify-between h-10">
        <button type="button" aria-label="홈으로" onClick={() => navigate('/')} className="flex items-center">
          <img src={logoUrl} alt="MOA" className="h-7 w-auto object-contain block select-none" />
        </button>
        <div className="flex items-center gap-1.5">
          <button type="button" aria-label="알림" onClick={() => navigate('/notifications')}
            className="relative w-9 h-9 grid place-items-center rounded-full text-[#4E5968] hover:bg-black/[0.04] transition-colors">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 9.5a6 6 0 1 1 12 0c0 3.6.9 5.4 1.7 6.4.3.4 0 1.1-.5 1.1H4.8c-.5 0-.8-.7-.5-1.1.8-1 1.7-2.8 1.7-6.4Z" />
              <path d="M10 20.2a2.2 2.2 0 0 0 4 0" />
            </svg>
            <span className="absolute top-[7px] right-[8px] w-[7px] h-[7px] rounded-full bg-[#FF4D4F] ring-2 ring-white" />
          </button>
          <button type="button" aria-label="내 정보" onClick={() => navigate(profileTo)}
            className="w-8 h-8 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#60A5FA] text-white text-[13px] font-bold grid place-items-center">
            {name.slice(0, 1)}
          </button>
        </div>
      </div>
    </header>
  );
}
