import { NavLink } from 'react-router-dom';

// iOS 탭바: 4개 탭 · 아이콘 + 라벨 · 선택 시 채움 아이콘
const ICONS = {
  home: {
    line: 'M3.5 10.5 12 3.5l8.5 7V20a1 1 0 0 1-1 1h-5v-6h-5v6h-5a1 1 0 0 1-1-1v-9.5Z',
    fill: 'M11.3 2.9a1.1 1.1 0 0 1 1.4 0l8.4 6.9c.3.2.4.5.4.9V20a1.1 1.1 0 0 1-1.1 1.1H15V15.5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5.6H4.6A1.1 1.1 0 0 1 3.5 20v-9.3c0-.4.1-.7.4-.9l7.4-6.9Z',
  },
  lab: {
    line: 'M9 3h6M10 3v6L4.6 18.2A2 2 0 0 0 6.3 21h11.4a2 2 0 0 0 1.7-2.8L14 9V3M7.5 15h9',
    fill: 'M9 2.2h6a.8.8 0 0 1 0 1.6h-.2V8.8l5.3 9.1A2.6 2.6 0 0 1 17.8 21.8H6.2A2.6 2.6 0 0 1 3.9 17.9l5.3-9.1V3.8H9a.8.8 0 0 1 0-1.6Z',
  },
  world: {
    line: 'M12 3.5l1.9 5.2 5.2 1.9-5.2 1.9L12 17.7l-1.9-5.2-5.2-1.9 5.2-1.9L12 3.5ZM18.5 16l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2Z',
    fill: 'M12 2.8c.3 0 .6.2.7.5l1.8 5 5 1.8a.75.75 0 0 1 0 1.4l-5 1.8-1.8 5a.75.75 0 0 1-1.4 0l-1.8-5-5-1.8a.75.75 0 0 1 0-1.4l5-1.8 1.8-5c.1-.3.4-.5.7-.5ZM18.5 15.3c.2 0 .4.1.5.3l.7 1.8 1.8.7a.5.5 0 0 1 0 .9l-1.8.7-.7 1.8a.5.5 0 0 1-.9 0l-.7-1.8-1.8-.7a.5.5 0 0 1 0-.9l1.8-.7.7-1.8c0-.2.2-.3.4-.3Z',
  },
  ledger: {
    line: 'M6 3.5h10.5a2 2 0 0 1 2 2v15l-3-1.8-3 1.8-3-1.8-3 1.8V5.5a2 2 0 0 1 .5-1.3M9 8.5h6M9 12.5h4',
    fill: 'M6.5 2.8h10a2.7 2.7 0 0 1 2.7 2.7v15a.8.8 0 0 1-1.2.7l-2.5-1.5-2.6 1.5a.8.8 0 0 1-.8 0L9.5 19.7 7 21.2a.8.8 0 0 1-1.2-.7V5.5a2.7 2.7 0 0 1 .7-2.7Zm2.5 5a.7.7 0 0 0 0 1.4h6a.7.7 0 0 0 0-1.4H9Zm0 4a.7.7 0 0 0 0 1.4h4a.7.7 0 0 0 0-1.4H9Z',
  },
} as const;

function Tab({ to, icon, label, end }: { to: string; icon: keyof typeof ICONS; label: string; end?: boolean }) {
  return (
    <NavLink to={to} end={end} className="flex-1 h-full flex flex-col items-center justify-center gap-[3px] select-none">
      {({ isActive }) => (
        <>
          <svg width="25" height="25" viewBox="0 0 24 24" aria-hidden="true" className={isActive ? 'text-[#3182F6]' : 'text-[#99A1AC]'}>
            {isActive
              ? <path d={ICONS[icon].fill} fill="currentColor" />
              : <path d={ICONS[icon].line} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />}
          </svg>
          <span className={`text-[10.5px] tracking-[-0.01em] ${isActive ? 'text-[#3182F6] font-semibold' : 'text-[#8B95A1] font-medium'}`}>{label}</span>
        </>
      )}
    </NavLink>
  );
}

export default function TabBar() {
  return (
    <nav className="absolute bottom-0 left-0 right-0 z-[45] bg-white/85 backdrop-blur-xl border-t border-black/[0.06] pb-[env(safe-area-inset-bottom)]" aria-label="주요 메뉴">
      <div className="h-[58px] flex items-stretch px-2">
        <Tab to="/" icon="home" label="홈" end />
        <Tab to="/lab" icon="lab" label="실험실" />
        <Tab to="/world" icon="world" label="평행세계" />
        <Tab to="/ledger" icon="ledger" label="가계부" />
      </div>
    </nav>
  );
}
