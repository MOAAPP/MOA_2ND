/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s11 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Report.controller';
import './Report.css';


import ReportPortalScene from '../three/ReportPortalScene';


function ReportScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {"SCREEN_10":-1});
  return (
    <div ref={rootRef} className="stitch-screen scr-report flex justify-center items-start min-h-full antialiased text-[#191F28]" style={{ overflow: "hidden" }}>
{/* Tailwind CSS CDN */}
{/* Pretendard Font */}
{/* Material Symbols Outlined */}
{/* 스마트폰 규격 뷰포트 (390px 최대 폭 최적화) */}
<div className="w-full max-w-[390px] min-h-full bg-[#F2F4F6] flex flex-col relative overflow-x-hidden">
{/* BEGIN: Top Navigation Header */}
<header className="fixed top-0 max-w-[390px] w-full bg-[#F2F4F6]/95 backdrop-blur-md px-4 py-3 border-b border-black/[0.03] z-50">
<div className="flex items-center justify-between relative">
<button aria-label="이전 화면" className="w-9 h-9 -ml-1 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all z-10" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_10'); })} type="button">
<span className="material-symbols-outlined text-[26px]">
arrow_back_ios_new
</span>
</button>
<h1 className="absolute inset-0 flex items-center justify-center text-[17px] font-bold text-toss-gray900 tracking-tight pointer-events-none">
11월 지출 분석
</h1>
<div className="w-9 h-9 -mr-1 pointer-events-none" aria-hidden="true" />
</div>
</header>
{/* END: Top Navigation Header */}
{/* BEGIN: Main Scroll Content */}
<main className="flex-1 px-4 pt-[72px] pb-8 space-y-3.5">
{/* SECTION 1: 메인 지출 총괄 요약 카드 */}
<section className="bg-white rounded-[24px] p-5 shadow-card" data-purpose="spending-summary">
<div className="flex items-center justify-between text-xs text-toss-gray500 mb-1.5 font-medium">
<span className="tracking-tight">
11월 총 지출
</span>
<div className="flex items-center space-x-1 cursor-pointer group" data-nav="/ledger">
<span>
수입{" "}
<span className="font-bold text-toss-gray700 tabular-nums">
1,279,713원
</span>
</span>
{" "}
<span className="material-symbols-outlined text-[14px] text-toss-gray400 group-hover:text-toss-gray600">
chevron_right
</span>
</div>
</div>
{/* 대형 지출 금액 타이포그래피 */}
<div className="flex items-baseline space-x-1 mb-3">
<span className="text-[32px] font-extrabold text-toss-gray900 tracking-tight tabular-nums">
270,447
</span>
{" "}
<span className="text-[22px] font-bold text-toss-gray900">
원
</span>
</div>
{/* 핀테크 감성 피드백 뱃지 */}
<div className="inline-flex items-center space-x-1.5 bg-[#E8F3FF] px-3 py-1.5 rounded-full mb-4">
<span className="text-sm">
👍
</span>
{" "}
<span className="text-xs font-bold text-toss-blue whitespace-nowrap">
지난달 동기간 대비 50,000원 덜 썼어요
</span>
</div>
{/* 예산 프로그레스 바 카드 */}
<div className="bg-toss-gray100/70 rounded-2xl p-3.5 border border-black/[0.02]">
<div className="flex items-center justify-between text-xs mb-2">
<div className="flex items-center space-x-1.5">
<span className="text-[13px]">
🎯
</span>
{" "}
<span className="font-semibold text-toss-gray700">
이번 달 예산 500,000원
</span>
</div>
<span className="font-bold text-toss-blue tabular-nums">
236,121원 남음
</span>
</div>
{/* 프로그레스 게이지 */}
<div className="w-full h-2 bg-toss-gray200 rounded-full overflow-hidden flex">
<div className="bg-toss-blue h-full rounded-full transition-all duration-500" style={{ width: "54.1%" }} />
</div>
<div className="flex justify-between items-center text-[11px] text-toss-gray400 mt-1.5 tabular-nums">
<span>
사용 54.1%
</span>
{" "}
<span>
남은 일수 12일
</span>
</div>
</div>
</section>
{/* SECTION 2: 지출 속도 & 추이 비교 차트 (인터랙티브 탭 & 툴팁 지원) */}
<section className="bg-white rounded-[24px] p-5 shadow-card" data-purpose="spending-pace-trend" id="pace-section">
<div className="flex items-center justify-between mb-3">
<div>
<h2 className="text-[17px] font-bold text-toss-gray900">
지출 속도
</h2>
<p className="text-[12px] text-toss-gray500 mt-0.5 transition-all duration-300" id="pace-subtitle" style={{ opacity: "1" }}>
어제보다 오늘 14,200원 덜 썼어요
</p>
</div>
{/* 기간 세그먼트 토글 버튼들 */}
<div className="flex bg-toss-gray100 p-0.5 rounded-xl text-xs font-semibold" role="tablist">
<button className="px-2.5 py-1 rounded-lg transition-all duration-200 active:scale-95 text-slate-500 hover:text-slate-900 bg-transparent font-medium" id="tab-monthly" onClick={(event) => run(event, (c) => { c.switchPaceTab('monthly'); })} type="button">
월별
</button>
{" "}
<button className="px-2.5 py-1 rounded-lg transition-all duration-200 active:scale-95 text-slate-500 hover:text-slate-900 bg-transparent font-medium" id="tab-weekly" onClick={(event) => run(event, (c) => { c.switchPaceTab('weekly'); })} type="button">
주별
</button>
{" "}
<button className="px-2.5 py-1 rounded-lg transition-all duration-200 active:scale-95 bg-slate-900 text-white shadow-sm font-semibold" id="tab-daily" onClick={(event) => run(event, (c) => { c.switchPaceTab('daily'); })} type="button">
일별
</button>
</div>
</div>
{/* 범례 */}
<div className="flex items-center space-x-3 text-[11px] text-toss-gray500 mb-2 transition-all duration-300" id="pace-legend">
<div className="flex items-center space-x-1.5">
<span className="w-2.5 h-0.5 bg-toss-blue rounded-full" />
{" "}
<span className="font-medium" id="legend-current-label">
오늘 지출
</span>
</div>
<div className="flex items-center space-x-1.5">
<span className="w-2.5 h-0.5 bg-toss-gray300 rounded-full" />
{" "}
<span className="font-medium" id="legend-prev-label">
일일 평균
</span>
</div>
<div className="flex items-center space-x-1.5" id="legend-highlight-chip">
<span className="w-1.5 h-1.5 rounded-full bg-toss-blue ring-2 ring-toss-blue/20" />
{" "}
<span className="font-bold text-toss-blue" id="legend-highlight-text">
오늘 (18일)
</span>
</div>
</div>
{/* 차트 컨테이너 (호버 & 클릭 인터랙션 포함) */}
<div className="relative w-full h-36 my-1 select-none">
{/* 월별 차트 뷰 (최근 6개월) */}
<div className="w-full h-full view-panel panel-hidden" id="view-monthly">
<svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 320 120">
<defs>
<linearGradient id="monthlyGlow" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stopColor="#3182F6" stopOpacity="0.22" />
<stop offset="100%" stopColor="#3182F6" stopOpacity="0.0" />
</linearGradient>
</defs>
{/* 그리드 라인 */}
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="25" y2="25" />
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="65" y2="65" />
<line stroke="#F2F4F6" strokeWidth="1" x1="0" x2="320" y1="110" y2="110" />
{/* 월별 예산선 (330,000원 기준선) */}
<line stroke="#D1D6DB" strokeDasharray="3 3" strokeWidth="1.2" x1="0" x2="320" y1="52" y2="52" />
<text fill="#8B95A1" fontSize="9" fontWeight="600" textAnchor="middle" x="288" y="47">
예산선
</text>
{/* 월별 영역 채우기 */}
{/* 6월: 25, 50 / 7월: 78, 62 / 8월: 131, 20 / 9월: 184, 68 / 10월: 237, 58 / 11월: 290, 78 */}
<path d="M 25 110 L 25 50 L 78 62 L 131 20 L 184 68 L 237 58 L 290 78 L 290 110 Z" fill="url(#monthlyGlow)" />
{/* 월별 지출 라인 */}
<path d="M 25 50 L 78 62 L 131 20 L 184 68 L 237 58 L 290 78" fill="none" stroke="#3182F6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
{/* 월별 포인트들 */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(25, 50, '6월', '340,000원'); })}>
<circle className="hover:r-5 transition-all" cx="25" cy="50" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(78, 62, '7월', '310,000원'); })}>
<circle className="hover:r-5 transition-all" cx="78" cy="62" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(131, 20, '8월', '420,000원'); })}>
<circle className="hover:r-5 transition-all" cx="131" cy="20" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(184, 68, '9월', '295,000원'); })}>
<circle className="hover:r-5 transition-all" cx="184" cy="68" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(237, 58, '10월', '320,000원'); })}>
<circle className="hover:r-5 transition-all" cx="237" cy="58" fill="#3182F6" r="3.5" />
</g>
{/* 현재 활성 11월 포인트 */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectMonthlyPoint(290, 78, '11월 (현재)', '270,447원'); })}>
<circle cx="184" cy="68" fill="#3182F6" id="monthly-halo" opacity="0.25" r="9" />
<circle className="animate-pulse" cx="184" cy="68" fill="#3182F6" id="monthly-ping" r="5" />
</g>
</svg>
{/* 11월 지출 툴팁 배지 */}
<div className="absolute left-[290px] top-[46px] -translate-x-1/2 bg-toss-gray900 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md whitespace-nowrap pointer-events-none transition-all duration-300" id="monthly-tooltip" style={{ left: "184px", top: "36px" }}>
295,000원
</div>
</div>
{/* 주별 차트 뷰 (4개 주간 추이) */}
<div className="w-full h-full view-panel panel-hidden" id="view-weekly">
<svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 320 120">
<defs>
<linearGradient id="weeklyGlow" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stopColor="#3182F6" stopOpacity="0.22" />
<stop offset="100%" stopColor="#3182F6" stopOpacity="0.0" />
</linearGradient>
</defs>
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="30" y2="30" />
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="70" y2="70" />
<line stroke="#F2F4F6" strokeWidth="1" x1="0" x2="320" y1="110" y2="110" />
{/* 지난달 동주차 평균선 (135,000원 기준선) */}
<line stroke="#D1D6DB" strokeDasharray="3 3" strokeWidth="1.2" x1="0" x2="320" y1="46" y2="46" />
<text fill="#8B95A1" fontSize="9" fontWeight="600" textAnchor="middle" x="282" y="41">
동주차 평균
</text>
{/* 4개 주간 추이 곡선 채우기 (1주: 45, 82 / 2주: 125, 64 / 3주: 205, 48 / 4주: 285, 96) */}
<path d="M 45 110 L 45 82 L 125 64 L 205 48 L 285 96 L 285 110 Z" fill="url(#weeklyGlow)" />
{/* 주간 지출 연결선 (3주차까지 실선, 4주차 예정 구간 점선) */}
<path d="M 45 82 L 125 64 L 205 48" fill="none" stroke="#3182F6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
<path d="M 205 48 L 285 96" fill="none" stroke="#3182F6" strokeDasharray="3 3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
{/* 주간 포인트들 */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectWeeklyPoint(45, 82, '1주차', '62,000원'); })}>
<circle className="hover:r-5 transition-all" cx="45" cy="82" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectWeeklyPoint(125, 64, '2주차', '85,400원'); })}>
<circle className="hover:r-5 transition-all" cx="125" cy="64" fill="#3182F6" r="3.5" />
</g>
{/* 현재 활성 3주차 포인트 */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectWeeklyPoint(205, 48, '3주차 (이번주)', '106,547원'); })}>
<circle cx="125" cy="64" fill="#3182F6" id="weekly-halo" opacity="0.25" r="9" />
<circle className="animate-pulse" cx="125" cy="64" fill="#3182F6" id="weekly-ping" r="5" />
</g>
{/* 4주차 예정 포인트 */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectWeeklyPoint(285, 96, '4주차 (예정)', '16,500원'); })}>
<circle className="hover:r-5 transition-all" cx="285" cy="96" fill="#FFFFFF" r="4" stroke="#3182F6" strokeWidth="2" />
</g>
</svg>
{/* 3주차 활성 툴팁 배지 */}
<div className="absolute left-[205px] top-[16px] -translate-x-1/2 bg-toss-gray900 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md whitespace-nowrap pointer-events-none transition-all duration-300" id="weekly-tooltip" style={{ left: "125px", top: "32px" }}>
85,400원
</div>
</div>
{/* 일별 차트 뷰 (기본 활성) */}
<div className="w-full h-full view-panel panel-visible" id="view-daily">
<svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 320 120">
<defs>
<linearGradient id="dailyGlow" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stopColor="#3182F6" stopOpacity="0.22" />
<stop offset="100%" stopColor="#3182F6" stopOpacity="0.0" />
</linearGradient>
</defs>
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="30" y2="30" />
<line stroke="#F2F4F6" strokeDasharray="3 3" strokeWidth="1" x1="0" x2="320" y1="70" y2="70" />
<line stroke="#F2F4F6" strokeWidth="1" x1="0" x2="320" y1="110" y2="110" />
{/* 일일 평균 기준선 (24,000원 선) */}
<line stroke="#D1D6DB" strokeDasharray="3 3" strokeWidth="1.2" x1="0" x2="320" y1="58" y2="58" />
<text fill="#8B95A1" fontSize="9" fontWeight="600" textAnchor="middle" x="280" y="54">
평균선
</text>
{/* 일별 영역 채우기 */}
<path d="M 20 110 L 20 80 L 65 65 L 110 92 L 155 45 L 200 70 L 245 35 L 290 85 L 290 110 Z" fill="url(#dailyGlow)" />
{/* 일별 지출 라인 */}
<path d="M 20 80 L 65 65 L 110 92 L 155 45 L 200 70 L 245 35 L 290 85" fill="none" stroke="#3182F6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
{/* 일별 포인트 클릭/호버 그룹들 (최근 7일: 월, 화, 수, 목, 금, 토, 일) */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(20, 80, '월 (12일)', '18,200원'); })}>
<circle className="hover:r-5 transition-all" cx="20" cy="80" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(65, 65, '화 (13일)', '22,400원'); })}>
<circle className="hover:r-5 transition-all" cx="65" cy="65" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(110, 92, '수 (14일)', '11,000원'); })}>
<circle className="hover:r-5 transition-all" cx="110" cy="92" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(155, 45, '목 (15일)', '34,500원'); })}>
<circle className="hover:r-5 transition-all" cx="155" cy="45" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(200, 70, '금 (16일)', '20,100원'); })}>
<circle className="hover:r-5 transition-all" cx="200" cy="70" fill="#3182F6" r="3.5" />
</g>
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(245, 35, '토 (17일)', '41,800원'); })}>
<circle className="hover:r-5 transition-all" cx="245" cy="35" fill="#3182F6" r="3.5" />
</g>
{/* 오늘 일요일 (활성) */}
<g className="cursor-pointer" onClick={(event) => run(event, (c) => { c.selectDailyPoint(290, 85, '오늘 일 (18일)', '16,500원'); })}>
<circle cx="200" cy="70" fill="#3182F6" id="daily-halo" opacity="0.25" r="9" />
<circle className="animate-pulse" cx="200" cy="70" fill="#3182F6" id="daily-ping" r="5" />
</g>
</svg>
<div className="absolute left-[290px] top-[51px] -translate-x-1/2 bg-toss-gray900 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md whitespace-nowrap pointer-events-none transition-all duration-300" id="daily-tooltip" style={{ left: "200px", top: "36px" }}>
20,100원
</div>
</div>
</div>
{/* X축 라벨 영역 */}
<div className="flex justify-between items-center text-[11px] text-toss-gray400 pt-1 border-t border-toss-gray100 tabular-nums transition-all" id="pace-axis-labels">
<span id="axis-left">
월(12일)
</span>
{" "}
<span className="text-toss-blue font-semibold" id="axis-mid">
목(15일)
</span>
{" "}
<span id="axis-right">
오늘 일(18일)
</span>
</div>
{/* 하단 대비 통계 2열 카드 */}
<div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-toss-gray100">
<div className="bg-toss-gray50 rounded-xl p-2.5 transition-all duration-300" id="card-stat-left">
<span className="text-[11px] text-toss-gray500 block mb-0.5" id="stat-left-label">
오늘 지출
</span>
{" "}
<span className="text-sm font-bold text-toss-blue tabular-nums" id="stat-left-val">
16,500원
</span>
</div>
<div className="bg-toss-gray50 rounded-xl p-2.5 transition-all duration-300" id="card-stat-right">
<span className="text-[11px] text-toss-gray500 block mb-0.5" id="stat-right-label">
일일 평균 지출
</span>
{" "}
<span className="text-sm font-bold text-toss-gray700 tabular-nums" id="stat-right-val">
24,000원
</span>
</div>
</div>
</section>
{/* SECTION 3: 카테고리별 지출 (모던 도넛 & 정교한 랭킹 리스트) */}
<section className="bg-white rounded-[24px] p-5 shadow-card" data-purpose="category-breakdown" id="category-breakdown-section">
<div className="flex items-center justify-between mb-2">
<h2 className="text-[17px] font-bold text-toss-gray900">
카테고리별 지출
</h2>
<span className="text-xs text-toss-gray400 font-medium" id="category-count-badge">
총 5개 항목
</span>
</div>
{/* 세련된 미니멀 도넛 차트 (충분한 중앙 여백 및 viewBox 최적화: r=70, C=439.82) */}
<div className="relative flex justify-center items-center py-2.5 select-none">
<svg className="w-48 h-48 -rotate-90 transform" viewBox="0 0 180 180">
{/* 배경 원환 (stroke 22) */}
<circle cx="90" cy="90" fill="none" r="70" stroke="#F2F4F6" strokeWidth="22" />
{/* C ≈ 439.82. 비율: 교통 43% -> 189.1, 금융 37% -> 162.7, 식비 7% -> 30.8, 뷰티 5% -> 22.0, 생활 8% -> 35.2 */}
{/* 1. 교통 (43%) */}
<circle className="cursor-pointer transition-all duration-200 hover:opacity-85" cx="90" cy="90" fill="none" onClick={(event) => run(event, (c) => { c.handleCategoryClick('traffic'); })} r="70" stroke="#00B493" strokeDasharray="189.1 439.82" strokeDashoffset="0" strokeWidth="22" />
{/* 2. 금융 (37%) */}
<circle className="cursor-pointer transition-all duration-200 hover:opacity-85" cx="90" cy="90" fill="none" onClick={(event) => run(event, (c) => { c.handleCategoryClick('finance'); })} r="70" stroke="#3182F6" strokeDasharray="162.7 439.82" strokeDashoffset="-189.1" strokeWidth="22" />
{/* 3. 식비 (7%) */}
<circle className="cursor-pointer transition-all duration-200 hover:opacity-85" cx="90" cy="90" fill="none" onClick={(event) => run(event, (c) => { c.handleCategoryClick('food'); })} r="70" stroke="#6366F1" strokeDasharray="30.8 439.82" strokeDashoffset="-351.8" strokeWidth="22" />
{/* 4. 뷰티/미용 (5%) */}
<circle className="cursor-pointer transition-all duration-200 hover:opacity-85" cx="90" cy="90" fill="none" onClick={(event) => run(event, (c) => { c.handleCategoryClick('beauty'); })} r="70" stroke="#A855F7" strokeDasharray="22.0 439.82" strokeDashoffset="-382.6" strokeWidth="22" />
{/* 5. 생활 (8%) */}
<circle className="cursor-pointer transition-all duration-200 hover:opacity-85" cx="90" cy="90" fill="none" onClick={(event) => run(event, (c) => { c.handleCategoryClick('life'); })} r="70" stroke="#F43F5E" strokeDasharray="35.2 439.82" strokeDashoffset="-404.6" strokeWidth="22" />
</svg>
{/* 도넛 센터 하이라이트 라벨: 레퍼런스 스타일 완벽 반영 및 텍스트 넘침 방지 */}
<div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-4" id="donut-center-info">
<span className="text-[11px] font-medium text-slate-400 tracking-tight leading-none mb-1" id="donut-badge-title">
선택 카테고리
</span>
{" "}
<span className="text-[15px] font-bold text-slate-800 tracking-tight leading-tight" id="donut-category-title">
뷰티/미용
</span>
{" "}
<span className="text-[12px] font-bold text-[#A855F7] leading-tight mt-1 tabular-nums whitespace-nowrap" id="donut-category-percent">
5% (13,600원)
</span>
</div>
</div>
{/* 카테고리 랭킹 및 상세 인터랙티브 리스트 (다중 아코디언 지원) */}
<div className="mt-2 space-y-1 divide-y divide-toss-gray100" id="category-list-container">
{/* 1. 교통 */}
<div className="pt-2.5 pb-2 rounded-xl transition-all" id="cat-wrapper-traffic">
<div className="flex items-center justify-between hover:bg-toss-gray50/60 rounded-xl px-2 py-1 transition-colors cursor-pointer group" onClick={(event) => run(event, (c) => { c.handleCategoryClick('traffic'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-teal-50 flex items-center justify-center text-toss-teal">
<span className="material-symbols-outlined text-[20px]">
directions_bus
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[14px] font-bold text-toss-gray900">
교통
</span>
{" "}
<span className="text-[11px] font-semibold text-toss-teal bg-teal-50 px-1.5 py-0.5 rounded">
43%
</span>
</div>
<span className="text-[11px] text-toss-gray400">
지하철, KTX, 택시 등 14건
</span>
</div>
</div>
<div className="flex items-center space-x-1">
<span className="text-[14px] font-bold text-toss-gray900 tabular-nums">
117,437원
</span>
{" "}
<span className="material-symbols-outlined text-[18px] text-toss-gray300 transition-transform duration-200 group-hover:text-toss-gray600" id="chevron-traffic" style={{ transform: "rotate(0deg)" }}>
expand_more
</span>
</div>
</div>
<div className="px-2 pt-2 pb-1.5 mt-1 bg-toss-gray50 rounded-xl space-y-2 border border-black/[0.03] hidden" id="detail-traffic">
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-toss-teal" />
{" "}
<span className="text-toss-gray700 font-medium">
KTX 경부선 예매
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-59,800원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-toss-teal" />
{" "}
<span className="text-toss-gray700 font-medium">
지하철 정기권 충전
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-55,000원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-toss-teal" />
{" "}
<span className="text-toss-gray700 font-medium">
카카오T 택시
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-2,637원
</span>
</div>
</div>
</div>
{/* 2. 금융 */}
<div className="pt-2.5 pb-2 rounded-xl transition-all" id="cat-wrapper-finance">
<div className="flex items-center justify-between hover:bg-toss-gray50/60 rounded-xl px-2 py-1 transition-colors cursor-pointer group" onClick={(event) => run(event, (c) => { c.handleCategoryClick('finance'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-blue-50 flex items-center justify-center text-toss-blue">
<span className="material-symbols-outlined text-[20px]">
credit_card
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[14px] font-bold text-toss-gray900">
금융
</span>
{" "}
<span className="text-[11px] font-semibold text-toss-blue bg-blue-50 px-1.5 py-0.5 rounded">
37%
</span>
</div>
<span className="text-[11px] text-toss-gray400">
적금, 대출이자, 보험 등 3건
</span>
</div>
</div>
<div className="flex items-center space-x-1">
<span className="text-[14px] font-bold text-toss-gray900 tabular-nums">
100,200원
</span>
{" "}
<span className="material-symbols-outlined text-[18px] text-toss-gray300 transition-transform duration-200 group-hover:text-toss-gray600" id="chevron-finance" style={{ transform: "rotate(0deg)" }}>
expand_more
</span>
</div>
</div>
<div className="px-2 pt-2 pb-1.5 mt-1 bg-toss-gray50 rounded-xl space-y-2 border border-black/[0.03] hidden" id="detail-finance">
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-toss-blue" />
{" "}
<span className="text-toss-gray700 font-medium">
청년도약적금 자동이체
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-100,000원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-toss-blue" />
{" "}
<span className="text-toss-gray700 font-medium">
계좌이체 수수료
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-200원
</span>
</div>
</div>
</div>
{/* 3. 식비 */}
<div className="pt-2.5 pb-2 rounded-xl transition-all" id="cat-wrapper-food">
<div className="flex items-center justify-between hover:bg-toss-gray50/60 rounded-xl px-2 py-1 transition-colors cursor-pointer group" onClick={(event) => run(event, (c) => { c.handleCategoryClick('food'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
<span className="material-symbols-outlined text-[20px]">
restaurant
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[14px] font-bold text-toss-gray900">
식비
</span>
{" "}
<span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
7%
</span>
</div>
<span className="text-[11px] text-toss-gray400">
카페, 점심식사 4건
</span>
</div>
</div>
<div className="flex items-center space-x-1">
<span className="text-[14px] font-bold text-toss-gray900 tabular-nums">
19,300원
</span>
{" "}
<span className="material-symbols-outlined text-[18px] text-toss-gray300 transition-transform duration-200 group-hover:text-toss-gray600" id="chevron-food" style={{ transform: "rotate(0deg)" }}>
expand_more
</span>
</div>
</div>
<div className="px-2 pt-2 pb-1.5 mt-1 bg-toss-gray50 rounded-xl space-y-2 border border-black/[0.03] hidden" id="detail-food">
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
{" "}
<span className="text-toss-gray700 font-medium">
스타벅스 강남점
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-6,500원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
{" "}
<span className="text-toss-gray700 font-medium">
맥도날드 런치세트
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-8,900원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
{" "}
<span className="text-toss-gray700 font-medium">
파리바게뜨 샌드위치
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-3,900원
</span>
</div>
</div>
</div>
{/* 4. 뷰티/미용 */}
<div className="pt-2.5 pb-2 rounded-xl transition-all bg-toss-gray50/70 p-1.5" id="cat-wrapper-beauty">
<div className="flex items-center justify-between hover:bg-toss-gray50/60 rounded-xl px-2 py-1 transition-colors cursor-pointer group" onClick={(event) => run(event, (c) => { c.handleCategoryClick('beauty'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
<span className="material-symbols-outlined text-[20px]">
content_cut
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[14px] font-bold text-toss-gray900">
뷰티/미용
</span>
{" "}
<span className="text-[11px] font-semibold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">
5%
</span>
</div>
<span className="text-[11px] text-toss-gray400">
헤어샵 케어 1건
</span>
</div>
</div>
<div className="flex items-center space-x-1">
<span className="text-[14px] font-bold text-toss-gray900 tabular-nums">
13,600원
</span>
{" "}
<span className="material-symbols-outlined text-[18px] text-toss-gray300 transition-transform duration-200 group-hover:text-toss-gray600" id="chevron-beauty" style={{ transform: "rotate(180deg)" }}>
expand_more
</span>
</div>
</div>
<div className="px-2 pt-2 pb-1.5 mt-1 bg-toss-gray50 rounded-xl space-y-2 border border-black/[0.03]" id="detail-beauty">
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-purple-600" />
{" "}
<span className="text-toss-gray700 font-medium">
올리브영 화장품/스킨케어
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-13,600원
</span>
</div>
</div>
</div>
{/* 5. 생활 */}
<div className="pt-2.5 pb-2 rounded-xl transition-all bg-toss-gray50/70 p-1.5" id="cat-wrapper-life">
<div className="flex items-center justify-between hover:bg-toss-gray50/60 rounded-xl px-2 py-1 transition-colors cursor-pointer group" onClick={(event) => run(event, (c) => { c.handleCategoryClick('life'); })}>
<div className="flex items-center space-x-3">
<div className="w-9 h-9 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
<span className="material-symbols-outlined text-[20px]">
shopping_bag
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="text-[14px] font-bold text-toss-gray900">
생활
</span>
{" "}
<span className="text-[11px] font-semibold text-rose-500 bg-rose-50 px-1.5 py-0.5 rounded">
3%
</span>
</div>
<span className="text-[11px] text-toss-gray400">
편의점 생필품 2건
</span>
</div>
</div>
<div className="flex items-center space-x-1">
<span className="text-[14px] font-bold text-toss-gray900 tabular-nums">
9,160원
</span>
{" "}
<span className="material-symbols-outlined text-[18px] text-toss-gray300 transition-transform duration-200 group-hover:text-toss-gray600" id="chevron-life" style={{ transform: "rotate(180deg)" }}>
expand_more
</span>
</div>
</div>
<div className="px-2 pt-2 pb-1.5 mt-1 bg-toss-gray50 rounded-xl space-y-2 border border-black/[0.03]" id="detail-life">
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
{" "}
<span className="text-toss-gray700 font-medium">
CU 편의점 생수/간식
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-5,200원
</span>
</div>
<div className="flex items-center justify-between text-xs">
<div className="flex items-center space-x-2">
<span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
{" "}
<span className="text-toss-gray700 font-medium">
GS25 생필품
</span>
</div>
<span className="font-bold text-toss-gray900 tabular-nums">
-3,960원
</span>
</div>
</div>
</div>
</div>
</section>
{/* SECTION 4: 고정 지출 & 예정 지출 요약 */}
<section className="bg-white rounded-[24px] p-5 shadow-card" data-purpose="fixed-expenses">
<div className="flex items-center justify-between mb-3">
<div className="flex items-center space-x-2">
<span className="material-symbols-outlined text-toss-gray700 text-[20px]">
event_repeat
</span>
<h2 className="text-[17px] font-bold text-toss-gray900">
고정 지출 리포트
</h2>
</div>
<span className="text-xs font-bold text-toss-gray700 tabular-nums">
총 299,417원 예정
</span>
</div>
{/* 2단계 상태 진행 바 */}
<div className="w-full h-2 bg-toss-gray200 rounded-full overflow-hidden flex mb-3">
<div className="bg-toss-gray400 h-full" style={{ width: "40.7%" }} />
<div className="bg-toss-blue h-full" style={{ width: "59.3%" }} />
</div>
{/* 고정 지출 상태 2열 카드 */}
<div className="grid grid-cols-2 gap-2.5">
{/* 나간 지출 */}
<div className="p-3 bg-toss-gray50 rounded-2xl border border-black/[0.02]">
<div className="flex items-center space-x-1.5 text-xs text-toss-gray500 mb-1">
<span className="w-2 h-2 rounded-full bg-toss-gray400" />
{" "}
<span className="whitespace-nowrap font-medium">
나간 고정 지출
</span>
</div>
<div className="text-[15px] font-bold text-toss-gray800 tabular-nums">
121,887원
</div>
<span className="text-[10px] text-toss-gray400">
통신비, 구독료 납부됨
</span>
</div>
{/* 나갈 예정 지출 */}
<div className="p-3 bg-blue-50/60 rounded-2xl border border-blue-100/50">
<div className="flex items-center space-x-1.5 text-xs text-toss-blue mb-1">
<span className="w-2 h-2 rounded-full bg-toss-blue" />
{" "}
<span className="whitespace-nowrap font-semibold">
나갈 예정 지출
</span>
</div>
<div className="text-[15px] font-bold text-toss-blue tabular-nums">
177,530원
</div>
<span className="text-[10px] text-blue-500/80">
월세·보험료 예정 (D-7)
</span>
</div>
</div>
</section>
{/* SECTION 5: 모아 시그니처: 평행세계 절약 환산 리포트 */}
<section className="rounded-[24px] p-5 shadow-card bg-gradient-to-br from-[#2563EB] via-[#3182F6] to-[#4F46E5] text-white relative overflow-hidden isolate" data-purpose="parallel-savings-simulator">
<ReportPortalScene className="absolute -right-20 -top-12 w-[300px] h-[260px] opacity-70 pointer-events-none -z-10" />
{/* 배경 글래스 데코 원환 */}
<div className="absolute -right-8 -top-8 w-36 h-36 rounded-full bg-white/10 blur-xl pointer-events-none" />
<div className="absolute -left-8 -bottom-8 w-28 h-28 rounded-full bg-indigo-300/10 blur-lg pointer-events-none" />
<div className="relative z-10">
<div className="flex items-center justify-between mb-2">
<span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-white/20 text-[11px] font-semibold text-white backdrop-blur-sm">
<span>
🪐
</span>
{" "}
<span>
MOA 평행세계 저축 환산
</span>
</span>
{" "}
<span className="text-[11px] text-blue-100 font-medium">
가상 적금 복리효과
</span>
</div>
<h3 className="text-[18px] font-extrabold leading-tight text-white mb-1">
아낀 소비가 평행세계 통장에 쌓여요!
</h3>
<p className="text-xs text-blue-100 mb-3.5">
이번 달 방어한 지출{" "}
<span className="font-bold text-white underline decoration-blue-300 decoration-2 tabular-nums">
48,500원
</span>
이 복리 투자 중
</p>
{/* 평행세계 자산 현황 박스 */}
<div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/15 mb-3 space-y-2">
<div className="flex items-center justify-between">
<span className="text-xs text-blue-100 font-medium">
누적 평행 자산
</span>
{" "}
<span className="text-base font-extrabold text-white tabular-nums">
+148,500원
</span>
</div>
<div className="space-y-1">
<div className="flex justify-between text-[11px] text-blue-100">
<span>
소행성 Lv.3 달성 중
</span>
{" "}
<span className="font-bold text-white tabular-nums">
82%
</span>
</div>
<div className="w-full h-1.5 bg-black/20 rounded-full overflow-hidden">
<div className="h-full bg-white rounded-full" style={{ width: "82%" }} />
</div>
</div>
<div className="pt-1.5 border-t border-white/10 flex justify-between text-[11px] text-blue-100">
<span>
가상 적금 환산 이율
</span>
{" "}
<span className="font-bold text-emerald-300 tabular-nums">
연 7.2% 복리 (+12,400원)
</span>
</div>
</div>
{/* 절약 환산 세부 칩 리스트 */}
<div className="space-y-1.5">
<div className="bg-white/15 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center justify-between cursor-pointer hover:bg-white/20 transition-all" data-nav="/invest">
<div className="flex items-center space-x-2">
<span className="text-[13px]">
☕
</span>
{" "}
<span className="text-xs font-semibold text-white">
커피 2회 절약
</span>
</div>
<div className="flex items-center space-x-1 text-xs font-bold text-white">
<span>
가상 ETF 9,000원 매수 환산
</span>
{" "}
<span className="material-symbols-outlined text-[14px] text-blue-200">
chevron_right
</span>
</div>
</div>
<div className="bg-white/15 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center justify-between cursor-pointer hover:bg-white/20 transition-all" data-nav="/savings">
<div className="flex items-center space-x-2">
<span className="text-[13px]">
🛵
</span>
{" "}
<span className="text-xs font-semibold text-white">
배달 1회 절약
</span>
</div>
<div className="flex items-center space-x-1 text-xs font-bold text-white">
<span>
우주여행 적금 22,000원 부스팅
</span>
{" "}
<span className="material-symbols-outlined text-[14px] text-blue-200">
chevron_right
</span>
</div>
</div>
</div>
</div>
</section>
</main>
{/* END: Main Scroll Content */}
{/* BEGIN: Sticky Bottom Button */}
<div className="sticky bottom-0 bg-white/95 backdrop-blur-md px-4 pt-2.5 pb-5 border-t border-black/[0.04] z-30 shadow-lg">
<button className="w-full py-3.5 bg-toss-blue hover:bg-toss-blueDark active:scale-[0.98] text-white font-bold rounded-2xl text-[15px] shadow-floating transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_10'); })} type="button">
<span>
가계부 화면으로 돌아가기
</span>
</button>
</div>
{/* END: Sticky Bottom Button */}
{/* BEGIN: Share Bottom Sheet Modal & Backdrop */}
{/* Floating Toast Notification */}
{/* END: Share Bottom Sheet Modal & Backdrop */}
</div>
{/* 공유 바텀시트 인터랙션 스크립트 */}
{/* 지출 속도 인터랙션 스크립트 */}
{/* 카테고리 독립 다중 아코디언 및 도넛 차트 스크립트 */}
    </div>
  );
}

export default memo(ReportScreen);
