/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s08. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  let absorptionScene, absorptionCamera, absorptionRenderer, absorptionAnimId;
  let absorptionPlanetGroup, coinItems = [], banknoteItems = [], stardustParticles;
  let isSceneInitialized = false;

  function initParallelWorld3DScene() {
    const container = document.getElementById('threejs-container-absorption');
    if (!container || isSceneInitialized) return;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Scene & Camera
    absorptionScene = new THREE.Scene();
    absorptionCamera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    absorptionCamera.position.set(0, 1.2, 8.5);

    // WebGL Renderer with alpha transparency enabled
    try {
      absorptionRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch (e) {
      console.warn("WebGL not supported, falling back to CSS background", e);
      return;
    }
    absorptionRenderer.setSize(width, height);
    absorptionRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    absorptionRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    absorptionRenderer.toneMappingExposure = 1.2;
    container.appendChild(absorptionRenderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.85);
    absorptionScene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x60a5fa, 2.0);
    dirLight1.position.set(5, 8, 5);
    absorptionScene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xa78bfa, 1.5);
    dirLight2.position.set(-6, -3, 3);
    absorptionScene.add(dirLight2);

    const centerPointLight = new THREE.PointLight(0x38bdf8, 3.5, 12);
    centerPointLight.position.set(0, 0.4, 0);
    absorptionScene.add(centerPointLight);

    // Parallel Sapphire Core Planet Group
    absorptionPlanetGroup = new THREE.Group();
    absorptionPlanetGroup.position.set(0, 0.5, 0);
    absorptionScene.add(absorptionPlanetGroup);

    // Planet Sphere (Sapphire Crystal Theme)
    const planetGeo = new THREE.SphereGeometry(1.6, 64, 64);
    const planetMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      emissive: 0x0c4a6e,
      emissiveIntensity: 0.6,
      roughness: 0.25,
      metalness: 0.85,
    });
    const planetMesh = new THREE.Mesh(planetGeo, planetMat);
    absorptionPlanetGroup.add(planetMesh);

    // Planet Atmosphere Aura Glow
    const auraGeo = new THREE.SphereGeometry(1.78, 32, 32);
    const auraMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.28,
      wireframe: true,
    });
    const auraMesh = new THREE.Mesh(auraGeo, auraMat);
    absorptionPlanetGroup.add(auraMesh);

    // Cosmic Planet Planetary Rings
    const ringGeo = new THREE.RingGeometry(2.1, 3.2, 64);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45,
    });
    const planetRing = new THREE.Mesh(ringGeo, ringMat);
    planetRing.rotation.x = Math.PI * 0.42;
    planetRing.rotation.y = Math.PI * 0.1;
    absorptionPlanetGroup.add(planetRing);

    // Second faint outer ring
    const ringGeo2 = new THREE.RingGeometry(3.35, 3.8, 64);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0x818cf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.25,
    });
    const planetRing2 = new THREE.Mesh(ringGeo2, ringMat2);
    planetRing2.rotation.x = Math.PI * 0.42;
    planetRing2.rotation.y = Math.PI * 0.1;
    absorptionPlanetGroup.add(planetRing2);

    // Starfield Particle Dust
    const starsCount = 400;
    const starCoords = new Float32Array(starsCount * 3);
    for (let i = 0; i < starsCount * 3; i += 3) {
      starCoords[i] = (Math.random() - 0.5) * 25;
      starCoords[i+1] = (Math.random() - 0.5) * 25;
      starCoords[i+2] = (Math.random() - 0.5) * 20;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starCoords, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xe0f2fe,
      size: 0.08,
      transparent: true,
      opacity: 0.8
    });
    stardustParticles = new THREE.Points(starGeo, starMat);
    absorptionScene.add(stardustParticles);

    // Swirling Money/Coins being absorbed toward center vortex
    const coinGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.04, 24);
    const coinMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      metalness: 0.95,
      roughness: 0.2,
      emissive: 0xd97706,
      emissiveIntensity: 0.35,
    });

    coinItems = [];
    const numCoins = 24;
    for (let i = 0; i < numCoins; i++) {
      const coin = new THREE.Mesh(coinGeo, coinMat);
      const angle = (i / numCoins) * Math.PI * 2 + Math.random() * 0.5;
      const radius = 2.4 + Math.random() * 2.2;
      const height = (Math.random() - 0.5) * 1.8;
      coin.position.set(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
      coin.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      absorptionScene.add(coin);
      coinItems.push({
        mesh: coin,
        angle: angle,
        radius: radius,
        speed: 0.014 + Math.random() * 0.012,
        heightOffset: height,
        rotSpeedX: (Math.random() - 0.5) * 0.06,
        rotSpeedY: (Math.random() - 0.5) * 0.06,
      });
    }

    // Swirling Banknote Rectangles
    const noteGeo = new THREE.PlaneGeometry(0.36, 0.2);
    const noteMat = new THREE.MeshStandardMaterial({
      color: 0x34d399,
      emissive: 0x059669,
      emissiveIntensity: 0.4,
      roughness: 0.4,
      metalness: 0.2,
      side: THREE.DoubleSide
    });

    banknoteItems = [];
    const numNotes = 16;
    for (let i = 0; i < numNotes; i++) {
      const note = new THREE.Mesh(noteGeo, noteMat);
      const angle = (i / numNotes) * Math.PI * 2;
      const radius = 2.6 + Math.random() * 2.0;
      const height = (Math.random() - 0.5) * 2.0;
      note.position.set(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
      note.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      absorptionScene.add(note);
      banknoteItems.push({
        mesh: note,
        angle: angle,
        radius: radius,
        speed: 0.012 + Math.random() * 0.01,
        heightOffset: height,
        rotSpeedX: (Math.random() - 0.5) * 0.05,
        rotSpeedY: (Math.random() - 0.5) * 0.05,
      });
    }

    window.addEventListener('resize', handleThreeResize);
    isSceneInitialized = true;
  }

  function handleThreeResize() {
    const container = document.getElementById('threejs-container-absorption');
    if (!container || !absorptionCamera || !absorptionRenderer) return;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    absorptionCamera.aspect = width / height;
    absorptionCamera.updateProjectionMatrix();
    absorptionRenderer.setSize(width, height);
  }

  function animateAbsorptionLoop() {
    absorptionAnimId = requestAnimationFrame(animateAbsorptionLoop);

    if (absorptionPlanetGroup) {
      // Calm, elegant cosmic rotation
      absorptionPlanetGroup.rotation.y += 0.005;
      absorptionPlanetGroup.rotation.x = Math.sin(Date.now() * 0.0008) * 0.08;
    }

    if (stardustParticles) {
      stardustParticles.rotation.y += 0.0008;
    }

    // Animate swirling vortex absorption of coins
    const centerTargetY = 0.5;
    coinItems.forEach(item => {
      item.angle += item.speed;
      // Gently pull inward toward the planet vortex, then reset at periphery
      item.radius -= 0.004;
      if (item.radius < 1.35) {
        item.radius = 4.2 + Math.random() * 0.6;
      }
      item.mesh.position.x = Math.cos(item.angle) * item.radius;
      item.mesh.position.z = Math.sin(item.angle) * item.radius;
      item.mesh.position.y = centerTargetY + item.heightOffset * (item.radius / 3.8);

      item.mesh.rotation.x += item.rotSpeedX;
      item.mesh.rotation.y += item.rotSpeedY;
    });

    // Animate fluttering banknotes toward planet
    banknoteItems.forEach(item => {
      item.angle += item.speed;
      item.radius -= 0.0035;
      if (item.radius < 1.4) {
        item.radius = 4.0 + Math.random() * 0.8;
      }
      item.mesh.position.x = Math.cos(item.angle) * item.radius;
      item.mesh.position.z = Math.sin(item.angle) * item.radius;
      item.mesh.position.y = centerTargetY + item.heightOffset * (item.radius / 3.5);

      item.mesh.rotation.x += item.rotSpeedX;
      item.mesh.rotation.y += item.rotSpeedY;
    });

    if (absorptionRenderer && absorptionScene && absorptionCamera) {
      absorptionRenderer.render(absorptionScene, absorptionCamera);
    }
  }


/* ---- */


  // Financial baseline
  const __fin = app.moa.financeSnapshot();
  const BASE_BALANCE = __fin.balance;
  const ESSENTIAL_SCHEDULED = __fin.essential;
  const MIN_BASELINE = __fin.minBalance;

  // States
  let currentConsiderAmount = 259000;
  let currentExpenseAmount = 6500;
  let currentSelectedInstallment = '6개월';
  let isConsiderDateUndecided = true;
  let lastSavedConsiderDate = '2026. 11. 12 (목)';
  let lastSavedConsiderSubtitle = '3일간 더 생각해보기를 권장해요';
  let toastTimer = null;
  let fullscreenTransitionTimer = null;

  // Toast Function
  function showToast(message, icon = '✓') {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toastMessage');
    const toastIcon = document.getElementById('toastIcon');
    if (!toast || !toastMsg) return;

    if (toastTimer) clearTimeout(toastTimer);
    toastMsg.textContent = message;
    if (toastIcon) toastIcon.textContent = icon;

    toast.classList.remove('opacity-0', 'translate-y-[-12px]', 'pointer-events-none');
    toast.classList.add('opacity-100', 'translate-y-0');

    toastTimer = setTimeout(() => {
      toast.classList.remove('opacity-100', 'translate-y-0');
      toast.classList.add('opacity-0', 'translate-y-[-12px]', 'pointer-events-none');
    }, 2800);
  }

  function formatWon(num) {
    return Number(num).toLocaleString('ko-KR') + '원';
  }

  function formatShortManWon(num) {
    if (num <= 0) return '0원';
    const man = (num / 10000).toFixed(1);
    return man.replace(/\.0$/, '') + '만';
  }

  // --- Purchase Consideration Dynamic Updates ---
  function updateConsiderationState() {
    const amount = Math.max(0, currentConsiderAmount);
    
    const inputEl = document.getElementById('considerAmountInput');
    if (inputEl && document.activeElement !== inputEl) inputEl.value = Number(amount).toLocaleString('ko-KR');

    const postPurchaseBal = BASE_BALANCE - amount;
    const postEssentialBal = BASE_BALANCE - amount - ESSENTIAL_SCHEDULED;

    const labelEl = document.getElementById('postPurchaseLabel');
    if (labelEl) labelEl.textContent = `구매 직후 예상 잔액 (-${Number(amount).toLocaleString('ko-KR')}원)`;

    const postBalEl = document.getElementById('postPurchaseBalanceText');
    if (postBalEl) {
      postBalEl.textContent = formatWon(postPurchaseBal);
      postBalEl.className = postPurchaseBal < 0 ? 'text-rose-600 font-extrabold' : 'text-blue-600 font-extrabold';
    }

    const postEssBalEl = document.getElementById('postEssentialBalanceText');
    if (postEssBalEl) {
      postEssBalEl.textContent = formatWon(postEssentialBal);
      if (postEssentialBal < 0) {
        postEssBalEl.className = 'text-rose-600 font-bold animate-pulse';
      } else if (postEssentialBal < MIN_BASELINE) {
        postEssBalEl.className = 'text-rose-600 font-bold';
      } else {
        postEssBalEl.className = 'text-emerald-600 font-bold';
      }
    }

    const safetyBadge = document.getElementById('balanceSafetyBadge');
    if (safetyBadge) {
      if (postEssentialBal < 0) {
        safetyBadge.textContent = '잔액 부족 위험';
        safetyBadge.className = 'text-rose-600 font-semibold px-2 py-0.5 rounded-full bg-rose-100 transition-colors animate-pulse';
      } else if (postEssentialBal < MIN_BASELINE) {
        safetyBadge.textContent = '주의: 여유 자금 부족';
        safetyBadge.className = 'text-amber-700 font-semibold px-2 py-0.5 rounded-full bg-amber-100 transition-colors';
      } else {
        safetyBadge.textContent = '안전 구간 유지';
        safetyBadge.className = 'text-blue-600 font-semibold px-2 py-0.5 rounded-full bg-blue-50 transition-colors';
      }
    }

    // Graphical Chart Line & Points
    function balanceToY(val) {
      const normalized = Math.max(0, Math.min(val, 450000));
      return (52 - (normalized / 450000) * 40).toFixed(1);
    }

    const y0 = balanceToY(BASE_BALANCE);
    const y1 = balanceToY(postPurchaseBal);
    const y2 = balanceToY(postEssentialBal);
    const y3 = Math.min(54, parseFloat(y2) + 4);

    const linePath = `M0,${y0} L70,${y0} L140,${y1} L220,${y2} L300,${y3}`;
    const areaPath = `M0,${y0} L70,${y0} L140,${y1} L220,${y2} L300,${y3} L300,60 L0,60 Z`;

    const chartLine = document.getElementById('chartLinePath');
    const chartArea = document.getElementById('chartAreaPath');
    const dot2 = document.getElementById('dotPoint2');
    const dot3 = document.getElementById('dotPoint3');

    if (chartLine) chartLine.setAttribute('d', linePath);
    if (chartArea) chartArea.setAttribute('d', areaPath);
    if (dot2) {
      dot2.setAttribute('cy', y1);
      dot2.setAttribute('fill', postPurchaseBal < MIN_BASELINE ? '#ef4444' : '#3182F6');
    }
    if (dot3) {
      dot3.setAttribute('cy', y2);
      dot3.setAttribute('fill', postEssentialBal < MIN_BASELINE ? '#ef4444' : '#10b981');
    }

    const chartLabelPost = document.getElementById('chartLabelPost');
    if (chartLabelPost) {
      chartLabelPost.textContent = `구매 직후 (${formatShortManWon(Math.max(0, postPurchaseBal))})`;
    }
    const chartLabelMonthEnd = document.getElementById('chartLabelMonthEnd');
    if (chartLabelMonthEnd) {
      chartLabelMonthEnd.textContent = `월말 예정 (${formatShortManWon(Math.max(0, postEssentialBal))})`;
    }

    const considerCtaText = document.getElementById('considerCtaText');
    if (considerCtaText) {
      considerCtaText.textContent = `${Number(amount).toLocaleString('ko-KR')}원 고민 목록에 담기`;
    }

    const celebSavedText = document.getElementById('celebSavedAmountText');
    const celebAccum = document.getElementById('celebAccumulatedAmount');
    const celebCompound = document.getElementById('celebCompoundAmount');
    if (celebSavedText) celebSavedText.textContent = formatWon(amount);
    if (celebAccum) celebAccum.textContent = `+${formatWon(amount)}`;
    if (celebCompound) {
      const compounded = Math.round(amount * 1.072);
      celebCompound.textContent = `1년 뒤 약 ${formatWon(compounded)}`;
    }
  }

  function addConsiderAmount(val) {
    currentConsiderAmount += val;
    updateConsiderationState();
    showToast(`+${(val >= 10000 ? val/10000 + '만' : val) }원 추가되었습니다.`);
  }

  function resetConsiderAmount() {
    currentConsiderAmount = 0;
    updateConsiderationState();
    showToast('금액이 0원으로 초기화되었습니다.');
  }

  function handleConsiderInput(val) {
    const numeric = parseInt(val.replace(/[^0-9]/g, '')) || 0;
    currentConsiderAmount = numeric;
    updateConsiderationState();
  }

  function clearConsiderProduct() {
    const input = document.getElementById('considerProductName');
    if (input) {
      input.value = '';
      input.focus();
    }
  }

  // --- Category Handlers ---
  function selectConsiderCategory(btn, catName) {
    const group = document.getElementById('considerCategoryGroup');
    if (!group) return;
    const buttons = group.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action';
    });
    btn.className = 'border border-blue-500 bg-blue-50 text-blue-600 font-bold py-2 rounded-xl text-xs tap-action';
    showToast(`카테고리가 [${catName}](으)로 설정되었습니다.`);
  }

  function selectRecordCategory(btn, catName) {
    const group = document.getElementById('recordCategoryGroup');
    if (!group) return;
    const buttons = group.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action';
    });
    btn.className = 'border border-blue-500 bg-blue-50 text-blue-600 font-bold py-2 rounded-xl text-xs tap-action';
    showToast(`카테고리가 [${catName}](으)로 변경되었습니다.`);
  }

  // --- Payment Handlers ---
  function selectConsiderPayment(name) {
    const group = document.getElementById('considerPaymentGroup');
    const installmentBox = document.getElementById('installmentBox');
    if (!group) return;

    const cards = group.children;
    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      const titleSpan = card.querySelector('span:first-child');
      const text = titleSpan ? titleSpan.textContent.trim() : '';

      if (text === name) {
        card.className = 'border-2 border-blue-500 bg-blue-50/40 rounded-xl p-3 flex flex-col justify-between h-20 tap-action';
        let badgeEl = card.querySelector('span.text-blue-500');
        if (!badgeEl) {
          const wrapDiv = document.createElement('div');
          wrapDiv.className = 'flex items-center justify-between';
          card.replaceChild(wrapDiv, titleSpan);
          wrapDiv.appendChild(titleSpan);
          titleSpan.className = 'text-sm font-bold text-blue-600';
          const newBadge = document.createElement('span');
          newBadge.className = 'text-[11px] text-blue-500 font-medium';
          newBadge.textContent = '선택됨';
          wrapDiv.appendChild(newBadge);
        } else {
          titleSpan.className = 'text-sm font-bold text-blue-600';
        }
      } else {
        card.className = 'border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 tap-action hover:bg-slate-100';
        const wrapDiv = card.querySelector('div.flex');
        if (wrapDiv) {
          const tSpan = wrapDiv.querySelector('span');
          tSpan.className = 'text-sm font-bold text-slate-700';
          card.replaceChild(tSpan, wrapDiv);
        } else if (titleSpan) {
          titleSpan.className = 'text-sm font-bold text-slate-700';
        }
      }
    }

    if (name === '신용카드') {
      if (installmentBox) installmentBox.classList.remove('hidden');
    } else {
      if (installmentBox) installmentBox.classList.add('hidden');
    }
    showToast(`결제수단: ${name} 선택됨`);
  }

  function selectInstallment(btn, months) {
    currentSelectedInstallment = months;
    const group = document.getElementById('installmentGroup');
    if (!group) return;
    const buttons = group.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-medium tap-action hover:bg-slate-200';
    });
    btn.className = 'px-2.5 py-1 rounded-lg bg-blue-500 text-white font-bold text-[11px] shadow-sm tap-action';
    showToast(`할부 개월 수가 [${months}](으)로 설정되었습니다.`);
  }

  function selectRecordPayment(btn, name) {
    const group = document.getElementById('recordPaymentGroup');
    if (!group) return;
    const buttons = group.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action hover:bg-slate-100';
      const spans = b.querySelectorAll('span');
      if (spans[0]) spans[0].className = 'text-sm font-bold text-slate-700';
      if (spans[1]) spans[1].className = 'text-[11px] text-slate-400';
    });

    btn.className = 'border-2 border-blue-500 bg-blue-50/40 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action';
    const activeSpans = btn.querySelectorAll('span');
    if (activeSpans[0]) activeSpans[0].className = 'text-sm font-bold text-blue-600';
    if (activeSpans[1]) activeSpans[1].className = 'text-[11px] text-blue-500 font-medium';
    showToast(`결제수단 [${name}] 선택`);
  }

  // --- Necessity 3-way toggle ---
  function selectNecessity(type) {
    const needBtn = document.getElementById('needBtn');
    const delayBtn = document.getElementById('delayBtn');
    const wantBtn = document.getElementById('wantBtn');
    const reasonInput = document.getElementById('necessityReasonInput');

    const resetBtnStyle = (b, icon, title, desc) => {
      b.className = 'p-3 rounded-xl text-center border border-slate-200 bg-white hover:bg-slate-50 tap-action flex flex-col items-center justify-between h-full relative';
      b.innerHTML = `
        <div class="flex flex-col items-center gap-1 w-full">
          <span class="text-base">${icon}</span>
          <span class="text-xs font-bold text-slate-700">${title}</span>
          <span class="text-[10px] text-slate-400 mt-0.5 leading-tight">${desc}</span>
        </div>`;
    };

    const setActiveBtnStyle = (b, icon, title, desc) => {
      b.className = 'p-3 rounded-xl text-center border-2 border-blue-500 bg-blue-50/50 hover:bg-blue-50 tap-action flex flex-col items-center justify-between h-full relative shadow-sm';
      b.innerHTML = `
        <div class="flex flex-col items-center gap-1 w-full">
          <span class="text-base">${icon}</span>
          <span class="text-xs font-bold text-blue-600">${title}</span>
          <span class="text-[10px] text-blue-600/80 mt-0.5 leading-tight font-medium">${desc}</span>
        </div>`;
    };

    if (type === 'must') {
      setActiveBtnStyle(needBtn, '⚡', '꼭 필요해요', '생필품·필수 지출');
      resetBtnStyle(delayBtn, '⏳', '급하지 않아요', '나중에 구매 가능');
      resetBtnStyle(wantBtn, '✨', '선택적 소비', '만족·여가를 위한');
      if (reasonInput) reasonInput.value = '업무 및 생활에 매일 필요하여 대체 수단이 없어 구매를 검토 중이에요.';
      showToast('필수 소비로 선택되었습니다.');
    } else if (type === 'delay') {
      resetBtnStyle(needBtn, '⚡', '꼭 필요해요', '생필품·필수 지출');
      setActiveBtnStyle(delayBtn, '⏳', '급하지 않아요', '나중에 구매 가능');
      resetBtnStyle(wantBtn, '✨', '선택적 소비', '만족·여가를 위한');
      if (reasonInput) reasonInput.value = '현재 다른 대체품이 있어서 조금 더 가격 할인을 기다리거나 다음 달로 미뤄도 괜찮아요.';
      showToast('급하지 않은 소비로 선택되었습니다.');
    } else {
      resetBtnStyle(needBtn, '⚡', '꼭 필요해요', '생필품·필수 지출');
      resetBtnStyle(delayBtn, '⏳', '급하지 않아요', '나중에 구매 가능');
      setActiveBtnStyle(wantBtn, '✨', '선택적 소비', '만족·여가를 위한');
      if (reasonInput) reasonInput.value = '기존 이어폰 배터리가 빨리 닳아서 편하긴 한데, 다음 달 필수 결제 예정금액이 있어서 고민돼요.';
      updateConsiderationState();
      showToast('선택적 소비로 선택되었습니다.');
    }
  }

  // --- Date Modal Functions ---
  function openDateModal() {
    const modal = document.getElementById('datePickerModal');
    const sheet = document.getElementById('datePickerSheet');
    if (!modal || !sheet) return;

    updateModalUndecidedStyle();
    modal.classList.remove('hidden');
    requestAnimationFrame(() => {
      modal.classList.remove('opacity-0');
      modal.classList.add('opacity-100');
      sheet.classList.remove('translate-y-full');
      sheet.classList.add('translate-y-0');
    });
  }

  function closeDateModal() {
    const modal = document.getElementById('datePickerModal');
    const sheet = document.getElementById('datePickerSheet');
    if (!modal || !sheet) return;

    modal.classList.add('opacity-0');
    modal.classList.remove('opacity-100');
    sheet.classList.add('translate-y-full');
    sheet.classList.remove('translate-y-0');

    setTimeout(() => {
      modal.classList.add('hidden');
    }, 280);
  }

  function handleDateModalBackdrop(e) {
    if (e.target.id === 'datePickerModal') closeDateModal();
  }

  function confirmDateModal() {
    closeDateModal();
  }

  function updateModalUndecidedStyle() {
    const modalBtn = document.getElementById('modalUndecidedBtn');
    const radio = document.getElementById('modalUndecidedRadio');
    const dot = document.getElementById('modalUndecidedRadioDot');
    if (!modalBtn) return;

    if (isConsiderDateUndecided) {
      modalBtn.className = "w-full p-3.5 rounded-2xl border-2 border-amber-500 bg-amber-50/60 shadow-sm flex items-center justify-between tap-action group";
      if (radio) radio.className = "w-5 h-5 rounded-full border-2 border-amber-500 flex items-center justify-center transition-colors bg-amber-500";
      if (dot) dot.className = "w-2 h-2 rounded-full bg-white";
    } else {
      modalBtn.className = "w-full p-3.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-between tap-action group";
      if (radio) radio.className = "w-5 h-5 rounded-full border-2 border-slate-300 flex items-center justify-center transition-colors";
      if (dot) dot.className = "w-2.5 h-2.5 rounded-full bg-transparent";
    }
  }

  function setConsiderDateUndecided() {
    isConsiderDateUndecided = true;
    renderDateCardState();
    updateModalUndecidedStyle();
    closeDateModal();
    showToast('구매 예정일이 [미정 (아직 안 정했어요)]으로 설정되었습니다.', '⏳');
  }

  function selectSpecificDate(dateStr, subtitle) {
    isConsiderDateUndecided = false;
    lastSavedConsiderDate = dateStr;
    lastSavedConsiderSubtitle = subtitle || '고민 후 결정해 보세요';
    renderDateCardState();
    updateModalUndecidedStyle();
    closeDateModal();
    showToast(`구매 예정일이 [${dateStr}](으)로 설정되었습니다.`);
  }

  function toggleUndecidedDirect() {
    if (isConsiderDateUndecided) {
      isConsiderDateUndecided = false;
      renderDateCardState();
      showToast(`구매 예정일이 다시 [${lastSavedConsiderDate}](으)로 설정되었습니다.`);
    } else {
      setConsiderDateUndecided();
    }
  }

  function renderDateCardState() {
    const dateText = document.getElementById('considerDateText');
    const dateSub = document.getElementById('considerDateSubtitle');
    const badge = document.getElementById('undecidedBadge');
    const iconBox = document.getElementById('considerDateIconBox');
    const toggleBtn = document.getElementById('quickUndecidedToggle');
    const toggleLabel = document.getElementById('undecidedBtnLabel');
    const cardBox = document.getElementById('considerDateCardBox');

    if (isConsiderDateUndecided) {
      if (dateText) dateText.textContent = '날짜 미정';
      if (dateSub) dateSub.textContent = '급하지 않은 소비는 여유를 두고 결정해요';
      if (badge) {
        badge.classList.remove('hidden');
        badge.textContent = '미정';
        badge.className = 'bg-amber-100 text-amber-800 text-[11px] font-semibold px-1.5 py-0.5 rounded-md border border-amber-200 shrink-0';
      }
      if (iconBox) {
        iconBox.className = 'w-11 h-11 rounded-xl bg-amber-100/70 border border-amber-200/60 flex items-center justify-center text-xl flex-shrink-0';
        iconBox.innerHTML = '⏳';
      }
      if (toggleBtn) {
        toggleBtn.className = 'bg-amber-50 text-amber-700 border border-amber-200/80 px-2.5 py-1 text-xs font-semibold rounded-full flex items-center gap-1 tap-action';
      }
      if (toggleLabel) toggleLabel.textContent = '날짜 미정 선택됨 ✓';
      if (cardBox) cardBox.className = 'bg-amber-50/40 border border-amber-200/90 rounded-2xl p-3.5 flex items-center justify-between gap-3 cursor-pointer tap-action transition-colors hover:bg-amber-50/70';
    } else {
      if (dateText) dateText.textContent = lastSavedConsiderDate;
      if (dateSub) dateSub.textContent = lastSavedConsiderSubtitle;
      if (badge) badge.classList.add('hidden');
      if (iconBox) {
        iconBox.className = 'w-11 h-11 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-xl flex-shrink-0 text-blue-600';
        iconBox.innerHTML = `
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect height="18" rx="2" stroke-width="2" width="18" x="3" y="4"></rect>
            <line stroke-linecap="round" stroke-width="2" x1="16" x2="16" y1="2" y2="6"></line>
            <line stroke-linecap="round" stroke-width="2" x1="8" x2="8" y1="2" y2="6"></line>
            <line stroke-width="2" x1="3" x2="21" y1="10" y2="10"></line>
          </svg>`;
      }
      if (toggleBtn) {
        toggleBtn.className = 'bg-slate-100 text-slate-600 border border-slate-200 px-2.5 py-1 text-xs font-semibold rounded-full flex items-center gap-1 tap-action hover:bg-slate-200';
      }
      if (toggleLabel) toggleLabel.textContent = '날짜 미정으로 변경';
      if (cardBox) cardBox.className = 'bg-white border border-slate-200/90 rounded-2xl p-3.5 flex items-center justify-between gap-3 cursor-pointer tap-action transition-colors hover:bg-slate-50';
    }
  }

  function changeRecordDate() {
    const dates = ['2026. 11. 10 (화)', '2026. 11. 09 (월)', '2026. 11. 08 (일)'];
    const cur = document.getElementById('recordDateText').textContent;
    const next = dates[(dates.indexOf(cur) + 1) % dates.length];
    document.getElementById('recordDateText').textContent = next;
    showToast(`결제일이 [${next}](으)로 변경되었습니다.`);
  }

  function toggleTimeUnknown(checked) {
    const badge = document.getElementById('recordTimeBadge');
    if (!badge) return;
    if (checked) {
      badge.textContent = '시간 미지정';
      badge.className = 'bg-slate-100 text-slate-500 font-medium text-[11px] px-1.5 py-0.5 rounded';
    } else {
      badge.textContent = '14:20';
      badge.className = 'bg-blue-50 text-blue-600 font-bold text-[11px] px-1.5 py-0.5 rounded';
    }
  }

  function selectRecordType(btn, type) {
    const group = document.getElementById('recordTypeGroup');
    const label = document.getElementById('recordAmountLabel');
    if (!group) return;

    const buttons = group.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-xl py-3 text-sm text-center transition-colors border-2 border-transparent tap-action';
    });

    btn.className = 'border-2 border-blue-500 bg-blue-50/50 text-blue-600 font-bold rounded-xl py-3 text-sm text-center shadow-sm tap-action';

    if (type === 'expense') {
      if (label) label.textContent = '지출 금액';
    } else if (type === 'income') {
      if (label) label.textContent = '수입 금액';
    } else {
      if (label) label.textContent = '이체 금액';
    }
    updateExpenseState();
    showToast(`기록 유형: [${btn.textContent.trim()}] 선택`);
  }

  function updateExpenseState() {
    const amount = Math.max(0, currentExpenseAmount);
    const inputEl = document.getElementById('expenseAmountInput');
    if (inputEl && document.activeElement !== inputEl) inputEl.value = Number(amount).toLocaleString('ko-KR');

    const ctaText = document.getElementById('recordCtaText');
    if (ctaText) ctaText.textContent = `${Number(amount).toLocaleString('ko-KR')}원 지출 등록하기`;
  }

  function addExpenseAmount(val) {
    currentExpenseAmount += val;
    updateExpenseState();
    showToast(`+${(val >= 10000 ? val/10000 + '만' : val/1000 + '천')}원 추가되었습니다.`);
  }

  function resetExpenseAmount() {
    currentExpenseAmount = 0;
    updateExpenseState();
    showToast('지출 금액이 0원으로 초기화되었습니다.');
  }

  function handleExpenseInput(val) {
    const numeric = parseInt(val.replace(/[^0-9]/g, '')) || 0;
    currentExpenseAmount = numeric;
    updateExpenseState();
  }

  function clearMerchantInput() {
    const input = document.getElementById('merchantInput');
    if (input) {
      input.value = '';
      input.focus();
    }
  }

  function appendTag(tag) {
    const memo = document.getElementById('recordMemoInput');
    if (memo) {
      if (!memo.value.includes(tag)) {
        memo.value = memo.value ? `${memo.value} ${tag}` : tag;
        showToast(`태그 ${tag} 추가됨`);
      }
    }
  }

  // --- FULLSCREEN 3D CINEMATIC IMMERSION TRANSITION ---
  function submitConsideration() {
    const overlay = document.getElementById('fullscreen-absorption-transition');
    const pBar = document.getElementById('fullscreenProgressBar');
    if (!overlay) return;

    // Reset progress animation (3.8s)
    if (pBar) {
      pBar.classList.remove('animate-progress-fullscreen');
      void pBar.offsetWidth; // force reflow
      pBar.classList.add('animate-progress-fullscreen');
    }

    // Unhide overlay & smoothly fade in
    overlay.classList.remove('hidden');
    requestAnimationFrame(() => {
      overlay.classList.remove('opacity-0', 'pointer-events-none');
      overlay.classList.add('opacity-100');
    });

    // Initialize & start 3D scene smoothly
    initParallelWorld3DScene();
    if (!absorptionAnimId) {
      animateAbsorptionLoop();
    }
    handleThreeResize();

    // Auto-advance after 3.8s
    if (fullscreenTransitionTimer) clearTimeout(fullscreenTransitionTimer);
    fullscreenTransitionTimer = setTimeout(() => {
      finishCelebrationAndReturn();
    }, 3800);
  }

  function finishCelebrationAndReturn() {
    if (fullscreenTransitionTimer) {
      clearTimeout(fullscreenTransitionTimer);
      fullscreenTransitionTimer = null;
    }

    const overlay = document.getElementById('fullscreen-absorption-transition');
    if (!overlay) return;

    overlay.classList.add('opacity-0', 'pointer-events-none');
    overlay.classList.remove('opacity-100');

    setTimeout(() => {
      overlay.classList.add('hidden');
      returnToLedgerView('평행세계 통장에 적립 완료! 259,000원이 가상 투자 자산으로 무사히 흡수되었습니다.');
    }, 450);
  }

  // --- SCREEN SWITCHING: Form vs Ledger ---
  function returnToLedgerView(message) {
    const formScreen = document.getElementById('formScreen');
    const ledgerScreen = document.getElementById('ledgerScreen');

    if (formScreen && ledgerScreen) {
      formScreen.classList.add('hidden');
      ledgerScreen.classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'instant' });
      showToast(message || '가계부 화면으로 이동했습니다.', '🪐');
    }
  }

  function returnToFormView() {
    const formScreen = document.getElementById('formScreen');
    const ledgerScreen = document.getElementById('ledgerScreen');

    if (formScreen && ledgerScreen) {
      ledgerScreen.classList.add('hidden');
      formScreen.classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'instant' });
      showToast('구매 고민 작성 화면으로 이동했습니다.');
    }
  }

  function submitRecord() {
    showToast(`${Number(currentExpenseAmount).toLocaleString('ko-KR')}원 지출이 등록되었습니다!`, '✓');
    setTimeout(() => {
      returnToLedgerView('지출 내역이 가계부에 등록되었습니다!');
    }, 700);
  }

  // --- Tab Switching Logic ---
  function switchTab(mode) {
    const tabRecordBtn = document.getElementById('tabRecordBtn');
    const tabConsiderBtn = document.getElementById('tabConsiderBtn');
    const tabRecordDot = document.getElementById('tabRecordDot');
    const tabConsiderDot = document.getElementById('tabConsiderDot');
    const tabDescription = document.getElementById('tabDescription');
    const recordView = document.getElementById('recordView');
    const considerView = document.getElementById('considerView');
    const screenTitle = document.getElementById('screenTitle');

    if (mode === 'consider') {
      tabRecordBtn.className = "text-slate-500 hover:text-slate-700 font-medium py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all rounded-xl tap-action";
      tabRecordDot.classList.add('hidden');
      const recSvg = tabRecordBtn.querySelector('svg');
      if (recSvg) { recSvg.classList.remove('text-slate-800'); recSvg.classList.add('text-slate-500'); }

      tabConsiderBtn.className = "bg-white rounded-xl shadow-sm text-slate-900 font-bold py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all tap-action";
      tabConsiderDot.classList.remove('hidden');
      const conSvg = tabConsiderBtn.querySelector('svg');
      if (conSvg) { conSvg.classList.remove('text-slate-500'); conSvg.classList.add('text-slate-800'); }

      tabDescription.textContent = "구매 고민은 가계부 잔액에 바로 반영되지 않으며, 고민 후 결정할 수 있어요.";
      recordView.classList.add('hidden');
      considerView.classList.remove('hidden');
      screenTitle.textContent = "모아 구매 고민하기";
      updateConsiderationState();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      tabConsiderBtn.className = "text-slate-500 hover:text-slate-700 font-medium py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all rounded-xl tap-action";
      tabConsiderDot.classList.add('hidden');
      const conSvg = tabConsiderBtn.querySelector('svg');
      if (conSvg) { conSvg.classList.remove('text-slate-800'); conSvg.classList.add('text-slate-500'); }

      tabRecordBtn.className = "bg-white rounded-xl shadow-sm text-slate-900 font-bold py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all tap-action";
      tabRecordDot.classList.remove('hidden');
      const recSvg = tabRecordBtn.querySelector('svg');
      if (recSvg) { recSvg.classList.remove('text-slate-500'); recSvg.classList.add('text-slate-800'); }

      tabDescription.textContent = "실제 통장 잔액과 가계부에 즉시 반영되는 거래 내역을 기록해요.";
      considerView.classList.add('hidden');
      recordView.classList.remove('hidden');
      screenTitle.textContent = "내역 기록하기";
      updateExpenseState();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // Pre-initialize scene & calculation trigger on DOM load
  document.addEventListener('DOMContentLoaded', () => {
    updateConsiderationState();
    updateExpenseState();
    renderDateCardState();
    // Warm up the 3D scene in advance
    setTimeout(() => {
      initParallelWorld3DScene();
    }, 150);
  });


  // MOA: this screen is the "기록" page. Leaving it goes back to the real ledger / parallel world screens.
  returnToLedgerView = function (message) {
    const m = message || '';
    if (/돌아왔|취소/.test(m)) return app.go('back');
    app.go(/평행세계/.test(m) ? '/world' : '/ledger');
  };
  returnToFormView = function () {};
  // MOA: 공통 상태 연결 (src/lib/bridge.js recordBridge)
  const __toast = showToast; let __mute = false;
  showToast = function (m, i) { if (!__mute) __toast(m, i); };
  const __rec = app.moa.recordBridge({
    document, app,
    mute: (fn) => { __mute = true; try { fn(); } finally { __mute = false; } },
    get: { considerAmount: () => currentConsiderAmount, expenseAmount: () => currentExpenseAmount, dateUndecided: () => isConsiderDateUndecided, savedDate: () => lastSavedConsiderDate },
    set: { expenseAmount: (v) => { currentExpenseAmount = v; } },
    orig: { selectRecordType, selectRecordCategory, selectRecordPayment, selectConsiderCategory, selectConsiderPayment, selectNecessity, updateExpenseState, submitConsideration, switchTab, showToast: __toast,
      clearCelebrationTimer: () => { if (fullscreenTransitionTimer) { clearTimeout(fullscreenTransitionTimer); fullscreenTransitionTimer = null; } } },
  });
  selectRecordType = __rec.api.selectRecordType; selectRecordCategory = __rec.api.selectRecordCategory; selectRecordPayment = __rec.api.selectRecordPayment;
  selectConsiderCategory = __rec.api.selectConsiderCategory; selectConsiderPayment = __rec.api.selectConsiderPayment; selectNecessity = __rec.api.selectNecessity;
  updateExpenseState = __rec.api.updateExpenseState; submitRecord = __rec.api.submitRecord; submitConsideration = __rec.api.submitConsideration;
  finishCelebrationAndReturn = __rec.api.finishCelebrationAndReturn;
  document.addEventListener('DOMContentLoaded', () => {
    const tab = new URLSearchParams(app.search || '').get('tab');
    if (tab === 'record') { __mute = true; switchTab('record'); __mute = false; }
    __rec.init();
  });
  cleanup.add(() => {
    try { if (absorptionAnimId) globalThis.cancelAnimationFrame(absorptionAnimId); } catch (e) {}
    try { if (absorptionRenderer) { absorptionRenderer.dispose(); absorptionRenderer.forceContextLoss && absorptionRenderer.forceContextLoss(); } } catch (e) {}
  });

  const api = {};
  if (typeof initParallelWorld3DScene === 'function') api.initParallelWorld3DScene = initParallelWorld3DScene;
  if (typeof handleThreeResize === 'function') api.handleThreeResize = handleThreeResize;
  if (typeof animateAbsorptionLoop === 'function') api.animateAbsorptionLoop = animateAbsorptionLoop;
  if (typeof showToast === 'function') api.showToast = showToast;
  if (typeof formatWon === 'function') api.formatWon = formatWon;
  if (typeof formatShortManWon === 'function') api.formatShortManWon = formatShortManWon;
  if (typeof updateConsiderationState === 'function') api.updateConsiderationState = updateConsiderationState;
  if (typeof balanceToY === 'function') api.balanceToY = balanceToY;
  if (typeof addConsiderAmount === 'function') api.addConsiderAmount = addConsiderAmount;
  if (typeof resetConsiderAmount === 'function') api.resetConsiderAmount = resetConsiderAmount;
  if (typeof handleConsiderInput === 'function') api.handleConsiderInput = handleConsiderInput;
  if (typeof clearConsiderProduct === 'function') api.clearConsiderProduct = clearConsiderProduct;
  if (typeof selectConsiderCategory === 'function') api.selectConsiderCategory = selectConsiderCategory;
  if (typeof selectRecordCategory === 'function') api.selectRecordCategory = selectRecordCategory;
  if (typeof selectConsiderPayment === 'function') api.selectConsiderPayment = selectConsiderPayment;
  if (typeof selectInstallment === 'function') api.selectInstallment = selectInstallment;
  if (typeof selectRecordPayment === 'function') api.selectRecordPayment = selectRecordPayment;
  if (typeof selectNecessity === 'function') api.selectNecessity = selectNecessity;
  if (typeof openDateModal === 'function') api.openDateModal = openDateModal;
  if (typeof closeDateModal === 'function') api.closeDateModal = closeDateModal;
  if (typeof handleDateModalBackdrop === 'function') api.handleDateModalBackdrop = handleDateModalBackdrop;
  if (typeof confirmDateModal === 'function') api.confirmDateModal = confirmDateModal;
  if (typeof updateModalUndecidedStyle === 'function') api.updateModalUndecidedStyle = updateModalUndecidedStyle;
  if (typeof setConsiderDateUndecided === 'function') api.setConsiderDateUndecided = setConsiderDateUndecided;
  if (typeof selectSpecificDate === 'function') api.selectSpecificDate = selectSpecificDate;
  if (typeof toggleUndecidedDirect === 'function') api.toggleUndecidedDirect = toggleUndecidedDirect;
  if (typeof renderDateCardState === 'function') api.renderDateCardState = renderDateCardState;
  if (typeof changeRecordDate === 'function') api.changeRecordDate = changeRecordDate;
  if (typeof toggleTimeUnknown === 'function') api.toggleTimeUnknown = toggleTimeUnknown;
  if (typeof selectRecordType === 'function') api.selectRecordType = selectRecordType;
  if (typeof updateExpenseState === 'function') api.updateExpenseState = updateExpenseState;
  if (typeof addExpenseAmount === 'function') api.addExpenseAmount = addExpenseAmount;
  if (typeof resetExpenseAmount === 'function') api.resetExpenseAmount = resetExpenseAmount;
  if (typeof handleExpenseInput === 'function') api.handleExpenseInput = handleExpenseInput;
  if (typeof clearMerchantInput === 'function') api.clearMerchantInput = clearMerchantInput;
  if (typeof appendTag === 'function') api.appendTag = appendTag;
  if (typeof submitConsideration === 'function') api.submitConsideration = submitConsideration;
  if (typeof finishCelebrationAndReturn === 'function') api.finishCelebrationAndReturn = finishCelebrationAndReturn;
  if (typeof returnToLedgerView === 'function') api.returnToLedgerView = returnToLedgerView;
  if (typeof returnToFormView === 'function') api.returnToFormView = returnToFormView;
  if (typeof submitRecord === 'function') api.submitRecord = submitRecord;
  if (typeof switchTab === 'function') api.switchTab = switchTab;
  if (typeof resetBtnStyle === 'function') api.resetBtnStyle = resetBtnStyle;
  if (typeof setActiveBtnStyle === 'function') api.setActiveBtnStyle = setActiveBtnStyle;
  return { api, cleanup };
}
