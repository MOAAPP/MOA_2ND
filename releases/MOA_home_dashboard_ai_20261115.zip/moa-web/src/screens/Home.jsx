import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore } from '../lib/store';
import { beforePayday } from '../lib/finance';
import { lessonById, pickToday, GENERAL_LESSONS } from '../lib/learning';
import { aiTask, useRemote } from '../lib/api';
import { briefFacts, dday, learningStats, md, ruleBrief } from '../lib/insights';
import { collectBranches, worldSeries, worldSummary } from '../lib/worldRecords';
import './Home.css';

const num = (n) => Math.round(n).toLocaleString('ko-KR');
const man = (n) => (Math.abs(n) >= 10000 ? `${Math.round(n / 1000) / 10}만 원` : `${num(n)}원`);
const koreanDate = new Intl.DateTimeFormat('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' })
  .format(new Date(`${APP_TODAY}T00:00:00`));

function Ico({ d, size = 18, w = 1.9 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">{d}</svg>;
}
const SPARK = <path d="M12 3.5l1.6 4.4 4.4 1.6-4.4 1.6L12 15.5l-1.6-4.4L6 9.5l4.4-1.6L12 3.5ZM18.5 15l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7.7-1.8Z" />;
const CHEV = <path d="m9 18 6-6-6-6" />;
const FLAME = <path d="M12 21c4 0 6.5-2.6 6.5-6.3 0-3.3-2.3-5.6-3.6-7.7-.3 1.9-1.2 3-2.3 3.6.2-2.9-1.1-5.6-3.4-7.1.2 3.1-1.6 4.9-2.8 6.6C5.4 11.6 5.5 13 5.5 14.7 5.5 18.4 8 21 12 21Z" />;

function MiniLines({ series }) {
  const max = Math.max(...series.map((p) => Math.max(p.mine, p.other)), 1);
  const x = (i) => (i / (series.length - 1)) * 110;
  const y = (v) => 42 - (v / max) * 38;
  const path = (k) => series.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`).join(' ');
  return <svg viewBox="0 0 110 46" className="mh-minilines" aria-hidden="true">
    <path d={path('other')} fill="none" stroke="#C7CFDB" strokeWidth="2" strokeDasharray="3 3" strokeLinecap="round" />
    <path d={path('mine')} fill="none" stroke="#5B5BF0" strokeWidth="2.6" strokeLinecap="round" className="mh-draw" />
  </svg>;
}

function HomeScreen() {
  const navigate = useNavigate();
  const s = useStore((x) => x);
  const [why, setWhy] = useState(false);

  const bp = beforePayday(s);
  const usable = Math.max(0, bp.spendable);
  const next = bp.due[0];
  const facts = useMemo(() => briefFacts(s), [s.txs, s.finance, s.bills, s.wishes]); // eslint-disable-line
  const ai = useRemote(`brief:${APP_TODAY}:${facts.usable}:${facts.monthSpent}:${facts.nextBill?.date}`, () => aiTask('brief', facts));
  const brief = ai.data?.data || ruleBrief(facts);
  const live = !!ai.data;
  const actionTo = { choose: '/world', ledger: '/ledger', save: '/lab?tab=save', forks: '/world' };

  const ls = learningStats(s);
  const pick = pickToday(s, APP_TODAY);
  const lesson = lessonById(pick.id) || GENERAL_LESSONS[0];
  const read = s.learning.done.includes(lesson.id);
  const quizDone = (s.learning.quizDone || []).includes(lesson.id);
  const lessonTo = pick.kind === 'review' || !read ? `/learn/${lesson.id}` : !quizDone ? `/learn/${lesson.id}/quiz` : '/lab';

  const branches = collectBranches(s);
  const world = worldSummary(branches, 5);
  const series = worldSeries(branches, 5, new Set(), 12);

  return <div className="mh" data-testid="moa-home">
    <AppHeader profileTo="/more" transparent />
    <main className="mh-main">
      <header className="mh-title">
        <p>{koreanDate}</p>
        <h1>{s.profile.name || '모아'}님, 오늘의 모아예요</h1>
      </header>

      {/* 1. AI 브리핑 — 한 문장 + 한 가지 행동 */}
      <section className="mh-ai" aria-label="AI 브리핑">
        <div className="mh-ai-top">
          <span className="mh-ai-badge"><Ico d={SPARK} size={14} w={1.6} />{live ? 'AI 브리핑' : '오늘의 브리핑'}</span>
          <span className="mh-ai-src">{live ? ai.data.meta.model : ai.loading ? 'AI가 분석 중…' : '기본 분석'}</span>
        </div>
        <h2>{brief.headline}</h2>
        <p>{brief.body}</p>
        <div className="mh-ai-actions">
          {brief.action && <button type="button" className="mh-ai-cta" onClick={() => navigate(actionTo[brief.action.to] || '/')}>{brief.action.label}</button>}
          <button type="button" className="mh-ai-why" onClick={() => setWhy((v) => !v)} aria-expanded={why}>{why ? '닫기' : '근거 보기'}</button>
        </div>
        {why && <ul className="mh-ai-facts">
          <li><span>월급 전 쓸 수 있는 돈</span><b>{num(facts.usable)}원</b></li>
          {facts.nextBill && <li><span>다음 필수 결제 · {md(facts.nextBill.date)}</span><b>{num(facts.nextBill.amount)}원</b></li>}
          {facts.topCategory && <li><span>이번 달 가장 많이 쓴 곳</span><b>{facts.topCategory.name}</b></li>}
          <li className="mh-ai-note">{live ? '숫자는 모아 계산 엔진이, 문장은 AI가 만들어요.' : 'AI를 쓸 수 없을 때는 같은 숫자로 만든 기본 문장을 보여드려요.'}</li>
        </ul>}
      </section>

      {/* 2. 결제일 안전 — 숫자 하나 */}
      <button type="button" className="mh-card mh-money" onClick={() => navigate('/bills')}>
        <span className="mh-money-label">월급날까지 쓸 수 있는 돈</span>
        <strong className="mh-money-num">{num(usable)}<small>원</small></strong>
        {next
          ? <span className={`mh-pill ${bp.firstRisk ? 'bad' : 'ok'}`}>{bp.firstRisk ? `${md(bp.firstRisk.date)} 잔액이 모자라요` : `${dday(next.date)} ${next.label} 결제도 괜찮아요`}</span>
          : <span className="mh-pill ok">월급 전 남은 필수 결제가 없어요</span>}
        <span className="mh-chev-abs"><Ico d={CHEV} size={18} w={2.2} /></span>
      </button>

      {/* 3. 오늘의 학습 — 한 번 누르면 시작 */}
      <button type="button" className="mh-card mh-today" onClick={() => navigate(lessonTo)}>
        <span className="mh-today-icon">{lesson.emoji}</span>
        <span className="mh-today-text">
          <small><Ico d={SPARK} size={12} w={1.7} />{pick.kind === 'review' ? '틀린 문제 복습' : '나에게 맞춘 오늘의 학습'}</small>
          <strong>{lesson.title}</strong>
          <em>{pick.reason}</em>
        </span>
        <span className="mh-today-side">
          <span className="mh-streak-mini"><Ico d={FLAME} size={14} w={1.7} />{ls.streak}</span>
          <span className="mh-today-go">{quizDone ? '완료' : read ? '퀴즈' : '시작'}</span>
        </span>
      </button>

      {/* 4. 같은 돈, 다른 미래 */}
      <button type="button" className="mh-card mh-world" onClick={() => navigate('/world')}>
        <span className="mh-world-text">
          <small>평행세계</small>
          <strong>{world.count ? `내 기록이 5년 뒤 ${world.gap >= 0 ? '+' : ''}${man(world.gap)}를 만들어요` : '기록하면 평행세계가 생겨요'}</strong>
          <em>같은 돈을 썼을 때와 모았을 때를 비교해요</em>
        </span>
        <MiniLines series={series} />
      </button>

      {/* 5. AI에게 묻기 */}
      <button type="button" className="mh-ask" onClick={() => navigate('/agent')}>
        <Ico d={SPARK} size={16} w={1.7} />월세는 지키면서 돈을 모으려면? <b>AI에게 묻기</b>
      </button>
    </main>
  </div>;
}

export default memo(HomeScreen);
