import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import { APP_TODAY, useStore } from '../lib/store';
import { beforePayday, monthPeriod, totals, monthlyBudget } from '../lib/finance';
import { lessonById, pickToday, GENERAL_LESSONS } from '../lib/learning';
import { aiTask, discord, useRemote } from '../lib/api';
import { assets, briefFacts, dday, learningStats, md, ruleBrief, weekdayForecast } from '../lib/insights';
import { collectBranches, worldSeries, worldSummary } from '../lib/worldRecords';
import './Home.css';

const num = (n) => Math.round(n).toLocaleString('ko-KR');
const koreanDate = new Intl.DateTimeFormat('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' })
  .format(new Date(`${APP_TODAY}T00:00:00`));

const I = {
  chevron: <path d="m9 18 6-6-6-6" />,
  spark: <path d="M12 3.5l1.6 4.4 4.4 1.6-4.4 1.6L12 15.5l-1.6-4.4L6 9.5l4.4-1.6L12 3.5ZM18.5 15l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7.7-1.8Z" />,
  card: <><rect x="3" y="5.5" width="18" height="13" rx="2.5" /><path d="M3 10h18M7 15h3" /></>,
  cal: <><rect x="3.5" y="5" width="17" height="15" rx="2.5" /><path d="M8 3v4M16 3v4M3.5 10h17" /></>,
  bag: <><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 8V6.5a3 3 0 0 1 6 0V8" /></>,
  wave: <path d="M3 13h3l2-6 4 12 2.5-8 1.5 2h5" />,
  coin: <><circle cx="12" cy="12" r="8.5" /><path d="M9.5 9.5c.4-1 1.4-1.5 2.5-1.5 1.5 0 2.5.8 2.5 2 0 2.6-5 1.6-5 4.1 0 1.2 1 1.9 2.5 1.9 1.2 0 2.1-.5 2.5-1.5M12 6.5v1.5M12 16v1.5" /></>,
  flame: <path d="M12 21c4 0 6.5-2.6 6.5-6.3 0-3.3-2.3-5.6-3.6-7.7-.3 1.9-1.2 3-2.3 3.6.2-2.9-1.1-5.6-3.4-7.1.2 3.1-1.6 4.9-2.8 6.6C5.4 11.6 5.5 13 5.5 14.7 5.5 18.4 8 21 12 21Z" />,
  globe: <><circle cx="12" cy="12" r="8.5" /><path d="M3.5 12h17M12 3.5c2.3 2.4 3.4 5.2 3.4 8.5s-1.1 6.1-3.4 8.5c-2.3-2.4-3.4-5.2-3.4-8.5S9.7 5.9 12 3.5Z" /></>,
  route: <><circle cx="6" cy="18" r="2.2" /><circle cx="18" cy="6" r="2.2" /><path d="M8.2 18H15a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h6.8" /></>,
  discord: <path d="M8.5 7.5c-1.4.3-2.6.8-3.6 1.5-1.5 2.4-2 4.7-1.8 7 1.4 1 2.8 1.6 4.2 2l.9-1.5M15.5 7.5c1.4.3 2.6.8 3.6 1.5 1.5 2.4 2 4.7 1.8 7-1.4 1-2.8 1.6-4.2 2l-.9-1.5M7.7 16c2.8 1.3 5.8 1.3 8.6 0M8.3 7.3c2.4-.6 5-.6 7.4 0M9.5 13.2a1 1 0 1 0 0-.1M14.5 13.2a1 1 0 1 0 0-.1" />,
  check: <path d="M5 12.5 10 17.5 19 7" />,
  plus: <path d="M12 5v14M5 12h14" />,
};
function Ico({ d, size = 18, w = 1.9 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">{d}</svg>;
}

function Sparkbars({ values, color, highlight = -1 }) {
  const max = Math.max(...values, 1);
  return <div className="mh-bars" aria-hidden="true">
    {values.map((v, i) => <span key={i} style={{ height: `${Math.max(8, (v / max) * 100)}%`, background: i === highlight ? color : `${color}55` }} />)}
  </div>;
}

function MiniLines({ series }) {
  const max = Math.max(...series.map((p) => Math.max(p.mine, p.other)), 1);
  const x = (i) => (i / (series.length - 1)) * 120;
  const y = (v) => 44 - (v / max) * 40;
  const path = (k) => series.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`).join(' ');
  return <svg viewBox="0 0 120 48" className="mh-minilines" aria-hidden="true">
    <path d={path('other')} fill="none" stroke="#C7CFDB" strokeWidth="2" strokeDasharray="3 3" strokeLinecap="round" />
    <path d={path('mine')} fill="none" stroke="#5B5BF0" strokeWidth="2.6" strokeLinecap="round" className="mh-draw" />
  </svg>;
}

function HomeScreen() {
  const navigate = useNavigate();
  const s = useStore((x) => x);
  const [why, setWhy] = useState(false);
  const [showReason, setShowReason] = useState(false);

  // ── 숫자는 코드가 계산 ──
  const bp = beforePayday(s);
  const month = totals(monthPeriod(), s);
  const budget = monthlyBudget(s);
  const facts = useMemo(() => briefFacts(s), [s.txs, s.finance, s.bills, s.wishes]); // eslint-disable-line
  const fc = weekdayForecast(s, 7);
  const a = assets(s);
  const ls = learningStats(s);
  const branches = collectBranches(s);
  const world = worldSummary(branches, 5);
  const series = worldSeries(branches, 5, new Set(), 12);

  // ── AI: 같은 사실을 서버 AI가 문장으로 (실패하면 규칙 문장) ──
  const factsKey = `brief:${APP_TODAY}:${facts.usable}:${facts.monthSpent}:${facts.nextBill?.date}`;
  const ai = useRemote(factsKey, () => aiTask('brief', facts));
  const brief = ai.data?.data || ruleBrief(facts);
  const live = !!ai.data;
  const dc = useRemote('discord:status', () => discord.status());

  const pick = pickToday(s, APP_TODAY);
  const lesson = lessonById(pick.id) || GENERAL_LESSONS[0];
  const read = s.learning.done.includes(lesson.id);
  const quizDone = (s.learning.quizDone || []).includes(lesson.id);

  const next = bp.due[0];
  const spentPct = Math.min(100, Math.round((month.expense / Math.max(1, budget)) * 100));
  const usable = Math.max(0, bp.spendable);
  const bar = { bills: bp.essential, min: bp.minBalance, free: usable };
  const barTotal = Math.max(1, bar.bills + bar.min + bar.free);
  const recent = s.txs.filter((t) => t.date <= APP_TODAY).slice().sort((x, y) => (y.date + (y.time || '')).localeCompare(x.date + (x.time || ''))).slice(0, 3);
  const actionTo = { choose: '/record', ledger: '/ledger', save: '/savings', forks: '/world' };

  return <div className="mh" data-testid="moa-home">
    <AppHeader profileTo="/more" transparent />
    <main className="mh-main">
      <header className="mh-title">
        <p>{koreanDate}</p>
        <h1>{s.profile.name || '나'}님의 모아</h1>
      </header>

      {/* 1. AI 브리핑 */}
      <section className="mh-ai" aria-label="AI 브리핑">
        <div className="mh-ai-top">
          <span className="mh-ai-badge"><Ico d={I.spark} size={14} w={1.6} />{live ? 'AI 브리핑' : '오늘의 브리핑'}</span>
          <span className="mh-ai-src">{live ? `${ai.data.meta.model} · 방금 생성` : ai.loading ? 'AI가 분석 중…' : '기본 분석'}</span>
        </div>
        <h2>{brief.headline}</h2>
        <p>{brief.body}</p>
        <div className="mh-ai-actions">
          {brief.action && <button type="button" className="mh-ai-cta" onClick={() => navigate(actionTo[brief.action.to] || '/')}>{brief.action.label}</button>}
          <button type="button" className="mh-ai-why" onClick={() => setWhy((v) => !v)} aria-expanded={why}>{why ? '근거 닫기' : '왜 이렇게 판단했나요?'}</button>
        </div>
        {why && <ul className="mh-ai-facts">
          <li><span>월급 전 쓸 수 있는 돈</span><b>{num(facts.usable)}원</b></li>
          <li><span>이번 달 지출</span><b>{num(facts.monthSpent)}원</b></li>
          {facts.nextBill && <li><span>다음 필수 결제 ({md(facts.nextBill.date)})</span><b>{num(facts.nextBill.amount)}원</b></li>}
          {facts.topCategory && <li><span>가장 많이 쓴 곳</span><b>{facts.topCategory.name}</b></li>}
          <li className="mh-ai-note">{live ? '숫자는 모아 계산 엔진이 만들고, AI는 이 숫자로 문장만 써요.' : 'AI를 쓸 수 없을 때는 같은 숫자로 만든 기본 문장을 보여드려요.'}</li>
        </ul>}
      </section>

      {/* 2. 내 통장 (토스·카카오뱅크형) */}
      <section className="mh-card mh-account" aria-label="생활비 통장">
        <button type="button" className="mh-account-head" onClick={() => navigate('/bills')}>
          <span className="mh-bank"><Ico d={I.card} size={17} /></span>
          <span className="mh-account-name">{s.profile.bank || '생활비 통장'}</span>
          <span className="mh-chev"><Ico d={I.chevron} size={16} w={2.2} /></span>
        </button>
        <strong className="mh-balance">{num(bp.balance)}<small>원</small></strong>
        <p className="mh-usable">월급 전까지 <b>{num(usable)}원</b> 쓸 수 있어요</p>
        <div className="mh-stack" aria-hidden="true">
          <span style={{ width: `${(bar.bills / barTotal) * 100}%`, background: '#FF8A8A' }} />
          <span style={{ width: `${(bar.min / barTotal) * 100}%`, background: '#C9D3E1' }} />
          <span style={{ width: `${(bar.free / barTotal) * 100}%`, background: '#3B82F6' }} />
        </div>
        <div className="mh-legend">
          <span><i style={{ background: '#FF8A8A' }} />필수 결제 {num(bar.bills)}</span>
          <span><i style={{ background: '#C9D3E1' }} />비상금 {num(bar.min)}</span>
          <span><i style={{ background: '#3B82F6' }} />여유</span>
        </div>
        <div className="mh-account-btns">
          <button type="button" onClick={() => navigate('/record')}>기록하기</button>
          <button type="button" onClick={() => navigate('/ledger')}>가계부</button>
        </div>
      </section>

      {/* 3. 건강 앱형 요약 타일 */}
      <div className="mh-section-head"><h3>요약</h3></div>
      <div className="mh-grid">
        <button type="button" className="mh-tile" onClick={() => navigate('/bills')}>
          <span className="mh-tile-label" style={{ color: '#F04452' }}><Ico d={I.cal} size={15} />다가오는 결제</span>
          {next ? <>
            <strong className="mh-tile-num">{dday(next.date)}</strong>
            <span className="mh-tile-sub">{next.label} {num(-next.amount)}원</span>
            <span className={`mh-chip ${bp.firstRisk ? 'is-bad' : 'is-ok'}`}>{bp.firstRisk ? `${md(bp.firstRisk.date)} 잔액 부족 위험` : '결제 가능'}</span>
          </> : <><strong className="mh-tile-num">없음</strong><span className="mh-tile-sub">월급 전 예정된 결제가 없어요</span></>}
        </button>
        <button type="button" className="mh-tile" onClick={() => navigate('/ledger')}>
          <span className="mh-tile-label" style={{ color: '#FF8A00' }}><Ico d={I.bag} size={15} />이번 달 지출</span>
          <strong className="mh-tile-num">{num(month.expense)}<small>원</small></strong>
          <span className="mh-tile-sub">예산의 {spentPct}% 사용</span>
          <span className="mh-progress"><i style={{ width: `${spentPct}%`, background: spentPct > 90 ? '#F04452' : '#FF8A00' }} /></span>
        </button>
        <button type="button" className="mh-tile" onClick={() => navigate('/ledger/report')}>
          <span className="mh-tile-label" style={{ color: '#7C3AED' }}><Ico d={I.wave} size={15} />7일 지출 예측</span>
          <strong className="mh-tile-num">{fc.total ? <>{num(fc.total)}<small>원</small></> : '준비 중'}</strong>
          <span className="mh-tile-sub">{fc.total ? '요일별 지출 패턴으로 예측' : '지출을 기록하면 예측해요'}</span>
          <Sparkbars values={fc.daily.map((d) => d.amount)} color="#7C3AED" highlight={fc.daily.reduce((m, d, i, arr) => (d.amount > arr[m].amount ? i : m), 0)} />
        </button>
        <button type="button" className="mh-tile" onClick={() => navigate('/lab')}>
          <span className="mh-tile-label" style={{ color: '#0E9F8E' }}><Ico d={I.coin} size={15} />가상 자산</span>
          <strong className="mh-tile-num">{num(a.invested + a.savings)}<small>원</small></strong>
          <span className="mh-tile-sub">투자 {a.pl >= 0 ? '+' : ''}{num(a.pl)}원 · 예적금 {num(a.savings)}원</span>
          <span className="mh-chip is-neutral">실제 통장과 분리</span>
        </button>
      </div>

      {/* 4. 오늘의 학습 (듀오링고형) */}
      <section className="mh-card mh-learn" aria-label="오늘의 학습">
        <div className="mh-learn-top">
          <span className="mh-streak"><Ico d={I.flame} size={18} w={1.7} /><b>{ls.streak}</b>일 연속</span>
          <span className="mh-xp">{ls.xp} XP</span>
        </div>
        <div className="mh-week">
          {ls.week.map((d) => <span key={d.iso} className={`${d.on ? 'is-on' : ''} ${d.iso === APP_TODAY ? 'is-today' : ''}`}><i>{d.on ? <Ico d={I.check} size={11} w={3} /> : null}</i>{d.label}</span>)}
        </div>
        <button type="button" className="mh-lesson" onClick={() => navigate(pick.kind === 'review' ? `/learn/${lesson.id}` : read && !quizDone ? `/learn/${lesson.id}/quiz` : `/learn/${lesson.id}`)}>
          <span className="mh-lesson-icon">{lesson.emoji}</span>
          <span className="mh-lesson-text">
            <small>{pick.kind === 'review' ? '복습할 학습' : '오늘의 맞춤 학습'} · {lesson.minutes}분</small>
            <strong>{lesson.title}</strong>
          </span>
          <span className="mh-lesson-go">{pick.kind === 'review' ? '복습' : quizDone ? '다시' : read ? '퀴즈' : '시작'}</span>
        </button>
        <button type="button" className="mh-reason" onClick={() => setShowReason((v) => !v)} aria-expanded={showReason}>
          <Ico d={I.spark} size={13} w={1.6} />왜 이 학습을 추천했나요?
        </button>
        {showReason && <p className="mh-reason-text">{pick.reason}. 퀴즈에서 틀린 문제, 가상 거래, 관심 분야 순서로 다음 학습을 골라요.</p>}
        <div className="mh-learn-foot">
          <button type="button" onClick={() => navigate('/learn')}>학습 경로 보기</button>
          {ls.reviews.length > 0 && <button type="button" className="is-warn" onClick={() => navigate(`/learn/${ls.reviews[0].lessonId}/quiz?review=${ls.reviews[0].questionId}`)}>복습 {ls.reviews.length}문제</button>}
        </div>
      </section>

      {/* 5. 평행세계 요약 */}
      <button type="button" className="mh-card mh-world" onClick={() => navigate('/world')}>
        <div className="mh-world-text">
          <span className="mh-tile-label" style={{ color: '#5B5BF0' }}><Ico d={I.globe} size={15} />평행세계</span>
          <strong>{world.count ? `내 기록 ${world.count}개가 만든 차이` : '기록하면 평행세계가 생겨요'}</strong>
          <span className="mh-world-num">{world.count ? <>{world.gap >= 0 ? '+' : ''}{num(world.gap)}원 <small>· 5년 뒤</small></> : <small>저축·소비·투자 기록이 갈림길이 돼요</small>}</span>
        </div>
        <MiniLines series={series} />
      </button>

      {/* 6. AI 에이전트 */}
      <section className="mh-card mh-agent" aria-label="AI 경로 탐색">
        <div className="mh-agent-head">
          <span className="mh-agent-icon"><Ico d={I.route} size={18} /></span>
          <div><strong>AI에게 목표 경로 묻기</strong><small>필수 결제를 지키는 경로만 골라줘요</small></div>
        </div>
        <div className="mh-prompts">
          {['월세 지키면서 3개월 안에 60만 원 모으기', 'ETF도 조금 경험하고 싶어', '이번 달 사고 싶은 걸 언제 살까?'].map((g) => (
            <button key={g} type="button" onClick={() => navigate(`/agent?goal=${encodeURIComponent(g)}`)}>{g}</button>
          ))}
        </div>
      </section>

      {/* 7. 최근 기록 (뱅크샐러드형) */}
      <section className="mh-card mh-recent" aria-label="최근 기록">
        <div className="mh-recent-head"><strong>최근 기록</strong><button type="button" onClick={() => navigate('/ledger')}>전체</button></div>
        {recent.length === 0 && <button type="button" className="mh-empty" onClick={() => navigate('/record')}>아직 기록이 없어요. 오늘 쓴 돈부터 기록해 보세요 ›</button>}
        <ul>
          {recent.map((t) => <li key={t.id}>
            <span className={`mh-dot-cat ${t.type}`}>{t.category.slice(0, 1)}</span>
            <span className="mh-recent-text"><b>{t.title}</b><small>{md(t.date)} · {t.category}</small></span>
            <span className={`mh-amt ${t.type}`}>{t.type === 'income' ? '+' : '-'}{num(t.amount)}원</span>
          </li>)}
        </ul>
      </section>

      {/* 8. Discord */}
      <button type="button" className="mh-card mh-discord" onClick={() => navigate('/settings#discord')}>
        <span className="mh-discord-icon"><Ico d={I.discord} size={20} w={1.6} /></span>
        <span className="mh-discord-text">
          <strong>매일 {s.learnAlert.time} 카드뉴스를 Discord로</strong>
          <small>{dc.data?.configured ? (s.learnAlert.discord ? '연결됨 · 학습 카드와 매수 카드가 전송돼요' : '채널 준비됨 · 눌러서 받기 켜기') : dc.loading ? '연결 확인 중…' : '알림 설정에서 연결할 수 있어요'}</small>
        </span>
        <span className={`mh-discord-state ${dc.data?.configured && s.learnAlert.discord ? 'on' : ''}`}>{dc.data?.configured && s.learnAlert.discord ? 'ON' : '설정'}</span>
      </button>
    </main>
  </div>;
}

export default memo(HomeScreen);
