/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s02 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './More.controller';
import './More.css';


import { ProfileName, WishBadge, ProfileInitial, MoreSavedSpending, MoreSavingsAmount, MoreSavingsCount, MoreSavingsLevel, MoreInvestAmount, MoreInvestRate, MoreSimulationSetting, MoreSafetyAlert } from '../components/MoaWidgets';
import AppHeader from '../components/AppHeader';

function MoreScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {});
  return (
    <div ref={rootRef} className="stitch-screen scr-more bg-[#F8FAFC] text-moa-title font-sans flex justify-center min-h-full antialiased">
{/* Mobile Viewport Container (iOS 390px width layout standard) */}
<div className="w-full max-w-[390px] min-h-full bg-[#F8FAFC] flex flex-col relative overflow-hidden pb-[90px]">
{/* BEGIN: TopHeader */}
{/* Fixed Top Navigation Header with Logo and Action Icons */}
<AppHeader profileTo="/settings" />
{/* END: TopHeader */}
{/* BEGIN: MainScrollContent */}
<main className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
{/* SECTION 1: Profile Summary Card */}
{/* BEGIN: UserProfileCard */}
<section className="bg-white rounded-2xl p-5 shadow-card border border-gray-100" data-purpose="user-profile-summary">
<div className="flex items-center justify-between">
<div className="flex items-center space-x-3.5">
{/* User Avatar with Planet Ring Badge */}
<div className="relative">
<div className="w-13 h-13 w-12 h-12 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
<ProfileInitial />
</div>
<span className="absolute -bottom-1 -right-1 text-xs bg-white rounded-full p-0.5 shadow-sm">
🪐
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<h2 className="text-lg font-bold text-moa-title leading-snug">
<ProfileName />
</h2>
<span className="px-2 py-0.5 text-[11px] font-semibold bg-brand-light text-brand rounded-full">
모아 회원
</span>
</div>
<p className="text-xs font-medium text-brand mt-0.5 flex items-center">
<MoreSavingsLevel />
</p>
</div>
</div>
{/* Profile Edit Icon / Action */}
<button aria-label="프로필 정보 보기" className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-moa-caption hover:text-moa-title touch-press" type="button" data-nav="/settings">
<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</button>
</div>
{/* Cumulative Asset Defense Box */}
<div className="mt-4 pt-3.5 border-t border-moa-border flex items-center justify-between">
<div>
<span className="text-xs text-moa-caption block">
이번 달 누적 방어한 소비
</span>
{" "}
<span className="text-base font-bold text-moa-title">
<MoreSavedSpending />
</span>
</div>
<span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md flex items-center gap-1">
<svg className="w-3 h-3 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M5 10l7-7m0 0l7 7m-7-7v18" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
</svg>
{" "}구매 포기 기록 기준
</span>
</div>
{/* Sub link: Account connection */}
<a className="mt-3 block text-center py-2 px-3 bg-gray-50 hover:bg-gray-100 rounded-xl text-xs font-semibold text-moa-body transition-colors touch-press" href="#accounts" data-nav="/settings">
내 프로필 및 연결 계좌 관리 〉
</a>
</section>
<section className="space-y-3" data-purpose="virtual-wealth-hero">
<div className="flex items-center justify-between px-1">
<div className="flex items-center space-x-1.5">
<span className="text-sm">
✨
</span>
<h3 className="text-xs font-bold text-moa-title tracking-wider uppercase">
가상 자산 운용 현황
</h3>
</div>
<span className="text-[11px] font-semibold text-brand">
가상 자산으로 학습 중
</span>
</div>
<div className="grid grid-cols-2 gap-2.5">
<div className="bg-gradient-to-tr from-emerald-50/80 to-white rounded-2xl p-4 shadow-card border border-emerald-50 flex flex-col justify-between relative overflow-hidden touch-press">
<div className="flex items-start justify-between">
<div>
<span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
모의 상품별 가정 금리
</span>
<h4 className="text-sm font-bold text-moa-title mt-2">
가상 예·적금
</h4>
</div>
<div className="w-8 h-8 rounded-xl bg-white/90 shadow-sm flex items-center justify-center text-base">
🏦
</div>
</div>
<div className="mt-3 pt-2 border-t border-emerald-50/60">
<p className="text-base font-bold text-moa-title tracking-tight">
<MoreSavingsAmount />
</p>
<div className="flex items-center justify-between mt-1">
<span className="text-[10px] text-moa-caption font-medium">
<MoreSavingsCount />
</span>
<button className="text-[10px] font-semibold text-emerald-600 bg-white px-1.5 py-0.5 rounded border border-emerald-50 hover:bg-emerald-50 transition-colors" type="button" data-nav="/savings">
상세 〉
</button>
</div>
</div>
</div>
<div className="bg-gradient-to-tr from-blue-50/80 to-white rounded-2xl p-4 shadow-card border border-blue-50 flex flex-col justify-between relative overflow-hidden touch-press">
<div className="flex items-start justify-between">
<div>
<span className="text-[10px] font-bold text-brand bg-brand-light px-2 py-0.5 rounded-full">
<MoreInvestRate />
</span>
<h4 className="text-sm font-bold text-moa-title mt-2">
투자 포트폴리오
</h4>
</div>
<div className="w-8 h-8 rounded-xl bg-white/90 shadow-sm flex items-center justify-center text-base">
📈
</div>
</div>
<div className="mt-3 pt-2 border-t border-blue-50/60">
<p className="text-base font-bold text-moa-title tracking-tight">
<MoreInvestAmount />
</p>
<div className="flex items-center justify-between mt-1">
<span className="text-[10px] text-moa-caption font-medium">
가상 시세 기준 평가금
</span>
<button className="text-[10px] font-semibold text-brand bg-white px-1.5 py-0.5 rounded border border-blue-50 hover:bg-blue-50 transition-colors" type="button" data-nav="/invest">
운용 〉
</button>
</div>
</div>
</div>
</div>
</section>
{/* END: UserProfileCard */}
{/* SECTION 2: 4-Grid Core Feature Actions */}
{/* BEGIN: CoreActionGrid */}
<section data-purpose="core-actions-grid">
<div className="grid grid-cols-2 gap-2.5">
{/* Item 1: Parallel Universe Asset Vault */}
<div className="bg-white rounded-2xl p-4 shadow-card border border-gray-100 flex flex-col justify-between touch-press" role="button" data-nav="/world/explore?view=E">
<div className="flex items-center justify-between">
<div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-lg">
🪐
</div>
<span className="text-[10px] font-bold text-brand bg-brand-light px-1.5 py-0.5 rounded">
핵심
</span>
</div>
<div className="mt-3">
<h3 className="text-sm font-bold text-moa-title leading-tight">
평행세계 보관함
</h3>
<p className="text-[11px] text-moa-caption mt-0.5 leading-tight">
저장한 미래 비교
</p>
</div>
</div>
{/* Item 2: Monthly Expenditure Report */}
<div className="bg-white rounded-2xl p-4 shadow-card border border-gray-100 flex flex-col justify-between touch-press" role="button" data-nav="/ledger/report">
<div className="flex items-center justify-between">
<div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-lg">
📊
</div>
<span className="text-[10px] font-medium text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
PDF
</span>
</div>
<div className="mt-3">
<h3 className="text-sm font-bold text-moa-title leading-tight">
지출 분석 리포트
</h3>
<p className="text-[11px] text-moa-caption mt-0.5 leading-tight">
이번 달 소비 카테고리
</p>
</div>
</div>
{/* Item 3: Purchase Wishlist (Pending) */}
<div className="bg-white rounded-2xl p-4 shadow-card border border-gray-100 flex flex-col justify-between touch-press" role="button" data-nav="/wishlist">
<div className="flex items-center justify-between">
<div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-lg">
💡
</div>
<span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
<WishBadge />
</span>
</div>
<div className="mt-3">
<h3 className="text-sm font-bold text-moa-title leading-tight">
고민 위시리스트
</h3>
<p className="text-[11px] text-moa-caption mt-0.5 leading-tight">
구매·보류·포기 결정
</p>
</div>
</div>
{/* Item 4: Zero-Spend Challenge Status */}
<div className="bg-white rounded-2xl p-4 shadow-card border border-gray-100 flex flex-col justify-between touch-press" role="button" data-nav="/ledger">
<div className="flex items-center justify-between">
<div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-lg">
🎯
</div>
<span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">
연속 5일
</span>
</div>
<div className="mt-3">
<h3 className="text-sm font-bold text-moa-title leading-tight">
무지출 챌린지
</h3>
<p className="text-[11px] text-moa-caption mt-0.5 leading-tight">
오늘도 성공 달성 중
</p>
</div>
</div>
</div>
</section>
{/* END: CoreActionGrid */}
{/* SECTION 3: Account & Budget Management Group */}
{/* BEGIN: LedgerManagementGroup */}
<section className="bg-white rounded-2xl shadow-card border border-gray-100 overflow-hidden" data-purpose="ledger-budget-management">
<div className="px-5 pt-4 pb-2 border-b border-gray-50">
<h3 className="text-xs font-bold text-moa-caption tracking-wider uppercase">
가계부 및 자산 연동
</h3>
</div>
<div className="divide-y divide-gray-50">
{/* Row 1: Linked Accounts */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#link-accounts" data-nav="/settings">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
💳
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
연결된 계좌 / 결제수단
</p>
<p className="text-xs text-moa-caption">
생활비 통장 1개, 체크카드 1건 연동됨
</p>
</div>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
{/* Row 2: Budget Setting */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#budget-setting" data-nav="/budget">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
💰
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
카테고리 / 예산 관리
</p>
<p className="text-xs text-moa-caption">
이번 달 예산 500,000원 설정
</p>
</div>
</div>
<span className="text-xs font-semibold text-brand bg-blue-50 px-2 py-0.5 rounded">
설정됨
</span>
</a>
{/* Row 3: Subscription & Fixed Costs */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#fixed-spending" data-nav="/bills">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
🔄
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
정기 결제 및 고정 지출
</p>
<p className="text-xs text-moa-caption">
넷플릭스 등 3건 (월 42,000원 예정)
</p>
</div>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
{/* Row 4: Excel Export & Backup */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#export" data-nav="/settings">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
📑
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
가계부 데이터 내보내기 & 백업
</p>
<p className="text-xs text-moa-caption">
설정 화면에서 CSV 파일로 내보내기
</p>
</div>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
</div>
</section>
{/* END: LedgerManagementGroup */}
{/* SECTION 4: Parallel Universe & Planet Customization */}
{/* BEGIN: ParallelUniverseSettings */}
<section className="bg-white rounded-2xl shadow-card border border-blue-50 overflow-hidden relative" data-purpose="parallel-universe-settings">
{/* Subtle gradient background highlight for signature feature */}
<div className="absolute -right-10 -top-10 w-32 h-32 bg-blue-100/40 rounded-full blur-2xl pointer-events-none" />
<div className="px-5 pt-4 pb-2 border-b border-gray-50 flex items-center justify-between">
<div className="flex items-center space-x-1.5">
<span className="text-sm">
🪐
</span>
<h3 className="text-xs font-bold text-moa-title tracking-wider uppercase">
모아 평행세계 가상 설정
</h3>
</div>
<span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
시그니처 모드
</span>
</div>
<div className="divide-y divide-gray-50">
<div className="flex items-center justify-between px-5 py-3.5">
<div>
<p className="text-sm font-semibold text-moa-title">
가상 복리 기준 수익률
</p>
<p className="text-xs text-moa-caption">
투자 미래 비교를 위한 가정값 (수익 보장 아님)
</p>
</div>
<MoreSimulationSetting kind="invest" />
</div>
<div className="flex items-center justify-between px-5 py-3.5">
<div>
<p className="text-sm font-semibold text-moa-title">
가상 예적금 복리 이율 설정
</p>
<p className="text-xs text-moa-caption">
실제 상품 금리가 아닌 학습용 가정값
</p>
</div>
<MoreSimulationSetting kind="save" />
</div>
<div className="flex items-center justify-between px-5 py-3.5">
<div>
<p className="text-sm font-semibold text-moa-title">
모의 투자 위험 성향 설정
</p>
<p className="text-xs text-moa-caption">
가상 경로를 설명할 때 사용하는 나의 선호
</p>
</div>
<MoreSimulationSetting kind="risk" />
</div>
<div className="flex items-center justify-between px-5 py-3.5">
<div>
<p className="text-sm font-semibold text-moa-title">
디지털 트윈 방어 알림
</p>
<p className="text-xs text-moa-caption">
지출 참았을 때 평행 자산 적립 푸시
</p>
</div>
<MoreSafetyAlert />
</div>
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#planet-skin" data-nav="/savings">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-sm">
🌌
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
내 행성 테마 & 아바타 스킨
</p>
<p className="text-xs text-moa-caption">
예적금 납입에 따라 행성이 성장해요
</p>
</div>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
</div>
</section>
{/* END: ParallelUniverseSettings */}
{/* SECTION 5: App Settings & Customer Support */}
{/* BEGIN: CustomerSupportAndSettings */}
<section className="bg-white rounded-2xl shadow-card border border-gray-100 overflow-hidden mb-4" data-purpose="app-settings-support">
<div className="px-5 pt-4 pb-2 border-b border-gray-50">
<h3 className="text-xs font-bold text-moa-caption tracking-wider uppercase">
고객지원 & 앱 설정
</h3>
</div>
<div className="divide-y divide-gray-50">
{/* 1:1 Support */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#support" data-nav="/support">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
💬
</div>
<span className="text-sm font-semibold text-moa-title">
1:1 고객센터 / 문의하기
</span>
</div>
<span className="text-[11px] text-brand font-medium">
도움말 확인
</span>
</a>
{/* FAQ */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#faq" data-nav="/support">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
❓
</div>
<span className="text-sm font-semibold text-moa-title">
자주 묻는 질문 (FAQ)
</span>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
{/* Notices */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#notices" data-nav="/notifications">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
📢
</div>
<span className="text-sm font-semibold text-moa-title">
공지사항 & 업데이트 소식
</span>
</div>
<span className="w-2 h-2 rounded-full bg-red-500" />
</a>
{/* Push Notifications Toggle */}
<div className="flex items-center justify-between px-5 py-3.5">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
🔔
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
푸시 및 야간 알림 제한
</p>
<p className="text-xs text-moa-caption">
22:00 ~ 08:00 무음 모드 적용
</p>
</div>
</div>
<MoreSafetyAlert />
</div>
{/* Screen Lock & Biometrics */}
<a className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors touch-press" href="#security">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
🔒
</div>
<div>
<p className="text-sm font-semibold text-moa-title">
앱 잠금 및 Face ID 인증
</p>
<p className="text-xs text-moa-caption">
보안 암호 사용 중
</p>
</div>
</div>
<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</a>
{/* Version Info */}
<div className="flex items-center justify-between px-5 py-3.5 bg-gray-50/50">
<div className="flex items-center space-x-3">
<div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm">
ℹ️
</div>
<span className="text-sm font-medium text-moa-body">
앱 버전 정보
</span>
</div>
<span className="text-xs font-semibold text-moa-caption">
v2.4.0 (최신 버전)
</span>
</div>
</div>
</section>
{/* END: CustomerSupportAndSettings */}
{/* Logout & Account Deletion Links */}
<div className="flex items-center justify-center space-x-4 py-3 text-xs text-moa-caption">
<button className="hover:underline" type="button" data-nav="/onboarding">
로그아웃
</button>
{" "}
<span>
|
</span>
{" "}
<button className="hover:underline" type="button" data-nav="/support">
이용약관
</button>
{" "}
<span>
|
</span>
{" "}
<button className="hover:underline" type="button" data-nav="/support">
개인정보처리방침
</button>
</div>
</main>
{/* END: MainScrollContent */}
{/* BEGIN: BottomNavigation */}
{/* Fixed Global Bottom Navigation Bar with 5 Tabs */}
{/* END: BottomNavigation */}
</div>
{/* BEGIN: InteractiveToastScript */}
{/* END: InteractiveToastScript */}
    </div>
  );
}

export default memo(MoreScreen);
