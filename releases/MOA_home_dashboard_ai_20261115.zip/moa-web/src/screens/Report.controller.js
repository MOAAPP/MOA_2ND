/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s11. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  let toastTimer = null;

  function showToast(message) {
    const toast = document.getElementById('share-toast');
    const toastText = document.getElementById('share-toast-text');
    if (!toast) return;

    if (toastText && message) {
      toastText.innerText = message;
    }

    if (toastTimer) clearTimeout(toastTimer);

    toast.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-[-12px]');
    toast.classList.add('opacity-100', 'translate-y-0');

    toastTimer = setTimeout(() => {
      toast.classList.remove('opacity-100', 'translate-y-0');
      toast.classList.add('opacity-0', 'pointer-events-none', 'translate-y-[-12px]');
    }, 2500);
  }

  function openShareSheet() {
    const backdrop = document.getElementById('share-modal-backdrop');
    const sheet = document.getElementById('share-bottom-sheet');
    if (!backdrop || !sheet) return;

    backdrop.classList.remove('opacity-0', 'pointer-events-none');
    backdrop.classList.add('opacity-100');
    sheet.classList.remove('translate-y-full');
    sheet.classList.add('translate-y-0');
    document.body.style.overflow = 'hidden';
  }

  function closeShareSheet() {
    const backdrop = document.getElementById('share-modal-backdrop');
    const sheet = document.getElementById('share-bottom-sheet');
    if (!backdrop || !sheet) return;

    backdrop.classList.remove('opacity-100');
    backdrop.classList.add('opacity-0', 'pointer-events-none');
    sheet.classList.remove('translate-y-0');
    sheet.classList.add('translate-y-full');
    document.body.style.overflow = '';
  }

  function handleBackdropClick(e) {
    if (e.target === document.getElementById('share-modal-backdrop')) {
      closeShareSheet();
    }
  }

  function copyShareLink() {
    const shareUrl = window.location.href;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(shareUrl).then(() => {
        showToast('리포트 링크가 클립보드에 복사되었어요!');
      }).catch(() => {
        showToast('리포트 링크가 복사되었어요!');
      });
    } else {
      showToast('리포트 링크가 클립보드에 복사되었어요!');
    }
  }

  function shareViaKakao() {
    showToast('카카오톡 공유창으로 연결 중이에요');
    setTimeout(() => {
      closeShareSheet();
    }, 800);
  }

  function saveAsImageAction() {
    showToast('리포트 이미지가 갤러리에 저장되었어요!');
    setTimeout(() => {
      closeShareSheet();
    }, 1200);
  }

  function shareMoreOptions() {
    if (navigator.share) {
      navigator.share({
        title: '11월 지출 분석 리포트',
        text: '11월 총 지출 270,447원 · 지난달 대비 50,000원 절약 리포트 확인하기',
        url: window.location.href,
      }).then(() => {
        closeShareSheet();
      }).catch(() => {
        showToast('공유 옵션이 실행되었습니다.');
      });
    } else {
      showToast('추가 공유 옵션을 지원하지 않는 브라우저입니다.');
    }
  }

  // Escape key support
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeShareSheet();
    }
  });


/* ---- */


  let currentTab = 'monthly';

  const tabConfig = {
    daily: {
      subtitle: "어제보다 오늘 14,200원 덜 썼어요",
      legendCurrent: "오늘 지출",
      legendPrev: "일일 평균",
      highlightText: "오늘 (18일)",
      axisLeft: "월(12일)",
      axisMid: "목(15일)",
      axisRight: "오늘 일(18일)",
      statLeftLabel: "오늘 지출",
      statLeftVal: "16,500원",
      statRightLabel: "일일 평균 지출",
      statRightVal: "24,000원"
    },
    weekly: {
      subtitle: "지난주 동기간 대비 35,000원 덜 썼어요",
      legendCurrent: "이번달 주간 지출",
      legendPrev: "지난달 동주차 평균",
      highlightText: "3주차 (현재)",
      axisLeft: "1주차",
      axisMid: "2주차",
      axisRight: "4주차 (예정)",
      statLeftLabel: "이번 주 지출",
      statLeftVal: "106,547원",
      statRightLabel: "주간 평균 지출",
      statRightVal: "135,000원"
    },
    monthly: {
      subtitle: "지난달보다 소비 속도가 15% 완만해요",
      legendCurrent: "최근 6개월 지출 추이",
      legendPrev: "월별 예산선",
      highlightText: "9월",
      axisLeft: "6월",
      axisMid: "8월",
      axisRight: "11월 (현재)",
      statLeftLabel: "9월 지출",
      statLeftVal: "295,000원",
      statRightLabel: "월평균 지출",
      statRightVal: "337,000원"
    }
  };

  const activeBtnClass = "px-2.5 py-1 rounded-lg transition-all duration-200 active:scale-95 bg-slate-900 text-white shadow-sm font-semibold";
  const inactiveBtnClass = "px-2.5 py-1 rounded-lg transition-all duration-200 active:scale-95 text-slate-500 hover:text-slate-900 bg-transparent font-medium";

  function switchPaceTab(tabKey) {
    if (currentTab === tabKey) return;
    currentTab = tabKey;

    // 1. 탭 버튼 스타일 갱신
    ['monthly', 'weekly', 'daily'].forEach(key => {
      const btn = document.getElementById(`tab-${key}`);
      const view = document.getElementById(`view-${key}`);
      if (key === tabKey) {
        btn.className = activeBtnClass;
        view.classList.remove('panel-hidden');
        view.classList.add('panel-visible');
      } else {
        btn.className = inactiveBtnClass;
        view.classList.remove('panel-visible');
        view.classList.add('panel-hidden');
      }
    });

    // 2. 텍스트 및 라벨 갱신
    const conf = tabConfig[tabKey];
    const subtitleEl = document.getElementById('pace-subtitle');
    subtitleEl.style.opacity = '0';
    setTimeout(() => {
      subtitleEl.innerText = conf.subtitle;
      subtitleEl.style.opacity = '1';
    }, 150);

    document.getElementById('legend-current-label').innerText = conf.legendCurrent;
    document.getElementById('legend-prev-label').innerText = conf.legendPrev;
    document.getElementById('legend-highlight-text').innerText = conf.highlightText;

    document.getElementById('axis-left').innerText = conf.axisLeft;
    document.getElementById('axis-mid').innerText = conf.axisMid;
    document.getElementById('axis-right').innerText = conf.axisRight;

    document.getElementById('stat-left-label').innerText = conf.statLeftLabel;
    document.getElementById('stat-left-val').innerText = conf.statLeftVal;
    document.getElementById('stat-right-label').innerText = conf.statRightLabel;
    document.getElementById('stat-right-val').innerText = conf.statRightVal;
  }

  // 월별 차트 포인트 클릭 인터랙션
  function selectMonthlyPoint(x, y, monthText, amount) {
    const tooltip = document.getElementById('monthly-tooltip');
    const ping = document.getElementById('monthly-ping');
    const halo = document.getElementById('monthly-halo');

    tooltip.style.left = `${x}px`;
    tooltip.style.top = `${y - 32}px`;
    tooltip.innerText = amount;

    ping.setAttribute('cx', x);
    ping.setAttribute('cy', y);
    halo.setAttribute('cx', x);
    halo.setAttribute('cy', y);

    document.getElementById('legend-highlight-text').innerText = monthText;
    document.getElementById('stat-left-label').innerText = `${monthText} 지출`;
    document.getElementById('stat-left-val').innerText = amount;
  }

  // 주별 차트 포인트 클릭 인터랙션
  function selectWeeklyPoint(x, y, weekText, amount) {
    const tooltip = document.getElementById('weekly-tooltip');
    const ping = document.getElementById('weekly-ping');
    const halo = document.getElementById('weekly-halo');

    tooltip.style.left = `${x}px`;
    tooltip.style.top = `${y - 32}px`;
    tooltip.innerText = amount;

    ping.setAttribute('cx', x);
    ping.setAttribute('cy', y);
    halo.setAttribute('cx', x);
    halo.setAttribute('cy', y);

    document.getElementById('legend-highlight-text').innerText = weekText;
    document.getElementById('stat-left-label').innerText = `${weekText} 지출`;
    document.getElementById('stat-left-val').innerText = amount;
  }

  // 일별 차트 포인트 클릭 인터랙션
  function selectDailyPoint(x, y, dayText, amount) {
    const tooltip = document.getElementById('daily-tooltip');
    const ping = document.getElementById('daily-ping');
    const halo = document.getElementById('daily-halo');

    tooltip.style.left = `${x}px`;
    tooltip.style.top = `${y - 34}px`;
    tooltip.innerText = amount;

    ping.setAttribute('cx', x);
    ping.setAttribute('cy', y);
    halo.setAttribute('cx', x);
    halo.setAttribute('cy', y);

    document.getElementById('legend-highlight-text').innerText = dayText;
    document.getElementById('stat-left-label').innerText = `${dayText} 지출`;
    document.getElementById('stat-left-val').innerText = amount;
  }


/* ---- */


const categoryMeta = {
  traffic: {
    title: '교통',
    badge: '선택 카테고리',
    percent: '43%',
    color: 'text-[#00B493]',
    amount: '117,437원'
  },
  finance: {
    title: '금융',
    badge: '선택 카테고리',
    percent: '37%',
    color: 'text-toss-blue',
    amount: '100,200원'
  },
  food: {
    title: '식비',
    badge: '선택 카테고리',
    percent: '7%',
    color: 'text-indigo-600',
    amount: '19,300원'
  },
  beauty: {
    title: '뷰티/미용',
    badge: '선택 카테고리',
    percent: '5%',
    color: 'text-[#A855F7]',
    amount: '13,600원'
  },
  life: {
    title: '생활',
    badge: '선택 카테고리',
    percent: '3%',
    color: 'text-[#F43F5E]',
    amount: '9,160원'
  }
};

const allCatKeys = ['traffic', 'finance', 'food', 'beauty', 'life'];
const openedCatKeys = new Set();
let focusedCatKey = null;

function updateDonutCenter(catKey) {
  const badgeEl = document.getElementById('donut-badge-title');
  const titleEl = document.getElementById('donut-category-title');
  const percentEl = document.getElementById('donut-category-percent');

  if (catKey && categoryMeta[catKey]) {
    const meta = categoryMeta[catKey];
    badgeEl.innerText = meta.badge;
    titleEl.innerText = meta.title;
    percentEl.innerText = `${meta.percent} (${meta.amount})`;
    percentEl.className = `text-[12px] font-bold ${meta.color} leading-tight mt-1 tabular-nums whitespace-nowrap`;
  } else {
    // 기본 상태 (최대 지출: 교통)
    badgeEl.innerText = '최대 지출';
    titleEl.innerText = '교통';
    percentEl.innerText = '43% (117,437원)';
    percentEl.className = 'text-[12px] font-bold text-emerald-600 leading-tight mt-1 tabular-nums whitespace-nowrap';
  }
}

// 각 카테고리 독립 토글 (Multi-Accordion)
function handleCategoryClick(catKey) {
  const detailEl = document.getElementById(`detail-${catKey}`);
  const chevronEl = document.getElementById(`chevron-${catKey}`);
  const wrapperEl = document.getElementById(`cat-wrapper-${catKey}`);

  const isCurrentlyOpen = openedCatKeys.has(catKey);

  if (isCurrentlyOpen) {
    // 닫기
    openedCatKeys.delete(catKey);
    if (detailEl) detailEl.classList.add('hidden');
    if (chevronEl) chevronEl.style.transform = 'rotate(0deg)';
    if (wrapperEl) wrapperEl.classList.remove('bg-toss-gray50/70', 'p-1.5');
    
    // 도넛 차트 포커스 조정
    if (focusedCatKey === catKey) {
      if (openedCatKeys.size > 0) {
        const lastOpened = Array.from(openedCatKeys).pop();
        focusedCatKey = lastOpened;
        updateDonutCenter(lastOpened);
      } else {
        focusedCatKey = null;
        updateDonutCenter(null);
      }
    }
  } else {
    // 열기
    openedCatKeys.add(catKey);
    if (detailEl) detailEl.classList.remove('hidden');
    if (chevronEl) chevronEl.style.transform = 'rotate(180deg)';
    if (wrapperEl) wrapperEl.classList.add('bg-toss-gray50/70', 'p-1.5');

    focusedCatKey = catKey;
    updateDonutCenter(catKey);
  }

  syncAllToggleBtnState();
}

function syncAllToggleBtnState() {
  const btnText = document.getElementById('toggle-all-text');
  const icon = document.getElementById('toggle-all-icon');
  if (openedCatKeys.size === allCatKeys.length) {
    btnText.innerText = '지출 상세내역 닫기';
    icon.innerText = 'expand_less';
  } else {
    btnText.innerText = '지출 상세내역 전체보기';
    icon.innerText = 'expand_more';
  }
}

// 전체보기 / 전체닫기 토글
function toggleAllCategoryDetails() {
  const shouldOpenAll = openedCatKeys.size < allCatKeys.length;

  allCatKeys.forEach(k => {
    const detailEl = document.getElementById(`detail-${k}`);
    const chevronEl = document.getElementById(`chevron-${k}`);
    const wrapperEl = document.getElementById(`cat-wrapper-${k}`);

    if (shouldOpenAll) {
      openedCatKeys.add(k);
      if (detailEl) detailEl.classList.remove('hidden');
      if (chevronEl) chevronEl.style.transform = 'rotate(180deg)';
      if (wrapperEl) wrapperEl.classList.add('bg-toss-gray50/70', 'p-1.5');
    } else {
      openedCatKeys.delete(k);
      if (detailEl) detailEl.classList.add('hidden');
      if (chevronEl) chevronEl.style.transform = 'rotate(0deg)';
      if (wrapperEl) wrapperEl.classList.remove('bg-toss-gray50/70', 'p-1.5');
    }
  });

  if (shouldOpenAll) {
    focusedCatKey = 'traffic';
    updateDonutCenter('traffic');
  } else {
    focusedCatKey = null;
    updateDonutCenter(null);
  }

  syncAllToggleBtnState();
}


  showToast = (m) => app.toast(m || '완료했어요');
  // MOA: 가계부 직접 기록을 합계·카테고리에 반영 (src/lib/bridge.js reportBridge)
  const __rep = app.moa.reportBridge({ document, meta: categoryMeta, tabs: tabConfig, orig: { updateDonutCenter } });
  updateDonutCenter = __rep.api.updateDonutCenter;
  document.addEventListener('DOMContentLoaded', () => __rep.init());

  const api = {};
  if (typeof showToast === 'function') api.showToast = showToast;
  if (typeof openShareSheet === 'function') api.openShareSheet = openShareSheet;
  if (typeof closeShareSheet === 'function') api.closeShareSheet = closeShareSheet;
  if (typeof handleBackdropClick === 'function') api.handleBackdropClick = handleBackdropClick;
  if (typeof copyShareLink === 'function') api.copyShareLink = copyShareLink;
  if (typeof shareViaKakao === 'function') api.shareViaKakao = shareViaKakao;
  if (typeof saveAsImageAction === 'function') api.saveAsImageAction = saveAsImageAction;
  if (typeof shareMoreOptions === 'function') api.shareMoreOptions = shareMoreOptions;
  if (typeof switchPaceTab === 'function') api.switchPaceTab = switchPaceTab;
  if (typeof selectMonthlyPoint === 'function') api.selectMonthlyPoint = selectMonthlyPoint;
  if (typeof selectWeeklyPoint === 'function') api.selectWeeklyPoint = selectWeeklyPoint;
  if (typeof selectDailyPoint === 'function') api.selectDailyPoint = selectDailyPoint;
  if (typeof updateDonutCenter === 'function') api.updateDonutCenter = updateDonutCenter;
  if (typeof handleCategoryClick === 'function') api.handleCategoryClick = handleCategoryClick;
  if (typeof syncAllToggleBtnState === 'function') api.syncAllToggleBtnState = syncAllToggleBtnState;
  if (typeof toggleAllCategoryDetails === 'function') api.toggleAllCategoryDetails = toggleAllCategoryDetails;
  return { api, cleanup };
}
