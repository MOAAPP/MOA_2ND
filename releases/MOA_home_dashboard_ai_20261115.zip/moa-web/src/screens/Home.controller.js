/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s03. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);



  // MOA: 잔액·여유·브리핑·결제 일정을 공통 금융 상태로 표시 (src/lib/bridge.js homeBridge)
  const __home = app.moa.homeBridge({ document });
  document.addEventListener('DOMContentLoaded', () => __home.init());

  const api = {};

  return { api, cleanup };
}
