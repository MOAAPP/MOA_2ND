/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s07. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  // Core State
  let currentAmount = 259000;
  let selectedWorldId = 5; // Default: World 5 (Investment)
  let compareTargetWorldId = 5;
  let selectedYears = 1;

  const worldMeta = {
    1: { tag: "WORLD 01 · 지금 구매", name: "지금 구매", desc: "즉시 소비로 효용 달성, 통장 유동성 차감", rate: 0 },
    2: { tag: "WORLD 02 · 구매 안 함", name: "구매하지 않기", desc: "현금 100% 보존 및 기회비용 전액 방어", rate: 0 },
    3: { tag: "WORLD 03 · 구매 연기", name: "구매 연기 (3개월)", desc: "3개월 쿨다운으로 충동 68% 흡수", rate: 0.072 * 0.68 },
    4: { tag: "WORLD 04 · 저축하기", name: "저축하기", desc: "고금리 파킹/예적금 연 3.8% 안전 복리", rate: 0.038 },
    5: { tag: "WORLD 05 · 글로벌 투자", name: "투자하기", desc: "글로벌 지수 ETF 연 7.2% 복리 운용 가정 (손실위험 안내 필독)", rate: 0.072 },
    6: { tag: "WORLD 06 · 혼합 배분", name: "혼합 자산 배분", desc: "소비 1/3, 저축 1/3, 투자 1/3 분할 균형", rate: 0.046 }
  };

  function fmt(val) {
    return Number(Math.round(val)).toLocaleString('ko-KR');
  }

  // Calculate Asset Projections
  function calculateWorldAssets(amt, years) {
    const y = years || 1;
    const w1 = 0;
    const w2 = amt;
    const w3 = (amt * 0.68) * Math.pow(1 + 0.072, y);
    const w4 = amt * Math.pow(1 + 0.038, y);
    const w5 = amt * Math.pow(1 + 0.072, y);
    const third = amt / 3;
    const w6 = 0 + (third * Math.pow(1 + 0.038, y)) + (third * Math.pow(1 + 0.072, y));

    return { 1: w1, 2: w2, 3: w3, 4: w4, 5: w5, 6: w6 };
  }

  // View Navigation Switcher
  function switchView(viewCode) {
    ['A', 'B', 'C', 'D', 'E'].forEach(code => {
      const sec = document.getElementById(`view-${code}`);
      const btn = document.getElementById(`tab-btn-${code}`);
      if (code === viewCode) {
        sec.classList.remove('hidden');
        btn.className = 'nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition-all bg-[#3182F6] text-white shadow-sm';
      } else {
        sec.classList.add('hidden');
        btn.className = 'nav-tab shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6B7684] hover:text-[#191F28] hover:bg-slate-100 transition-all';
      }
    });

    const mainEl = document.querySelector('main');
    if (mainEl) mainEl.scrollTop = 0;
  }

  // Time Horizon Controller [1년] [3년] [5년] [10년]
  function setTimeHorizonYears(years) {
    selectedYears = years;
    const yearList = [1, 3, 5, 10];
    const btns = document.querySelectorAll('.time-tab');
    btns.forEach((b, i) => {
      if (yearList[i] === years) {
        b.className = 'time-tab py-1.5 rounded-xl text-[11px] font-bold bg-white text-[#3182F6] shadow-sm transition-all';
      } else {
        b.className = 'time-tab py-1.5 rounded-xl text-[11px] font-semibold text-[#6B7684] hover:text-[#191F28] transition-all';
      }
    });

    document.getElementById('time-horizon-label').innerText = `${years}년 뒤 기준 시뮬레이션`;
    document.getElementById('label-horizon-a').innerText = `${years}년 뒤 자산`;
    document.getElementById('label-horizon-b').innerText = `${years}년 뒤 자산`;
    document.getElementById('diff-ribbon-label').innerText = `${years}년 후 예상 자산 격차`;

    refreshCalculations();
  }

  // Refresh All Dynamic Figures
  function refreshCalculations() {
    const assets = calculateWorldAssets(currentAmount, selectedYears);
    const oneYearAssets = calculateWorldAssets(currentAmount, 1);
    const sixMonthAssets = calculateWorldAssets(currentAmount, 0.5);
    const targetFutureVal = assets[5];
    const interest = targetFutureVal - currentAmount;
    const ratePercent = ((targetFutureVal / (currentAmount || 1)) * 100).toFixed(1);

    // View A Sync
    document.querySelectorAll('.sync-amount-text').forEach(el => el.innerText = `-${fmt(currentAmount)}원`);
    document.querySelectorAll('.sync-base-amt').forEach(el => el.innerText = `${fmt(currentAmount)}원`);
    document.querySelectorAll('.sync-saved-future').forEach(el => el.innerText = `+${fmt(targetFutureVal)}원`);
    document.querySelectorAll('.sync-saved-6m').forEach(el => el.innerText = `${fmt(sixMonthAssets[5])}원`);
    document.querySelectorAll('.sync-diff-val').forEach(el => el.innerText = `+${fmt(targetFutureVal)}원`);
    document.querySelectorAll('.sync-interest-gain').forEach(el => el.innerText = `+${fmt(interest)}원`);
    const rateLabel = document.getElementById('diff-rate-label');
    if (rateLabel) rateLabel.innerText = `+${ratePercent}% 가치 보존`;

    // View B Sync
    document.getElementById('wcard-amt-1').innerText = `-${fmt(currentAmount)}원`;
    document.getElementById('wcard-amt-2').innerText = `+${fmt(oneYearAssets[2])}원`;
    document.getElementById('wcard-amt-3').innerText = `+${fmt(oneYearAssets[3])}원`;
    document.getElementById('wcard-amt-4').innerText = `+${fmt(oneYearAssets[4])}원`;
    document.getElementById('wcard-amt-5').innerText = `+${fmt(oneYearAssets[5])}원`;
    document.getElementById('wcard-amt-6').innerText = `+${fmt(oneYearAssets[6])}원`;

    updateViewBHero();
    updateComparisonView();
  }

  function updateViewBHero() {
    const oneYear = calculateWorldAssets(currentAmount, 1);
    const val = oneYear[selectedWorldId];
    const meta = worldMeta[selectedWorldId];

    const bBadge = document.getElementById('view-b-badge');
    if (bBadge) bBadge.innerText = `WORLD 0${selectedWorldId} 선택됨`;
    document.getElementById('b-hero-world-tag').innerText = meta.tag;
    document.getElementById('b-hero-world-val').innerText = selectedWorldId === 1 ? `-${fmt(currentAmount)}원` : `+${fmt(val)}원`;
    document.getElementById('b-hero-world-desc').innerText = meta.desc;
    document.getElementById('b-hero-world-diff').innerText = selectedWorldId === 1 ? `0원` : `+${fmt(val)}원`;

    const selectB = document.getElementById('select-comp-b');
    if (selectB) selectB.value = selectedWorldId;

    const dBadge = document.getElementById('d-world-badge');
    if (dBadge) dBadge.innerText = `${meta.tag} 기준`;
  }

  function chooseWorld(id) {
    selectedWorldId = id;
    compareTargetWorldId = id;
    const cards = document.querySelectorAll('.world-option-card');
    cards.forEach((card, idx) => {
      const cardWorldId = idx + 1;
      if (cardWorldId === id) {
        card.className = 'world-option-card p-3 rounded-2xl border-2 border-[#3182F6] bg-[#E8F3FF]/60 cursor-pointer transition-all active:scale-97 shadow-sm';
      } else {
        card.className = 'world-option-card p-3 rounded-2xl border border-slate-200 bg-white cursor-pointer transition-all active:scale-97 hover:border-slate-300';
      }
    });

    updateViewBHero();
    updateComparisonView();
  }

  function onCompareTargetChange(val) {
    compareTargetWorldId = parseInt(val, 10);
    selectedWorldId = compareTargetWorldId;
    updateComparisonView();
  }

  function updateComparisonView() {
    const assets = calculateWorldAssets(currentAmount, 1);
    const targetVal = assets[compareTargetWorldId] || 0;
    const meta = worldMeta[compareTargetWorldId];

    const thB = document.getElementById('th-b-name');
    if (thB) thB.innerText = `미래 B (${meta.name})`;
    const tdBAsset = document.getElementById('td-b-asset');
    if (tdBAsset) tdBAsset.innerText = `+${fmt(targetVal)}원`;

    document.getElementById('metric-asset-diff').innerText = `+${fmt(targetVal)}원`;
    document.getElementById('metric-b-total').innerText = `B세계: ${fmt(targetVal)}원`;

    // Cash Liquidity description
    const cashEl = document.getElementById('metric-cash');
    const tdBCash = document.getElementById('td-b-cash');
    if (compareTargetWorldId === 1) {
      if (cashEl) cashEl.innerText = '0원 (즉시 전액 지출)';
      if (tdBCash) tdBCash.innerText = '0원 (전액 지출)';
    } else if (compareTargetWorldId === 2 || compareTargetWorldId === 4) {
      if (cashEl) cashEl.innerText = `${fmt(currentAmount)}원 즉시 인출 가능`;
      if (tdBCash) tdBCash.innerText = `${fmt(currentAmount)}원 보존`;
    } else if (compareTargetWorldId === 3) {
      const rem = Math.round(currentAmount * 0.68);
      if (cashEl) cashEl.innerText = `${fmt(rem)}원 (연기 후 보존)`;
      if (tdBCash) tdBCash.innerText = `${fmt(rem)}원 보존`;
    } else if (compareTargetWorldId === 5) {
      if (cashEl) cashEl.innerText = `${fmt(targetVal)}원 (환매 D+2)`;
      if (tdBCash) tdBCash.innerText = `${fmt(targetVal)}원 평가`;
    } else {
      const third = Math.round(currentAmount / 3);
      if (cashEl) cashEl.innerText = `${fmt(third)}원 저축 유동성`;
      if (tdBCash) tdBCash.innerText = `${fmt(third * 2)}원 보존·투자`;
    }
  }

  // Base Amount Change Handlers
  function onAmountInput(val) {
    const num = parseInt(val, 10);
    if (!isNaN(num) && num > 0) {
      currentAmount = num;
      refreshCalculations();
    }
  }

  function setBaseAmount(amt) {
    currentAmount = amt;
    const input = document.getElementById('input-amount');
    if (input) input.value = amt;
    refreshCalculations();
  }

  // View E History Re-experiment
  function reloadSavedExperiment(title, amt) {
    document.getElementById('item-title-input').value = title;
    setBaseAmount(amt);
    switchView('A');
  }

  // View D AI On-Demand Coaching
  function triggerAiCoaching() {
    const btn = document.getElementById('ai-trigger-btn');
    const box = document.getElementById('ai-insight-box');
    btn.innerHTML = `
      <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      <span>지출 패턴 및 카드 결제일 교차 분석 중 (1.5초)...</span>
    `;
    btn.disabled = true;

    setTimeout(() => {
      btn.innerHTML = `
        <span class="material-symbols-outlined text-base text-emerald-400">task_alt</span>
        <span>AI 정밀 코칭 완료</span>
      `;
      btn.className = 'mt-3.5 w-full py-3 bg-slate-800 text-white font-extrabold rounded-2xl text-xs flex items-center justify-center space-x-1.5 border border-slate-700';
      box.classList.remove('hidden');

      document.getElementById('ai-insight-text').innerHTML = `
        현재 방어 금액 <strong class="text-white">${fmt(currentAmount)}원</strong>을 <strong class="text-blue-300">${worldMeta[selectedWorldId].name}</strong> 경로로 운용할 경우, 등록된 결제 일정만을 기준으로 분석했으며 1년 뒤 <strong class="text-amber-300">+${fmt(calculateWorldAssets(currentAmount, 1)[selectedWorldId])}원</strong>의 가상 결과를 계산합니다. 실제 금융 결과는 다를 수 있습니다.
      `;
    }, 1500);
  }

  function savePlanToBudget() {
    alert(`[${worldMeta[selectedWorldId].name}] 기준 ${fmt(currentAmount)}원 방어 계획이 이번 달 MOA 가계부 예산에 안전하게 저장되었습니다.`);
  }

  function handleRecordAdd() {
    const val = prompt('새로운 소비 고민 또는 방어할 금액을 입력해 주세요:', '259000');
    if (val && !isNaN(val)) {
      setBaseAmount(parseInt(val, 10));
      switchView('A');
      alert(`${fmt(val)}원이 새로운 평행세계 실험 자산으로 등록되었습니다.`);
    }
  }

  function handleGlobalTab(name) {
    alert(`[${name}] 메뉴로 이동합니다.`);
  }

  // Initial Boot
  window.addEventListener('DOMContentLoaded', () => {
    refreshCalculations();
  });


  // MOA: 기간·조건 반영 계산, 보관함 저장 (src/lib/bridge.js worldBridge)
  const __world = app.moa.worldBridge({
    document, app, root, meta: worldMeta,
    get: { amount: () => currentAmount, years: () => selectedYears, selected: () => selectedWorldId, compare: () => compareTargetWorldId },
    set: { amount: (v) => { currentAmount = v; } },
    orig: { reloadSavedExperiment, switchView, chooseWorld, onCompareTargetChange, setTimeHorizonYears },
  });
  calculateWorldAssets = __world.api.calculateWorldAssets; refreshCalculations = __world.api.refreshCalculations;
  updateViewBHero = __world.api.updateViewBHero; updateComparisonView = __world.api.updateComparisonView;
  triggerAiCoaching = __world.api.triggerAiCoaching; savePlanToBudget = __world.api.savePlanToBudget; handleRecordAdd = __world.api.handleRecordAdd;
  const __chooseWorld = chooseWorld;
  chooseWorld = function (id) { __chooseWorld(id); refreshCalculations(); };
  const __onCompare = onCompareTargetChange;
  onCompareTargetChange = function (v) { __onCompare(v); refreshCalculations(); };
  window.addEventListener('DOMContentLoaded', () => __world.init());

  const api = {};
  if (typeof fmt === 'function') api.fmt = fmt;
  if (typeof calculateWorldAssets === 'function') api.calculateWorldAssets = calculateWorldAssets;
  if (typeof switchView === 'function') api.switchView = switchView;
  if (typeof setTimeHorizonYears === 'function') api.setTimeHorizonYears = setTimeHorizonYears;
  if (typeof refreshCalculations === 'function') api.refreshCalculations = refreshCalculations;
  if (typeof updateViewBHero === 'function') api.updateViewBHero = updateViewBHero;
  if (typeof chooseWorld === 'function') api.chooseWorld = chooseWorld;
  if (typeof onCompareTargetChange === 'function') api.onCompareTargetChange = onCompareTargetChange;
  if (typeof updateComparisonView === 'function') api.updateComparisonView = updateComparisonView;
  if (typeof onAmountInput === 'function') api.onAmountInput = onAmountInput;
  if (typeof setBaseAmount === 'function') api.setBaseAmount = setBaseAmount;
  if (typeof reloadSavedExperiment === 'function') api.reloadSavedExperiment = reloadSavedExperiment;
  if (typeof triggerAiCoaching === 'function') api.triggerAiCoaching = triggerAiCoaching;
  if (typeof savePlanToBudget === 'function') api.savePlanToBudget = savePlanToBudget;
  if (typeof handleRecordAdd === 'function') api.handleRecordAdd = handleRecordAdd;
  if (typeof handleGlobalTab === 'function') api.handleGlobalTab = handleGlobalTab;
  return { api, cleanup };
}
