/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s06 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useStore, APP_TODAY } from '../lib/store';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Invest.controller';
import './Invest.css';





function InvestScreen() {
  const holdingCount = useStore((st) => Object.values(st.invest.holdings || {}).filter((q) => q > 0).length);
  const realized = useStore((st) => Math.round(st.invest.orders
    .filter((o) => o.side === 'sell' && o.status === 'filled' && (o.filledAt || o.at).slice(0, 10) === APP_TODAY)
    .reduce((a, o) => a + (o.price - (st.invest.avgPrice[o.name] || o.price)) * o.shares, 0)));
  const { rootRef, run } = useLegacyScreen(mount, {"SCREEN_10":-1});
  return (
    <div ref={rootRef} className="stitch-screen scr-invest flex justify-center items-start min-h-full antialiased text-[#191F28]" style={{ overflowX: "hidden" }}>
{/* 스마트폰 규격 뷰포트 (390px 최대 폭 최적화) */}
<div className="w-full max-w-[390px] min-h-full bg-[#F2F4F6] flex flex-col relative overflow-x-hidden">
{/* BEGIN: Top Navigation Header & Live Market Status */}
<header className="fixed top-0 max-w-[390px] w-full bg-[#F2F4F6]/95 backdrop-blur-md border-b border-black/[0.04] z-40">
{/* 상단 앱 바 */}
<div className="flex items-center justify-between px-4 py-2.5">
<button aria-label="이전 화면" className="w-9 h-9 -ml-1 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_10'); })} type="button">
<span className="material-symbols-outlined text-[24px]">
arrow_back_ios_new
</span>
</button>
<div className="flex items-center space-x-1.5">
<span className="text-[17px] font-bold text-toss-gray900">
모아 가상 거래소
</span>
{" "}
<span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-blue-100/80 text-blue-700">
모의투자
</span>
</div>
<div className="flex items-center space-x-1">
<button aria-label="종목 검색" className="w-9 h-9 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all" onClick={(event) => run(event, (c) => { c.openStockSearch(); })} type="button">
<span className="material-symbols-outlined text-[22px]">
search
</span>
</button>
{" "}
<button aria-label="체결 알림" className="w-9 h-9 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all relative" onClick={(event) => run(event, (c) => { c.showToast('최근 체결 내역 3건이 있습니다'); })} type="button">
<span className="material-symbols-outlined text-[22px]">
notifications
</span>
{" "}
<span className="w-2 h-2 rounded-full bg-rose-500 absolute top-2 right-2 ring-2 ring-white" />
</button>
</div>
</div>
{/* 1. 상단 마켓 실시간 상태 바 */}
<div className="px-4 pb-2.5 flex items-center justify-between text-xs">
<div className="inline-flex items-center space-x-1.5 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200/60">
<span className="w-2 h-2 rounded-full bg-emerald-500 animate-live-pulse" />
{" "}
<span className="text-emerald-700 font-bold text-[11px]">
가상 정규장 거래 중 (09:00~15:30)
</span>
</div>
<div className="flex items-center space-x-1 text-[11px] text-slate-500 font-medium">
<span className="material-symbols-outlined text-[14px] text-blue-500">
schedule
</span>
{" "}
<span>
가상 시세
</span>
</div>
</div>
</header>
{/* END: Top Navigation Header */}
{/* BEGIN: Main Scroll Content */}
<main className="flex-1 px-4 pt-[98px] pb-24 space-y-3.5">
{/* 2. 내 투자 자산 & 주문 가능 금액 (방어 머니 연동 Hero Card) */}
<section className="bg-white rounded-3xl p-5 shadow-card relative overflow-hidden">
<div className="flex items-center justify-between mb-2">
<div className="flex items-center space-x-1.5">
<span className="text-xs font-semibold text-slate-400">
내 모아 투자 지갑
</span>
{" "}
<span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200/60">
소비 방어 연동
</span>
</div>
<button className="text-xs text-blue-600 font-semibold hover:underline flex items-center" type="button" data-nav="/invest/portfolio">
방어머니 내역{" "}
<span className="material-symbols-outlined text-sm">
chevron_right
</span>
</button>
</div>
{/* 총 평가 자산 & 손익 */}
<div className="space-y-1">
<div className="flex items-baseline space-x-1">
<h2 className="text-3xl font-extrabold text-slate-900 tracking-tight tabular-nums" id="user-total-asset">
138,000
</h2>
<span className="text-lg font-bold text-slate-700">
원
</span>
</div>
<div className="flex items-center space-x-2 pt-0.5">
<div className="flex items-center text-rose-500 text-xs font-bold tabular-nums">
<span className="material-symbols-outlined text-sm">
arrow_drop_up
</span>
{" "}
<span id="user-profit-sum">
+9,260원
</span>
{" "}
<span className="ml-1 px-1.5 py-0.5 bg-rose-50 text-rose-600 rounded-md font-extrabold" id="user-profit-rate">
+7.2%
</span>
</div>
<span className="text-[11px] text-slate-400">
· 원금 128,740원
</span>
</div>
</div>
{/* 하단: 주문 가능 방어 머니 & 당일 실현 손익 요약 그리드 */}
<div className="grid grid-cols-2 gap-2 mt-4 pt-3.5 border-t border-slate-100">
<div className="bg-slate-50/90 rounded-2xl p-3 border border-slate-100">
<span className="text-[11px] font-medium text-slate-500 block mb-0.5">
주문 가능 방어 머니
</span>
<div className="flex items-baseline space-x-0.5">
<span className="text-[15px] font-black text-blue-600 tabular-nums" id="available-defense-money">
518,000
</span>
{" "}
<span className="text-xs font-bold text-slate-700">
원
</span>
</div>
<span className="text-[10px] text-slate-400 block mt-0.5">
즉시 매수 주문 가능
</span>
</div>
<div className="bg-slate-50/90 rounded-2xl p-3 border border-slate-100">
<span className="text-[11px] font-medium text-slate-500 block mb-0.5">
당일 실현 손익
</span>
<div className="flex items-baseline space-x-0.5">
<span className={`text-[15px] font-black tabular-nums ${realized > 0 ? 'text-rose-500' : realized < 0 ? 'text-blue-500' : 'text-slate-700'}`}>
{realized > 0 ? '+' : ''}{realized.toLocaleString('ko-KR')}
</span>
{" "}
<span className="text-xs font-bold text-slate-700">
원
</span>
</div>
<span className="text-[10px] text-emerald-600 font-semibold block mt-0.5">
수수료 0원 혜택
</span>
</div>
</div>
</section>
{/* 가상 체결 예시 티커 배너 (실제 사용자 거래 아님) */}
<div className="bg-white/80 backdrop-blur rounded-2xl px-3.5 py-2 border border-slate-200/70 flex items-center justify-between overflow-hidden shadow-xs">
<div className="flex items-center space-x-2 text-xs text-slate-600 min-w-0">
<span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
{" "}
<span className="text-[11px] font-bold text-slate-400 shrink-0">
가상 체결 예시
</span>
<p className="truncate text-[11px] text-slate-700 ticker-anim" id="ticker-live-text">
<b className="text-slate-900">
시드수호자
</b>
님이{" "}
<b>
ACE 미국나스닥100
</b>
{" "}1주 매수 체결
</p>
</div>
<span className="text-[10px] font-bold text-blue-600 shrink-0 ml-2">
방금 전
</span>
</div>
{/* 3. 가상 주식장 마켓 종목 탭 */}
<div className="flex items-center space-x-1.5 overflow-x-auto hide-scrollbar pb-0.5">
<button className="market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-white shrink-0 shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.changeMarketTab('holding', event.currentTarget); })} type="button">
보유 종목{" "}
<span className="tabular-nums font-semibold text-blue-300">
{holdingCount}
</span>
</button>
{" "}
<button className="market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.changeMarketTab('all', event.currentTarget); })} type="button">
전체 가상 마켓{" "}
<span className="tabular-nums font-semibold text-slate-400">
12
</span>
</button>
{" "}
<button className="market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.changeMarketTab('surge', event.currentTarget); })} type="button">
🔥 가상 가격 상승
</button>
{" "}
<button className="market-tab-btn px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.changeMarketTab('etf', event.currentTarget); })} type="button">
가상 ETF
</button>
</div>
{/* 종목 카드 리스트 */}
<section className="space-y-2.5" id="market-stock-list">
{/* 종목 1: TIGER 미국S&P500 */}
<div className="stock-card bg-white rounded-2xl p-4 shadow-card hover:border-blue-200 border border-transparent transition-all" data-category="holding,all,etf" data-code="SP500" data-name="TIGER 미국S&P500" data-price="62100" data-shares="1.45" data-tag="가상 체결 활발">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3 cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'buy'); })}>
<div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 font-black text-xs shrink-0 border border-blue-100">
S&P
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
TIGER 미국S&P500
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-600 border border-blue-100">
ETF
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
보유{" "}
<b className="text-slate-700 tabular-nums">
1.45주
</b>
{" "}· 평가 90,045원
</p>
</div>
</div>
{/* 현재가 및 등락 */}
<div className="text-right cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'buy'); })}>
<span className="text-sm font-extrabold text-slate-900 tabular-nums">
62,100원
</span>
<div className="flex items-center justify-end text-xs font-bold text-rose-500 tabular-nums mt-0.5">
<span>
▲ +1,100원 (+1.8%)
</span>
</div>
</div>
</div>
<div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
<div className="flex items-center space-x-1.5">
<span className="px-2 py-0.5 bg-rose-50 text-rose-600 rounded-md text-[10px] font-bold">
체결량 급증
</span>
{" "}
<span className="text-[11px] text-slate-400">
가상 호가 활발
</span>
</div>
{/* 빠른 매수/매도 버튼 */}
<div className="flex items-center space-x-1.5">
<button className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:scale-95 text-blue-600 text-xs font-bold transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'sell'); })} type="button">
매도
</button>
{" "}
<button className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'buy'); })} type="button">
매수
</button>
</div>
</div>
</div>
{/* 종목 2: ACE 미국나스닥100 */}
<div className="stock-card bg-white rounded-2xl p-4 shadow-card hover:border-sky-200 border border-transparent transition-all" data-category="holding,all,surge,etf" data-code="QQQ" data-name="ACE 미국나스닥100" data-price="34500" data-shares="0.68" data-tag="인기 종목">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3 cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('ACE 미국나스닥100', 34500, 0.68, '+2.4%', 3470, 'buy'); })}>
<div className="w-10 h-10 rounded-2xl bg-sky-50 flex items-center justify-center text-sky-600 font-black text-xs shrink-0 border border-sky-100">
QQQ
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
ACE 미국나스닥100
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-50 text-sky-600 border border-sky-100">
기술주
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
보유{" "}
<b className="text-slate-700 tabular-nums">
0.68주
</b>
{" "}· 평가 23,460원
</p>
</div>
</div>
<div className="text-right cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('ACE 미국나스닥100', 34500, 0.68, '+2.4%', 3470, 'buy'); })}>
<span className="text-sm font-extrabold text-slate-900 tabular-nums">
34,500원
</span>
<div className="flex items-center justify-end text-xs font-bold text-rose-500 tabular-nums mt-0.5">
<span>
▲ +810원 (+2.4%)
</span>
</div>
</div>
</div>
<div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
<div className="flex items-center space-x-1.5">
<span className="px-2 py-0.5 bg-sky-50 text-sky-700 rounded-md text-[10px] font-bold">
매수 우위
</span>
{" "}
<span className="text-[11px] text-slate-400">
빅테크 강세
</span>
</div>
<div className="flex items-center space-x-1.5">
<button className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:scale-95 text-blue-600 text-xs font-bold transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('ACE 미국나스닥100', 34500, 0.68, '+2.4%', 3470, 'sell'); })} type="button">
매도
</button>
{" "}
<button className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('ACE 미국나스닥100', 34500, 0.68, '+2.4%', 3470, 'buy'); })} type="button">
매수
</button>
</div>
</div>
</div>
{/* 종목 3: MOA 평행 우주·AI */}
<div className="stock-card bg-white rounded-2xl p-4 shadow-card hover:border-indigo-200 border border-transparent transition-all" data-category="holding,all,surge" data-code="SPACE" data-name="MOA 평행 우주·AI" data-price="13800" data-shares="1.0" data-tag="인기 급상승">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3 cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('MOA 평행 우주·AI', 13800, 1.0, '+5.2%', 1780, 'buy'); })}>
<div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black text-sm shrink-0 border border-indigo-100">
<span className="material-symbols-outlined text-[20px]">
rocket_launch
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
MOA 평행 우주·AI
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700">
인기급등
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
보유{" "}
<b className="text-slate-700 tabular-nums">
1.0주
</b>
{" "}· 평가 13,800원
</p>
</div>
</div>
<div className="text-right cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('MOA 평행 우주·AI', 13800, 1.0, '+5.2%', 1780, 'buy'); })}>
<span className="text-sm font-extrabold text-slate-900 tabular-nums">
13,800원
</span>
<div className="flex items-center justify-end text-xs font-bold text-rose-500 tabular-nums mt-0.5">
<span>
▲ +680원 (+5.2%)
</span>
</div>
</div>
</div>
<div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
<div className="flex items-center space-x-1.5">
<span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded-md text-[10px] font-bold">
테마형
</span>
{" "}
<span className="text-[11px] text-slate-400">
절약 리워드 2배
</span>
</div>
<div className="flex items-center space-x-1.5">
<button className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:scale-95 text-blue-600 text-xs font-bold transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('MOA 평행 우주·AI', 13800, 1.0, '+5.2%', 1780, 'sell'); })} type="button">
매도
</button>
{" "}
<button className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('MOA 평행 우주·AI', 13800, 1.0, '+5.2%', 1780, 'buy'); })} type="button">
매수
</button>
</div>
</div>
</div>
{/* 종목 4: SOL 한국고배당 */}
<div className="stock-card bg-white rounded-2xl p-4 shadow-card hover:border-emerald-200 border border-transparent transition-all" data-category="holding,all,etf" data-code="DIVIDEND" data-name="SOL 한국고배당" data-price="27600" data-shares="2.1" data-tag="월배당">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3 cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('SOL 한국고배당', 27600, 2.1, '-0.6%', 930, 'buy'); })}>
<div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold text-xs shrink-0 border border-emerald-100">
배당
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
SOL 한국고배당
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
월배당
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
보유{" "}
<b className="text-slate-700 tabular-nums">
2.1주
</b>
{" "}· 평가 57,960원
</p>
</div>
</div>
<div className="text-right cursor-pointer" onClick={(event) => run(event, (c) => { c.openOrderModal('SOL 한국고배당', 27600, 2.1, '-0.6%', 930, 'buy'); })}>
<span className="text-sm font-extrabold text-slate-900 tabular-nums">
27,600원
</span>
<div className="flex items-center justify-end text-xs font-bold text-blue-500 tabular-nums mt-0.5">
<span>
▼ -170원 (-0.6%)
</span>
</div>
</div>
</div>
<div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
<div className="flex items-center space-x-1.5">
<span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md text-[10px] font-bold">
연 5.8% 배당
</span>
{" "}
<span className="text-[11px] text-slate-400">
D-5 배당락일
</span>
</div>
<div className="flex items-center space-x-1.5">
<button className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:scale-95 text-blue-600 text-xs font-bold transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('SOL 한국고배당', 27600, 2.1, '-0.6%', 930, 'sell'); })} type="button">
매도
</button>
{" "}
<button className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.openOrderModal('SOL 한국고배당', 27600, 2.1, '-0.6%', 930, 'buy'); })} type="button">
매수
</button>
</div>
</div>
</div>
</section>
{/* 소비 방어 미션 연동 배너 */}
<section className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-4 shadow-card">
<div className="flex items-center space-x-2 mb-1.5">
<span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-bold flex items-center space-x-1">
<span className="material-symbols-outlined text-[12px] fill-1">
bolt
</span>
{" "}
<span>
소비 방어 머니 부스터
</span>
</span>
</div>
<p className="text-xs font-medium text-slate-300">
오늘 간식비{" "}
<b className="text-amber-300">
6,500원
</b>
을 아끼면 가상 거래소에 방어 머니가 즉시 충전돼요!
</p>
</section>
</main>
{/* END: Main Scroll Content */}
{/* BEGIN: Sticky Bottom Fixed Action Bar */}
<div className="fixed bottom-0 max-w-[390px] w-full bg-white/95 backdrop-blur-md px-4 py-3 border-t border-black/[0.05] z-30 shadow-order flex items-center space-x-2">
<button className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 active:scale-[0.98] text-slate-800 font-bold rounded-2xl text-[14px] transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'buy'); })} type="button">
<span className="material-symbols-outlined text-[18px] text-slate-600">
bar_chart
</span>
{" "}
<span>
가상 호가 주문
</span>
</button>
{" "}
<button className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 active:scale-[0.98] text-white font-bold rounded-2xl text-[14px] shadow-sm transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.openOrderModal('TIGER 미국S&P500', 62100, 1.45, '+1.8%', 4810, 'buy'); })} type="button">
<span className="material-symbols-outlined text-[18px]">
add_circle
</span>
{" "}
<span>
빠른 모의 매수·매도
</span>
</button>
</div>
{/* END: Sticky Bottom Fixed Action Bar */}
{/* BEGIN: 4. 가상 호가창 및 매수/매도 주문 슬라이드 바텀시트 모달 */}
<div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity duration-300 flex items-end justify-center opacity-0 pointer-events-none" id="order-modal-backdrop" onClick={(event) => run(event, (c) => { c.handleBackdropClick(event); })}>
<div className="w-full max-w-[390px] bg-white rounded-t-[32px] shadow-2xl flex flex-col max-h-[calc(var(--app-h)*0.92)] overflow-hidden transform translate-y-full transition-transform duration-300" id="order-modal-content" onClick={(event) => run(event, (c) => { event.stopPropagation(); })}>
{/* Drag Handle & Top Bar */}
<div className="pt-3 pb-2 px-5 flex flex-col border-b border-slate-100 shrink-0 bg-white">
<div className="w-10 h-1 bg-slate-200 rounded-full mx-auto mb-3" />
<div className="flex items-start justify-between">
<div className="flex items-center space-x-2.5">
<div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 font-black text-xs border border-blue-100" id="bs-stock-badge">
S&P
</div>
<div>
<div className="flex items-center space-x-1.5">
<h3 className="text-base font-extrabold text-slate-900 tracking-tight" id="modal-stock-name">
TIGER 미국S&P500
</h3>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-600 border border-blue-100">
가상 ETF
</span>
</div>
<div className="flex items-baseline space-x-1.5 mt-0.5">
<span className="text-[18px] font-black text-slate-900 tabular-nums" id="modal-stock-price">
62,100
</span>
{" "}
<span className="text-xs font-bold text-slate-700">
원
</span>
{" "}
<span className="text-xs font-bold text-rose-500 tabular-nums" id="modal-stock-rate">
▲ +1,100원 (+1.8%)
</span>
</div>
</div>
</div>
<button aria-label="주문 닫기" className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-all" onClick={(event) => run(event, (c) => { c.closeOrderModal(); })} type="button">
<span className="material-symbols-outlined text-[18px]">
close
</span>
</button>
</div>
{/* Sub Tabs: 호가 / 차트 / 체결 / 정보 */}
<div className="flex items-center space-x-6 mt-3 border-b border-slate-100 text-xs font-bold">
<button className="pb-2 border-b-2 border-blue-600 text-blue-600 font-bold transition-colors modal-sub-tab" id="tab-btn-orderbook" onClick={(event) => run(event, (c) => { c.switchModalTab('orderbook'); })} type="button">
가상 호가
</button>
{" "}
<button className="pb-2 border-b-2 border-transparent text-slate-400 hover:text-slate-700 transition-colors modal-sub-tab" id="tab-btn-chart" onClick={(event) => run(event, (c) => { c.switchModalTab('chart'); })} type="button">
차트
</button>
{" "}
<button className="pb-2 border-b-2 border-transparent text-slate-400 hover:text-slate-700 transition-colors modal-sub-tab" id="tab-btn-history" onClick={(event) => run(event, (c) => { c.switchModalTab('history'); })} type="button">
체결내역
</button>
{" "}
<button className="pb-2 border-b-2 border-transparent text-slate-400 hover:text-slate-700 transition-colors modal-sub-tab" id="tab-btn-info" onClick={(event) => run(event, (c) => { c.switchModalTab('info'); })} type="button">
종목 정보
</button>
</div>
</div>
{/* Scrollable Body Content */}
<div className="flex-1 overflow-y-auto hide-scrollbar p-4 space-y-3 bg-[#F8F9FA]">
{/* 1. [가상 호가] 탭 뷰 */}
<div className="space-y-2.5" id="tab-content-orderbook">
<div className="bg-white rounded-2xl p-3 border border-slate-200/70 shadow-xs">
<div className="flex items-center justify-between text-[11px] mb-1.5">
<span className="font-bold text-blue-600">
매도 잔량{" "}
<b className="tabular-nums font-black">
1,420주
</b>
{" "}(42%)
</span>
{" "}
<span className="flex items-center space-x-1 text-emerald-600 font-semibold">
<span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-live-pulse" />
{" "}
<span>
가상 체결 예시
</span>
</span>
{" "}
<span className="font-bold text-rose-500">
매수 잔량{" "}
<b className="tabular-nums font-black">
1,980주
</b>
{" "}(58%)
</span>
</div>
<div className="w-full h-2 rounded-full overflow-hidden flex bg-slate-100">
<div className="bg-blue-500 h-full transition-all duration-300" style={{ width: "42%" }} />
<div className="bg-rose-500 h-full transition-all duration-300" style={{ width: "58%" }} />
</div>
</div>
<div className="bg-white rounded-2xl border border-slate-200/70 overflow-hidden shadow-xs grid grid-cols-12">
<div className="col-span-7 border-r border-slate-100 divide-y divide-slate-100 text-xs tabular-nums">
<div className="flex items-center justify-between px-2 py-1 bg-blue-50/40 relative">
<div className="absolute right-0 top-0 bottom-0 bg-blue-100/60 pointer-events-none" style={{ width: "32%" }} />
<span className="text-[10px] text-blue-500 font-medium z-10">
112
</span>
{" "}
<span className="font-bold text-blue-700 z-10">
62,400
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-blue-50/60 relative">
<div className="absolute right-0 top-0 bottom-0 bg-blue-100/70 pointer-events-none" style={{ width: "48%" }} />
<span className="text-[10px] text-blue-500 font-medium z-10">
245
</span>
{" "}
<span className="font-bold text-blue-700 z-10">
62,300
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-blue-50/80 relative">
<div className="absolute right-0 top-0 bottom-0 bg-blue-200/80 pointer-events-none" style={{ width: "65%" }} />
<span className="text-[10px] text-blue-600 font-bold z-10">
380
</span>
{" "}
<span className="font-extrabold text-blue-800 z-10">
62,200
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-blue-100/70 relative border-l-2 border-blue-600">
<div className="absolute right-0 top-0 bottom-0 bg-blue-300/60 pointer-events-none" style={{ width: "84%" }} />
<span className="text-[10px] text-blue-700 font-extrabold z-10">
683
</span>
{" "}
<span className="font-black text-blue-800 text-[13px] z-10">
62,100
</span>
</div>
<div className="bg-rose-50 px-2 py-1.5 flex items-center justify-between border-y-2 border-rose-500">
<div className="flex items-center space-x-1 text-rose-600 font-black text-xs">
<span className="material-symbols-outlined text-[13px]">
play_arrow
</span>
{" "}
<span>
현재 체결가
</span>
</div>
<span className="font-black text-rose-600 text-sm">
62,100
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-rose-100/70 relative border-l-2 border-rose-500">
<div className="absolute left-0 top-0 bottom-0 bg-rose-200/80 pointer-events-none" style={{ width: "78%" }} />
<span className="font-black text-rose-700 text-[13px] z-10">
62,000
</span>
{" "}
<span className="text-[10px] text-rose-600 font-extrabold z-10">
524
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-rose-50/80 relative">
<div className="absolute left-0 top-0 bottom-0 bg-rose-200/60 pointer-events-none" style={{ width: "60%" }} />
<span className="font-extrabold text-rose-600 z-10">
61,900
</span>
{" "}
<span className="text-[10px] text-rose-500 font-bold z-10">
410
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-rose-50/60 relative">
<div className="absolute left-0 top-0 bottom-0 bg-rose-100/70 pointer-events-none" style={{ width: "44%" }} />
<span className="font-bold text-rose-600 z-10">
61,800
</span>
{" "}
<span className="text-[10px] text-rose-400 font-medium z-10">
288
</span>
</div>
<div className="flex items-center justify-between px-2 py-1 bg-rose-50/40 relative">
<div className="absolute left-0 top-0 bottom-0 bg-rose-100/50 pointer-events-none" style={{ width: "25%" }} />
<span className="font-medium text-rose-500 z-10">
61,700
</span>
{" "}
<span className="text-[10px] text-rose-400 font-medium z-10">
152
</span>
</div>
</div>
<div className="col-span-5 p-2.5 flex flex-col justify-between bg-white text-[11px]">
<div className="space-y-2">
<div>
<span className="text-slate-400 block text-[10px]">
전일 종가
</span>
{" "}
<span className="font-bold text-slate-800 tabular-nums">
61,000원
</span>
</div>
<div>
<span className="text-slate-400 block text-[10px]">
시가
</span>
{" "}
<span className="font-bold text-rose-500 tabular-nums">
61,500원
</span>
</div>
<div>
<span className="text-slate-400 block text-[10px]">
고가
</span>
{" "}
<span className="font-bold text-rose-500 tabular-nums">
62,600원
</span>
</div>
<div>
<span className="text-slate-400 block text-[10px]">
저가
</span>
{" "}
<span className="font-bold text-blue-500 tabular-nums">
61,200원
</span>
</div>
<div>
<span className="text-slate-400 block text-[10px]">
가상 누적거래량
</span>
{" "}
<span className="font-bold text-slate-900 tabular-nums">
18,490주
</span>
</div>
</div>
<div className="mt-2 pt-2 border-t border-slate-100">
<span className="inline-block px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 text-[9px] font-bold border border-amber-200/60">
가상 거래
</span>
</div>
</div>
</div>
</div>
{/* 2. [차트] 탭 뷰 */}
<div className="space-y-2.5 hidden" id="tab-content-chart" style={{ display: "none" }}>
<div className="bg-white rounded-2xl p-3 border border-slate-200/70 shadow-xs">
<div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs font-bold">
<div className="flex items-center space-x-1">
<button className="px-2 py-0.5 rounded bg-slate-900 text-white text-[11px]" data-chart-range="1d" type="button">
1일
</button>
{" "}
<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1w" type="button">
1주
</button>
{" "}
<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1m" type="button">
1달
</button>
{" "}
<button className="px-2 py-0.5 rounded text-slate-500 hover:text-slate-900 text-[11px]" data-chart-range="1y" type="button">
1년
</button>
</div>
<span className="text-[11px] text-rose-500 font-bold tabular-nums" id="chart-hilo">
최고 62,600 / 최저 61,200
</span>
</div>
<div className="w-full h-44 relative flex items-center justify-center bg-slate-50/50 rounded-xl overflow-hidden p-1">
<svg className="w-full h-full" id="stock-chart-svg" preserveAspectRatio="none" viewBox="0 0 320 140">
<line stroke="#E2E8F0" strokeDasharray="3,3" strokeWidth="1" x1="0" x2="320" y1="30" y2="30" />
<line stroke="#E2E8F0" strokeDasharray="3,3" strokeWidth="1" x1="0" x2="320" y1="70" y2="70" />
<line stroke="#E2E8F0" strokeDasharray="3,3" strokeWidth="1" x1="0" x2="320" y1="110" y2="110" />
<line stroke="#3182F6" strokeWidth="1.5" x1="25" x2="25" y1="55" y2="100" />
<rect fill="#3182F6" height="25" rx="1" width="10" x="20" y="65" />
<line stroke="#F04452" strokeWidth="1.5" x1="55" x2="55" y1="50" y2="90" />
<rect fill="#F04452" height="20" rx="1" width="10" x="50" y="58" />
<line stroke="#F04452" strokeWidth="1.5" x1="85" x2="85" y1="40" y2="80" />
<rect fill="#F04452" height="24" rx="1" width="10" x="80" y="46" />
<line stroke="#3182F6" strokeWidth="1.5" x1="115" x2="115" y1="35" y2="75" />
<rect fill="#3182F6" height="16" rx="1" width="10" x="110" y="42" />
<line stroke="#F04452" strokeWidth="1.5" x1="145" x2="145" y1="30" y2="70" />
<rect fill="#F04452" height="28" rx="1" width="10" x="140" y="35" />
<line stroke="#3182F6" strokeWidth="1.5" x1="175" x2="175" y1="40" y2="85" />
<rect fill="#3182F6" height="22" rx="1" width="10" x="170" y="48" />
<line stroke="#F04452" strokeWidth="1.5" x1="205" x2="205" y1="25" y2="65" />
<rect fill="#F04452" height="25" rx="1" width="10" x="200" y="32" />
<line stroke="#F04452" strokeWidth="1.5" x1="235" x2="235" y1="20" y2="55" />
<rect fill="#F04452" height="20" rx="1" width="10" x="230" y="25" />
<line stroke="#F04452" strokeWidth="1.5" x1="265" x2="265" y1="15" y2="50" />
<rect fill="#F04452" height="26" rx="1" width="10" x="260" y="18" />
<rect fill="#93C5FD" height="18" opacity="0.6" width="10" x="20" y="118" />
<rect fill="#FCA5A5" height="14" opacity="0.6" width="10" x="50" y="122" />
<rect fill="#FCA5A5" height="22" opacity="0.6" width="10" x="80" y="114" />
<rect fill="#93C5FD" height="10" opacity="0.6" width="10" x="110" y="126" />
<rect fill="#FCA5A5" height="26" opacity="0.7" width="10" x="140" y="110" />
<rect fill="#93C5FD" height="16" opacity="0.6" width="10" x="170" y="120" />
<rect fill="#FCA5A5" height="31" opacity="0.7" width="10" x="200" y="105" />
<rect fill="#FCA5A5" height="24" opacity="0.7" width="10" x="230" y="112" />
<rect fill="#F04452" height="36" opacity="0.9" width="10" x="260" y="100" />
</svg>
</div>
</div>
</div>
{/* 3. [체결내역] 탭 뷰 */}
<div className="space-y-2.5 hidden" id="tab-content-history" style={{ display: "none" }}>
{/* 상단 서브 필터 */}
<div className="flex items-center space-x-1.5">
<button className="px-3 py-1 rounded-full text-xs font-bold bg-slate-900 text-white shadow-xs" id="history-filter-all" onClick={(event) => run(event, (c) => { c.filterHistory('all', event.currentTarget); })} type="button">
전체 체결
</button>
{" "}
<button className="px-3 py-1 rounded-full text-xs font-medium bg-white text-slate-600 border border-slate-200/70 hover:text-slate-900" id="history-filter-my" onClick={(event) => run(event, (c) => { c.filterHistory('my', event.currentTarget); })} type="button">
내 주문 체결{" "}
<span className="text-blue-600 font-bold">
(1)
</span>
</button>
</div>
{/* 방금 체결된 주문 강조 카드 */}
<div className="bg-blue-50/80 rounded-2xl p-3 border border-blue-200/80 shadow-xs flex items-center justify-between">
<div className="flex items-start space-x-2.5">
<div className="w-7 h-7 rounded-full bg-blue-500 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
<span className="material-symbols-outlined text-[16px]">
check
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-blue-100 text-blue-700">
내 체결 성공
</span>
{" "}
<span className="text-[11px] text-slate-500 tabular-nums">
14:30:05 체결 완료!
</span>
</div>
<p className="text-xs font-bold text-slate-900 mt-0.5">
1주 ·{" "}
<span className="text-blue-700 tabular-nums">
62,100원
</span>
{" "}
<span className="text-[11px] text-slate-600 font-medium">
(매수, 소비 방어 머니)
</span>
</p>
</div>
</div>
<span className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200/60 text-[10px] font-bold shrink-0">
수수료 0원
</span>
</div>
{/* 당일 체결 요약 통계 */}
<div className="grid grid-cols-3 gap-1.5 bg-white rounded-2xl p-2.5 border border-slate-200/70 text-center">
<div className="bg-slate-50/70 rounded-xl p-2">
<span className="text-[10px] text-slate-400 block mb-0.5">
총 체결량
</span>
{" "}
<span className="text-xs font-black text-slate-900 tabular-nums">
18,491주
</span>
</div>
<div className="bg-slate-50/70 rounded-xl p-2">
<span className="text-[10px] text-slate-400 block mb-0.5">
평균 체결가
</span>
{" "}
<span className="text-xs font-black text-slate-900 tabular-nums">
62,080원
</span>
</div>
<div className="bg-slate-50/70 rounded-xl p-2">
<span className="text-[10px] text-slate-400 block mb-0.5">
가상 체결강도
</span>
{" "}
<span className="text-xs font-black text-rose-500 tabular-nums">
118%
</span>
</div>
</div>
{/* 실시간 마켓 체결 리스트 */}
<div className="bg-white rounded-2xl p-3 border border-slate-200/70 divide-y divide-slate-100 text-xs tabular-nums">
<div className="flex items-center justify-between pb-1.5 font-bold text-slate-400 text-[11px]">
<span>
체결 시간
</span>
{" "}
<span>
체결가(변동)
</span>
{" "}
<span>
수량 / 구분
</span>
</div>
{/* 내 주문 */}
<div className="flex items-center justify-between py-2 text-rose-600 bg-rose-50/40 -mx-1 px-1 rounded-lg font-bold history-row history-my">
<div className="flex items-center space-x-1.5">
<span className="px-1 rounded bg-blue-100 text-blue-700 text-[9px] font-black">
내주문
</span>
{" "}
<span className="text-slate-600">
14:30:05
</span>
</div>
<div className="text-right">
<span className="font-black">
62,100원
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
▲ +1.8%
</span>
</div>
<div className="text-right">
<span className="font-black">
1주
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
매수
</span>
</div>
</div>
{/* 마켓 체결 행들 */}
<div className="flex items-center justify-between py-1.5 text-rose-500 font-semibold history-row history-market">
<span className="text-slate-500">
14:29:58
</span>
<div className="text-right">
<span className="font-bold">
62,100원
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
▲ +1.8%
</span>
</div>
<div className="text-right">
<span className="font-bold text-rose-500">
+5주
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
매수
</span>
</div>
</div>
<div className="flex items-center justify-between py-1.5 text-blue-500 font-semibold history-row history-market">
<span className="text-slate-500">
14:29:42
</span>
<div className="text-right">
<span className="font-bold">
62,000원
</span>
{" "}
<span className="text-[10px] text-blue-500 block">
▲ +1.6%
</span>
</div>
<div className="text-right">
<span className="font-bold text-blue-500">
-3주
</span>
{" "}
<span className="text-[10px] text-blue-500 block">
매도
</span>
</div>
</div>
<div className="flex items-center justify-between py-1.5 text-rose-500 font-semibold history-row history-market">
<span className="text-slate-500">
14:28:12
</span>
<div className="text-right">
<span className="font-bold">
62,100원
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
▲ +1.8%
</span>
</div>
<div className="text-right">
<span className="font-bold text-rose-500">
+12주
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
매수
</span>
</div>
</div>
<div className="flex items-center justify-between py-1.5 text-rose-500 font-semibold history-row history-market">
<span className="text-slate-500">
14:27:55
</span>
<div className="text-right">
<span className="font-bold">
62,100원
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
▲ +1.8%
</span>
</div>
<div className="text-right">
<span className="font-bold text-rose-500">
+2주
</span>
{" "}
<span className="text-[10px] text-rose-500 block">
매수
</span>
</div>
</div>
<div className="flex items-center justify-between py-1.5 text-blue-500 font-semibold history-row history-market">
<span className="text-slate-500">
14:26:18
</span>
<div className="text-right">
<span className="font-bold">
62,000원
</span>
{" "}
<span className="text-[10px] text-blue-500 block">
▲ +1.6%
</span>
</div>
<div className="text-right">
<span className="font-bold text-blue-500">
-8주
</span>
{" "}
<span className="text-[10px] text-blue-500 block">
매도
</span>
</div>
</div>
</div>
</div>
{/* 4. [종목 정보] 탭 뷰 */}
<div className="space-y-2 hidden" id="tab-content-info" style={{ display: "none" }}>
<div className="bg-white rounded-2xl p-3.5 border border-slate-200/70 text-xs space-y-2">
<p className="font-bold text-slate-800">
TIGER 미국S&P500 ETF
</p>
<p className="text-slate-500 text-[11px] leading-relaxed">
미국을 대표하는 우량 500개 대기업 지수를 추종하는 대표 인덱스 펀드입니다. 모아 소비 방어로 모은 시드머니로 안정적인 미국 성장주에 분산 모의투자할 수 있습니다.
</p>
<div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px]">
<div>
<span className="text-slate-400">
운용보수:
</span>
{" "}
<b className="text-slate-700">
0.07%
</b>
</div>
<div>
<span className="text-slate-400">
가상 배당수익률:
</span>
{" "}
<b className="text-emerald-600">
연 1.4%
</b>
</div>
</div>
</div>
</div>
{/* 주문 수량 조절 및 방어머니 연동 주문 패널 (항상 유지) */}
<div className="bg-white rounded-2xl p-3.5 border border-slate-200/70 shadow-xs space-y-2.5">
<div className="flex items-center justify-between text-xs">
<span className="font-bold text-slate-700">주문 방식</span>
<div className="flex bg-slate-100 rounded-lg p-0.5 text-[11px] font-bold">
<button className="px-2.5 py-1 rounded-md bg-white text-slate-900 shadow-xs" id="btn-type-market" onClick={(event) => run(event, (c) => { c.setOrderType('market'); })} type="button">시장가</button>
<button className="px-2.5 py-1 rounded-md text-slate-500" id="btn-type-limit" onClick={(event) => run(event, (c) => { c.setOrderType('limit'); })} type="button">지정가</button>
</div>
</div>
<div className="hidden items-center justify-between text-xs" id="limit-price-row">
<span className="font-bold text-slate-700">지정 가격</span>
<div className="flex items-center gap-1">
<button className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700" id="limit-minus" type="button" aria-label="50원 내리기">−</button>
<input className="w-24 h-8 text-center rounded-lg border border-slate-200 font-bold tabular-nums text-sm outline-none focus:border-blue-500" id="limit-price-input" inputMode="numeric" aria-label="지정 가격" />
<button className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700" id="limit-plus" type="button" aria-label="50원 올리기">+</button>
<span className="text-slate-500 ml-0.5">원</span>
</div>
</div>
<div className="flex items-center justify-between text-xs">
<span className="font-bold text-slate-700">
주문 수량 조절
</span>
{" "}
<span className="text-[11px] text-slate-400 font-medium" id="order-unit-desc">
주문 가능:{" "}
<b className="text-blue-600 font-bold" id="max-possible-shares">
8주
</b>
</span>
</div>
<div className="flex items-center space-x-2">
<button className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 flex items-center justify-center font-bold text-slate-700" onClick={(event) => run(event, (c) => { c.adjustShares(-1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
remove
</span>
</button>
<div className="flex-1 h-10 bg-slate-50 border border-slate-200 rounded-xl px-3 flex items-center justify-center">
<span className="text-base font-black text-slate-900 tabular-nums" id="input-shares">
1
</span>
{" "}
<span className="text-xs font-bold text-slate-600 ml-1">
주
</span>
</div>
<button className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 flex items-center justify-center font-bold text-slate-700" onClick={(event) => run(event, (c) => { c.adjustShares(1); })} type="button">
<span className="material-symbols-outlined text-[18px]">
add
</span>
</button>
<div className="flex items-center space-x-1">
<button className="px-2 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] active:scale-95" onClick={(event) => run(event, (c) => { c.setShareRatio(0.25); })} type="button">
25%
</button>
{" "}
<button className="px-2 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] active:scale-95" onClick={(event) => run(event, (c) => { c.setShareRatio(0.5); })} type="button">
50%
</button>
{" "}
<button className="px-2 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] active:scale-95" onClick={(event) => run(event, (c) => { c.setShareRatio(1.0); })} type="button">
최대
</button>
</div>
</div>
<div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
<div className="flex items-center space-x-1 text-slate-500">
<span>
총 예상 주문금액:
</span>
{" "}
<b className="text-slate-900 font-black tabular-nums text-sm" id="order-total-price">
62,100
</b>
{" "}
<span className="text-slate-700 font-bold">
원
</span>
</div>
<span className="text-[11px] text-emerald-600 font-semibold">
수수료 0원 혜택
</span>
</div>
</div>
</div>
<p className="hidden px-4 pt-2 text-[11.5px] font-semibold text-rose-500 bg-white" id="order-limit-hint" />
{/* Fixed Bottom Dual Action Order Buttons */}
<div className="p-3.5 bg-white border-t border-slate-100 flex items-center space-x-2 shrink-0">
<button id="btn-quick-sell" className="disabled:cursor-not-allowed flex-1 py-3.5 bg-blue-50 hover:bg-blue-100 active:scale-[0.98] text-blue-600 font-extrabold rounded-2xl text-[14px] transition-all flex items-center justify-center space-x-1 shadow-xs" onClick={(event) => run(event, (c) => { c.executeOrderQuick('sell'); })} type="button">
<span className="material-symbols-outlined text-[18px]">
arrow_downward
</span>
{" "}
<span>
가상 매도
</span>
</button>
{" "}
<button id="btn-quick-buy" className="disabled:cursor-not-allowed flex-[1.5] py-3.5 bg-rose-500 hover:bg-rose-600 active:scale-[0.98] text-white font-extrabold rounded-2xl text-[14px] shadow-floating transition-all flex items-center justify-center space-x-1" onClick={(event) => run(event, (c) => { c.executeOrderQuick('buy'); })} type="button">
<span className="material-symbols-outlined text-[18px]">
arrow_upward
</span>
{" "}
<span>
방어 머니로 매수
</span>
</button>
</div>
</div>
</div>
{/* END: 가상 호가 주문 슬라이드 바텀시트 모달 */}
{/* BEGIN: 즉시 체결 토스트 알림 */}
<div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-center justify-center px-5 transition-opacity duration-300 hidden" id="order-complete-modal">
<div className="w-full max-w-[340px] bg-white rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center transform transition-all duration-300 scale-100 animate-in" id="order-complete-card">
<div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-4 ring-8 ring-rose-50/60" id="complete-icon-box">
<span className="material-symbols-outlined text-[36px] font-bold">
check_circle
</span>
</div>
<div className="inline-flex items-center space-x-1 bg-rose-50 px-2.5 py-0.5 rounded-full text-rose-600 text-[11px] font-bold mb-2" id="complete-badge">
<span>
실시간 가상 체결 성공
</span>
</div>
<h3 className="text-[20px] font-black text-slate-900 tracking-tight leading-tight" id="complete-title">
1주 매수 주문이
<br />
체결되었어요!
</h3>
<p className="text-xs text-slate-500 font-medium mt-1.5" id="complete-subtitle">
TIGER 미국S&P500 · 체결가 62,100원
</p>
<div className="w-full bg-slate-50 rounded-2xl p-3.5 mt-4 mb-5 border border-slate-100 text-left space-y-2 text-xs">
<div className="flex justify-between"><span className="text-slate-500">체결 수량</span><b className="text-slate-900" id="complete-shares">1주</b></div>
<div className="flex justify-between"><span className="text-slate-500">체결 금액</span><b className="text-slate-900" id="complete-amount">62,100원</b></div>
<div className="flex justify-between"><span className="text-slate-500">사용한 자금</span><b className="text-blue-600">방어 머니</b></div>
</div>
<div className="w-full space-y-2">
<button className="w-full py-3.5 bg-blue-500 hover:bg-blue-600 active:scale-[0.98] text-white font-extrabold rounded-2xl text-[14px] shadow-sm transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.goToExecutionHistory(); })} type="button">
<span>
체결 내역 및 지갑 확인
</span>
{" "}
<span className="material-symbols-outlined text-[18px]">
arrow_forward
</span>
</button>
{" "}
<button className="w-full py-3.5 bg-slate-900 active:scale-[0.98] text-white font-extrabold rounded-2xl text-[14px] transition-all flex items-center justify-center gap-1.5" id="complete-learn-btn" data-nav="/learn" type="button">
<span className="material-symbols-outlined text-[18px]">school</span>
<span>이번 거래로 배우기</span>
</button>
<button className="w-full py-2.5 text-slate-500 hover:text-slate-800 text-xs font-semibold rounded-xl transition-all" onClick={(event) => run(event, (c) => { c.closeCompleteModal(); })} type="button">
계속 거래하기
</button>
</div>
</div>
</div>
<div className="fixed top-5 left-1/2 -translate-x-1/2 z-[60] bg-slate-900/95 text-white px-4 py-2.5 rounded-full shadow-2xl flex items-center space-x-2 text-xs font-semibold opacity-0 pointer-events-none transition-all duration-300 max-w-[340px] w-auto" id="share-toast">
<span className="material-symbols-outlined text-[18px] text-emerald-400">
check_circle
</span>
{" "}
<span className="truncate" id="share-toast-text">
주문이 정상 체결되었습니다.
</span>
</div>
{/* END: 토스트 알림 */}
</div>
{/* BEGIN: Page Logic & Real-time Market Simulation Script */}
{/* END: Page Logic */}
    </div>
  );
}

export default memo(InvestScreen);
