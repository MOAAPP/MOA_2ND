/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s09. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  var calendarTxMockData = {
    1: {
      title: '11월 1일 일요일',
      count: '내역 0건 · 총 0원',
      items: []
    },
    2: {
      title: '11월 2일 월요일',
      count: '지출 1건 · 총 -15,400원',
      items: [
        { name: '파리바게뜨 강남역점', cat: '식비 • 생활비 통장', tag: '지출', tagColor: 'red', amount: '-15,400원', isIncome: false, time: '08:45', benefit: '' }
      ]
    },
    5: {
      title: '11월 5일 목요일',
      count: '내역 2건 · 총 +1,395,750원',
      items: [
        { name: '11월 정기 급여 입금', cat: '급여 • 주거래 통장', tag: '수입', tagColor: 'emerald', amount: '+1,500,000원', isIncome: true, time: '10:00', benefit: '' },
        { name: '이마트 역삼점 장보기', cat: '식비 • 생활비 통장', tag: '지출', tagColor: 'red', amount: '-104,250원', isIncome: false, time: '19:20', benefit: '평행 자산 +3,200원 효과' }
      ]
    },
    7: {
      title: '11월 7일 토요일',
      count: '내역 0건 · 총 0원',
      items: []
    },
    8: {
      title: '11월 8일 일요일',
      count: '수입 1건 · 총 +50,000원',
      items: [
        { name: '중고거래 당근마켓 판매', cat: '기타수입 • 카카오페이', tag: '수입', tagColor: 'emerald', amount: '+50,000원', isIncome: true, time: '15:30', benefit: '' }
      ]
    },
    9: {
      title: '11월 9일 월요일',
      count: '지출 2건 · 총 -48,200원',
      items: [
        { name: '올리브영 강남본점', cat: '생활/쇼핑 • 생활비 통장', tag: '지출', tagColor: 'red', amount: '-32,200원', isIncome: false, time: '13:10', benefit: '' },
        { name: '교보문고 서적 구매', cat: '문화/취미 • 체크카드', tag: '지출', tagColor: 'red', amount: '-16,000원', isIncome: false, time: '18:50', benefit: '' }
      ]
    },
    10: {
      title: '11월 10일 화요일',
      count: '내역 4건 · 총 670,447원',
      items: [
        { name: '스타벅스 역삼점', cat: '카페/간식 • 생활비 통장', tag: '지출', tagColor: 'red', amount: '-6,500원', isIncome: false, time: '14:20', benefit: '평행 자산 +1,500원 효과', icon: 'coffee' },
        { name: '마켓컬리 장보기', cat: '식비 • 생활비 통장', tag: '지출', tagColor: 'red', amount: '-28,000원', isIncome: false, time: '08:15', benefit: '', icon: 'bag' },
        { name: '청년도약적금 자동이체', cat: '비상금 파킹통장 • 국민은행', tag: '예적금', tagColor: 'teal', amount: '+300,000원', isIncome: true, time: '09:00', benefit: '목돈 모으기 11회차 달성', icon: 'savings' },
        { name: '주택청약 종합저축', cat: '청약통장 • 우리은행', tag: '예적금', tagColor: 'teal', amount: '+100,000원', isIncome: true, time: '09:30', benefit: '', icon: 'home_work' }
      ]
    }
  };

  var currentSelectedCalDay = 10;
  var lastSelectedCalCell = null;

  function selectCalendarDay(day, cellEl) {
    currentSelectedCalDay = day;
    var cells = document.querySelectorAll('#calendar-view-container .grid.grid-cols-7 > div');
    cells.forEach(function(c) {
      if (c.classList.contains('bg-blue-600')) {
        c.classList.remove('bg-blue-600', 'text-white', 'shadow-md', 'shadow-blue-500/35', 'scale-105');
        c.classList.add('hover:bg-slate-50');
        var sp = c.querySelector('span:first-child');
        if (sp) {
          if (sp.textContent.trim() === '1' || sp.textContent.trim() === '8' || sp.textContent.trim() === '15' || sp.textContent.trim() === '22' || sp.textContent.trim() === '29') {
            sp.className = 'text-[11px] font-bold text-red-500';
          } else {
            sp.className = 'text-[11px] font-semibold text-slate-800';
          }
        }
      }
      c.classList.remove('ring-2', 'ring-blue-600', 'bg-blue-50/80');
    });

    if (cellEl) {
      if (day === 10) {
        cellEl.className = 'p-1 min-h-[52px] rounded-xl bg-blue-600 text-white flex flex-col justify-start items-center cursor-pointer shadow-md shadow-blue-500/35 relative transform scale-105 transition-all';
      } else {
        cellEl.classList.add('ring-2', 'ring-blue-600', 'bg-blue-50/80');
      }
    }

    renderCalendarDayDetails(day);
  }

  function renderCalendarDayDetails(day) {
    var dateTitle = document.getElementById('cal-detail-date-title');
    var countTitle = document.getElementById('cal-detail-tx-count');
    var listEl = document.getElementById('cal-detail-tx-list');
    if (!listEl) return;

    var data = calendarTxMockData[day] || {
      title: '11월 ' + day + '일',
      count: '내역 0건 · 총 0원',
      items: []
    };

    if (dateTitle) dateTitle.textContent = data.title;
    if (countTitle) countTitle.textContent = data.count;

    if (data.items.length === 0) {
      listEl.innerHTML = '<div class="py-6 px-4 bg-slate-50/80 rounded-2xl border border-slate-100 flex flex-col items-center justify-center text-center space-y-1.5"><div class="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600"><span class="material-symbols-outlined text-[18px]">eco</span></div><p class="text-xs font-bold text-slate-800">소비 내역이 없는 날이에요 🌿</p><p class="text-[11px] text-slate-400">무지출 챌린지 성공! 평행세계 씨앗 +1개가 적립되었어요.</p></div>';
      return;
    }

    var html = '';
    data.items.forEach(function(item, idx) {
      var borderClass = idx > 0 ? 'border-t border-slate-50 pt-2.5' : '';
      var tagBg = item.tagColor === 'red' ? 'bg-red-50 text-red-500' : (item.tagColor === 'teal' ? 'bg-teal-50 text-teal-700' : 'bg-emerald-50 text-emerald-700');
      var amtColor = item.isIncome ? 'text-emerald-600' : 'text-slate-900';
      var benefitBadge = item.benefit ? '<span class="inline-block mt-1 text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">' + item.benefit + '</span>' : '';
      var iconEl = '';
      if (item.tag === '예적금') {
        var iconName = item.name.indexOf('주택') !== -1 ? 'home_work' : 'savings';
        iconEl = '<div class="w-9 h-9 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0 mt-0.5 text-teal-600"><span class="material-symbols-outlined text-[18px]">' + iconName + '</span></div>';
      } else if (item.tag === '수입') {
        iconEl = '<div class="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5 text-emerald-600"><span class="material-symbols-outlined text-[18px]">payments</span></div>';
      } else if (item.name.indexOf('스타벅스') !== -1) {
        iconEl = '<div class="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5"><svg class="w-4 h-4 text-emerald-600 stroke-[1.8]" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8zM6 1v3M10 1v3M14 1v3" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>';
      } else {
        iconEl = '<div class="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 mt-0.5"><svg class="w-4 h-4 text-blue-600 stroke-[1.8]" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>';
      }

      html += '<div class="flex items-start justify-between py-1 transition-all ' + borderClass + '"><div class="flex items-start space-x-3">' + iconEl + '<div><div class="flex items-center space-x-1.5"><p class="text-sm font-bold text-slate-900 leading-tight">' + item.name + '</p><span class="px-1.5 py-0.5 text-[9px] font-bold ' + tagBg + ' rounded">' + item.tag + '</span></div><p class="text-[11px] text-slate-400 mt-0.5">' + item.cat + '</p>' + benefitBadge + '</div></div><div class="text-right"><span class="text-sm font-bold ' + amtColor + '">' + item.amount + '</span><p class="text-[10px] text-slate-400 mt-0.5">' + item.time + '</p></div></div>';
    });
    listEl.innerHTML = html;
  }


/* ---- */


  var currentSelectedYear = 2026;
  var currentSelectedMonth = 11;
  var tempSelectedYear = 2026;
  var tempSelectedMonth = 11;
  var currentFilter = 'all';

  // State for Custom Fintech Calendar Range Picker
  var customCalYear = 2026;
  var customCalMonth = 11; // 1-12
  var rangeStartDate = new Date(2026, 10, 1);  // 2026-11-01
  var rangeEndDate = new Date(2026, 10, 18);   // 2026-11-18
  var selectingTarget = 'start'; // 'start' | 'end'
  var activePresetName = '이번 달';

  function formatDateObj(d) {
    var y = d.getFullYear();
    var m = (d.getMonth() + 1 < 10 ? '0' : '') + (d.getMonth() + 1);
    var day = (d.getDate() < 10 ? '0' : '') + d.getDate();
    return y + '.' + m + '.' + day;
  }

  function formatShortDateObj(d) {
    var m = (d.getMonth() + 1 < 10 ? '0' : '') + (d.getMonth() + 1);
    var day = (d.getDate() < 10 ? '0' : '') + d.getDate();
    return m + '.' + day;
  }

  function isSameDay(d1, d2) {
    if (!d1 || !d2) return false;
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getDate() === d2.getDate();
  }

  function switchPickerMode(mode) {
    var tabMonth = document.getElementById('picker-tab-month');
    var tabCustom = document.getElementById('picker-tab-custom');
    var panelMonth = document.getElementById('month-grid-container');
    var panelCustom = document.getElementById('custom-range-container');

    if (mode === 'month') {
      if (tabMonth) tabMonth.className = 'py-2.5 rounded-xl bg-white text-slate-900 shadow-sm transition-all text-center font-bold cursor-pointer';
      if (tabCustom) tabCustom.className = 'py-2.5 rounded-xl text-slate-500 hover:text-slate-900 font-medium transition-all text-center cursor-pointer';
      if (panelMonth) panelMonth.classList.remove('hidden');
      if (panelCustom) panelCustom.classList.add('hidden');
    } else {
      if (tabCustom) tabCustom.className = 'py-2.5 rounded-xl bg-white text-slate-900 shadow-sm transition-all text-center font-bold cursor-pointer';
      if (tabMonth) tabMonth.className = 'py-2.5 rounded-xl text-slate-500 hover:text-slate-900 font-medium transition-all text-center cursor-pointer';
      if (panelCustom) panelCustom.classList.remove('hidden');
      if (panelMonth) panelMonth.classList.add('hidden');
      renderCustomCalendar();
      updateRangeBoxUI();
    }
  }

  function setSelectingTarget(target) {
    selectingTarget = target;
    updateRangeBoxUI();
  }

  function updateRangeBoxUI() {
    var boxStart = document.getElementById('box-start-date');
    var boxEnd = document.getElementById('box-end-date');
    var lblStart = document.getElementById('label-start-date');
    var lblEnd = document.getElementById('label-end-date');
    var dispStart = document.getElementById('display-custom-start');
    var dispEnd = document.getElementById('display-custom-end');
    var summaryText = document.getElementById('custom-range-summary-text');

    if (dispStart) dispStart.textContent = formatDateObj(rangeStartDate);
    if (dispEnd) dispEnd.textContent = formatDateObj(rangeEndDate);

    if (selectingTarget === 'start') {
      if (boxStart) {
        boxStart.className = 'flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white shadow-xs border-[#3182F6] ring-2 ring-blue-500/10 cursor-pointer';
      }
      if (boxEnd) {
        boxEnd.className = 'flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white border-transparent hover:border-slate-200 cursor-pointer';
      }
      if (lblStart) {
        lblStart.textContent = '시작일 선택 중';
        lblStart.className = 'text-[10px] font-bold uppercase tracking-wider text-[#3182F6]';
      }
      if (lblEnd) {
        lblEnd.textContent = '종료일';
        lblEnd.className = 'text-[10px] font-bold uppercase tracking-wider text-slate-400';
      }
    } else {
      if (boxEnd) {
        boxEnd.className = 'flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white shadow-xs border-[#3182F6] ring-2 ring-blue-500/10 cursor-pointer';
      }
      if (boxStart) {
        boxStart.className = 'flex flex-col text-left p-2.5 rounded-xl border-2 transition-all bg-white border-transparent hover:border-slate-200 cursor-pointer';
      }
      if (lblEnd) {
        lblEnd.textContent = '종료일 선택 중';
        lblEnd.className = 'text-[10px] font-bold uppercase tracking-wider text-[#3182F6]';
      }
      if (lblStart) {
        lblStart.textContent = '시작일';
        lblStart.className = 'text-[10px] font-bold uppercase tracking-wider text-slate-400';
      }
    }

    if (summaryText) {
      var diffTime = Math.abs(rangeEndDate.getTime() - rangeStartDate.getTime());
      var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      summaryText.textContent = '총 ' + diffDays + '일간 조회 (' + formatShortDateObj(rangeStartDate) + ' ~ ' + formatShortDateObj(rangeEndDate) + ')';
    }
  }

  function changeCustomMonth(offset) {
    customCalMonth += offset;
    if (customCalMonth > 12) {
      customCalMonth = 1;
      customCalYear += 1;
    } else if (customCalMonth < 1) {
      customCalMonth = 12;
      customCalYear -= 1;
    }
    renderCustomCalendar();
  }

  function renderCustomCalendar() {
    var headerLabel = document.getElementById('custom-cal-header-label');
    if (headerLabel) {
      headerLabel.textContent = customCalYear + '년 ' + customCalMonth + '월';
    }

    var grid = document.getElementById('custom-calendar-grid');
    if (!grid) return;
    grid.innerHTML = '';

    // First day of month & total days
    var firstDayIndex = new Date(customCalYear, customCalMonth - 1, 1).getDay();
    var lastDate = new Date(customCalYear, customCalMonth, 0).getDate();

    // Previous month filler days
    var prevLastDate = new Date(customCalYear, customCalMonth - 1, 0).getDate();
    for (var p = firstDayIndex - 1; p >= 0; p--) {
      var prevDayNum = prevLastDate - p;
      var emptyCell = document.createElement('div');
      emptyCell.className = 'h-9 flex items-center justify-center text-xs text-slate-300 select-none';
      emptyCell.textContent = prevDayNum;
      grid.appendChild(emptyCell);
    }

    // Days in current month
    for (var day = 1; day <= lastDate; day++) {
      var thisDate = new Date(customCalYear, customCalMonth - 1, day);
      var dayOfWeek = thisDate.getDay();
      var isStart = isSameDay(thisDate, rangeStartDate);
      var isEnd = isSameDay(thisDate, rangeEndDate);
      var isBoth = isStart && isEnd;
      var isInRange = thisDate > rangeStartDate && thisDate < rangeEndDate;

      var cellWrapper = document.createElement('div');
      cellWrapper.className = 'h-9 relative flex items-center justify-center';

      // Range connector background strip
      if (isInRange) {
        var rangeBg = document.createElement('div');
        rangeBg.className = 'absolute inset-y-1 inset-x-0 bg-blue-50';
        cellWrapper.appendChild(rangeBg);
      } else if (isStart && !isBoth) {
        var startBg = document.createElement('div');
        startBg.className = 'absolute inset-y-1 right-0 left-1/2 bg-blue-50';
        cellWrapper.appendChild(startBg);
      } else if (isEnd && !isBoth) {
        var endBg = document.createElement('div');
        endBg.className = 'absolute inset-y-1 left-0 right-1/2 bg-blue-50';
        cellWrapper.appendChild(endBg);
      }

      // Date button/circle
      var dayBtn = document.createElement('button');
      dayBtn.type = 'button';
      dayBtn.setAttribute('data-day', day);
      dayBtn.onclick = (function(d) {
        return function() {
          onDateCellClick(d);
        };
      })(new Date(customCalYear, customCalMonth - 1, day));

      var btnClasses = 'relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ';
      if (isStart || isEnd) {
        btnClasses += 'bg-[#3182F6] text-white font-bold shadow-md shadow-blue-500/30 scale-105';
      } else if (isInRange) {
        btnClasses += 'text-blue-700 font-bold hover:bg-blue-100/70';
      } else {
        if (dayOfWeek === 0) {
          btnClasses += 'text-rose-500 hover:bg-slate-100';
        } else if (dayOfWeek === 6) {
          btnClasses += 'text-blue-500 hover:bg-slate-100';
        } else {
          btnClasses += 'text-slate-800 hover:bg-slate-100';
        }
      }

      dayBtn.className = btnClasses;
      dayBtn.textContent = day;

      cellWrapper.appendChild(dayBtn);
      grid.appendChild(cellWrapper);
    }
  }

  function onDateCellClick(clickedDate) {
    if (selectingTarget === 'start') {
      rangeStartDate = clickedDate;
      if (rangeEndDate < rangeStartDate) {
        // Automatically shift end date if start is greater
        rangeEndDate = new Date(rangeStartDate);
      }
      selectingTarget = 'end';
    } else {
      if (clickedDate < rangeStartDate) {
        rangeStartDate = clickedDate;
      } else {
        rangeEndDate = clickedDate;
        selectingTarget = 'start';
      }
    }
    // Deselect preset chip active state if custom clicked
    activePresetName = '';
    updatePresetChipsUI();
    updateRangeBoxUI();
    renderCustomCalendar();
  }

  function selectQuickPreset(presetName) {
    activePresetName = presetName;
    var baseYear = 2026;
    var baseMonth = 11; // November
    customCalYear = baseYear;
    customCalMonth = baseMonth;

    if (presetName === '최근 7일') {
      rangeStartDate = new Date(2026, 10, 4);
      rangeEndDate = new Date(2026, 10, 10);
    } else if (presetName === '이번 달') {
      rangeStartDate = new Date(2026, 10, 1);
      rangeEndDate = new Date(2026, 10, 18);
    } else if (presetName === '지난 달') {
      customCalMonth = 10;
      rangeStartDate = new Date(2026, 9, 1);
      rangeEndDate = new Date(2026, 9, 31);
    } else if (presetName === '최근 30일') {
      rangeStartDate = new Date(2026, 9, 19);
      rangeEndDate = new Date(2026, 10, 18);
    }

    selectingTarget = 'start';
    updatePresetChipsUI();
    updateRangeBoxUI();
    renderCustomCalendar();
  }

  function updatePresetChipsUI() {
    var chips = document.querySelectorAll('.preset-chip');
    chips.forEach(function(c) {
      if (c.textContent.trim() === activePresetName) {
        c.className = 'preset-chip px-3 py-1.5 rounded-full text-xs font-bold bg-blue-50 text-blue-600 border border-blue-200 shadow-xs transition-all shrink-0 cursor-pointer';
      } else {
        c.className = 'preset-chip px-3 py-1.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-all shrink-0 cursor-pointer';
      }
    });
  }

  function applyCustomDateRange() {
    var sStr = formatShortDateObj(rangeStartDate);
    var eStr = formatShortDateObj(rangeEndDate);
    var rangeText = sStr + ' ~ ' + eStr;
    var fullRangeText = formatDateObj(rangeStartDate) + ' ~ ' + formatShortDateObj(rangeEndDate);

    var display = document.getElementById('selected-month-display');
    if (display) {
      display.textContent = fullRangeText;
    }

    var titleEl = document.getElementById('summary-title');
    if (titleEl) {
      titleEl.textContent = rangeText + ' 내역';
    }

    var timelineHeader = document.getElementById('daily-timeline-header');
    if (timelineHeader) {
      timelineHeader.textContent = rangeText + ' 상세';
    }

    closeMonthPicker();
    showToast(fullRangeText + ' 기간으로 설정되었습니다');
  }

  function openMonthPicker() {
    tempSelectedYear = currentSelectedYear;
    tempSelectedMonth = currentSelectedMonth;
    updateMonthPickerUI();
    var modal = document.getElementById('month-picker-modal');
    if (modal) {
      modal.classList.remove('hidden');
    }
  }

  function closeMonthPicker() {
    var modal = document.getElementById('month-picker-modal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  function changePickerYear(offset) {
    tempSelectedYear += offset;
    updateMonthPickerUI();
  }

  function selectPickerMonth(m) {
    tempSelectedMonth = m;
    updateMonthPickerUI();
  }

  function setPickerToday() {
    tempSelectedYear = 2026;
    tempSelectedMonth = 11;
    updateMonthPickerUI();
  }

  function updateMonthPickerUI() {
    var yLabel = document.getElementById('picker-current-year');
    if (yLabel) yLabel.textContent = tempSelectedYear + '년';

    var grid = document.getElementById('picker-month-grid');
    if (!grid) return;
    var btns = grid.querySelectorAll('button');
    btns.forEach(function(b, idx) {
      var monthNum = idx + 1;
      if (monthNum === tempSelectedMonth) {
        b.className = 'py-2.5 rounded-xl text-xs font-bold bg-[#3182F6] text-white shadow-md shadow-blue-500/35 transition-all scale-[1.02] cursor-pointer';
      } else {
        b.className = 'py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all cursor-pointer';
      }
    });
  }

  function applyMonthPicker() {
    currentSelectedYear = tempSelectedYear;
    currentSelectedMonth = tempSelectedMonth;
    var display = document.getElementById('selected-month-display');
    if (display) {
      display.textContent = currentSelectedYear + '년 ' + currentSelectedMonth + '월';
    }
    
    // Update labels corresponding to the new month
    updateSummaryDataForMonth(currentSelectedMonth);
    closeMonthPicker();
    showToast(currentSelectedYear + '년 ' + currentSelectedMonth + '월 가계부 내역으로 변경되었습니다');
  }

  function updateSummaryDataForMonth(month) {
    var titleEl = document.getElementById('summary-title');
    var timelineHeader = document.getElementById('daily-timeline-header');
    if (currentFilter === 'expense') {
      if (titleEl) titleEl.textContent = month + '월 총 지출';
    } else if (currentFilter === 'savings') {
      if (titleEl) titleEl.textContent = month + '월 모은 돈';
    } else {
      if (titleEl) titleEl.textContent = month + '월 전체 내역';
    }
    if (timelineHeader) {
      timelineHeader.textContent = month + '월 10일 화요일';
    }
  }

  function filterCategory(cat) {
    currentFilter = cat;
    var tabs = {
      all: document.getElementById('cat-filter-all'),
      expense: document.getElementById('cat-filter-expense'),
      savings: document.getElementById('cat-filter-savings')
    };

    var activeClass = 'cat-tab shrink-0 px-3.5 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-full shadow-sm transition-all';
    var inactiveClass = 'cat-tab shrink-0 px-3.5 py-1.5 bg-white text-slate-600 text-xs font-medium rounded-full border border-slate-200/90 shadow-sm hover:bg-slate-50 transition-all';

    for (var key in tabs) {
      if (tabs[key]) {
        tabs[key].className = (key === cat) ? activeClass : inactiveClass;
      }
    }

    var titleEl = document.getElementById('summary-title');
    var amountEl = document.getElementById('summary-amount');
    var budgetText = document.getElementById('summary-budget-text');
    var badgeSub = document.getElementById('summary-badge-sub');
    var progressLabel = document.getElementById('summary-progress-label');
    var progressTarget = document.getElementById('summary-progress-target');
    var progressBar = document.getElementById('summary-progress-bar');
    var dailyTxCount = document.getElementById('daily-tx-count');

    var items = document.querySelectorAll('.tx-item');
    items.forEach(function(item) {
      var itemCat = item.getAttribute('data-category');
      if (cat === 'all') {
        item.style.display = 'flex';
      } else if (itemCat === cat) {
        item.style.display = 'flex';
      } else {
        item.style.display = 'none';
      }
    });

    if (cat === 'expense') {
      if (titleEl) titleEl.textContent = currentSelectedMonth + '월 총 지출';
      if (amountEl) amountEl.textContent = '270,447';
      if (budgetText) budgetText.innerHTML = '남은 예산 <strong class="text-slate-900 font-bold">236,121원</strong> (예산 506,568원)';
      if (badgeSub) badgeSub.textContent = '남은 20일';
      if (progressLabel) progressLabel.innerHTML = '예산 506,568원 중 <strong class="text-blue-600 font-bold">53.4%</strong> 사용';
      if (progressTarget) progressTarget.textContent = '목표 50%';
      if (progressBar) progressBar.style.width = '53.4%';
      if (dailyTxCount) dailyTxCount.textContent = '지출 2건 · 총 -34,500원';
    } else if (cat === 'savings') {
      if (titleEl) titleEl.textContent = currentSelectedMonth + '월 모은 돈';
      if (amountEl) amountEl.textContent = '400,000';
      if (budgetText) budgetText.innerHTML = '목표 저축액 <strong class="text-teal-600 font-bold">500,000원</strong> 달성중';
      if (badgeSub) badgeSub.textContent = '달성률 80%';
      if (progressLabel) progressLabel.innerHTML = '목표 500,000원 중 <strong class="text-teal-600 font-bold">80.0%</strong> 달성';
      if (progressTarget) progressTarget.textContent = '목표 100%';
      if (progressBar) progressBar.style.width = '80.0%';
      if (dailyTxCount) dailyTxCount.textContent = '예적금 2건 · 총 +400,000원';
    } else {
      if (titleEl) titleEl.textContent = currentSelectedMonth + '월 전체 내역';
      if (amountEl) amountEl.textContent = '670,447';
      if (budgetText) budgetText.innerHTML = '남은 예산 <strong class="text-slate-900 font-bold">236,121원</strong>';
      if (badgeSub) badgeSub.textContent = '남은 20일';
      if (progressLabel) progressLabel.innerHTML = '예산 506,568원 중 <strong class="text-blue-600 font-bold">53.4%</strong> 사용';
      if (progressTarget) progressTarget.textContent = '목표 50%';
      if (progressBar) progressBar.style.width = '53.4%';
      if (dailyTxCount) dailyTxCount.textContent = '내역 4건 · 총 670,447원';
    }
  }

  function switchLedgerView(mode) {
    var cal = document.getElementById('calendar-view-container');
    var list = document.getElementById('list-view-container');
    var btnList = document.getElementById('tab-btn-list');
    var btnCal = document.getElementById('tab-btn-calendar');

    var activeBtnClass = 'inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold text-white bg-slate-900 shadow-sm transition-all';
    var inactiveBtnClass = 'inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold text-slate-600 transition-all hover:text-slate-900';

    if (mode === 'calendar') {
      if (cal) cal.classList.remove('hidden');
      if (list) list.classList.add('hidden');
      if (btnCal) btnCal.className = activeBtnClass;
      if (btnList) btnList.className = inactiveBtnClass;
    } else {
      if (cal) cal.classList.add('hidden');
      if (list) list.classList.remove('hidden');
      if (btnList) btnList.className = activeBtnClass;
      if (btnCal) btnCal.className = inactiveBtnClass;
    }
  }

  var toastTimer = null;
  function showToast(msg) {
    var toast = document.getElementById('toast-notification');
    var txt = document.getElementById('toast-text');
    if (!toast || !txt) return;
    txt.textContent = msg;
    toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function() {
      toast.classList.add('hidden');
    }, 2800);
  }

  function hideToast() {
    var toast = document.getElementById('toast-notification');
    if (toast) toast.classList.add('hidden');
  }

  function triggerAnalysisReport() {
    showToast(currentSelectedMonth + '월 소비 분석 리포트로 이동합니다');
  }

  // Initialize custom calendar UI on load
  document.addEventListener('DOMContentLoaded', function() {
    renderCustomCalendar();
    updateRangeBoxUI();
  });


  // MOA: 직접 기록한 내역을 달력·목록·합계에 반영 (src/lib/bridge.js ledgerBridge)
  const __led = app.moa.ledgerBridge({
    document, app, root, data: calendarTxMockData,
    get: { day: () => currentSelectedCalDay, filter: () => currentFilter, year: () => currentSelectedYear, month: () => currentSelectedMonth,
      rangeStart: () => rangeStartDate, rangeEnd: () => rangeEndDate, target: () => selectingTarget },
    set: { day: (d) => { currentSelectedCalDay = d; } },
    orig: { renderCalendarDayDetails, filterCategory, applyMonthPicker, applyCustomDateRange, onDateCellClick, setSelectingTarget, updateRangeBoxUI },
  });
  renderCalendarDayDetails = __led.api.renderCalendarDayDetails; filterCategory = __led.api.filterCategory;
  applyMonthPicker = __led.api.applyMonthPicker; applyCustomDateRange = __led.api.applyCustomDateRange;
  onDateCellClick = __led.api.onDateCellClick; setSelectingTarget = __led.api.setSelectingTarget; updateRangeBoxUI = __led.api.updateRangeBoxUI;
  document.addEventListener('DOMContentLoaded', () => __led.init());

  const api = {};
  if (typeof selectCalendarDay === 'function') api.selectCalendarDay = selectCalendarDay;
  if (typeof renderCalendarDayDetails === 'function') api.renderCalendarDayDetails = renderCalendarDayDetails;
  if (typeof formatDateObj === 'function') api.formatDateObj = formatDateObj;
  if (typeof formatShortDateObj === 'function') api.formatShortDateObj = formatShortDateObj;
  if (typeof isSameDay === 'function') api.isSameDay = isSameDay;
  if (typeof switchPickerMode === 'function') api.switchPickerMode = switchPickerMode;
  if (typeof setSelectingTarget === 'function') api.setSelectingTarget = setSelectingTarget;
  if (typeof updateRangeBoxUI === 'function') api.updateRangeBoxUI = updateRangeBoxUI;
  if (typeof changeCustomMonth === 'function') api.changeCustomMonth = changeCustomMonth;
  if (typeof renderCustomCalendar === 'function') api.renderCustomCalendar = renderCustomCalendar;
  if (typeof onDateCellClick === 'function') api.onDateCellClick = onDateCellClick;
  if (typeof selectQuickPreset === 'function') api.selectQuickPreset = selectQuickPreset;
  if (typeof updatePresetChipsUI === 'function') api.updatePresetChipsUI = updatePresetChipsUI;
  if (typeof applyCustomDateRange === 'function') api.applyCustomDateRange = applyCustomDateRange;
  if (typeof openMonthPicker === 'function') api.openMonthPicker = openMonthPicker;
  if (typeof closeMonthPicker === 'function') api.closeMonthPicker = closeMonthPicker;
  if (typeof changePickerYear === 'function') api.changePickerYear = changePickerYear;
  if (typeof selectPickerMonth === 'function') api.selectPickerMonth = selectPickerMonth;
  if (typeof setPickerToday === 'function') api.setPickerToday = setPickerToday;
  if (typeof updateMonthPickerUI === 'function') api.updateMonthPickerUI = updateMonthPickerUI;
  if (typeof applyMonthPicker === 'function') api.applyMonthPicker = applyMonthPicker;
  if (typeof updateSummaryDataForMonth === 'function') api.updateSummaryDataForMonth = updateSummaryDataForMonth;
  if (typeof filterCategory === 'function') api.filterCategory = filterCategory;
  if (typeof switchLedgerView === 'function') api.switchLedgerView = switchLedgerView;
  if (typeof showToast === 'function') api.showToast = showToast;
  if (typeof hideToast === 'function') api.hideToast = hideToast;
  if (typeof triggerAnalysisReport === 'function') api.triggerAnalysisReport = triggerAnalysisReport;
  return { api, cleanup };
}
