/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s08 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Record.controller';
import './Record.css';





function RecordScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {});
  return (
    <div ref={rootRef} className="stitch-screen scr-record min-h-full bg-[#F2F4F6] text-slate-800 antialiased flex justify-center selection:bg-blue-100">
{/* Toast Notification Element */}
<div className="fixed top-6 left-1/2 -translate-x-1/2 z-[120] bg-slate-900/95 backdrop-blur text-white text-sm font-semibold px-5 py-3 rounded-full shadow-2xl flex items-center gap-2 transition-all duration-300 text-center max-w-[90vw] opacity-0 translate-y-[-12px] pointer-events-none" id="toast">
<span id="toastIcon">
🏷️
</span>
{" "}
<span id="toastMessage">
고민 목록에 안전하게 보관되었습니다! 가계부 잔액은 차감되지 않았어요.
</span>
</div>
{/* ==================== MAIN CONTAINER / ROUTE WRAPPER ==================== */}
<div className="w-full max-w-[440px] min-h-full bg-[#F2F4F6] flex flex-col relative" id="appRoot">
{/* ==================== SCREEN A: FORM SCREEN (구매 고민 & 내역 기록) ==================== */}
<div className="w-full min-h-full flex flex-col pb-32 transition-opacity duration-300" id="formScreen">
{/* BEGIN: TopNavigation */}
<header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-100 px-4 h-14 flex items-center justify-between" data-purpose="top-app-bar">
{/* Back button */}
<button aria-label="가계부로 돌아가기" className="w-10 h-10 -ml-2 flex items-center justify-center text-slate-800 tap-action" onClick={(event) => run(event, (c) => { c.returnToLedgerView('가계부로 돌아왔습니다.'); })} type="button">
<svg className="w-6 h-6 stroke-[2.2]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M15.75 19.5L8.25 12l7.5-7.5" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</button>
{/* Screen Title */}
<h1 className="text-[17px] font-bold text-slate-900 tracking-tight" id="screenTitle">
모아 구매 고민하기
</h1>
{/* Placeholder to balance back button */}
<button className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-2 py-1 rounded tap-action -mr-1" onClick={(event) => run(event, (c) => { c.returnToLedgerView('취소하고 가계부로 이동했습니다.'); })} type="button">
취소
</button>
</header>
{/* END: TopNavigation */}
{/* BEGIN: TabSwitcher */}
<nav className="px-4 mt-3" data-purpose="segmented-tab-control">
{/* 2-Tab Segmented Container */}
<div className="bg-slate-200/80 p-1 rounded-2xl flex items-center relative">
{/* Tab 1: 내역 기록 */}
<button className="text-slate-500 hover:text-slate-700 font-medium py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all rounded-xl tap-action" id="tabRecordBtn" onClick={(event) => run(event, (c) => { c.switchTab('record'); })} type="button">
<span className="w-1.5 h-1.5 rounded-full bg-blue-500 hidden" id="tabRecordDot" />
{" "}
<svg className="w-4 h-4 transition-colors text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M4 6h16M4 12h10M4 18h7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.2" />
</svg>
{" "}
<span className="text-sm">
내역 기록
</span>
</button>
{/* Tab 2: 구매 고민 */}
<button className="bg-white rounded-xl shadow-sm text-slate-900 font-bold py-2.5 px-3 flex items-center justify-center gap-1.5 flex-1 transition-all tap-action" id="tabConsiderBtn" onClick={(event) => run(event, (c) => { c.switchTab('consider'); })} type="button">
<span className="w-1.5 h-1.5 rounded-full bg-blue-500" id="tabConsiderDot" />
{" "}
<svg className="w-4 h-4 transition-colors text-slate-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
{" "}
<span className="text-sm">
구매 고민
</span>
</button>
</div>
{/* Segment Caption */}
<p className="text-center text-xs text-slate-500 mt-2.5 mb-1 tracking-tight transition-all" id="tabDescription">
구매 고민은 가계부 잔액에 바로 반영되지 않으며, 고민 후 결정할 수 있어요.
</p>
</nav>
{/* END: TabSwitcher */}
{/* ==================== TAB 1 VIEW: 내역 기록 ==================== */}
<div className="flex flex-col hidden" id="recordView">
<main className="px-4 py-2 flex flex-col gap-3" data-purpose="transaction-record-form">
{/* CARD 1: 기록 유형 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="record-type-selector">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
기록 유형
</label>
</div>
<div className="grid grid-cols-3 gap-2" id="recordTypeGroup">
<button className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-xl py-3 text-sm text-center transition-colors border-2 border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordType(event.currentTarget, 'expense'); })} type="button">
지출
</button>
{" "}
<button className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-xl py-3 text-sm text-center transition-colors border-2 border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordType(event.currentTarget, 'income'); })} type="button">
수입
</button>
{" "}
<button className="border-2 border-blue-500 bg-blue-50/50 text-blue-600 font-bold rounded-xl py-3 text-sm text-center shadow-sm tap-action" onClick={(event) => run(event, (c) => { c.selectRecordType(event.currentTarget, 'transfer'); })} type="button">
이체·저축
</button>
</div>
</section>
{/* CARD 2: 지출 금액 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="expense-amount-input">
<div className="flex items-center justify-between mb-2">
<label className="text-xs font-bold text-slate-700" id="recordAmountLabel">
지출 금액
</label>
<div className="flex items-center gap-1.5">
<span className="bg-blue-50 text-blue-600 text-[11px] font-bold px-2 py-0.5 rounded-full">
현재 잔액 420,000원
</span>
</div>
</div>
<div className="flex items-center justify-between py-1">
<div className="inline-flex items-baseline gap-1 flex-1 min-w-0">
<input aria-label="지출 금액 입력" className="text-3xl font-extrabold text-slate-900 tracking-tight bg-transparent border-0 p-0 focus:ring-0 outline-none text-left selection:bg-blue-100 w-auto min-w-[32px] max-w-[200px]" id="expenseAmountInput" inputMode="numeric" onInput={(event) => run(event, (c) => { c.handleExpenseInput(event.currentTarget.value); })} placeholder="0" type="text" defaultValue="6,500" />
</div>
<div className="flex items-center gap-2 shrink-0">
<button aria-label="금액 초기화" className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center text-xs tap-action" onClick={(event) => run(event, (c) => { c.resetExpenseAmount(); })} type="button">
✕
</button>
</div>
</div>
<div className="flex items-center gap-2 mt-3 pt-1">
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addExpenseAmount(1000); })} type="button">
+1천
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addExpenseAmount(5000); })} type="button">
+5천
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addExpenseAmount(10000); })} type="button">
+1만
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addExpenseAmount(50000); })} type="button">
+5만
</button>
</div>
</section>
{/* CARD 3: 사용처 / 상품명 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="merchant-input">
<div className="flex items-center justify-between mb-2">
<label className="text-xs font-bold text-slate-700">
사용처 / 상품명
</label>
{" "}
<span className="text-[11px] text-slate-400">
지출처 입력
</span>
</div>
<div className="relative bg-slate-50 border border-slate-200/80 rounded-xl px-3.5 py-3 flex items-center justify-between">
<input className="w-full bg-transparent border-0 p-0 text-sm font-semibold text-slate-900 focus:ring-0 outline-none" id="merchantInput" placeholder="사용처를 입력하세요" type="text" defaultValue="스타벅스 역삼점" />
{" "}
<button aria-label="입력 지우기" className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center text-xs ml-2 shrink-0 tap-action" onClick={(event) => run(event, (c) => { c.clearMerchantInput(); })} type="button">
✕
</button>
</div>
</section>
{/* CARD 4: 카테고리 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="category-selector">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
카테고리
</label>
</div>
<div className="grid grid-cols-4 gap-2" id="recordCategoryGroup">
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '디지털/가전'); })} type="button">
디지털/가전
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '식비'); })} type="button">
식비
</button>
{" "}
<button className="border border-blue-500 bg-blue-50 text-blue-600 font-bold py-2 rounded-xl text-xs tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '카페/간식'); })} type="button">
카페/간식
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '쇼핑'); })} type="button">
쇼핑
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '교통'); })} type="button">
교통
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '의료/건강'); })} type="button">
의료/건강
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '생활/마트'); })} type="button">
생활/마트
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectRecordCategory(event.currentTarget, '기타'); })} type="button">
기타
</button>
</div>
</section>
{/* CARD 5: 결제 일시 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="datetime-selector">
<div className="flex items-center justify-between mb-2.5">
<label className="text-xs font-bold text-slate-700">
결제 일시
</label>
{" "}
<label className="flex items-center gap-1.5 cursor-pointer text-xs text-slate-500 select-none">
<input className="w-3.5 h-3.5 rounded text-blue-500 border-slate-300 focus:ring-0 tap-action" id="timeUnknownCheck" onChange={(event) => run(event, (c) => { c.toggleTimeUnknown(event.currentTarget.checked); })} type="checkbox" />
{" "}
<span>
시간 모름
</span>
</label>
</div>
<div className="border border-slate-200/70 rounded-xl p-3 flex items-center justify-between bg-white">
<div className="flex items-center gap-2.5">
<div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<rect height="18" rx="2" strokeWidth="2" width="18" x="3" y="4" />
<line strokeLinecap="round" strokeWidth="2" x1="16" x2="16" y1="2" y2="6" />
<line strokeLinecap="round" strokeWidth="2" x1="8" x2="8" y1="2" y2="6" />
<line strokeWidth="2" x1="3" x2="21" y1="10" y2="10" />
</svg>
</div>
<div>
<div className="flex items-center gap-1.5">
<span className="text-sm font-bold text-slate-900" id="recordDateText">
2026. 11. 10 (화)
</span>
{" "}
<span className="bg-blue-50 text-blue-600 font-bold text-[11px] px-1.5 py-0.5 rounded" id="recordTimeBadge">
14:20
</span>
</div>
<p className="text-[11px] text-slate-400 mt-0.5">
지출 캘린더 및 잔액 실시간 반영
</p>
</div>
</div>
<button className="text-xs text-blue-600 font-semibold border border-blue-100 rounded-lg px-2.5 py-1.5 bg-white hover:bg-blue-50 transition-colors flex items-center gap-0.5 tap-action" onClick={(event) => run(event, (c) => { c.changeRecordDate(); })} type="button">
변경{" "}
<svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
</svg>
</button>
</div>
</section>
{/* CARD 6: 결제수단 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="payment-method-selector">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
결제수단
</label>
</div>
<div className="grid grid-cols-2 gap-2.5" id="recordPaymentGroup">
<button className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectRecordPayment(event.currentTarget, '체크카드 (즉시 출금)'); })} type="button">
<span className="text-sm font-bold text-slate-700">
체크카드
</span>
{" "}
<span className="text-[11px] text-slate-400">
구매일 즉시 출금
</span>
</button>
{" "}
<button className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectRecordPayment(event.currentTarget, '신용카드 (청구일 결제)'); })} type="button">
<span className="text-sm font-bold text-slate-700">
신용카드
</span>
{" "}
<span className="text-[11px] text-slate-400">
청구일 결제
</span>
</button>
{" "}
<button className="border-2 border-blue-500 bg-blue-50/40 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action" onClick={(event) => run(event, (c) => { c.selectRecordPayment(event.currentTarget, '계좌이체 (직접 이체)'); })} type="button">
<span className="text-sm font-bold text-blue-600">
계좌이체
</span>
{" "}
<span className="text-[11px] text-blue-500 font-medium">
구매일 직접 이체
</span>
</button>
{" "}
<button className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 text-left tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectRecordPayment(event.currentTarget, '현금 지출'); })} type="button">
<span className="text-sm font-bold text-slate-700">
현금
</span>
{" "}
<span className="text-[11px] text-slate-400">
보유 현금 지출
</span>
</button>
</div>
</section>
{/* CARD 7: 메모 & 추천 태그 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="memo-section">
<div className="flex items-center justify-between mb-2">
<label className="text-xs font-bold text-slate-700">
메모
</label>
{" "}
<span className="text-[11px] text-slate-400 font-normal">
선택 사항
</span>
</div>
<div className="bg-slate-50 border border-slate-200/70 rounded-xl p-3 focus-within:border-blue-500 focus-within:bg-white transition">
<input className="w-full bg-transparent border-0 p-0 text-xs font-medium text-slate-800 outline-none focus:ring-0" id="recordMemoInput" placeholder="메모를 입력하세요" type="text" defaultValue="업무 미팅 전 커피 주문" />
</div>
<div className="flex items-center gap-1.5 mt-2.5 flex-wrap">
<span className="text-[11px] text-slate-400 font-semibold mr-1">
#추천
</span>
{" "}
<button className="text-[11px] bg-slate-100 text-slate-600 px-2 py-1 rounded-lg hover:bg-slate-200 tap-action" onClick={(event) => run(event, (c) => { c.appendTag('#커피'); })} type="button">
#커피
</button>
{" "}
<button className="text-[11px] bg-slate-100 text-slate-600 px-2 py-1 rounded-lg hover:bg-slate-200 tap-action" onClick={(event) => run(event, (c) => { c.appendTag('#미팅'); })} type="button">
#미팅
</button>
{" "}
<button className="text-[11px] bg-slate-100 text-slate-600 px-2 py-1 rounded-lg hover:bg-slate-200 tap-action" onClick={(event) => run(event, (c) => { c.appendTag('#식비'); })} type="button">
#식비
</button>
</div>
</section>
</main>
{/* Sticky Bottom Action (Record) */}
<footer className="fixed bottom-0 left-0 right-0 z-40 flex justify-center bg-gradient-to-t from-[#F2F4F6] via-[#F2F4F6]/95 to-transparent pt-3 pb-5 px-4" data-purpose="bottom-sticky-button">
<div className="w-full max-w-[440px] flex flex-col items-center">
<button className="w-full bg-tossBlue hover:bg-blue-600 tap-action text-white font-bold text-base py-4 rounded-2xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2" onClick={(event) => run(event, (c) => { c.submitRecord(); })} type="button">
<svg className="w-5 h-5 stroke-[2.5]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M4.5 12.75l6 6 9-13.5" strokeLinecap="round" strokeLinejoin="round" />
</svg>
{" "}
<span id="recordCtaText">
6,500원 지출 등록하기
</span>
</button>
<p className="text-[11px] text-slate-400 text-center mt-2">
등록 즉시 가계부 내역과 11월 총 지출에 반영됩니다.
</p>
</div>
</footer>
</div>
{/* ==================== TAB 2 VIEW: 구매 고민 (기본 뷰) ==================== */}
<div className="flex flex-col" id="considerView">
<main className="px-4 py-2 flex flex-col gap-3" data-purpose="purchase-consideration-form">
{/* CARD 1: 구매 예정 금액 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="expected-amount-card">
<div className="flex items-center justify-between mb-2">
<label className="text-xs font-bold text-slate-700">
구매 예정 금액
</label>
<div className="flex items-center gap-1.5">
<span className="bg-blue-50 text-blue-600 text-[11px] font-bold px-2 py-0.5 rounded-full">
현재 잔액 420,000원
</span>
</div>
</div>
<div className="flex items-center justify-between py-1">
<div className="inline-flex items-baseline gap-1 flex-1 min-w-0">
<input aria-label="구매 예정 금액 입력" className="text-3xl font-extrabold text-slate-900 tracking-tight bg-transparent border-0 p-0 focus:ring-0 outline-none text-left selection:bg-blue-100 w-auto min-w-[32px] max-w-[200px]" id="considerAmountInput" inputMode="numeric" onInput={(event) => run(event, (c) => { c.handleConsiderInput(event.currentTarget.value); })} placeholder="0" type="text" defaultValue="259,000" />
</div>
<div className="flex items-center gap-2 shrink-0">
<button aria-label="금액 초기화" className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center text-xs tap-action" onClick={(event) => run(event, (c) => { c.resetConsiderAmount(); })} type="button">
✕
</button>
</div>
</div>
<div className="flex items-center gap-2 mt-3 pt-1">
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addConsiderAmount(10000); })} type="button">
+1만
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addConsiderAmount(30000); })} type="button">
+3만
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addConsiderAmount(50000); })} type="button">
+5만
</button>
{" "}
<button className="flex-1 bg-slate-100 text-slate-700 font-semibold text-xs py-2 px-1 rounded-xl text-center tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.addConsiderAmount(100000); })} type="button">
+10만
</button>
</div>
</section>
{/* CARD 2: 사용처 / 상품명 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="product-name-card">
<div className="flex items-center justify-between mb-2">
<label className="text-xs font-bold text-slate-700">
사용처 / 상품명
</label>
{" "}
<span className="text-[11px] text-slate-400">
고민 중인 아이템
</span>
</div>
<div className="relative bg-slate-50 border border-slate-200/80 rounded-xl px-3.5 py-3 flex items-center justify-between">
<input className="w-full bg-transparent border-0 p-0 text-sm font-semibold text-slate-900 focus:ring-0 outline-none" id="considerProductName" placeholder="고민 중인 상품명을 입력하세요" type="text" defaultValue="소니 노이즈캔슬링 헤드폰" />
{" "}
<button aria-label="입력 지우기" className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center text-xs ml-2 shrink-0 tap-action" onClick={(event) => run(event, (c) => { c.clearConsiderProduct(); })} type="button">
✕
</button>
</div>
</section>
{/* CARD 3: 카테고리 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="consideration-category">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
카테고리
</label>
</div>
<div className="grid grid-cols-4 gap-2" id="considerCategoryGroup">
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '디지털/가전'); })} type="button">
디지털/가전
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '식비'); })} type="button">
식비
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '카페/간식'); })} type="button">
카페/간식
</button>
{" "}
<button className="border border-blue-500 bg-blue-50 text-blue-600 font-bold py-2 rounded-xl text-xs tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '쇼핑'); })} type="button">
쇼핑
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '교통'); })} type="button">
교통
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '의료/건강'); })} type="button">
의료/건강
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '생활/마트'); })} type="button">
생활/마트
</button>
{" "}
<button className="bg-slate-100 text-slate-600 font-medium py-2 rounded-xl text-xs hover:bg-slate-200 border border-transparent tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderCategory(event.currentTarget, '기타'); })} type="button">
기타
</button>
</div>
</section>
{/* CARD 4: 결제 / 구매 예정 일시 (노란색/모래시계 강조 디자인) */}
<section className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex flex-col gap-3" data-purpose="expected-datetime-card">
<div className="flex items-center justify-between">
<span className="text-xs font-bold text-slate-700">
결제 / 구매 예정 일시
</span>
{" "}
<button className="bg-amber-50 text-amber-700 border border-amber-200/80 px-2.5 py-1 text-xs font-semibold rounded-full flex items-center gap-1 tap-action" id="quickUndecidedToggle" onClick={(event) => run(event, (c) => { c.toggleUndecidedDirect(); })} type="button">
<span id="undecidedBtnLabel">
날짜 미정 선택됨 ✓
</span>
</button>
</div>
<div className="bg-amber-50/40 border border-amber-200/90 rounded-2xl p-3.5 flex items-center justify-between gap-3 cursor-pointer tap-action transition-colors hover:bg-amber-50/70" id="considerDateCardBox" onClick={(event) => run(event, (c) => { c.openDateModal(); })}>
<div className="flex items-center gap-3 min-w-0 flex-1">
<div className="w-11 h-11 rounded-xl bg-amber-100/70 border border-amber-200/60 flex items-center justify-center text-xl flex-shrink-0" id="considerDateIconBox">
⏳
</div>
<div className="min-w-0 flex-1">
<div className="flex items-center gap-2">
<span className="font-bold text-slate-800 text-[15px] leading-tight truncate" id="considerDateText">
날짜 미정
</span>
{" "}
<span className="bg-amber-100 text-amber-800 text-[11px] font-semibold px-1.5 py-0.5 rounded-md border border-amber-200 shrink-0" id="undecidedBadge">
미정
</span>
</div>
<p className="text-[12px] text-slate-500 font-medium leading-tight mt-1 truncate" id="considerDateSubtitle">
급하지 않은 소비는 여유를 두고 결정해요
</p>
</div>
</div>
<button className="flex-shrink-0 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 shadow-sm flex items-center gap-1 transition-all tap-action" onClick={(event) => run(event, (c) => { event.stopPropagation(); c.openDateModal(); })} type="button">
<span>
날짜 선택
</span>
{" "}
<svg className="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
<path d="M9 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
</svg>
</button>
</div>
</section>
{/* CARD 5: 결제수단 */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="expected-payment-method">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
결제수단
</label>
</div>
<div className="grid grid-cols-2 gap-2.5" id="considerPaymentGroup">
<div className="border-2 border-blue-500 bg-blue-50/40 rounded-xl p-3 flex flex-col justify-between h-20 tap-action" onClick={(event) => run(event, (c) => { c.selectConsiderPayment('체크카드'); })}>
<div className="flex items-center justify-between">
<span className="text-sm font-bold text-blue-600">
체크카드
</span>
<span className="text-[11px] text-blue-500 font-medium">
선택됨
</span>
</div>
<span className="text-[11px] text-slate-400">
즉시 잔액 차감
</span>
</div>
<div className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectConsiderPayment('신용카드'); })}>
<span className="text-sm font-bold text-slate-700">
신용카드
</span>
{" "}
<span className="text-[11px] text-slate-400">
청구일 지출 시뮬레이션
</span>
</div>
<div className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectConsiderPayment('계좌이체'); })}>
<span className="text-sm font-bold text-slate-700">
계좌이체
</span>
{" "}
<span className="text-[11px] text-slate-400">
예금 직접 이체
</span>
</div>
<div className="border border-slate-200/70 bg-slate-50/80 rounded-xl p-3 flex flex-col justify-between h-20 tap-action hover:bg-slate-100" onClick={(event) => run(event, (c) => { c.selectConsiderPayment('할부 / 핀테크'); })}>
<span className="text-sm font-bold text-slate-700">
할부 / 핀테크
</span>
{" "}
<span className="text-[11px] text-slate-400">
분할 납부
</span>
</div>
</div>
<div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs hidden" id="installmentBox">
<span className="text-slate-500 font-medium">
할부 개월 수
</span>
<div className="flex items-center gap-1.5" id="installmentGroup">
<button className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-medium tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.selectInstallment(event.currentTarget, '일시불'); })} type="button">
일시불
</button>
{" "}
<button className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-medium tap-action hover:bg-slate-200" onClick={(event) => run(event, (c) => { c.selectInstallment(event.currentTarget, '3개월'); })} type="button">
3개월
</button>
{" "}
<button className="px-2.5 py-1 rounded-lg bg-blue-500 text-white font-bold text-[11px] shadow-sm tap-action" onClick={(event) => run(event, (c) => { c.selectInstallment(event.currentTarget, '6개월'); })} type="button">
6개월
</button>
</div>
</div>
</section>
{/* CARD 6: 나에게 얼마나 필요한가요? */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="necessity-evaluation">
<div className="flex items-center justify-between mb-3">
<label className="text-xs font-bold text-slate-700">
나에게 얼마나 필요한가요?
</label>
</div>
<div className="grid grid-cols-3 gap-2 mb-3.5" id="necessityCardGrid">
<button className="p-3 rounded-xl text-center border-2 border-blue-500 bg-blue-50/50 hover:bg-blue-50 tap-action flex flex-col items-center justify-between h-full relative shadow-sm" id="needBtn" onClick={(event) => run(event, (c) => { c.selectNecessity('must'); })} type="button">
<div className="flex flex-col items-center gap-1 w-full">
<span className="text-base">
⚡
</span>
{" "}
<span className="text-xs font-bold text-blue-600">
꼭 필요해요
</span>
{" "}
<span className="text-[10px] text-blue-600/80 mt-0.5 leading-tight font-medium">
생필품·필수 지출
</span>
</div>
</button>
{" "}
<button className="p-3 rounded-xl text-center border border-slate-200 bg-white hover:bg-slate-50 tap-action flex flex-col items-center justify-between h-full relative" id="delayBtn" onClick={(event) => run(event, (c) => { c.selectNecessity('delay'); })} type="button">
<div className="flex flex-col items-center gap-1 w-full">
<span className="text-base">
⏳
</span>
{" "}
<span className="text-xs font-bold text-slate-700">
급하지 않아요
</span>
{" "}
<span className="text-[10px] text-slate-400 mt-0.5 leading-tight">
나중에 구매 가능
</span>
</div>
</button>
{" "}
<button className="p-3 rounded-xl text-center border border-slate-200 bg-white hover:bg-slate-50 tap-action flex flex-col items-center justify-between h-full relative" id="wantBtn" onClick={(event) => run(event, (c) => { c.selectNecessity('want'); })} type="button">
<div className="flex flex-col items-center gap-1 w-full">
<span className="text-base">
✨
</span>
{" "}
<span className="text-xs font-bold text-slate-700">
선택적 소비
</span>
{" "}
<span className="text-[10px] text-slate-400 mt-0.5 leading-tight">
만족·여가를 위한
</span>
</div>
</button>
</div>
<div>
<div className="flex items-center justify-between mb-1.5">
<label className="text-[11px] text-slate-500 font-medium block">
고민되는 이유
</label>
{" "}
<span className="text-[10px] text-slate-400" id="reasonHint">
솔직한 소비 이유를 남겨보세요
</span>
</div>
<div className="relative bg-slate-50 border border-slate-200/80 rounded-xl p-3 focus-within:border-blue-500 focus-within:bg-white transition">
<textarea className="w-full bg-transparent border-0 p-0 text-xs text-slate-800 leading-relaxed focus:ring-0 resize-none outline-none" id="necessityReasonInput" rows="2" defaultValue="기존 이어폰 배터리가 빨리 닳아서 편하긴 한데, 다음 달 필수 결제 예정금액이 있어서 고민돼요." />
</div>
</div>
</section>
{/* CARD 7: 구매하면 내 잔액은? */}
<section className="bg-white rounded-2xl p-4 card-shadow" data-purpose="simulation-balance-card">
<div className="flex items-center justify-between mb-3">
<div className="flex items-center gap-1.5">
<svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3l1 3m0 0l.5 1.5m-.5-1.5h-9.5m0 0l-.5 1.5M9 11.25v1.5M12 9v3.75m3-6v6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
</svg>
<h2 className="text-xs font-bold text-slate-800">
구매하면 내 잔액은?
</h2>
</div>
<span className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-semibold">
실시간 시뮬레이션
</span>
</div>
<div className="space-y-2 mb-3">
<div className="flex items-center justify-between text-xs py-1 border-b border-slate-100">
<span className="text-slate-500">
현재 통장 잔액
</span>
{" "}
<span className="text-slate-900 font-bold">
420,000원
</span>
</div>
<div className="flex items-center justify-between text-xs py-1 border-b border-slate-100">
<span className="text-slate-500" id="postPurchaseLabel">
구매 직후 예상 잔액 (-259,000원)
</span>
{" "}
<span className="text-blue-600 font-extrabold" id="postPurchaseBalanceText">
161,000원
</span>
</div>
<div className="flex items-center justify-between text-xs py-1">
<span className="text-slate-500">
이달 필수 지출 결제 후 잔액 (11.14 예정)
</span>
{" "}
<span className="text-rose-600 font-bold" id="postEssentialBalanceText">
39,113원
</span>
</div>
</div>
<div className="bg-slate-50 rounded-xl p-3">
<div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
<span>
잔액 변화 궤도 시뮬레이션
</span>
{" "}
<span className="text-amber-700 font-semibold px-2 py-0.5 rounded-full bg-amber-100 transition-colors" id="balanceSafetyBadge">
주의: 여유 자금 부족
</span>
</div>
<div className="h-16 w-full relative flex items-center">
<svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 300 60">
<defs>
<linearGradient id="balanceGrad" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stopColor="#3182F6" stopOpacity="0.3" />
<stop offset="100%" stopColor="#3182F6" stopOpacity="0.0" />
</linearGradient>
</defs>
<path className="transition-all duration-300" d="M0,14.7 L70,14.7 L140,37.7 L220,48.5 L300,52.5 L300,60 L0,60 Z" fill="url(#balanceGrad)" id="chartAreaPath" />
<path className="transition-all duration-300" d="M0,14.7 L70,14.7 L140,37.7 L220,48.5 L300,52.5" fill="none" id="chartLinePath" stroke="#3182F6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
<circle cx="70" cy="15" fill="#3182F6" id="dotPoint1" r="4" stroke="#ffffff" strokeWidth="2" />
<circle className="transition-all duration-300" cx="140" cy="37.7" fill="#3182F6" id="dotPoint2" r="4" stroke="#ffffff" strokeWidth="2" />
<circle className="transition-all duration-300" cx="220" cy="48.5" fill="#ef4444" id="dotPoint3" r="4" stroke="#ffffff" strokeWidth="2" />
</svg>
</div>
<div className="flex justify-between text-[10px] text-slate-400 mt-1 font-medium">
<span>
현재 (42만)
</span>
{" "}
<span id="chartLabelPost">
구매 직후 (16.1만)
</span>
{" "}
<span id="chartLabelMonthEnd">
월말 예정 (3.9만)
</span>
</div>
</div>
</section>
</main>
{/* BEGIN: StickyBottomAction (Consider) */}
<footer className="fixed bottom-0 left-0 right-0 z-40 flex justify-center bg-gradient-to-t from-[#F2F4F6] via-[#F2F4F6]/95 to-transparent pt-3 pb-5 px-4" data-purpose="bottom-sticky-button">
<div className="w-full max-w-[440px] flex flex-col items-center">
<button className="w-full bg-slate-900 hover:bg-slate-800 active:scale-[0.98] tap-action text-white font-bold text-base py-4 rounded-2xl shadow-lg shadow-slate-900/20 flex items-center justify-center gap-2 transition-transform" onClick={(event) => run(event, (c) => { c.submitConsideration(); })} type="button">
<span>
🏷️
</span>
{" "}
<span id="considerCtaText">
259,000원 고민 목록에 담기
</span>
</button>
<button className="mt-2 text-[12px] font-semibold text-blue-600 underline underline-offset-2" data-nav="/wishlist" type="button">
내 소비 결정 보관함 보기
</button>
<p className="text-[11px] text-slate-400 text-center mt-2">
통장 잔액에서 차감되지 않아요. 담은 뒤 구매·보류·포기를 정할 수 있어요.
</p>
</div>
</footer>
{/* END: StickyBottomAction (Consider) */}
</div>
</div>
{/* ==================== SCREEN B: RETURNED HOUSEHOLD LEDGER VIEW (가계부 / 홈) ==================== */}
<div className="w-full min-h-full flex flex-col pb-20 transition-opacity duration-300 hidden" id="ledgerScreen">
<header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-100 px-4 h-14 flex items-center justify-between">
<div className="flex items-center gap-2">
<span className="text-lg font-black text-slate-900 tracking-tight">
MOA
</span>
<span className="bg-blue-50 text-blue-600 text-[11px] font-bold px-2 py-0.5 rounded-full">
평행세계 가계부
</span>
</div>
<div className="flex items-center gap-2">
<button aria-label="알림" className="w-9 h-9 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center tap-action" type="button" data-nav="/notifications">
<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
</svg>
</button>
<button className="bg-blue-500 hover:bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl tap-action flex items-center gap-1 shadow-sm" onClick={(event) => run(event, (c) => { c.returnToFormView(); })} type="button">
<span>
+ 고민 담기
</span>
</button>
</div>
</header>
<main className="px-4 py-3 flex flex-col gap-3 pb-24">
<section className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100/80 rounded-2xl p-3.5 flex items-start gap-3 shadow-sm">
<div className="w-9 h-9 rounded-xl bg-blue-500 text-white flex items-center justify-center text-base shrink-0">
☀️
</div>
<div className="flex-1 min-w-0">
<div className="flex items-center justify-between">
<span className="text-xs font-bold text-blue-900">
모아 모닝 브리핑
</span>
<span className="text-[10px] text-blue-600 font-semibold">
오늘 예정
</span>
</div>
<p className="text-xs text-slate-700 mt-0.5 leading-snug font-medium">
방어한 소비 259,000원이 가상 평행세계 자산으로 무사히 적립되었어요.
</p>
</div>
</section>
<section className="bg-white rounded-2xl p-4 card-shadow">
<div className="flex items-center justify-between text-xs text-slate-500 mb-1">
<div className="flex items-center gap-1.5">
<span className="font-bold text-slate-700">
생활비 통장
</span>
<span className="text-[11px] text-slate-400">
(토스뱅크 1002)
</span>
</div>
<span className="text-[11px] text-blue-600 font-semibold">
송금
</span>
</div>
<div className="text-2xl font-black text-slate-900 tracking-tight mb-2.5">
4,120,300원
</div>
<div className="grid grid-cols-2 gap-2 pt-2.5 border-t border-slate-100 text-xs">
<div>
<span className="block text-[11px] text-slate-400">
이번 달 지출
</span>
<span className="font-bold text-slate-800">
214,500원
</span>
</div>
<div>
<span className="block text-[11px] text-slate-400">
방어한 고민 자산
</span>
<span className="font-bold text-emerald-600">
+259,000원
</span>
</div>
</div>
</section>
<section className="grid grid-cols-4 gap-2">
<button className="bg-white rounded-xl p-3 card-shadow flex flex-col items-center gap-1 tap-action hover:bg-slate-50" onClick={(event) => run(event, (c) => { c.returnToFormView(); })} type="button">
<span className="text-xl">
🏷️
</span>
<span className="text-xs font-bold text-slate-700">
고민하기
</span>
</button>
<button className="bg-white rounded-xl p-3 card-shadow flex flex-col items-center gap-1 tap-action hover:bg-slate-50" onClick={(event) => run(event, (c) => { c.returnToFormView(); c.switchTab('record'); })} type="button">
<span className="text-xl">
📝
</span>
<span className="text-xs font-bold text-slate-700">
내역기록
</span>
</button>
<button className="bg-white rounded-xl p-3 card-shadow flex flex-col items-center gap-1 tap-action hover:bg-slate-50" type="button" data-nav="/ledger/report">
<span className="text-xl">
📊
</span>
<span className="text-xs font-bold text-slate-700">
분석리포트
</span>
</button>
<button className="bg-white rounded-xl p-3 card-shadow flex flex-col items-center gap-1 tap-action hover:bg-slate-50" type="button" data-nav="/savings">
<span className="text-xl">
🪐
</span>
<span className="text-xs font-bold text-slate-700">
평행행성
</span>
</button>
</section>
<section className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-md relative overflow-hidden">
<div className="flex items-center justify-between text-xs text-slate-300 mb-1">
<span>
🪐 평행세계 시뮬레이터
</span>
<span className="text-[10px] bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 px-2 py-0.5 rounded-full font-semibold">
연 7.2% 복리
</span>
</div>
<div className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-indigo-200 mb-2">
누적 방어 자산 518,000원
</div>
<p className="text-xs text-slate-300 leading-snug">
실제로 사지 않고 아낀 돈이 가상 행성 펀드에서 무럭무럭 자라나고 있어요.
</p>
<div className="mt-3 pt-2.5 border-t border-slate-700/70 flex items-center justify-between text-xs">
<span className="text-slate-400">
우주 행성 키우기
</span>
<span className="font-bold text-amber-300">
Lv.4 네뷸라 (85%)
</span>
</div>
</section>
<section className="bg-white rounded-2xl p-4 card-shadow">
<div className="flex items-center justify-between mb-3">
<h3 className="text-xs font-bold text-slate-800">
다가오는 결제
</h3>
<span className="text-[11px] text-slate-400">
예정 3건
</span>
</div>
<div className="space-y-2.5">
<div className="flex items-center justify-between py-1 border-b border-slate-100">
<div className="flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-blue-500" />
<span className="text-xs font-bold text-slate-800">
넷플릭스 프리미엄
</span>
</div>
<span className="text-xs font-bold text-slate-800">
17,000원 (11.14)
</span>
</div>
<div className="flex items-center justify-between py-1 border-b border-slate-100">
<div className="flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-amber-500" />
<span className="text-xs font-bold text-slate-800">
아파트 관리비
</span>
</div>
<span className="text-xs font-bold text-slate-800">
104,887원 (11.20)
</span>
</div>
<div className="flex items-center justify-between py-1">
<div className="flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-emerald-500" />
<span className="text-xs font-bold text-slate-800">
소니 헤드폰 (고민 보류)
</span>
</div>
<span className="text-xs font-semibold text-blue-600">
259,000원 방어 중
</span>
</div>
</div>
</section>
</main>
</div>
</div>
{/* ==================== FULLSCREEN 3D CINEMATIC IMMERSION TRANSITION OVERLAY ==================== */}
<div className="fixed inset-0 z-[100] w-full h-full bg-gradient-to-b from-[#020512] via-[#091026] to-[#040612] flex flex-col items-center justify-between smooth-immersion-transition overflow-hidden select-none opacity-0 pointer-events-none hidden" id="fullscreen-absorption-transition">
{/* Fallback Deep Cosmic Nebula Glow Background */}
<div className="absolute inset-0 cosmic-nebula-fallback pointer-events-none" />
{/* Dedicated Three.js WebGL Canvas Mount Container */}
<div className="absolute inset-0 w-full h-full pointer-events-none" id="threejs-container-absorption" />
{/* Top Ambient Glow Gradient */}
<div className="absolute inset-x-0 top-0 h-44 bg-gradient-to-b from-[#020512]/95 via-[#020512]/50 to-transparent pointer-events-none z-10" />
{/* Bottom Ambient Glow Gradient */}
<div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-[#020512]/95 via-[#020512]/60 to-transparent pointer-events-none z-10" />
{/* TOP FLOATING HEADER / STATUS */}
<header className="w-full max-w-[440px] px-5 pt-12 pb-3 flex items-center justify-between relative z-20">
<div className="flex items-center gap-2 bg-slate-900/70 backdrop-blur-md border border-cyan-400/30 px-3.5 py-1.5 rounded-full shadow-lg shadow-cyan-500/10">
<span className="relative flex h-2 w-2">
<span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
{" "}
<span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
</span>
{" "}
<span className="text-xs font-semibold text-cyan-200 tracking-wide">
🪐 평행세계로 옮기는 중
</span>
</div>
<button aria-label="건너뛰기" className="bg-slate-900/70 hover:bg-slate-800/80 backdrop-blur-md text-slate-300 hover:text-white text-xs font-medium px-3.5 py-1.5 rounded-full border border-slate-700/60 tap-action flex items-center gap-1.5 transition-colors" onClick={(event) => run(event, (c) => { c.finishCelebrationAndReturn(); })} type="button">
<span>
건너뛰기
</span>
{" "}
<span className="text-[10px] text-slate-400">
✕
</span>
</button>
</header>
{/* CENTER DYNAMIC COPY & FINANCIAL IMPACT CARDS */}
<div className="w-full max-w-[420px] px-5 flex flex-col items-center text-center relative z-20 my-auto py-2">
{/* Cosmic Shield Icon Pulse */}
<div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600/40 via-indigo-500/30 to-cyan-400/40 border border-cyan-400/50 backdrop-blur-md mb-2 shadow-[0_0_25px_rgba(6,182,212,0.3)]">
<span className="text-2xl">
🛡️
</span>
</div>
{/* Headline Hero Copy */}
<h2 className="text-2xl font-black tracking-tight text-white mb-1.5 drop-shadow-[0_2px_12px_rgba(56,189,248,0.45)]">
<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-200 to-indigo-300" id="celebSavedAmountText">
259,000원
</span>
{" "}지켜냈어요!
</h2>
<p className="text-xs text-cyan-100/90 leading-relaxed max-w-[330px] font-medium drop-shadow-sm mb-4">
실제 잔액은 그대로예요. 이 돈을 저축하거나 투자했다면 어떻게 달라지는지 평행세계에서 비교해 볼게요.
</p>
{/* Key Financial Stats Floating Glassmorphic Badges */}
<div className="w-full flex flex-col gap-2.5">
{/* Glass Badge 1: 누적 방어 자산 & 평행 복리 예측 */}
<div className="bg-slate-900/75 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-3.5 shadow-xl flex flex-col gap-2 relative overflow-hidden">
<div className="absolute -right-6 -top-6 w-24 h-24 bg-blue-500/15 rounded-full blur-xl pointer-events-none" />
<div className="flex items-center justify-between text-xs">
<span className="text-slate-300 font-normal">
지금까지 참은 금액
</span>
{" "}
<span className="text-base font-extrabold text-emerald-400 tracking-tight drop-shadow-[0_0_8px_rgba(52,211,153,0.4)]" id="celebAccumulatedAmount">
+259,000원
</span>
</div>
<div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
<span className="text-slate-300 font-normal">
1년 뒤 가정 평가액{" "}
<span className="text-cyan-300 font-medium text-[11px]">
(연 7.2% 가정)
</span>
</span>
{" "}
<span className="text-xs font-semibold text-slate-100" id="celebCompoundAmount">
1년 뒤 약 277,648원
</span>
</div>
</div>
{/* Glass Badge 2: 우주 행성 에너지 */}
<div className="bg-gradient-to-r from-blue-950/60 via-indigo-950/60 to-purple-950/60 backdrop-blur-xl border border-indigo-500/30 rounded-xl px-3.5 py-2.5 flex items-center justify-between shadow-md">
<div className="flex items-center gap-2">
<span className="text-base">
⭐
</span>
{" "}
<span className="text-xs font-medium text-slate-200">
우주 행성 에너지
</span>
</div>
<span className="text-xs font-bold text-amber-300 drop-shadow-[0_0_5px_rgba(252,211,77,0.5)]">
+25pt 획득
</span>
</div>
</div>
</div>
{/* BOTTOM ACTIONS & AUTO-TRANSITION BAR */}
<footer className="w-full max-w-[440px] px-5 pb-8 flex flex-col gap-3 relative z-20">
{/* Progress Auto Transition Indicator */}
<div className="w-full bg-slate-900/80 backdrop-blur-md border border-slate-800/90 rounded-xl p-2.5 flex flex-col gap-1.5 shadow-md">
<div className="flex items-center justify-between text-[11px]">
<span className="text-cyan-300 font-medium flex items-center gap-1.5">
<span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
{" "}
<span id="fullscreenProgressLabel">
잠시 후 평행세계로 이동해요
</span>
</span>
{" "}
<span className="text-slate-400 text-[10px]" id="fullscreenTimeLeft">
자동 전환
</span>
</div>
<div className="w-full bg-slate-950/90 rounded-full h-1.5 overflow-hidden">
<div className="bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400 h-full rounded-full w-0 animate-progress-fullscreen" id="fullscreenProgressBar" />
</div>
</div>
{/* Action Button */}
<button className="w-full bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 active:scale-[0.98] text-white font-bold py-4 rounded-2xl shadow-xl shadow-cyan-500/25 text-sm tap-action flex items-center justify-center gap-2 transition-transform" onClick={(event) => run(event, (c) => { c.finishCelebrationAndReturn(); })} type="button">
<span>
평행세계에서 비교하기 →
</span>
</button>
</footer>
</div>
{/* ==================== DATE SELECT MODAL / BOTTOM SHEET ==================== */}
<div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm transition-opacity duration-300 opacity-0 hidden" id="datePickerModal" onClick={(event) => run(event, (c) => { c.handleDateModalBackdrop(event); })}>
<div className="w-full max-w-[440px] bg-white rounded-t-3xl p-5 shadow-2xl transform transition-transform duration-300 translate-y-full" id="datePickerSheet">
<div className="flex items-center justify-between pb-3 border-b border-slate-100">
<div className="flex items-center gap-2">
<span className="text-base font-bold text-slate-900">
구매 예정 일시 선택
</span>
{" "}
<span className="text-xs text-slate-400">
언제 살 계획인가요?
</span>
</div>
<button className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center tap-action" onClick={(event) => run(event, (c) => { c.closeDateModal(); })} type="button">
✕
</button>
</div>
<div className="my-3.5">
<button className="w-full p-3.5 rounded-2xl border-2 border-amber-500 bg-amber-50/60 shadow-sm flex items-center justify-between tap-action group" id="modalUndecidedBtn" onClick={(event) => run(event, (c) => { c.setConsiderDateUndecided(); })} type="button">
<div className="flex items-center gap-3">
<div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center text-lg shrink-0 group-hover:scale-105 transition-transform">
❓
</div>
<div className="text-left">
<div className="flex items-center gap-1.5">
<span className="text-sm font-bold text-slate-900" id="modalUndecidedTitle">
아직 몰라요 (날짜 미정)
</span>
{" "}
<span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-1.5 py-0.5 rounded">
추천
</span>
</div>
<p className="text-[11px] text-slate-500 mt-0.5">
급하지 않은 소비는 여유를 두고 결정해 보세요
</p>
</div>
</div>
<div className="w-5 h-5 rounded-full border-2 border-amber-500 flex items-center justify-center transition-colors bg-amber-500" id="modalUndecidedRadio">
<span className="w-2 h-2 rounded-full bg-white" id="modalUndecidedRadioDot" />
</div>
</button>
</div>
<div className="relative flex items-center justify-center my-2">
<div className="border-t border-slate-200 w-full" />
<span className="bg-white px-3 text-[11px] text-slate-400 shrink-0 font-medium">
또는 날짜 직접 선택
</span>
</div>
<div className="grid grid-cols-3 gap-2 my-3">
<button className="py-2.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold text-center tap-action transition" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 12 (목)', '3일간 더 생각해보기를 권장해요'); })} type="button">
3일 뒤 (11.12)
</button>
{" "}
<button className="py-2.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold text-center tap-action transition" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 15 (일)', '주말 동안 냉정하게 검토해봐요'); })} type="button">
이번 주말 (11.15)
</button>
{" "}
<button className="py-2.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold text-center tap-action transition" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 25 (수)', '다음 월급날 이후로 미루기'); })} type="button">
월급날 (11.25)
</button>
</div>
<div className="bg-slate-50 rounded-2xl p-3 border border-slate-200/80 mb-4">
<div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2 px-1">
<span>
2026년 11월
</span>
<div className="flex items-center gap-1 text-slate-400">
<span className="cursor-pointer hover:text-slate-600 px-1">
‹
</span>
{" "}
<span className="cursor-pointer hover:text-slate-600 px-1">
›
</span>
</div>
</div>
<div className="grid grid-cols-7 gap-1 text-center text-[10px] text-slate-400 mb-1 font-semibold">
<span className="text-rose-500">
일
</span>
<span>
월
</span>
<span>
화
</span>
<span>
수
</span>
<span>
목
</span>
<span>
금
</span>
<span>
토
</span>
</div>
<div className="grid grid-cols-7 gap-1 text-center text-xs">
<span className="text-slate-300 py-1.5">
1
</span>
{" "}
<span className="text-slate-300 py-1.5">
2
</span>
{" "}
<span className="text-slate-300 py-1.5">
3
</span>
{" "}
<span className="text-slate-300 py-1.5">
4
</span>
{" "}
<span className="text-slate-300 py-1.5">
5
</span>
{" "}
<span className="text-slate-300 py-1.5">
6
</span>
{" "}
<span className="text-slate-300 py-1.5">
7
</span>
{" "}
<span className="text-slate-300 py-1.5">
8
</span>
{" "}
<span className="text-slate-300 py-1.5">
9
</span>
{" "}
<span className="text-slate-700 py-1.5 bg-slate-200/60 rounded-lg font-bold">
10
</span>
{" "}
<span className="text-slate-700 py-1.5 hover:bg-slate-200 rounded-lg cursor-pointer tap-action" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 11 (수)', '내일까지 하루 더 고민해봐요'); })}>
11
</span>
{" "}
<button className="bg-blue-500 text-white font-bold py-1.5 rounded-lg shadow-sm tap-action" id="cal12Btn" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 12 (목)', '3일간 더 생각해보기를 권장해요'); })} type="button">
12
</button>
{" "}
<span className="text-slate-700 py-1.5 hover:bg-slate-200 rounded-lg cursor-pointer tap-action" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 13 (금)', '주말 전 결제 고려'); })}>
13
</span>
{" "}
<span className="text-slate-700 py-1.5 hover:bg-slate-200 rounded-lg cursor-pointer tap-action" onClick={(event) => run(event, (c) => { c.selectSpecificDate('2026. 11. 14 (토)', '필수 지출 이후 결정'); })}>
14
</span>
</div>
</div>
<div className="flex items-center gap-2">
<button className="flex-1 py-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm tap-action" onClick={(event) => run(event, (c) => { c.closeDateModal(); })} type="button">
취소
</button>
{" "}
<button className="flex-[2] py-3.5 rounded-xl bg-tossBlue hover:bg-blue-600 text-white font-bold text-sm shadow-md shadow-blue-500/20 tap-action" onClick={(event) => run(event, (c) => { c.confirmDateModal(); })} type="button">
선택 완료
</button>
</div>
</div>
</div>
{/* ==================== THREE.JS 3D PARALLEL WORLD VORTEX ENGINE ==================== */}
{/* BEGIN: Tab & Dynamic Live Calculation Script */}
{/* END: Tab & Dynamic Live Calculation Script */}
    </div>
  );
}

export default memo(RecordScreen);
