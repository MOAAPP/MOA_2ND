/* eslint-disable */
// @ts-nocheck
// Interaction logic ported from Stitch screen s04. Runs scoped to this screen's root element.
import * as THREE from 'three';
import { createScope } from '../lib/legacyScope';

export function mount(root, app) {
  const { document, window, setTimeout, setInterval, clearTimeout, clearInterval, requestAnimationFrame, cancelAnimationFrame, alert, prompt, confirm, localStorage, cleanup } = createScope(root, app);


  let toastTimer = null;

  function showToast(message) {
    const toast = document.getElementById('share-toast');
    const toastText = document.getElementById('share-toast-text');
    if (!toast) return;

    if (toastText && message) {
      toastText.innerText = message;
    }

    if (toastTimer) clearTimeout(toastTimer);

    toast.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-[-12px]');
    toast.classList.add('opacity-100', 'translate-y-0');

    toastTimer = setTimeout(() => {
      toast.classList.remove('opacity-100', 'translate-y-0');
      toast.classList.add('opacity-0', 'pointer-events-none', 'translate-y-[-12px]');
    }, 2500);
  }

  function openShareSheet() {
    const backdrop = document.getElementById('share-modal-backdrop');
    const sheet = document.getElementById('share-bottom-sheet');
    if (!backdrop || !sheet) return;

    backdrop.classList.remove('opacity-0', 'pointer-events-none');
    backdrop.classList.add('opacity-100');
    sheet.classList.remove('translate-y-full');
    sheet.classList.add('translate-y-0');
    document.body.style.overflow = 'hidden';
  }

  function closeShareSheet() {
    const backdrop = document.getElementById('share-modal-backdrop');
    const sheet = document.getElementById('share-bottom-sheet');
    if (!backdrop || !sheet) return;

    backdrop.classList.remove('opacity-100');
    backdrop.classList.add('opacity-0', 'pointer-events-none');
    sheet.classList.remove('translate-y-0');
    sheet.classList.add('translate-y-full');
    document.body.style.overflow = '';
  }

  function handleBackdropClick(e) {
    if (e.target === document.getElementById('share-modal-backdrop')) {
      closeShareSheet();
    }
  }

  function copyShareLink() {
    const shareUrl = window.location.href;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(shareUrl).then(() => {
        showToast('리포트 링크가 클립보드에 복사되었어요!');
      }).catch(() => {
        showToast('리포트 링크가 복사되었어요!');
      });
    } else {
      showToast('리포트 링크가 클립보드에 복사되었어요!');
    }
  }

  function shareViaKakao() {
    showToast('카카오톡 공유창으로 연결 중이에요');
    setTimeout(() => {
      closeShareSheet();
    }, 800);
  }

  function saveAsImageAction() {
    showToast('리포트 이미지가 갤러리에 저장되었어요!');
    setTimeout(() => {
      closeShareSheet();
    }, 1200);
  }

  function shareMoreOptions() {
    if (navigator.share) {
      navigator.share({
        title: '11월 지출 분석 리포트',
        text: '11월 총 지출 270,447원 · 지난달 대비 50,000원 절약 리포트 확인하기',
        url: window.location.href,
      }).then(() => {
        closeShareSheet();
      }).catch(() => {
        showToast('공유 옵션이 실행되었습니다.');
      });
    } else {
      showToast('추가 공유 옵션을 지원하지 않는 브라우저입니다.');
    }
  }

  // Escape key support
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeShareSheet();
    }
  });


/* ---- */


  function selectPeriod(btn, period, profitRate) {
    const parent = document.getElementById('period-chips');
    const buttons = parent.querySelectorAll('button');
    buttons.forEach(b => {
      b.className = 'px-2.5 py-1 text-xs rounded-lg text-slate-500 font-medium transition-all';
    });
    btn.className = 'px-2.5 py-1 text-xs rounded-lg bg-white text-slate-900 font-bold shadow-sm transition-all';
    
    const rateEl = document.getElementById('hero-profit-rate');
    if (rateEl) {
      rateEl.innerText = profitRate;
    }
  }

  function filterCategory(cat, btn) {
    const chipButtons = document.querySelectorAll('.category-chip');
    chipButtons.forEach(b => {
      b.className = 'category-chip px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all';
    });
    btn.className = 'category-chip px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-white shrink-0 shadow-sm transition-all';

    const stockItems = document.querySelectorAll('.stock-item');
    stockItems.forEach(item => {
      if (cat === 'all' || item.getAttribute('data-group') === cat) {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });
  }

  function togglePortfolioSettings() {
    openAddAssetModal();
  }

  function showTargetDetailModal() {
    openAddAssetModal();
  }

  function quickRebalanceAction() {
    openAddAssetModal();
  }

  function openAddAssetModal() {
    const modal = document.getElementById('rebalance-modal');
    const content = document.getElementById('rebalance-modal-content');
    if (!modal || !content) return;
    modal.classList.remove('opacity-0', 'pointer-events-none');
    modal.classList.add('opacity-100');
    content.classList.remove('translate-y-full');
    content.classList.add('translate-y-0');
  }

  function closeRebalanceModal() {
    const modal = document.getElementById('rebalance-modal');
    const content = document.getElementById('rebalance-modal-content');
    if (!modal || !content) return;
    modal.classList.remove('opacity-100');
    modal.classList.add('opacity-0', 'pointer-events-none');
    content.classList.remove('translate-y-0');
    content.classList.add('translate-y-full');
  }

  function updateSliderVal(idx, val) {
    const label = document.getElementById(`slider-val-${idx}`);
    if (label) {
      label.innerText = val + '%';
    }
  }

  function applyRebalance() {
    closeRebalanceModal();
    if (typeof showToast === 'function') {
      showToast('목표 포트폴리오 비중이 업데이트되었어요!');
    }
  }


  showToast = (m) => app.toast(m || '완료했어요');
  // MOA: 보유 현황·목표 비중 저장 (src/lib/bridge.js portfolioBridge)
  const __pf = app.moa.portfolioBridge({ document, orig: { openAddAssetModal, updateSliderVal, applyRebalance, closeRebalanceModal, showToast } });
  openAddAssetModal = __pf.api.openAddAssetModal; updateSliderVal = __pf.api.updateSliderVal; applyRebalance = __pf.api.applyRebalance;
  document.addEventListener('DOMContentLoaded', () => __pf.init());

  const api = {};
  if (typeof showToast === 'function') api.showToast = showToast;
  if (typeof openShareSheet === 'function') api.openShareSheet = openShareSheet;
  if (typeof closeShareSheet === 'function') api.closeShareSheet = closeShareSheet;
  if (typeof handleBackdropClick === 'function') api.handleBackdropClick = handleBackdropClick;
  if (typeof copyShareLink === 'function') api.copyShareLink = copyShareLink;
  if (typeof shareViaKakao === 'function') api.shareViaKakao = shareViaKakao;
  if (typeof saveAsImageAction === 'function') api.saveAsImageAction = saveAsImageAction;
  if (typeof shareMoreOptions === 'function') api.shareMoreOptions = shareMoreOptions;
  if (typeof selectPeriod === 'function') api.selectPeriod = selectPeriod;
  if (typeof filterCategory === 'function') api.filterCategory = filterCategory;
  if (typeof togglePortfolioSettings === 'function') api.togglePortfolioSettings = togglePortfolioSettings;
  if (typeof showTargetDetailModal === 'function') api.showTargetDetailModal = showTargetDetailModal;
  if (typeof quickRebalanceAction === 'function') api.quickRebalanceAction = quickRebalanceAction;
  if (typeof openAddAssetModal === 'function') api.openAddAssetModal = openAddAssetModal;
  if (typeof closeRebalanceModal === 'function') api.closeRebalanceModal = closeRebalanceModal;
  if (typeof updateSliderVal === 'function') api.updateSliderVal = updateSliderVal;
  if (typeof applyRebalance === 'function') api.applyRebalance = applyRebalance;
  return { api, cleanup };
}
