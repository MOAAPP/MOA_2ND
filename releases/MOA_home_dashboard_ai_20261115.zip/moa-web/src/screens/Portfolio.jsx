/* eslint-disable */
// @ts-nocheck
// Generated from Stitch screen s04 — markup kept 1:1 with the design.
import { memo } from 'react';
import { useLegacyScreen } from '../lib/useLegacyScreen';
import { mount } from './Portfolio.controller';
import './Portfolio.css';





function PortfolioScreen() {
  const { rootRef, run } = useLegacyScreen(mount, {"SCREEN_10":-1});
  return (
    <div ref={rootRef} className="stitch-screen scr-portfolio flex justify-center items-start min-h-full antialiased text-[#191F28]" style={{ overflow: "hidden" }}>
{/* Tailwind CSS CDN */}
{/* Pretendard Font */}
{/* Material Symbols Outlined */}
{/* 스마트폰 규격 뷰포트 (390px 최대 폭 최적화) */}
<div className="w-full max-w-[390px] min-h-full bg-[#F2F4F6] flex flex-col relative overflow-x-hidden">
{/* BEGIN: Top Navigation Header */}
<header className="fixed top-0 max-w-[390px] w-full bg-[#F2F4F6]/95 backdrop-blur-md px-4 py-3 border-b border-black/[0.03] z-50">
<div className="flex items-center justify-between relative">
<button aria-label="이전 화면" className="w-9 h-9 -ml-1 flex items-center justify-center rounded-xl text-toss-gray700 hover:bg-black/5 active:scale-95 transition-all z-10" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_10'); })} type="button">
<span className="material-symbols-outlined text-[26px]">
arrow_back_ios_new
</span>
</button>
<h1 className="absolute inset-0 flex items-center justify-center text-[17px] font-bold text-toss-gray900 tracking-tight pointer-events-none">
투자 포트폴리오
</h1>
<div aria-hidden="true" className="w-9 h-9 -mr-1 pointer-events-none" />
</div>
</header>
{/* END: Top Navigation Header */}
{/* BEGIN: Main Scroll Content */}
<main className="flex-1 px-4 pt-[72px] pb-8 space-y-3.5">
<div className="flex flex-col w-full space-y-4">
{/* 1. 총 운용 자산 & 누적 수익률 요약 카드 (Hero Bento Card) */}
<section className="bg-white rounded-3xl p-5 shadow-card relative overflow-hidden">
<div className="flex items-center justify-between mb-3">
<div className="inline-flex items-center space-x-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold">
<span className="material-symbols-outlined text-[15px] fill-1 text-emerald-600">
shield
</span>
{" "}
<span>
소비 방어로 모은 시드 머니
</span>
</div>
<button aria-label="리밸런싱 설정" className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-500 hover:text-slate-900 active:scale-90 transition-transform" onClick={(event) => run(event, (c) => { c.togglePortfolioSettings(); })} type="button">
<span className="material-symbols-outlined text-[18px]">
tune
</span>
</button>
</div>
{/* 금액 및 누적 손익 */}
<div className="space-y-1">
<span className="text-xs text-slate-400 font-medium">
총 투자 운용 자산
</span>
<div className="flex items-baseline space-x-1">
<h2 className="text-3xl font-extrabold text-slate-900 tracking-tight tabular-nums" id="hero-total-amount">
138,000
</h2>
<span className="text-lg font-bold text-slate-700">
원
</span>
</div>
<div className="flex items-center space-x-2 pt-0.5">
<div className="flex items-center text-rose-500 text-sm font-bold tabular-nums">
<span className="material-symbols-outlined text-base">
arrow_drop_up
</span>
{" "}
<span id="hero-profit-amount">
+9,260원
</span>
{" "}
<span className="ml-1 text-xs px-1.5 py-0.5 bg-rose-50 rounded-md font-semibold" id="hero-profit-rate">
+7.2%
</span>
</div>
<span className="text-[11px] text-slate-400">
· 원금 128,740원
</span>
</div>
</div>
{/* 기간 선택 필터 칩스 */}
<div className="flex items-center justify-between mt-5 pt-3.5 border-t border-slate-100">
<span className="text-xs font-medium text-slate-400">
수익률 기간
</span>
<div className="flex items-center p-0.5 bg-slate-100/80 rounded-xl space-x-0.5" id="period-chips">
<button className="px-2.5 py-1 text-xs rounded-lg text-slate-500 font-medium transition-all" onClick={(event) => run(event, (c) => { c.selectPeriod(event.currentTarget, '1m', '+2.4%'); })} type="button">
1개월
</button>
{" "}
<button className="px-2.5 py-1 text-xs rounded-lg bg-white text-slate-900 font-bold shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.selectPeriod(event.currentTarget, '3m', '+7.2%'); })} type="button">
3개월
</button>
{" "}
<button className="px-2.5 py-1 text-xs rounded-lg text-slate-500 font-medium transition-all" onClick={(event) => run(event, (c) => { c.selectPeriod(event.currentTarget, '6m', '+11.8%'); })} type="button">
6개월
</button>
{" "}
<button className="px-2.5 py-1 text-xs rounded-lg text-slate-500 font-medium transition-all" onClick={(event) => run(event, (c) => { c.selectPeriod(event.currentTarget, '1y', '+18.5%'); })} type="button">
1년
</button>
</div>
</div>
</section>
{/* 2. 테마 필터 탭 (가로 스크롤) */}
<div className="flex items-center space-x-2 overflow-x-auto hide-scrollbar pb-0.5">
<button className="category-chip px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-white shrink-0 shadow-sm transition-all" onClick={(event) => run(event, (c) => { c.filterCategory('all', event.currentTarget); })} type="button">
전체{" "}
<span className="tabular-nums font-medium text-slate-300">
4
</span>
</button>
{" "}
<button className="category-chip px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.filterCategory('us-etf', event.currentTarget); })} type="button">
미국 ETF{" "}
<span className="tabular-nums font-semibold text-blue-600">
70%
</span>
</button>
{" "}
<button className="category-chip px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.filterCategory('kr-dividend', event.currentTarget); })} type="button">
국내 고배당{" "}
<span className="tabular-nums font-semibold text-emerald-600">
20%
</span>
</button>
{" "}
<button className="category-chip px-3.5 py-1.5 rounded-full text-xs font-medium bg-white text-slate-600 hover:text-slate-900 shrink-0 shadow-card transition-all" onClick={(event) => run(event, (c) => { c.filterCategory('future-theme', event.currentTarget); })} type="button">
가상 테마{" "}
<span className="tabular-nums font-semibold text-indigo-600">
10%
</span>
</button>
</div>
{/* 3. 종목별 자산 배분 비주얼 (Asset Allocation Bento Card) */}
<section className="bg-white rounded-3xl p-5 shadow-card space-y-4">
<div className="flex items-center justify-between">
<div>
<h3 className="text-sm font-bold text-slate-900">
자산 배분 현황
</h3>
<p className="text-xs text-slate-400 mt-0.5">
목표 비중 대비 안정적으로 분산 중이에요
</p>
</div>
<span className="inline-flex items-center px-2 py-0.5 rounded-md bg-blue-50 text-blue-600 text-[11px] font-bold">
리밸런싱 건강도 양호
</span>
</div>
{/* 다중 분할 비례 프로그레스 바 */}
<div className="space-y-1.5">
<div className="h-3.5 w-full bg-slate-100 rounded-full flex overflow-hidden p-0.5 gap-0.5">
<div className="h-full bg-blue-500 rounded-l-full transition-all duration-500" style={{ width: "45%" }} title="미국 S&P 500: 45%" />
<div className="h-full bg-sky-400 transition-all duration-500" style={{ width: "25%" }} title="미국 나스닥 100: 25%" />
<div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: "20%" }} title="한국 고배당 인프라: 20%" />
<div className="h-full bg-indigo-500 rounded-r-full transition-all duration-500" style={{ width: "10%" }} title="우주·AI 테마: 10%" />
</div>
{/* 배분 범례 4종 */}
<div className="grid grid-cols-2 gap-2 pt-2">
<div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
<div className="flex items-center space-x-1.5 min-w-0">
<span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
{" "}
<span className="text-xs font-medium text-slate-700 truncate">
S&P 500
</span>
</div>
<span className="text-xs font-bold text-slate-900 tabular-nums">
45%
</span>
</div>
<div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
<div className="flex items-center space-x-1.5 min-w-0">
<span className="w-2.5 h-2.5 rounded-full bg-sky-400 shrink-0" />
{" "}
<span className="text-xs font-medium text-slate-700 truncate">
나스닥 100
</span>
</div>
<span className="text-xs font-bold text-slate-900 tabular-nums">
25%
</span>
</div>
<div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
<div className="flex items-center space-x-1.5 min-w-0">
<span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
{" "}
<span className="text-xs font-medium text-slate-700 truncate">
한국 고배당
</span>
</div>
<span className="text-xs font-bold text-slate-900 tabular-nums">
20%
</span>
</div>
<div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
<div className="flex items-center space-x-1.5 min-w-0">
<span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0" />
{" "}
<span className="text-xs font-medium text-slate-700 truncate">
우주·AI 테마
</span>
</div>
<span className="text-xs font-bold text-slate-900 tabular-nums">
10%
</span>
</div>
</div>
</div>
{/* 목표 대비 현황 미니 배너 */}
<div className="p-3 bg-gradient-to-r from-blue-50/60 via-slate-50 to-emerald-50/60 rounded-2xl flex items-center justify-between">
<div className="flex items-center space-x-2">
<span className="material-symbols-outlined text-[19px] text-blue-600">
balance
</span>
{" "}
<span className="text-xs font-medium text-slate-700">
목표 비율 오차범위{" "}
<b className="text-slate-900">
±1.2%
</b>
{" "}이내
</span>
</div>
<button className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center" onClick={(event) => run(event, (c) => { c.showTargetDetailModal(); })} type="button">
비교보기{" "}
<span className="material-symbols-outlined text-sm">
chevron_right
</span>
</button>
</div>
</section>
{/* 4. 보유 종목 리스트 (상세 카드 리스트) */}
<section className="space-y-2.5">
<div className="flex items-center justify-between px-1">
<h3 className="text-sm font-bold text-slate-900">
보유 종목
</h3>
<span className="text-xs text-slate-400">
가상 시세 기준
</span>
</div>
{/* 종목 1: TIGER 미국S&P500 */}
<div className="stock-item bg-white rounded-2xl p-4 shadow-card hover:bg-slate-50/50 transition-colors" data-group="us-etf">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3">
<div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 font-black text-sm shrink-0">
S&P
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
TIGER 미국S&P500
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100/70 text-blue-700">
45%
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
62,100원 보유 · 1.45주
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-extrabold text-rose-500 tabular-nums">
+4,810원
</span>
<p className="text-xs font-semibold text-rose-500 tabular-nums">
(+8.4%)
</p>
</div>
</div>
<div className="flex items-center space-x-1.5 mt-3 pt-2.5 border-t border-slate-100">
<span className="px-2 py-0.5 bg-slate-100 rounded-md text-[11px] font-medium text-slate-600">
안정성장
</span>
{" "}
<span className="px-2 py-0.5 bg-slate-100 rounded-md text-[11px] font-medium text-slate-600">
배당재투자
</span>
{" "}
<span className="text-[11px] text-slate-400 ml-auto flex items-center">
복리 효과 누적 중{" "}
<span className="material-symbols-outlined text-[13px] text-amber-500 ml-0.5 fill-1">
bolt
</span>
</span>
</div>
</div>
{/* 종목 2: ACE 미국나스닥100 */}
<div className="stock-item bg-white rounded-2xl p-4 shadow-card hover:bg-slate-50/50 transition-colors" data-group="us-etf">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3">
<div className="w-10 h-10 rounded-2xl bg-sky-50 flex items-center justify-center text-sky-600 font-black text-sm shrink-0">
QQQ
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
ACE 미국나스닥100
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100/70 text-sky-700">
25%
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
34,500원 보유 · 0.68주
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-extrabold text-rose-500 tabular-nums">
+3,470원
</span>
<p className="text-xs font-semibold text-rose-500 tabular-nums">
(+11.2%)
</p>
</div>
</div>
<div className="flex items-center space-x-1.5 mt-3 pt-2.5 border-t border-slate-100">
<span className="px-2 py-0.5 bg-slate-100 rounded-md text-[11px] font-medium text-slate-600">
기술성장
</span>
{" "}
<span className="px-2 py-0.5 bg-sky-50 text-sky-700 rounded-md text-[11px] font-medium">
최고 수익률
</span>
{" "}
<span className="text-[11px] text-slate-400 ml-auto">
빅테크 100종목
</span>
</div>
</div>
{/* 종목 3: SOL 한국고배당인프라 */}
<div className="stock-item bg-white rounded-2xl p-4 shadow-card hover:bg-slate-50/50 transition-colors" data-group="kr-dividend">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3">
<div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 font-black text-sm shrink-0">
배당
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
SOL 한국고배당인프라
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100/70 text-emerald-700">
20%
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
27,600원 보유 · 2.1주
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-extrabold text-rose-500 tabular-nums">
+930원
</span>
<p className="text-xs font-semibold text-rose-500 tabular-nums">
(+3.5%)
</p>
</div>
</div>
<div className="flex items-center space-x-1.5 mt-3 pt-2.5 border-t border-slate-100">
<span className="px-2 py-0.5 bg-slate-100 rounded-md text-[11px] font-medium text-slate-600">
월배당
</span>
{" "}
<span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md text-[11px] font-medium">
연 5.8% 배당수익
</span>
{" "}
<span className="text-[11px] text-slate-400 ml-auto">
다음 배당 5일 전
</span>
</div>
</div>
{/* 종목 4: MOA 우주·AI 미래 평행 펀드 */}
<div className="stock-item bg-white rounded-2xl p-4 shadow-card hover:bg-slate-50/50 transition-colors" data-group="future-theme">
<div className="flex items-start justify-between">
<div className="flex items-center space-x-3">
<div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black text-sm shrink-0">
<span className="material-symbols-outlined text-[20px]">
rocket_launch
</span>
</div>
<div>
<div className="flex items-center space-x-1.5">
<h4 className="text-[14px] font-bold text-slate-900">
MOA 우주·AI 미래 평행 펀드
</h4>
<span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-100/70 text-indigo-700">
10%
</span>
</div>
<p className="text-xs text-slate-400 mt-0.5">
13,800원 운용 · 1.0포인트
</p>
</div>
</div>
<div className="text-right">
<span className="text-sm font-extrabold text-rose-500 tabular-nums">
+1,780원
</span>
<p className="text-xs font-semibold text-rose-500 tabular-nums">
(+14.8%)
</p>
</div>
</div>
<div className="flex items-center space-x-1.5 mt-3 pt-2.5 border-t border-slate-100">
<span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md text-[11px] font-semibold">
가상 시뮬레이션
</span>
{" "}
<span className="px-2 py-0.5 bg-slate-100 rounded-md text-[11px] font-medium text-slate-600">
소비절약 리워드 연동
</span>
{" "}
<span className="text-[11px] text-slate-400 ml-auto">
레벨 3 달성
</span>
</div>
</div>
</section>
{/* 5. 스마트 리밸런싱 & 소비 방어 연동 인사이트 배너 */}
<section className="bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-900 text-white rounded-3xl p-5 shadow-card relative overflow-hidden">
<div className="relative z-10 space-y-3">
<div className="flex items-center space-x-2">
<span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[11px] font-bold flex items-center space-x-1">
<span className="material-symbols-outlined text-[13px] fill-1">
savings
</span>
{" "}
<span>
소비 방어 연동 팁
</span>
</span>
</div>
<div className="space-y-1">
<h4 className="text-[15px] font-bold leading-snug">
이번 달 커피 3잔(13,500원)을 아끼면
<br />
{" "}
<span className="text-blue-300 underline underline-offset-4 decoration-blue-400">
S&P 500 ETF를 1주 더
</span>
{" "}모을 수 있어요!
</h4>
<p className="text-xs text-slate-300 pt-0.5">
지난달 소비 절약 머니가 다음 주 화요일에 자동 배분됩니다.
</p>
</div>
<div className="pt-2 flex items-center space-x-2">
<button className="flex-1 py-2.5 px-3 bg-white/10 hover:bg-white/20 active:scale-[0.98] rounded-xl text-xs font-bold text-white transition-all flex items-center justify-center space-x-1" onClick={(event) => run(event, (c) => { c.quickRebalanceAction(); })} type="button">
<span className="material-symbols-outlined text-[16px]">
sync_alt
</span>
{" "}
<span>
목표 비중 재조정
</span>
</button>
{" "}
<button className="py-2.5 px-3 bg-white/10 hover:bg-white/20 active:scale-[0.98] rounded-xl text-xs font-medium text-slate-200 transition-all" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_1'); })} type="button">
소비 내역 확인
</button>
</div>
</div>
{/* 배경 은은한 데코 그래픽 */}
<div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-blue-500/20 blur-2xl pointer-events-none" />
<div className="absolute right-3 top-3 w-16 h-16 rounded-full bg-indigo-400/10 blur-xl pointer-events-none" />
</section>
{/* 6. 액션 버튼 (포트폴리오 비중 수정 모달 트리거) */}
<div className="pt-1">
<button className="w-full py-3.5 bg-white border border-slate-200 hover:bg-slate-50 active:scale-[0.98] text-slate-800 font-bold rounded-2xl text-[14px] shadow-sm transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.openAddAssetModal(); })} type="button">
<span className="material-symbols-outlined text-[18px] text-blue-600">
add_circle
</span>
{" "}
<span>
종목 추가 및 비중 재조정
</span>
</button>
</div>
</div>
{/* 리밸런싱 / 목표 비중 모달 (슬라이드업) */}
<div className="fixed inset-0 z-50 bg-black/50 opacity-0 pointer-events-none transition-opacity duration-300 flex items-end justify-center" id="rebalance-modal">
<div className="w-full max-w-[390px] bg-white rounded-t-3xl p-5 space-y-4 transform translate-y-full transition-transform duration-300" id="rebalance-modal-content">
<div className="flex items-center justify-between">
<h3 className="text-base font-bold text-slate-900">
목표 자산 비중 조정
</h3>
<button className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500" onClick={(event) => run(event, (c) => { c.closeRebalanceModal(); })} type="button">
<span className="material-symbols-outlined text-[18px]">
close
</span>
</button>
</div>
<div className="space-y-3 pt-1">
<div>
<div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
<span>
TIGER 미국S&P500
</span>
{" "}
<span className="text-blue-600 font-bold tabular-nums" id="slider-val-1">
45%
</span>
</div>
<input className="w-full accent-blue-600 cursor-pointer" max="80" min="10" onInput={(event) => run(event, (c) => { c.updateSliderVal(1, event.currentTarget.value); })} type="range" defaultValue="45" />
</div>
<div>
<div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
<span>
ACE 미국나스닥100
</span>
{" "}
<span className="text-sky-600 font-bold tabular-nums" id="slider-val-2">
25%
</span>
</div>
<input className="w-full accent-sky-500 cursor-pointer" max="60" min="10" onInput={(event) => run(event, (c) => { c.updateSliderVal(2, event.currentTarget.value); })} type="range" defaultValue="25" />
</div>
<div>
<div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
<span>
SOL 한국고배당인프라
</span>
{" "}
<span className="text-emerald-600 font-bold tabular-nums" id="slider-val-3">
20%
</span>
</div>
<input className="w-full accent-emerald-500 cursor-pointer" max="50" min="5" onInput={(event) => run(event, (c) => { c.updateSliderVal(3, event.currentTarget.value); })} type="range" defaultValue="20" />
</div>
<div>
<div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
<span>
MOA 우주·AI 미래 펀드
</span>
{" "}
<span className="text-indigo-600 font-bold tabular-nums" id="slider-val-4">
10%
</span>
</div>
<input className="w-full accent-indigo-600 cursor-pointer" max="30" min="0" onInput={(event) => run(event, (c) => { c.updateSliderVal(4, event.currentTarget.value); })} type="range" defaultValue="10" />
</div>
</div>
<div className="pt-2">
<button className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-colors" onClick={(event) => run(event, (c) => { c.applyRebalance(); })} type="button">
설정한 비중으로 자동 리밸런싱 저장
</button>
</div>
</div>
</div>
</main>
{/* END: Main Scroll Content */}
{/* BEGIN: Sticky Bottom Button */}
<div className="sticky bottom-0 bg-white/95 backdrop-blur-md px-4 pt-2.5 pb-5 border-t border-black/[0.04] z-30 shadow-lg">
<button className="w-full py-3.5 bg-toss-blue hover:bg-toss-blueDark active:scale-[0.98] text-white font-bold rounded-2xl text-[15px] shadow-floating transition-all flex items-center justify-center space-x-1.5" onClick={(event) => run(event, (c) => { c.__nav('SCREEN_10'); })} type="button">
<span>
거래소로 돌아가기
</span>
</button>
</div>
{/* END: Sticky Bottom Button */}
{/* BEGIN: Share Bottom Sheet Modal & Backdrop */}
{/* Floating Toast Notification */}
{/* END: Share Bottom Sheet Modal & Backdrop */}
</div>
{/* 공유 바텀시트 인터랙션 스크립트 */}
{/* 지출 속도 인터랙션 스크립트 */}
{/* 카테고리 독립 다중 아코디언 및 도넛 차트 스크립트 */}
    </div>
  );
}

export default memo(PortfolioScreen);
