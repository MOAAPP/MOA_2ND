import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode, type RefObject } from 'react';

type AppApi = {
  toast: (message: string, icon?: string) => void;
  scroller: () => HTMLElement | null;
  frame: () => HTMLElement | null;
};

const AppCtx = createContext<AppApi | null>(null);

export function useApp() {
  const v = useContext(AppCtx);
  if (!v) throw new Error('useApp outside provider');
  return v;
}

export function AppProvider({ children, scrollerRef, frameRef }: { children: ReactNode; scrollerRef: RefObject<HTMLElement>; frameRef: RefObject<HTMLElement> }) {
  const [toast, setToast] = useState<{ id: number; message: string; icon?: string } | null>(null);
  const timer = useRef<number>();
  const show = useCallback((message: string, icon?: string) => {
    window.clearTimeout(timer.current);
    setToast({ id: Date.now(), message, icon });
    timer.current = window.setTimeout(() => setToast(null), 2600);
  }, []);
  const api = useMemo<AppApi>(() => ({
    toast: show,
    scroller: () => scrollerRef.current,
    frame: () => frameRef.current,
  }), [show, scrollerRef, frameRef]);

  return (
    <AppCtx.Provider value={api}>
      {children}
      <div
        aria-live="polite"
        className={`absolute top-5 left-1/2 -translate-x-1/2 z-[200] max-w-[340px] w-max bg-slate-900/95 text-white px-4 py-2.5 rounded-2xl shadow-xl text-[13px] font-semibold flex items-center gap-2 transition-all duration-300 ${toast ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-3 pointer-events-none'}`}
      >
        <span className="material-symbols-outlined text-[18px] text-emerald-400">{toast?.icon ?? 'check_circle'}</span>
        <span className="truncate">{toast?.message}</span>
      </div>
    </AppCtx.Provider>
  );
}
