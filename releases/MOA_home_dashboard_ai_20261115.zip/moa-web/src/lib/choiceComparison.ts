/** 구매한 나 / 구매하지 않은 나: 동일한 등록 금융 상태에서 선택 한 건만 바꿔 비교.
 * AI 예측이나 투자 수익률을 포함하지 않는 프론트 전용 결정적 현금흐름 계산.
 */
import { APP_TODAY, balanceDelta, type Tx, type Wish, type Finance, getState } from './store';
import { cashTimeline, isoOf } from './finance';

type AppState = ReturnType<typeof getState>;
export type ChoiceInput = { name: string; amount: number; wish?: Wish | null; transaction?: Tx | null; payment?: string };
export type CashPoint = { day: number; date: string; bought: number; kept: number };
export type ChoiceProjection = {
  boughtNow: number; keptNow: number; boughtEnd: number; keptEnd: number;
  delta: number; points: CashPoint[]; boughtRisk: string | null; keptRisk: string | null;
  actual: 'bought' | 'kept' | 'demo'; payment: string; isDemo: boolean;
};

const dayISO = (days: number) => {
  const d = new Date(`${APP_TODAY}T00:00:00`);
  d.setDate(d.getDate() + days);
  return isoOf(d);
};

/** 현금 snapshot 자체가 해당 구매를 반영했는지 여부는 linked Tx로 판단. */
export function comparePurchaseChoice(s: AppState, input: ChoiceInput, horizonDays: number): ChoiceProjection {
  const amount = Math.max(0, Math.round(Number.isFinite(input.amount) ? input.amount : 0));
  const days = Math.max(1, Math.min(120, Math.trunc(horizonDays)));
  const wish = input.wish;
  const recorded: Tx | undefined = input.transaction || (wish?.status === 'bought'
    ? s.txs.find((t) => t.id === wish.txId && t.wishId === wish.id)
    : undefined);
  const payment = recorded?.payment || wish?.payment || input.payment || '체크카드 (즉시 출금)';
  const simulated: Tx = {
    id: `choice-preview-${wish?.id || 'manual'}`, type: 'expense', title: input.name,
    amount, payment, category: wish?.category || '쇼핑', date: APP_TODAY,
    sample: false, balanceApplied: true,
  };
  // 이미 구매했다면 해당 거래만 취소한 반대 세계를 만든다. 반대 세계는 현재 금융 상태의
  // 단순 차감이 아니라 카드 청구일에 잡힌 미래 승인 내역까지 함께 제거한다.
  const bought: AppState = recorded ? s : {
    ...s, txs: [simulated, ...s.txs],
    finance: { ...s.finance, balance: s.finance.balance + balanceDelta(simulated) } as Finance,
  };
  const kept: AppState = recorded ? {
    ...s, txs: s.txs.filter((t) => t.id !== recorded.id),
    finance: { ...s.finance, balance: s.finance.balance - balanceDelta(recorded) } as Finance,
  } : s;
  const be = cashTimeline(days, bought);
  const ke = cashTimeline(days, kept);
  const at = (state: AppState, events: typeof be, day: number) => {
    if (day === 0) return state.finance.balance; // 첫 점은 실제 현재 잔액 스냅샷
    const to = dayISO(day);
    const matched = events.filter((e) => e.date <= to);
    return matched.length ? matched[matched.length - 1].balanceAfter : state.finance.balance;
  };
  const ticks = [...new Set([0, Math.floor(days / 4), Math.floor(days / 2), Math.floor(days * 3 / 4), days])];
  const points = ticks.map((day) => ({ day, date: dayISO(day), bought: at(bought, be, day), kept: at(kept, ke, day) }));
  const firstRisk = (state: AppState, events: typeof be) => state.finance.balance < state.finance.minBalance
    ? APP_TODAY : events.find((e) => e.balanceAfter < state.finance.minBalance)?.date || null;
  const last = points[points.length - 1];
  return {
    boughtNow: bought.finance.balance, keptNow: kept.finance.balance,
    boughtEnd: last.bought, keptEnd: last.kept, delta: last.kept - last.bought,
    points, boughtRisk: firstRisk(bought, be), keptRisk: firstRisk(kept, ke),
    payment, actual: recorded ? 'bought' : wish ? 'kept' : 'demo', isDemo: !wish,
  };
}
