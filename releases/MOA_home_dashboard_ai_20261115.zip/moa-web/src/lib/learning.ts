// 금융 학습 카드 · 퀴즈 데이터.
// 지금은 앱에 담긴 학습 노트를 쓰고, 백엔드가 붙으면 같은 모양(Lesson)으로 받아오면 화면은 그대로 동작해요.

export type LessonCard = { title: string; body: string; point?: string; emoji?: string };
export type QuizQuestion = { id: string; q: string; options: string[]; answer: number; explain: string };
export type Lesson = {
  id: string; topic: string; title: string; summary: string; minutes: number; emoji: string;
  updated: string; source: string; cards: LessonCard[]; quiz: QuizQuestion[];
  practice: { label: string; to: string };
};

const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
const compound = (p: number, r: number, y: number) => p * Math.pow(1 + r, y);

export const LESSONS: Lesson[] = [
  {
    id: 'compound', topic: '저축', emoji: '🌱', minutes: 3, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '단리와 복리, 뭐가 달라요?',
    summary: '참은 돈이 시간이 지나며 어떻게 불어나는지 이자 계산법부터 알아봐요.',
    cards: [
      { emoji: '💧', title: '단리는 원금에만 이자가 붙어요', body: `259,000원을 연 3.8% 단리로 3년 두면 매년 ${won(259000 * 0.038)}씩, 3년 동안 이자 ${won(259000 * 0.038 * 3)}이 생겨요.` },
      { emoji: '❄️', title: '복리는 이자에도 이자가 붙어요', body: `같은 돈을 연 3.8% 복리로 3년 두면 ${won(compound(259000, 0.038, 3))}이 돼요. 단리보다 ${won(compound(259000, 0.038, 3) - 259000 * (1 + 0.038 * 3))} 더 많아요.`, point: '기간이 길수록 차이가 커져요.' },
      { emoji: '⏱️', title: '72의 법칙', body: '72를 연 수익률(%)로 나누면 원금이 두 배가 되는 대략의 기간이 나와요. 연 3.8%면 약 19년, 연 7.2%면 약 10년이에요.' },
      { emoji: '🧾', title: '세금도 기억해요', body: '예·적금 이자에는 보통 이자소득세 15.4%(지방소득세 포함)가 붙어요. 광고 금리는 세금을 떼기 전 금리인 경우가 많아요.' },
    ],
    quiz: [
      { id: 'compound-1', q: '100만 원을 연 5% 복리로 2년 두면 2년 뒤 금액은?', options: ['1,100,000원', '1,102,500원', '1,050,000원'], answer: 1, explain: '1년 뒤 105만 원, 2년째에는 105만 원에 5% 이자가 붙어 110만 2,500원이 돼요.' },
      { id: 'compound-2', q: '72의 법칙으로 연 8% 수익이면 원금이 두 배가 되는 기간은?', options: ['약 6년', '약 9년', '약 12년'], answer: 1, explain: '72 ÷ 8 = 9, 약 9년이에요. 정확한 값이 아니라 어림셈이에요.' },
    ],
    practice: { label: '가상 적금으로 복리 체험하기', to: '/savings' },
  },
  {
    id: 'etf', topic: '투자', emoji: '🧺', minutes: 4, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: 'ETF, 한 바구니에 담긴 주식',
    summary: '여러 종목을 한 번에 사는 ETF의 구조와 꼭 확인할 점을 알아봐요.',
    cards: [
      { emoji: '🧺', title: 'ETF는 지수를 따라가는 펀드예요', body: 'S&P500·코스피200 같은 지수에 들어 있는 종목을 묶어, 주식처럼 거래소에서 사고팔 수 있게 만든 상품이에요.' },
      { emoji: '🛡️', title: '나눠 담으면 한 종목 위험이 줄어요', body: '한 회사 주가가 떨어져도 다른 종목이 함께 있어 충격이 줄어요. 하지만 시장 전체가 내려가면 ETF도 함께 내려가요.', point: '분산 투자 ≠ 손실이 없는 투자' },
      { emoji: '💸', title: '보수(수수료)를 확인해요', body: 'ETF는 운용 비용인 총보수가 매일 조금씩 빠져나가요. 같은 지수를 따라가는 ETF라면 보수가 낮은 쪽이 장기적으로 유리해요.' },
      { emoji: '💱', title: '해외 지수는 환율도 영향을 줘요', body: '미국 지수를 따라가는 국내 상장 ETF는 원·달러 환율에 따라 수익이 달라질 수 있어요. 이름에 (H)가 붙으면 환율 영향을 줄인 환헤지 상품이에요.' },
    ],
    quiz: [
      { id: 'etf-1', q: 'ETF에 대한 설명으로 맞는 것은?', options: ['원금이 보장된다', '거래소에서 주식처럼 사고팔 수 있다', '수수료가 전혀 없다'], answer: 1, explain: 'ETF는 상장된 펀드라 주식처럼 거래해요. 원금 보장이 없고 총보수가 있어요.' },
      { id: 'etf-2', q: '상품 이름 끝의 (H)는 무엇을 뜻할까요?', options: ['고배당', '환헤지', '레버리지'], answer: 1, explain: '(H)는 환율 변동 위험을 줄인 환헤지 상품이라는 뜻이에요.' },
    ],
    practice: { label: '가상 거래소에서 ETF 살펴보기', to: '/invest' },
  },
  {
    id: 'emergency', topic: '생활비', emoji: '🧯', minutes: 3, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '비상금은 얼마나, 어디에 둘까?',
    summary: '갑자기 돈이 필요할 때 투자금을 깨지 않도록 비상금부터 챙겨요.',
    cards: [
      { emoji: '🧯', title: '비상금은 생활비 3~6개월치', body: '흔히 한 달 생활비의 3~6개월치를 권해요. 한 달 예산이 50만 원이라면 150~300만 원이 목표예요.' },
      { emoji: '🅿️', title: '바로 꺼낼 수 있는 곳에', body: '비상금은 언제든 출금할 수 있는 파킹통장이나 입출금 통장에 두는 게 좋아요. 만기가 있는 적금이나 가격이 변하는 투자는 맞지 않아요.' },
      { emoji: '🏦', title: '예금자보호 한도', body: '은행 예금은 금융회사 한 곳당 원금과 이자를 합쳐 1억 원까지 예금보험공사가 보호해요(2025년 9월부터).' },
      { emoji: '📅', title: '결제일 전 잔액부터', body: '카드값·월세처럼 꼭 나갈 돈을 먼저 빼고 남는 금액이 진짜 쓸 수 있는 돈이에요. 모아 홈의 결제 일정이 이 계산을 도와줘요.' },
    ],
    quiz: [
      { id: 'emergency-1', q: '비상금을 두기에 가장 알맞은 곳은?', options: ['주식 계좌', '언제든 출금되는 파킹통장', '3년 만기 적금'], answer: 1, explain: '비상금은 필요할 때 바로, 원금 그대로 꺼낼 수 있어야 해요.' },
      { id: 'emergency-2', q: '은행 예금자보호 한도는 금융회사 한 곳당 얼마일까요?', options: ['5천만 원', '1억 원', '한도 없음'], answer: 1, explain: '2025년 9월 1일부터 원금과 이자를 합쳐 1억 원까지 보호돼요.' },
    ],
    practice: { label: '가상 예금으로 비상금 만들기', to: '/savings' },
  },
  {
    id: 'order-type', topic: '투자', emoji: '🎯', minutes: 2, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '시장가와 지정가 주문',
    summary: '주문 방식에 따라 체결 가격과 시점이 달라져요.',
    cards: [
      { emoji: '⚡', title: '시장가: 지금 바로', body: '지금 나와 있는 가장 유리한 가격으로 바로 체결돼요. 대신 가격이 빠르게 움직이면 생각보다 비싸게 살 수 있어요.' },
      { emoji: '🎯', title: '지정가: 원하는 가격에', body: '내가 정한 가격에 도달해야 체결돼요. 가격이 오지 않으면 체결되지 않고 대기하다가 취소될 수 있어요.' },
      { emoji: '🔒', title: '대기 중인 돈은 묶여요', body: '지정가 매수 주문을 넣으면 체결 전까지 그 금액은 다른 주문에 쓸 수 없어요. 모아 가상 거래소도 똑같이 동작해요.' },
    ],
    quiz: [
      { id: 'order-1', q: '가격이 원하는 수준에 오지 않으면 체결되지 않는 주문은?', options: ['시장가 주문', '지정가 주문'], answer: 1, explain: '지정가 주문은 정한 가격에 도달해야 체결돼요.' },
    ],
    practice: { label: '지정가 주문 넣어보기', to: '/invest' },
  },
  // ---- 가상 매수 후 종목 학습 ----
  {
    id: 'stock-SP500', topic: '내 거래', emoji: '🇺🇸', minutes: 3, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: 'S&P500 ETF를 샀어요',
    summary: '방금 산 종목이 무엇을 따라가는지, 어떤 위험이 있는지 알아봐요.',
    cards: [
      { emoji: '🏢', title: '미국 대형주 500개', body: 'S&P500은 미국 증시에 상장된 대형 기업 약 500개로 만든 지수예요. 이 ETF를 1주 사면 그 500개 기업에 조금씩 나눠 투자하는 셈이에요.' },
      { emoji: '⚖️', title: '큰 회사일수록 비중이 커요', body: '시가총액이 큰 회사가 지수에서 차지하는 비중이 커요. 최근에는 대형 기술 기업 비중이 높아 이들 주가 영향을 크게 받아요.' },
      { emoji: '💱', title: '환율도 수익에 영향을 줘요', body: '환헤지(H) 표시가 없는 미국 지수 ETF는 달러가 오르면 원화 수익이 늘고, 달러가 내리면 줄어요.' },
      { emoji: '📉', title: '오래 보면 오르내림이 있어요', body: '지수 투자도 한 해에 수십 퍼센트 떨어진 적이 있어요. 당장 쓸 돈이 아닌 돈으로, 긴 기간을 보고 투자하는 게 기본이에요.' },
    ],
    quiz: [
      { id: 'sp500-1', q: 'S&P500 지수에 담긴 기업은 대략 몇 개일까요?', options: ['30개', '100개', '500개'], answer: 2, explain: '이름처럼 미국 대형주 약 500개로 구성돼요.' },
      { id: 'sp500-2', q: '환헤지 표시가 없는 미국 지수 ETF에서 달러가 오르면?', options: ['원화 수익이 늘어난다', '원화 수익이 줄어든다', '아무 영향 없다'], answer: 0, explain: '달러 자산을 원화로 환산하기 때문에 달러가 오르면 원화 기준 수익이 늘어요.' },
    ],
    practice: { label: '같은 금액을 저축했을 때와 비교하기', to: '/world' },
  },
  {
    id: 'stock-QQQ', topic: '내 거래', emoji: '💻', minutes: 3, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '나스닥100 ETF를 샀어요',
    summary: '기술주 비중이 높은 지수의 특징과 변동성을 알아봐요.',
    cards: [
      { emoji: '💻', title: '나스닥 상장 대형주 100개', body: '나스닥100은 나스닥 거래소에 상장된 금융회사를 뺀 대형 기업 100개로 만든 지수예요.' },
      { emoji: '🎢', title: '기술주 비중이 높아요', body: '빅테크 기업 비중이 커서 오를 때 많이 오르고, 떨어질 때도 S&P500보다 크게 떨어지는 경향이 있어요.' },
      { emoji: '🧩', title: '겹치는 종목 확인', body: 'S&P500 ETF와 함께 가지고 있으면 상위 기업이 많이 겹쳐요. 분산했다고 생각했는데 같은 회사에 몰려 있을 수 있어요.' },
    ],
    quiz: [
      { id: 'qqq-1', q: '나스닥100 지수에서 빠지는 업종은?', options: ['기술', '금융', '헬스케어'], answer: 1, explain: '나스닥100은 금융회사를 제외한 대형 기업으로 구성돼요.' },
    ],
    practice: { label: '같은 금액을 저축했을 때와 비교하기', to: '/world' },
  },
  {
    id: 'stock-SPACE', topic: '내 거래', emoji: '🚀', minutes: 2, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '테마형 상품을 샀어요',
    summary: '우주·AI처럼 한 주제에 모은 상품은 오르내림이 커요.',
    cards: [
      { emoji: '🚀', title: '한 주제에 집중해요', body: '테마형 상품은 특정 산업 기업만 모아요. 그 산업이 주목받으면 크게 오르지만, 관심이 식으면 함께 떨어져요.' },
      { emoji: '🎢', title: '변동성이 커요', body: '종목 수가 적고 업종이 같아 시장 전체 지수보다 가격 변화가 훨씬 커요.' },
      { emoji: '🥧', title: '비중을 작게', body: '테마 투자는 전체 투자금 중 일부로만 하고, 나머지는 넓게 분산된 상품에 두는 방법이 많이 쓰여요.' },
    ],
    quiz: [
      { id: 'space-1', q: '테마형 상품의 특징으로 맞는 것은?', options: ['시장 지수보다 변동성이 작다', '한 산업에 집중해 변동성이 크다', '원금이 보장된다'], answer: 1, explain: '한 업종에 몰려 있어 오르내림이 커요.' },
    ],
    practice: { label: '같은 금액을 저축했을 때와 비교하기', to: '/world' },
  },
  {
    id: 'stock-DIVIDEND', topic: '내 거래', emoji: '💰', minutes: 3, updated: '2026-11-10', source: '모아 금융 학습 노트',
    title: '고배당 ETF를 샀어요',
    summary: '배당이 무엇이고, 언제 어떻게 받는지 알아봐요.',
    cards: [
      { emoji: '💰', title: '배당은 이익을 나눠주는 돈', body: '회사가 번 돈 일부를 주주에게 나눠주는 게 배당이에요. 고배당 ETF는 배당을 많이 주는 기업을 모아요.' },
      { emoji: '📆', title: '기준일에 갖고 있어야 받아요', body: '배당은 정해진 기준일에 보유한 사람에게 줘요. 기준일이 지나면 그만큼 가격이 내려가는 배당락이 생길 수 있어요.' },
      { emoji: '🧾', title: '배당에도 세금이 있어요', body: '국내에서 받는 배당에는 보통 배당소득세 15.4%가 떼어져요.' },
      { emoji: '⚠️', title: '배당이 높다고 안전한 건 아니에요', body: '주가가 크게 떨어져서 배당률이 높아 보이는 경우도 있어요. 배당률과 함께 주가 흐름도 봐야 해요.' },
    ],
    quiz: [
      { id: 'div-1', q: '배당을 받으려면 언제 주식을 보유하고 있어야 할까요?', options: ['배당 기준일', '배당 지급일 당일만', '언제든 상관없다'], answer: 0, explain: '배당 기준일에 보유한 주주에게 배당이 지급돼요.' },
    ],
    practice: { label: '같은 금액을 저축했을 때와 비교하기', to: '/world' },
  },
];

export const lessonById = (id: string) => LESSONS.find((l) => l.id === id);
export const stockLessonId = (code: string) => (LESSONS.some((l) => l.id === `stock-${code}`) ? `stock-${code}` : 'etf');
export const GENERAL_LESSONS = LESSONS.filter((l) => !l.id.startsWith('stock-'));

// ---------- 복습 일정 (1·3·7일) ----------
type Attempt = { questionId: string; lessonId: string; correct: boolean; at: string };
const DAY = 86400000;
export const REVIEW_STEPS = [1, 3, 7];

/**
 * 틀린 적 있는 문제의 복습 상태.
 * 마지막으로 틀린 뒤 연속으로 맞힌 횟수(stage)에 따라 1일 → 3일 → 7일 뒤 다시 풀어요. 3번 연속 맞히면 복습 끝.
 */
export function reviewQueue(attempts: Attempt[], today: string) {
  const byQ: Record<string, Attempt[]> = {};
  attempts.forEach((a) => (byQ[a.questionId] ||= []).push(a));
  const now = new Date(`${today}T23:59:59`).getTime();
  const out: { questionId: string; lessonId: string; stage: number; dueAt: number; due: boolean; daysLeft: number; wrongCount: number }[] = [];
  Object.entries(byQ).forEach(([qid, list]) => {
    list.sort((x, y) => x.at.localeCompare(y.at));
    const lastWrong = list.map((x) => x.correct).lastIndexOf(false);
    if (lastWrong < 0) return;
    const stage = list.length - 1 - lastWrong; // 틀린 뒤 연속 정답 수
    if (stage >= REVIEW_STEPS.length) return;
    const last = new Date(list[list.length - 1].at).getTime();
    const dueAt = last + REVIEW_STEPS[stage] * DAY;
    out.push({ questionId: qid, lessonId: list[0].lessonId, stage, dueAt, due: dueAt <= now, daysLeft: Math.max(0, Math.ceil((dueAt - now) / DAY)), wrongCount: list.filter((x) => !x.correct).length });
  });
  return out.sort((a, b) => a.dueAt - b.dueAt);
}

/** 학습별 정답률 (누적 응시 기준) */
export function lessonAccuracy(attempts: Attempt[]) {
  const out: Record<string, { tries: number; correct: number; rate: number }> = {};
  attempts.forEach((a) => { const r = (out[a.lessonId] ||= { tries: 0, correct: 0, rate: 0 }); r.tries++; if (a.correct) r.correct++; });
  Object.values(out).forEach((r) => { r.rate = r.tries ? r.correct / r.tries : 0; });
  return out;
}

const INTEREST_TOPIC: Record<string, string[]> = { 저축: ['compound', 'emergency'], 투자: ['etf', 'order-type'], 절약: ['emergency', 'compound'], 비상금: ['emergency'] };

/** 오늘의 학습 추천 — 복습할 오답 → 최근 거래 → 관심 분야 → 기본 순서로, 이유와 함께 */
export function pickToday(s: {
  wishes: { status: string }[];
  invest: { orders: { side: string; status: string; name: string; id: string }[] };
  learning: { done: string[]; quizDone?: string[]; attempts?: Attempt[] };
  profile?: { interests?: string[] };
}, today = new Date().toISOString().slice(0, 10)): { id: string; reason: string; kind: 'review' | 'trade' | 'interest' | 'basic' } {
  const done = new Set(s.learning.done);
  const quizDone = new Set(s.learning.quizDone || []);
  const queue = reviewQueue(s.learning.attempts || [], today);
  const review = queue.find((r) => r.due);
  if (review) {
    const l = lessonById(review.lessonId);
    return { id: review.lessonId, kind: 'review', reason: `'${l?.title ?? ''}'에서 틀렸던 문제를 다시 풀 때예요 (${REVIEW_STEPS[review.stage]}일 복습)` };
  }
  // 방금 틀린 문제가 있으면 카드부터 한 번 더 정리
  const fresh = queue.find((r) => r.stage === 0);
  if (fresh) {
    const l = lessonById(fresh.lessonId);
    return { id: fresh.lessonId, kind: 'review', reason: `'${l?.title ?? ''}' 퀴즈에서 틀린 문제가 있어서, 카드를 한 번 더 정리해요` };
  }
  const lastBuy = s.invest.orders.find((o) => o.side === 'buy' && o.status === 'filled');
  if (lastBuy) {
    const code = { 'TIGER 미국S&P500': 'SP500', 'ACE 미국나스닥100': 'QQQ', 'MOA 평행 우주·AI': 'SPACE', 'SOL 한국고배당': 'DIVIDEND' }[lastBuy.name];
    const id = code ? stockLessonId(code) : 'etf';
    if (!quizDone.has(id)) return { id, kind: 'trade', reason: `가상 거래소에서 산 ${lastBuy.name}을 이해하는 학습이에요` };
  }
  if (s.invest.orders.some((o) => o.status === 'pending') && !done.has('order-type')) return { id: 'order-type', kind: 'basic', reason: '체결을 기다리는 지정가 주문이 있어서 골랐어요' };
  if (s.wishes.some((w) => w.status === 'skipped') && !done.has('compound')) return { id: 'compound', kind: 'basic', reason: '구매를 참은 금액이 있어서, 그 돈이 어떻게 불어나는지 골랐어요' };
  for (const it of s.profile?.interests || []) {
    const id = (INTEREST_TOPIC[it] || []).find((x) => !done.has(x));
    if (id) return { id, kind: 'interest', reason: `관심 분야로 고른 '${it}'에 맞춰 골랐어요` };
  }
  const basics: [string, string][] = [['emergency', '결제일 전 잔액을 지키는 첫걸음이라 골랐어요'], ['compound', '저축을 시작하기 전에 알아두면 좋아서 골랐어요'], ['etf', '투자를 시작하기 전에 알아두면 좋아서 골랐어요'], ['order-type', '가상 거래소에서 주문하기 전에 알아두면 좋아서 골랐어요']];
  const b = basics.find(([id]) => !done.has(id) || !quizDone.has(id)) || basics[0];
  return { id: b[0], kind: 'basic', reason: b[1] };
}
