// 모아 서버 연결
// - /api/ai/*  : 프론트 저장소의 Node 서버(Vercel api/index.mjs). 앱이 계산한 숫자를 받아 AI가 문장으로 풀어줘요.
// - /api/v4/*  : MOA_2ND_BE(FastAPI). Vercel 게이트웨이(api/moa-gateway.mjs)를 거쳐 호출해요.
// 서버가 꺼져 있거나 AI 크레딧이 없으면 null을 돌려주고, 화면은 앱 안의 계산 결과로 대신 보여줘요.
import { useEffect, useRef, useState } from 'react';

const BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/+$/, '') ?? '';

async function call<T>(path: string, init: { method?: 'GET' | 'POST'; body?: unknown; timeout?: number } = {}): Promise<T | null> {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), init.timeout ?? 8000);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: init.method ?? 'GET',
      headers: init.body ? { 'Content-Type': 'application/json' } : undefined,
      body: init.body ? JSON.stringify(init.body) : undefined,
      signal: ctrl.signal,
    });
    if (!res.ok) return null;
    const type = res.headers.get('content-type') || '';
    if (!type.includes('application/json')) return null; // 정적 호스팅에서 index.html이 돌아오는 경우
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

/* ───────── /api/ai (Node · FactChat) ───────── */
export type AiMeta = { source: 'live'; task: string; model: string; ms: number };
export type BriefIn = {
  usable: number; daysLeftInMonth: number; monthSpent: number; lastMonthSameDay: number | null;
  topCategory: { name: string; amount: number } | null; savedThisMonth: number; holdsThisMonth: number;
  nextBill: { date: string; amount: number } | null;
};
export type BriefOut = { headline: string; body: string; action: { label: string; to: 'choose' | 'ledger' | 'save' | 'forks' } | null };
export type CoachIn = { item: string; category: string; price: number; frequency: 'once' | 'weekly' | 'daily'; usableNow: number; usableAfter: number; afterBills: number; yearGap: number; categorySpentThisMonth: number; categoryCount30: number };
export type CoachOut = { tone: 'ok' | 'careful' | 'warn'; message: string; tip: string | null };

export async function aiTask<I, O>(task: 'brief' | 'coach' | 'ledgerSummary', input: I) {
  return call<{ data: O; meta: AiMeta }>(`/api/ai/${task}`, { method: 'POST', body: { input }, timeout: 15000 });
}

/* ───────── /api/v4 (FastAPI · MOA_2ND_BE) ───────── */
export const DEMO_AS_OF = '2026-11-04';
export type AgentRoute = {
  id: string; label: string; kind: string; purchase_date: string | null; payment_method: string;
  purchase_amount: number; savings_amount: number; investment_amount: number; purchase_delay_days: number;
  minimum_balance: number; ending_balance: number; savings_goal_impact: number; investment_profit_loss: number;
  investment_risk: string; hard_constraints_met: boolean; checks: Record<string, boolean>;
};
export type AgentSearch = {
  user_id: string; as_of: string; forecast_source: string | null; status: 'ok' | 'no_valid_route' | 'needs_confirmation';
  routes: AgentRoute[]; evaluated_count: number; valid_count: number; rejection_counts: Record<string, number>;
  conflict_explanations: string[]; confirmations_required: string[]; elapsed_ms: number; algorithm: string;
};
export type AgentToolLog = { tool: string; status: 'ok' | 'error'; arguments?: Record<string, unknown>; error?: string };
export type AgentAnalyze = {
  status: string; conditions: Record<string, unknown>; search: AgentSearch; tool_execution_log: AgentToolLog[];
  tool_success_rate: number; llm_model: string; elapsed_ms: number; numbers_source: string;
};
export type GoalConditions = {
  user_id: string; as_of: string; purchase_amount?: number; allowed_payment_methods: ('debit' | 'transfer' | 'credit')[];
  protect_essential_bills: boolean; investment_allowed: boolean; maximum_investment_amount: number;
  acceptable_purchase_delay_days?: number; required_savings_amount?: number;
};
export type Forecast = {
  model_type: string; model_version: string; data_quality_status: string; observed_days: number;
  daily: { date: string; amount: number }[]; forecasts: { horizon_days: number; predicted_variable_outflow: number }[];
};
export type DailyQuiz = { id: string; date: string; topic: string; source: string; model: string | null; question: string; options: string[]; answer_record?: { choice: number; correct: boolean } | null; explanation?: string | null; correct_answer?: number | null };
export type DailyAnswer = DailyQuiz & { answer_record: { choice: number; correct: boolean } | null; explanation: string | null; correct_answer: number | null };

export const v4 = {
  health: () => call<{ status: string; users: number; snapshot_date: string }>('/api/v4/health', { timeout: 5000 }),
  agentAnalyze: (user: string, goal: string) => call<AgentAnalyze>('/api/v4/agent/analyze', {
    method: 'POST', timeout: 45000, body: { user_id: user, as_of: DEMO_AS_OF, goal },
  }),
  agentSearch: (conditions: GoalConditions) => call<AgentSearch>('/api/v4/agent/search', {
    method: 'POST', timeout: 20000, body: { conditions, max_results: 3 },
  }),
  forecast: (user: string) => call<Forecast>(`/api/v4/users/${user}/forecast`),
  dailyQuiz: (user: string) => call<DailyQuiz>(`/api/v4/users/${user}/daily-quiz`),
  answerQuiz: (user: string, quizId: string, choice: number) => call<DailyAnswer>(`/api/v4/users/${user}/daily-quiz/answer`, {
    method: 'POST', body: { quiz_id: quizId, choice },
  }),
};

/** 화면에서 쓰는 비동기 훅 — 같은 키는 한 세션 동안 한 번만 호출해요(AI 비용 통제). */
const memo = new Map<string, unknown>();
export function useRemote<T>(key: string | null, fn: () => Promise<T | null>) {
  const [state, setState] = useState<{ data: T | null; loading: boolean }>(() => ({
    data: key && memo.has(key) ? (memo.get(key) as T) : null,
    loading: !!key && !memo.has(key),
  }));
  const fnRef = useRef(fn);
  fnRef.current = fn;
  useEffect(() => {
    if (!key) return;
    if (memo.has(key)) { setState({ data: memo.get(key) as T, loading: false }); return; }
    let alive = true;
    setState((s) => ({ ...s, loading: true }));
    fnRef.current().then((data) => {
      if (data != null) memo.set(key, data);
      if (alive) setState({ data, loading: false });
    });
    return () => { alive = false; };
  }, [key]);
  return state;
}

/* ───────── /api/discord · /api/daily (Node 서버의 Discord 웹훅) ───────── */
export function deviceId() {
  try {
    let id = localStorage.getItem('moa.device');
    if (!id || !/^[0-9a-f-]{20,64}$/i.test(id)) {
      id = (crypto.randomUUID?.() ?? `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}-moa`).toLowerCase();
      localStorage.setItem('moa.device', id);
    }
    return id;
  } catch { return '00000000-0000-4000-8000-000000000000'; }
}
async function callDevice<T>(path: string, method: 'GET' | 'POST' | 'PUT', body?: unknown) {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), 12000);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method, signal: ctrl.signal,
      headers: { 'x-device-id': deviceId(), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const type = res.headers.get('content-type') || '';
    if (!type.includes('application/json')) return { ok: false as const, error: '서버에 연결할 수 없어요.' };
    const json = await res.json();
    if (!res.ok) return { ok: false as const, error: (json?.message || json?.error?.message || 'Discord 전송에 실패했어요.') as string };
    return { ok: true as const, data: json as T };
  } catch {
    return { ok: false as const, error: '서버에 연결할 수 없어요.' };
  } finally { window.clearTimeout(timer); }
}
export type DiscordStatus = { configured: boolean; misconfigured: boolean; lastSuccessAt: number | null; lastError: string | null; destination?: string };
export const discord = {
  status: () => call<DiscordStatus>('/api/discord/status', { timeout: 6000 }),
  test: () => callDevice<{ ok: true; status: DiscordStatus }>('/api/discord/test', 'POST'),
  subscribe: (time: string, nickname: string, streak: number) =>
    callDevice<{ subscription: unknown }>('/api/daily/subscription', 'PUT', {
      enabled: true, time, nickname: nickname.slice(0, 12), includePhotos: false, level: 1,
      nextLessonId: null, streak: Math.max(0, Math.min(10000, streak)), holdings: [], watchlist: [],
    }),
};

/* ───────── 가상 거래 체결 → 종목 학습 카드뉴스를 Discord로 (/api/discord/trade-card) ───────── */
export type TradeCardInput = {
  tradeId: string; name: string; side: 'buy' | 'sell'; shares: number; price: number; cashLeft?: number;
  lesson: { title: string; points: string[]; risk?: string; quiz?: { q: string; options: string[] } }; link?: string;
};
export async function sendTradeCard(t: TradeCardInput) {
  return callDevice<{ ok: true; ai?: boolean; model?: string | null; duplicate?: boolean }>('/api/discord/trade-card', 'POST', {
    ...t, tradeId: t.tradeId.replace(/[^\w-]/g, '').slice(0, 80).padEnd(4, '0'),
  });
}
