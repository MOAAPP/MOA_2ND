// 기록이 만든 평행세계
// 가계부·구매 고민·예적금·모의투자에 남긴 '실제 기록' 하나하나를 갈림길로 보고,
// 그 선택을 반대로 했을 때의 나(평행세계)와 지금의 나를 같은 가정으로 비교해요.
// 금액은 코드가 계산해요. 투자 결과는 보장된 수익이 아니라 연 수익률 가정이에요.
import { APP_TODAY, getState } from './store';

type S = ReturnType<typeof getState>;
export type BranchKind = 'save' | 'skip' | 'invest' | 'spend' | 'buy';
export type Branch = {
  id: string; kind: BranchKind; date: string; title: string; amount: number;
  /** 지금의 나에게 이 기록이 어떤 의미였는지 (UI 문구) */
  mine: string; other: string; rate: number;
};

const SPEND_CATS = ['쇼핑', '카페/간식', '디지털/가전'];

export function collectBranches(s: S = getState()): Branch[] {
  const save = s.simSettings.saveRate / 100;
  const inv = s.simSettings.investRate / 100;
  const out: Branch[] = [];
  (s.savings || []).forEach((p) => (p.history?.length ? p.history : [{ date: p.startedAt, amount: p.principal, kind: 'join' as const }])
    .forEach((h, i) => out.push({
      id: `sv-${p.id}-${i}`, kind: 'save', date: h.date, title: `${p.name} ${h.kind === 'join' ? '가입' : '납입'}`, amount: h.amount,
      mine: '예·적금에 넣었어요', other: '그 돈을 그냥 썼어요', rate: p.rate / 100,
    })));
  s.wishes.filter((w) => w.status === 'skipped' || w.status === 'bought').forEach((w) => out.push({
    id: `w-${w.id}`, kind: w.status === 'skipped' ? 'skip' : 'buy', date: (w.decidedAt || w.createdAt).slice(0, 10), title: w.name, amount: w.amount,
    mine: w.status === 'skipped' ? '고민 끝에 사지 않았어요' : '고민 끝에 샀어요', other: w.status === 'skipped' ? '바로 샀어요' : '사지 않고 모았어요', rate: save,
  }));
  const filled = s.invest.orders.filter((o) => o.status === 'filled' && o.side === 'buy');
  if (filled.length) filled.forEach((o) => out.push({
    id: `o-${o.id}`, kind: 'invest', date: (o.filledAt || o.at).slice(0, 10), title: `${o.name} 매수`, amount: Math.round(o.price * o.shares),
    mine: '가상으로 투자했어요', other: '현금으로 두었어요', rate: inv,
  }));
  else Object.entries(s.invest.holdings || {}).filter(([, q]) => q > 0).forEach(([name, q]) => out.push({
    id: `h-${name}`, kind: 'invest', date: APP_TODAY.slice(0, 8) + '01', title: `${name} 보유`, amount: Math.round(q * (s.invest.avgPrice[name] || 0)),
    mine: '가상으로 투자했어요', other: '현금으로 두었어요', rate: inv,
  }));
  s.txs.filter((t) => t.type === 'expense' && t.date <= APP_TODAY && SPEND_CATS.includes(t.category) && t.amount >= 6000).forEach((t) => out.push({
    id: `t-${t.id}`, kind: 'spend', date: t.date, title: t.title, amount: t.amount,
    mine: '썼어요', other: '쓰지 않고 적금에 넣었어요', rate: save,
  }));
  return out.filter((b) => b.amount > 0).sort((a, b) => b.date.localeCompare(a.date));
}

/** years년 뒤 이 갈림길 하나가 만든 차이 (+면 지금의 내가 유리, -면 반대 선택이 유리) */
export function branchGap(b: Branch, years: number) {
  const grow = (r: number) => b.amount * Math.pow(1 + r, years);
  switch (b.kind) {
    case 'save': return grow(b.rate);                  // 넣은 나: 원금+이자 / 반대: 0
    case 'skip': return b.amount;                      // 안 산 나: 현금 보유 / 반대: 0
    case 'invest': return grow(b.rate) - b.amount;     // 투자한 나 vs 현금으로 둔 나 (가정 수익률)
    case 'spend':
    case 'buy': return -grow(b.rate);                  // 쓴 나: 0 / 반대: 적금 원리금
  }
}

export function worldSummary(branches: Branch[], years: number, flipped: Set<string> = new Set()) {
  let mine = 0; let gained = 0; let missed = 0;
  branches.forEach((b) => {
    const g = branchGap(b, years) * (flipped.has(b.id) ? -1 : 1);
    mine += g;
    if (g >= 0) gained += g; else missed += -g;
  });
  return { gap: Math.round(mine), gained: Math.round(gained), missed: Math.round(missed), count: branches.length };
}

/** 그래프용: 0~years 사이 지금의 나 / 평행세계의 나 누적 자산(기록 금액 기준) */
export function worldSeries(branches: Branch[], years: number, flipped: Set<string>, steps = 24) {
  return Array.from({ length: steps + 1 }, (_, i) => {
    const t = (years * i) / steps;
    let mine = 0; let other = 0;
    branches.forEach((b) => {
      const flip = flipped.has(b.id);
      const keepCash = b.amount;
      const grown = b.amount * Math.pow(1 + b.rate, t);
      // 각 세계에서 이 기록 금액이 남긴 자산
      const a = b.kind === 'save' ? grown : b.kind === 'skip' ? keepCash : b.kind === 'invest' ? grown : 0;
      const o = b.kind === 'save' ? 0 : b.kind === 'skip' ? 0 : b.kind === 'invest' ? keepCash : grown;
      mine += flip ? o : a; other += flip ? a : o;
    });
    return { t, mine: Math.round(mine), other: Math.round(other) };
  });
}

export const KIND_META: Record<BranchKind, { label: string; color: string; bg: string }> = {
  save: { label: '저축', color: '#2563EB', bg: '#EAF1FF' },
  skip: { label: '참음', color: '#0E9F8E', bg: '#E6F7F4' },
  invest: { label: '투자', color: '#7C3AED', bg: '#F1EBFF' },
  spend: { label: '소비', color: '#F04452', bg: '#FFEEF0' },
  buy: { label: '구매', color: '#F04452', bg: '#FFEEF0' },
};
