// Small persistent app state (works without a backend; swap for API calls later).
// 스프링부트 API가 붙으면 read/setState 와 각 액션 함수 내부만 API 호출로 바꾸면 화면은 그대로 동작해요.
/**
 * 두 가지 시작 방식
 * - /demo (또는 ?demo) : 발표·테스트용. 예시 기록이 채워진 상태로 바로 홈에서 시작하고, 들어올 때마다 처음 상태로 돌아가요.
 * - /     : 일반 사용자. 빈 상태에서 온보딩부터 시작하고, 기록은 이 기기에 계속 남아요.
 */
export const MODE: 'demo' | 'user' = (() => {
  try {
    const q = new URLSearchParams(location.search);
    const path = location.pathname.replace(/\/+$/, '');
    if (path === '/demo' || q.has('demo')) {
      sessionStorage.setItem('moa.mode', 'demo');
      localStorage.removeItem('moa.demo.v1');
      history.replaceState(null, '', '/');
      return 'demo';
    }
    if (path === '/start' || q.has('new')) {
      sessionStorage.removeItem('moa.mode');
      history.replaceState(null, '', '/');
      return 'user';
    }
    if (sessionStorage.getItem('moa.mode') === 'demo') return 'demo';
    if (import.meta.env.VITE_DEFAULT_MODE === 'demo') return 'demo';
  } catch { /* 저장소를 쓸 수 없는 환경 */ }
  return 'user';
})();
const KEY = MODE === 'demo' ? 'moa.demo.v1' : 'moa.v1';

export type Profile = { name: string; payday: number; monthlyBudget: number; goal: string; goalAmount?: number; level?: string; interests?: string[]; bank?: string | null };
export type SavingsDeposit = { date: string; amount: number; kind: 'join' | 'deposit' };
export type SavingsProduct = { id: string; kind: 'deposit' | 'saving'; name: string; rate: number; months: number; monthly: number; principal: number; startedAt: string; history?: SavingsDeposit[] };

/** 가계부에 실제로 반영되는 거래 */
export type TxType = 'expense' | 'income' | 'transfer';
export type Tx = { id: string; type: TxType; amount: number; title: string; category: string; payment: string; date: string; time?: string; memo?: string; wishId?: string; sample?: boolean; balanceApplied?: boolean };

/** 필수 결제(월세·카드값·통신비 등) — 매월 같은 날 빠져나가는 돈 */
export type BillKind = 'card' | 'rent' | 'phone' | 'subscription' | 'loan' | 'etc';
export type Bill = { id: string; name: string; amount: number; day: number; kind: BillKind };
/** 생활비 통장 기준 금융 상태 (계좌 자동 연결 전에는 직접 입력) */
export type Finance = { balance: number; minBalance: number; salary: number };
/** 학습 알림 설정 — Discord 전송은 연동되면 이 설정대로 보내요 */
export type LearnAlert = { on: boolean; time: string; topics: string[]; discord: boolean; discordConsent: boolean };

/** 구매 고민 — 등록만으로는 잔액에 반영되지 않음 */
export type WishStatus = 'thinking' | 'later' | 'bought' | 'skipped';
export type Necessity = 'must' | 'delay' | 'want';
export type Wish = {
  id: string; name: string; amount: number; category: string; payment: string; necessity: Necessity;
  plannedDate: string | null; reason: string; status: WishStatus; createdAt: string; decidedAt?: string; txId?: string;
};

/** 모의투자 */
export type OrderSide = 'buy' | 'sell';
export type Order = { id: string; name: string; side: OrderSide; shares: number; price: number; type: 'market' | 'limit'; status: 'filled' | 'pending' | 'canceled'; at: string; limitPrice?: number; filledAt?: string };
export type InvestState = { cash: number; holdings: Record<string, number>; avgPrice: Record<string, number>; orders: Order[]; target: Record<string, number> };

/** 평행세계 저장 시나리오 */
export type WorldOptions = { delayMonths: number; mix: number[]; saveRate: number; investRate: number };
export type Scenario = { id: string; title: string; amount: number; worldId: number; worldName: string; years: number; value: number; createdAt: string; wishId?: string; opts?: WorldOptions; cash?: number };

/** 금융 학습 기록 */
export type LessonCardLike = { title: string; body: string; point?: string; emoji?: string };
export type QuizResult = { questionId: string; lessonId: string; correct: boolean; at: string };
/** done: 카드를 끝까지 읽은 학습, quizDone: 퀴즈까지 끝낸 학습, attempts: 모든 응시 기록(누적) */
export type LearningState = { done: string[]; quizDone: string[]; progress: Record<string, number>; quiz: QuizResult[]; attempts: QuizResult[]; activity: string[] };

type State = {
  onboarded: boolean; profile: Profile; savings: SavingsProduct[]; readNoti: string[]; budgets: Record<string, number>; settings: Record<string, boolean>;
  txs: Tx[]; wishes: Wish[]; invest: InvestState; scenarios: Scenario[]; learning: LearningState;
  finance: Finance; bills: Bill[]; dataVersion: number;
  learnAlert: LearnAlert; supportDrafts: { id: string; body: string; at: string }[];
  simSettings: WorldOptions & { risk: 'stable' | 'balanced' | 'active' };
};

// 앱 전체가 쓰는 '오늘' — 가계부·구매 고민·예적금 이자·결제 일정이 모두 이 날짜를 기준으로 계산해요.
// 실제 날짜로 바꾸려면 이 한 줄만 new Date() 기반으로 바꾸면 됩니다.
// Local date (Asia/Seoul for the intended audience). Existing November 2026 examples remain clearly labeled as sample data.
export const APP_TODAY = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })();
export const todayDate = () => new Date(`${APP_TODAY}T00:00:00`);

// 11월 가계부 기본 내역 (달력 시안과 같은 금액)
const S = (date: string, type: TxType, title: string, category: string, amount: number, time = '', payment = '체크카드 (즉시 출금)'): Tx =>
  ({ id: `x${date.slice(5).replace('-', '')}${title.length}${amount}`, date, type, title, category, amount, time, payment, sample: true });
export const SAMPLE_TXS: Tx[] = [
  S('2026-11-02', 'expense', '파리바게뜨 강남역점', '식비', 15400, '08:45'),
  S('2026-11-03', 'expense', 'GS25 역삼점', '생활/마트', 8500, '21:10'),
  S('2026-11-04', 'expense', 'KTX 서울→대전', '교통', 32000, '07:30'),
  S('2026-11-05', 'income', '11월 정기 급여 입금', '급여', 1500000, '10:00', '계좌이체 (직접 이체)'),
  S('2026-11-05', 'expense', '이마트 역삼점 장보기', '생활/마트', 104250, '19:20'),
  S('2026-11-06', 'expense', '지하철·버스', '교통', 4500, '18:40'),
  S('2026-11-08', 'income', '중고거래 판매', '기타', 50000, '15:30', '계좌이체 (직접 이체)'),
  S('2026-11-09', 'expense', '올리브영 강남본점', '쇼핑', 32200, '13:10'),
  S('2026-11-09', 'expense', '교보문고 서적 구매', '기타', 16000, '18:50'),
  S('2026-11-10', 'expense', '스타벅스 역삼점', '카페/간식', 6500, '14:20'),
  S('2026-11-10', 'expense', '마켓컬리 장보기', '식비', 28000, '08:15'),
  S('2026-11-10', 'transfer', '청년도약적금 자동이체', '저축', 300000, '09:00', '계좌이체 (직접 이체)'),
  S('2026-11-10', 'transfer', '주택청약 종합저축', '저축', 100000, '09:30', '계좌이체 (직접 이체)'),
];
export const EXPENSE_CATEGORIES = ['식비', '카페/간식', '교통', '쇼핑', '생활/마트', '의료/건강', '디지털/가전', '기타'];
const DEFAULT_BUDGETS: Record<string, number> = { 식비: 150000, '카페/간식': 40000, 교통: 60000, 쇼핑: 80000, '생활/마트': 100000, '의료/건강': 20000, '디지털/가전': 20000, 기타: 30000 };
const DATA_VERSION = 3;

const DEFAULT: State = {
  onboarded: false,
  profile: { name: '지현', payday: 25, monthlyBudget: 500000, goal: '여행 자금 모으기', goalAmount: 1000000, level: '', interests: [] },
  savings: [
    { id: 's1', kind: 'saving', name: '우주여행 적금', rate: 4.5, months: 12, monthly: 100000, principal: 400000, startedAt: '2026-07-25',
      history: [{ date: '2026-07-25', amount: 100000, kind: 'join' }, { date: '2026-08-25', amount: 100000, kind: 'deposit' }, { date: '2026-09-25', amount: 100000, kind: 'deposit' }, { date: '2026-10-25', amount: 100000, kind: 'deposit' }] },
    { id: 's2', kind: 'deposit', name: '비상금 파킹 예금', rate: 3.8, months: 6, monthly: 0, principal: 300000, startedAt: '2026-09-01',
      history: [{ date: '2026-09-01', amount: 300000, kind: 'join' }] },
  ],
  readNoti: [],
  budgets: DEFAULT_BUDGETS,
  settings: { push: true, payAlert: true, aiBrief: true, marketing: false, lock: true },
  txs: SAMPLE_TXS,
  wishes: [],
  invest: {
    cash: 518000,
    holdings: { 'TIGER 미국S&P500': 1.45, 'ACE 미국나스닥100': 0.68, 'MOA 평행 우주·AI': 1.0, 'SOL 한국고배당': 2.1 },
    avgPrice: { 'TIGER 미국S&P500': 58783, 'ACE 미국나스닥100': 29397, 'MOA 평행 우주·AI': 12020, 'SOL 한국고배당': 27157 },
    orders: [],
    // 목표 비중(%) — 포트폴리오 화면에서 조정, 합계 100
    target: { SP500: 45, QQQ: 25, DIVIDEND: 20, SPACE: 10 },
  },
  scenarios: [],
  learning: { done: [], quizDone: [], progress: {}, quiz: [], attempts: [], activity: [] },
  finance: { balance: 420000, minBalance: 100000, salary: 2450000 },
  bills: [
    { id: 'b1', name: '카드값', amount: 98000, day: 14, kind: 'card' },
    { id: 'b2', name: '통신비', amount: 23887, day: 20, kind: 'phone' },
    { id: 'b3', name: '월세', amount: 520000, day: 1, kind: 'rent' },
  ],
  dataVersion: DATA_VERSION,
  supportDrafts: [],
  learnAlert: { on: true, time: '08:00', topics: ['오늘의 학습', '복습할 문제'], discord: false, discordConsent: false },
  simSettings: { delayMonths: 3, mix: [1, 1, 1], saveRate: 3.8, investRate: 7.2, risk: 'balanced' },
};

/** 일반 사용자: 예시 기록 없이 빈 상태에서 시작 (가상 투자용 방어 머니만 지급) */
const EMPTY: State = {
  ...DEFAULT,
  onboarded: false,
  profile: { ...DEFAULT.profile, name: '', goal: '여행 자금 모으기', goalAmount: 1000000 },
  savings: [],
  txs: [],
  wishes: [],
  invest: { cash: 1000000, holdings: {}, avgPrice: {}, orders: [], target: DEFAULT.invest.target },
  scenarios: [],
  finance: { balance: 0, minBalance: 100000, salary: 0 },
  bills: [],
};
const DEMO: State = { ...DEFAULT, onboarded: true };
const BASE: State = MODE === 'demo' ? DEMO : EMPTY;

function read(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return JSON.parse(JSON.stringify(BASE)) as State;
    const saved = JSON.parse(raw);
    const merged: State = { ...BASE, ...saved, invest: { ...BASE.invest, ...(saved.invest || {}) }, learning: { ...BASE.learning, ...(saved.learning || {}) }, finance: { ...BASE.finance, ...(saved.finance || {}) }, learnAlert: { ...BASE.learnAlert, ...(saved.learnAlert || {}) }, simSettings: { ...BASE.simSettings, ...(saved.simSettings || {}) } };
    // v1 → v2: 기본 가계부 내역을 거래 목록에 넣고, 예산 카테고리를 기록 카테고리와 맞춤
    if ((saved.dataVersion || 1) < 2) {
      const ids = new Set((merged.txs || []).map((t) => t.id));
      merged.txs = [...(merged.txs || []), ...SAMPLE_TXS.filter((t) => !ids.has(t.id))];
      merged.budgets = DEFAULT_BUDGETS;
      merged.learning = { ...merged.learning, attempts: merged.learning.attempts?.length ? merged.learning.attempts : merged.learning.quiz || [] };
      merged.dataVersion = DATA_VERSION;
    }
    merged.dataVersion = DATA_VERSION;
    return merged;
  } catch {
    return JSON.parse(JSON.stringify(BASE)) as State;
  }
}
let state = read();
const subs = new Set<() => void>();

export function getState() { return state; }
export function setState(patch: Partial<State> | ((s: State) => Partial<State>)) {
  const p = typeof patch === 'function' ? patch(state) : patch;
  state = { ...state, ...p };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* private mode */ }
  subs.forEach((f) => f());
}
export function subscribe(f: () => void) { subs.add(f); return () => { subs.delete(f); }; }
export const isOnboarded = () => state.onboarded;
/** 이 브라우저의 모든 시연 기록을 초기 상태로 되돌림. 계정 삭제나 서버 삭제가 아님. */
export function resetDemoData() {
  state = JSON.parse(JSON.stringify(BASE)) as State;
  try { localStorage.removeItem(KEY); } catch { /* private mode */ }
  subs.forEach((f) => f());
}


import { useSyncExternalStore } from 'react';
export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(subscribe, () => sel(state));
}

export const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
export const uid = (p: string) => `${p}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
/** 앱 기준 '지금' = APP_TODAY + 실제 시각. 기록·응시 시간도 앱 날짜를 따라요 */
export const appNow = () => { const n = new Date(); const d = todayDate(); d.setHours(n.getHours(), n.getMinutes(), n.getSeconds(), n.getMilliseconds()); return d; };
const nowIso = () => appNow().toISOString();

// ---------- 거래 ----------
// 직접 입력한 계좌 거래만 생활비 통장에 반영. 신용카드 승인/보유 현금 지출은 당일 계좌 출금이 아님.
// 샘플 거래는 초기 잔액(balance snapshot)에 이미 반영된 과거 예시로 취급.
export const isCreditPayment = (p: string = '') => /신용카드|credit/i.test(p);
export const isCashPayment = (p: string = '') => /현금(?!흐름)/.test(p);
export function balanceDelta(t: Pick<Tx, 'type' | 'amount' | 'payment' | 'sample'> & { date?: string; balanceApplied?: boolean }) {
  if (t.sample || t.balanceApplied === false || (t.balanceApplied !== true && t.date && t.date > APP_TODAY)) return 0;
  if (t.type === 'income') return isCashPayment(t.payment) ? 0 : t.amount;
  if (t.type === 'expense' && (isCreditPayment(t.payment) || isCashPayment(t.payment))) return 0;
  return -t.amount;
}
export function addTx(tx: Omit<Tx, 'id'>) {
  const t: Tx = { ...tx, balanceApplied: tx.date <= APP_TODAY, id: uid('t') };
  setState((s) => ({ txs: [t, ...s.txs], finance: { ...s.finance, balance: s.finance.balance + balanceDelta(t) } }));
  return t;
}
export function updateTx(id: string, patch: Partial<Tx>) {
  setState((s) => {
    const prev = s.txs.find((t) => t.id === id);
    if (!prev) return {};
    const next = { ...prev, ...patch, balanceApplied: patch.date !== undefined && patch.date !== prev.date ? patch.date <= APP_TODAY : prev.balanceApplied };
    return { txs: s.txs.map((t) => (t.id === id ? next : t)), finance: { ...s.finance, balance: s.finance.balance - balanceDelta(prev) + balanceDelta(next) } };
  });
}
export function removeTx(id: string) {
  setState((s) => {
    const prev = s.txs.find((t) => t.id === id);
    return {
      txs: s.txs.filter((t) => t.id !== id),
      finance: prev ? { ...s.finance, balance: s.finance.balance - balanceDelta(prev) } : s.finance,
      // 구매 완료로 연결된 고민이 있으면 다시 '고민 중'으로 되돌림
      wishes: s.wishes.map((w) => (w.txId === id ? { ...w, status: 'thinking', txId: undefined, decidedAt: undefined } : w)),
    };
  });
}
/** 온보딩 전체 예산을 기존 카테고리 비중대로 배분. 어떤 금액에서도 합계가 정확함. */
export function scaleBudgets(budgets: Record<string, number>, requested: number) {
  const keys = Object.keys(budgets);
  if (!keys.length) return budgets;
  const target = Math.max(0, Math.round(Number.isFinite(requested) ? requested : 0));
  const weight = keys.map((k) => Math.max(0, budgets[k] || 0));
  const sum = weight.reduce((a, b) => a + b, 0);
  const exact = weight.map((w) => (target * (sum ? w / sum : 1 / keys.length)));
  const rounded = exact.map(Math.floor);
  let remain = target - rounded.reduce((a, b) => a + b, 0);
  const order = keys.map((_, i) => i).sort((a, b) => exact[b] - rounded[b] - (exact[a] - rounded[a]));
  for (let i = 0; i < remain; i++) rounded[order[i % keys.length]]++;
  return Object.fromEntries(keys.map((k, i) => [k, rounded[i]]));
}

export const TX_LABEL: Record<TxType, string> = { expense: '지출', income: '수입', transfer: '이체' };

// ---------- 구매 고민 ----------
export function addWish(w: Omit<Wish, 'id' | 'status' | 'createdAt'>) {
  const item: Wish = { ...w, id: uid('w'), status: 'thinking', createdAt: nowIso() };
  setState((s) => ({ wishes: [item, ...s.wishes] }));
  return item;
}
export function updateWish(id: string, patch: Partial<Wish>) {
  const before = state.wishes.find((w) => w.id === id);
  if (!before) return;
  if (before.txId && (patch.amount !== undefined || patch.payment || patch.category || patch.name || patch.plannedDate)) {
    updateTx(before.txId, {
      amount: patch.amount ?? before.amount, payment: patch.payment ?? before.payment,
      category: patch.category ?? before.category, title: patch.name ?? before.name,
      date: patch.plannedDate ?? before.plannedDate ?? APP_TODAY,
    });
  }
  setState((s) => ({ wishes: s.wishes.map((w) => (w.id === id ? { ...w, ...patch } : w)) }));
}
export function removeWish(id: string) {
  setState((s) => ({ wishes: s.wishes.filter((w) => w.id !== id) }));
}
/** 구매 결정. 'bought'만 가계부 지출이 생기고, 나머지는 잔액에 영향 없음 */
export function decideWish(id: string, status: WishStatus, opts: { date?: string } = {}) {
  const w = state.wishes.find((x) => x.id === id);
  if (!w) return;
  let txId = w.txId;
  if (w.txId && status !== 'bought') { removeTx(w.txId); txId = undefined; }
  if (status === 'bought' && !w.txId) {
    txId = addTx({ type: 'expense', amount: w.amount, title: w.name, category: w.category, payment: w.payment, date: opts.date || APP_TODAY, memo: '구매 고민에서 구매 완료', wishId: w.id }).id;
  }
  updateWish(id, { status, txId, decidedAt: status === 'thinking' ? undefined : nowIso(), plannedDate: opts.date ?? w.plannedDate });
}
export const WISH_LABEL: Record<WishStatus, string> = { thinking: '고민 중', later: '보류 중', bought: '구매 완료', skipped: '구매 포기' };
export const skippedTotal = (s: State = state) => s.wishes.filter((w) => w.status === 'skipped').reduce((a, w) => a + w.amount, 0);

// ---------- 모의투자 ----------
/**
 * 주문. price = 지금 가상 시세.
 * 지정가(limitPrice)는 매수는 시세가 지정가 이하, 매도는 이상일 때 체결 — 이미 조건을 만족하면 바로 체결되고, 아니면 대기해요.
 */
export function placeOrder(o: { name: string; side: OrderSide; shares: number; price: number; type: 'market' | 'limit'; limitPrice?: number }): { ok: boolean; reason?: string; order?: Order } {
  const inv = state.invest;
  const have = inv.holdings[o.name] || 0;
  const pendingSell = inv.orders.filter((x) => x.status === 'pending' && x.side === 'sell' && x.name === o.name).reduce((a, x) => a + x.shares, 0);
  if (!Number.isFinite(o.shares) || !(o.shares > 0)) return { ok: false, reason: '주문 수량을 확인해 주세요.' };
  if (!Number.isFinite(o.price) || o.price <= 0) return { ok: false, reason: '가상 시세를 확인할 수 없어요. 잠시 뒤 다시 시도해 주세요.' };
  if (o.type === 'limit' && !(Number.isFinite(o.limitPrice) && o.limitPrice! > 0)) return { ok: false, reason: '지정 가격을 입력해 주세요.' };
  const marketable = o.type === 'market' || (o.side === 'buy' ? o.price <= o.limitPrice! : o.price >= o.limitPrice!);
  const reservePrice = o.type === 'limit' && !marketable ? o.limitPrice! : o.price;
  if (o.side === 'buy' && reservePrice * o.shares > inv.cash) return { ok: false, reason: '주문 가능한 방어 머니가 부족해요.' };
  if (o.side === 'sell' && o.shares > have - pendingSell + 1e-9) return { ok: false, reason: `팔 수 있는 수량(${fmtShares(Math.max(0, have - pendingSell))}주)보다 많이 팔 수 없어요.` };
  const order: Order = { id: uid('o'), name: o.name, side: o.side, shares: o.shares, type: o.type, limitPrice: o.limitPrice, price: marketable ? o.price : reservePrice, status: marketable ? 'filled' : 'pending', at: nowIso() };
  if (order.status === 'pending') {
    // 대기 중에는 매수 금액을 묶어둠(매도는 수량을 묶음)
    setState((s) => ({ invest: { ...s.invest, cash: o.side === 'buy' ? s.invest.cash - reservePrice * o.shares : s.invest.cash, orders: [order, ...s.invest.orders] } }));
    return { ok: true, order };
  }
  applyFill(order, true);
  return { ok: true, order };
}
/** 대기 중인 지정가 주문을 현재 가상 시세로 점검해 조건을 만족하면 체결 */
export function settlePending(priceOf: (name: string) => number) {
  const done: Order[] = [];
  state.invest.orders.filter((o) => o.status === 'pending').forEach((o) => {
    const p = priceOf(o.name);
    if (!p || !o.limitPrice) return;
    if ((o.side === 'buy' && p <= o.limitPrice) || (o.side === 'sell' && p >= o.limitPrice)) { const filled = fillPending(o.id, p); if (filled) done.push(filled); }
  });
  return done;
}
function applyFill(o: Order, chargeCash: boolean, reservedBuyAmount = 0) {
  setState((s) => {
    const inv = s.invest;
    const have = inv.holdings[o.name] || 0;
    const cost = o.price * o.shares;
    const holdings = { ...inv.holdings };
    const avgPrice = { ...inv.avgPrice };
    let cash = inv.cash;
    if (o.side === 'buy') {
      const next = have + o.shares;
      avgPrice[o.name] = Math.round(((avgPrice[o.name] || o.price) * have + cost) / next);
      holdings[o.name] = round2(next);
      if (chargeCash) cash -= cost;
      else cash += reservedBuyAmount - cost; // limit buy: release unused reserved funds
    } else {
      holdings[o.name] = round2(Math.max(0, have - o.shares));
      cash += cost;
    }
    const orders = inv.orders.some((x) => x.id === o.id)
      ? inv.orders.map((x) => (x.id === o.id ? { ...x, price: o.price, status: 'filled' as const, filledAt: nowIso() } : x))
      : [{ ...o, status: 'filled' as const, filledAt: nowIso() }, ...inv.orders];
    return { invest: { ...inv, cash, holdings, avgPrice, orders } };
  });
}
export function fillPending(id: string, executionPrice?: number): Order | undefined {
  const o = state.invest.orders.find((x) => x.id === id && x.status === 'pending');
  if (!o || !o.limitPrice) return;
  const price = executionPrice ?? o.limitPrice;
  if (!Number.isFinite(price) || price <= 0 || (o.side === 'buy' && price > o.limitPrice) || (o.side === 'sell' && price < o.limitPrice)) return;
  if (o.side === 'sell' && o.shares > (state.invest.holdings[o.name] || 0) + 1e-9) { cancelOrder(id); return; }
  const filled = { ...o, price };
  applyFill(filled, false, o.side === 'buy' ? o.limitPrice * o.shares : 0);
  return { ...filled, status: 'filled' };
}
export function cancelOrder(id: string) {
  const o = state.invest.orders.find((x) => x.id === id && x.status === 'pending');
  if (!o) return;
  setState((s) => ({
    invest: {
      ...s.invest,
      cash: o.side === 'buy' ? s.invest.cash + o.price * o.shares : s.invest.cash,
      orders: s.invest.orders.map((x) => (x.id === id ? { ...x, status: 'canceled' as const } : x)),
    },
  }));
}
const round2 = (n: number) => Math.round(n * 100) / 100;
export const fmtShares = (n: number) => String(round2(n));

// ---------- 평행세계 ----------
export function addScenario(sc: Omit<Scenario, 'id' | 'createdAt'>) {
  const item: Scenario = { ...sc, id: uid('sc'), createdAt: nowIso() };
  setState((s) => ({ scenarios: [item, ...s.scenarios].slice(0, 30) }));
  return item;
}
export function setTargetWeights(target: Record<string, number>) {
  setState((s) => ({ invest: { ...s.invest, target } }));
}
export function removeScenario(id: string) {
  setState((s) => ({ scenarios: s.scenarios.filter((x) => x.id !== id) }));
}

// ---------- 학습 ----------
const markActivity = (l: LearningState) => (l.activity.includes(APP_TODAY) ? l.activity : [...l.activity, APP_TODAY].slice(-60));
export function setLessonProgress(lessonId: string, card: number, total: number) {
  setState((s) => ({
    learning: {
      ...s.learning,
      activity: markActivity(s.learning),
      progress: { ...s.learning.progress, [lessonId]: Math.max(s.learning.progress[lessonId] || 0, card) },
      done: card >= total && !s.learning.done.includes(lessonId) ? [...s.learning.done, lessonId] : s.learning.done,
    },
  }));
}
/** 응시 기록은 누적(attempts), quiz에는 문제별 최신 결과만 */
export function recordQuiz(r: Omit<QuizResult, 'at'>) {
  const item = { ...r, at: nowIso() };
  setState((s) => ({ learning: { ...s.learning, activity: markActivity(s.learning), attempts: [...s.learning.attempts, item].slice(-500), quiz: [...s.learning.quiz.filter((q) => q.questionId !== r.questionId), item] } }));
}
export function finishQuiz(lessonId: string) {
  setState((s) => ({ learning: { ...s.learning, quizDone: s.learning.quizDone.includes(lessonId) ? s.learning.quizDone : [...s.learning.quizDone, lessonId] } }));
}

// ---------- 필수 결제 · 금융 상태 ----------
export function setFinance(patch: Partial<Finance>) { setState((s) => ({ finance: { ...s.finance, ...patch } })); }
export function saveBill(b: Omit<Bill, 'id'> & { id?: string }) {
  setState((s) => ({ bills: b.id ? s.bills.map((x) => (x.id === b.id ? { ...x, ...b } as Bill : x)) : [...s.bills, { ...b, id: uid('b') } as Bill] }));
}
export function removeBill(id: string) { setState((s) => ({ bills: s.bills.filter((x) => x.id !== id) })); }

export function timeAgo(iso: string) {
  const d = Math.max(0, (appNow().getTime() - new Date(iso).getTime()) / 1000);
  if (d < 60) return '방금 전';
  if (d < 3600) return `${Math.floor(d / 60)}분 전`;
  if (d < 86400) return `${Math.floor(d / 3600)}시간 전`;
  return `${Math.floor(d / 86400)}일 전`;
}
