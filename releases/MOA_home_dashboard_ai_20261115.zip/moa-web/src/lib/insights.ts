// 홈·학습·평행세계가 함께 쓰는 '숫자 사실'. 숫자는 항상 코드가 계산하고,
// AI는 이 사실을 받아 문장으로 풀어 줘요(서버 /api/ai/brief). AI를 못 쓰면 아래 규칙 문장을 보여줘요.
import { APP_TODAY, getState, todayDate } from './store';
import { beforePayday, byCategory, dday, isoOf, md, monthPeriod, totals } from './finance';
import { livePrice } from './market';
import { lessonAccuracy, reviewQueue } from './learning';
import type { BriefIn, BriefOut } from './api';

type S = ReturnType<typeof getState>;
const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;

export function briefFacts(s: S = getState()): BriefIn {
  const bp = beforePayday(s);
  const month = totals(monthPeriod(), s);
  const cats = Object.entries(byCategory(monthPeriod(), s)).map(([name, v]) => ({ name, amount: v.amount })).sort((a, b) => b.amount - a.amount);
  const top = cats[0] ? { name: cats[0].name, amount: cats[0].amount } : null;
  const t = todayDate();
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  const next = bp.due[0];
  return {
    usable: Math.max(0, bp.spendable),
    daysLeftInMonth: last - t.getDate(),
    monthSpent: month.expense,
    lastMonthSameDay: null,
    topCategory: top,
    savedThisMonth: month.saving,
    holdsThisMonth: s.wishes.filter((w) => w.status === 'skipped' && (w.decidedAt || '').slice(0, 7) === APP_TODAY.slice(0, 7)).reduce((a, w) => a + w.amount, 0),
    nextBill: next ? { date: next.date, amount: -next.amount } : null,
  };
}

/** AI를 쓸 수 없을 때의 규칙 기반 브리핑 (같은 사실만 사용) */
export function ruleBrief(f: BriefIn): BriefOut {
  const daily = f.daysLeftInMonth > 0 ? Math.floor(f.usable / Math.max(1, f.daysLeftInMonth)) : f.usable;
  const roughly = (n: number) => (n >= 10000 ? `${Math.round(n / 5000) * 0.5}만 원` : `${Math.round(n / 1000)}천 원`);
  if (f.nextBill && f.usable <= 0) {
    return { headline: '다음 결제 전까지는 꼭 필요한 것만 써요', body: `${md(f.nextBill.date)} 결제가 빠지면 최소 잔액을 지키기 어려워요. 오늘은 기록부터 해 볼까요?`, action: { label: '결제 일정 보기', to: 'ledger' } };
  }
  return {
    headline: f.topCategory ? `이번 달은 ${f.topCategory.name}에 가장 많이 썼어요` : '이번 달 소비가 안정적이에요',
    body: `하루 ${roughly(daily)} 안쪽으로 쓰면 ${f.nextBill ? `${md(f.nextBill.date)} 결제까지` : '월말까지'} 여유 있게 지낼 수 있어요.`,
    action: f.topCategory ? { label: '아낀 돈으로 평행세계 보기', to: 'forks' } : null,
  };
}

/** 요일별 기준선 지출 예측 — 백엔드 baseline-weekday-v1과 같은 방식 (최근 거래의 요일 평균) */
export function weekdayForecast(s: S = getState(), horizon = 7) {
  const exp = s.txs.filter((t) => t.type === 'expense' && t.date <= APP_TODAY);
  const byDay: Record<number, number[]> = {};
  const days = new Map<string, number>();
  exp.forEach((t) => days.set(t.date, (days.get(t.date) || 0) + t.amount));
  // 관측 기간의 모든 날짜(지출 없는 날 0원 포함)
  const first = exp.map((t) => t.date).sort()[0] || APP_TODAY;
  for (let d = new Date(`${first}T00:00:00`); isoOf(d) <= APP_TODAY; d.setDate(d.getDate() + 1)) {
    const iso = isoOf(d);
    (byDay[d.getDay()] ||= []).push(days.get(iso) || 0);
  }
  const avg = (k: number) => { const a = byDay[k] || []; return a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0; };
  const daily = Array.from({ length: horizon }, (_, i) => {
    const d = todayDate(); d.setDate(d.getDate() + i + 1);
    return { date: isoOf(d), amount: Math.round(avg(d.getDay())), label: '일월화수목금토'[d.getDay()] };
  });
  return { daily, total: daily.reduce((a, b) => a + b.amount, 0), observedDays: Object.values(byDay).reduce((a, b) => a + b.length, 0), model: '요일별 기준선' };
}

export function assets(s: S = getState()) {
  const holdings = Object.entries(s.invest.holdings || {}).filter(([, q]) => q > 0);
  const invested = holdings.reduce((a, [n, q]) => a + q * livePrice(n), 0);
  const cost = holdings.reduce((a, [n, q]) => a + q * (s.invest.avgPrice[n] || livePrice(n)), 0);
  const savings = (s.savings || []).reduce((a, p) => a + (p.history?.length ? p.history.reduce((x, h) => x + h.amount, 0) : p.principal), 0);
  return { invested, cost, pl: invested - cost, cash: s.invest.cash, savings, holdings: holdings.length, total: invested + s.invest.cash + savings };
}

/** 듀오링고처럼: 연속 학습일, XP, 정답률 */
export function learningStats(s: S = getState()) {
  const act = new Set(s.learning.activity || []);
  let streak = 0;
  const d = todayDate();
  if (!act.has(isoOf(d))) d.setDate(d.getDate() - 1); // 오늘 아직 안 했으면 어제까지의 연속
  while (act.has(isoOf(d))) { streak++; d.setDate(d.getDate() - 1); }
  const attempts = s.learning.attempts || [];
  const correct = attempts.filter((a) => a.correct).length;
  const xp = correct * 10 + s.learning.done.length * 15 + (s.learning.quizDone || []).length * 20;
  const week = Array.from({ length: 7 }, (_, i) => { const x = todayDate(); x.setDate(x.getDate() - (6 - i)); return { iso: isoOf(x), on: act.has(isoOf(x)), label: '일월화수목금토'[x.getDay()] }; });
  const acc = lessonAccuracy(attempts);
  const reviews = reviewQueue(attempts, APP_TODAY).filter((r) => r.due);
  return { streak, xp, accuracy: attempts.length ? correct / attempts.length : null, week, doneToday: act.has(APP_TODAY), acc, reviews, attempts: attempts.length };
}

export { dday, md, won };
