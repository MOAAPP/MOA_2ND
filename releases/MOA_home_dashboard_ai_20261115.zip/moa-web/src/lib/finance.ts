// 모든 화면이 같은 기준으로 쓰는 금융 계산.
// 같은 거래 목록(store.txs)과 같은 날짜(APP_TODAY)로 합계를 내고,
// 같은 잔액·필수 결제·최소 잔액으로 '쓸 수 있는 돈'과 부족 위험을 계산해요.
import { APP_TODAY, getState, todayDate, isCreditPayment, type Bill, type Tx } from './store';

type S = ReturnType<typeof getState>;
const pad = (n: number) => String(n).padStart(2, '0');
export const isoOf = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

/** 월말 날짜 보정: 1월 31일 + 1개월 → 2월 말일 (3월로 넘어가지 않음). */
export function addMonthsClamped(from: Date, months: number) {
  const d = new Date(from);
  const day = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth() + months);
  d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()));
  return d;
}

// ---------- 거래 합계 ----------
export type Period = { start: string; end: string };
export function monthPeriod(ym = APP_TODAY.slice(0, 7)): Period {
  const [y, m] = ym.split('-').map(Number);
  return { start: `${ym}-01`, end: `${ym}-${pad(new Date(y, m, 0).getDate())}` };
}
export const txsIn = (p: Period, s: S = getState()) => s.txs.filter((t) => t.date >= p.start && t.date <= p.end);

export function totals(p: Period = monthPeriod(), s: S = getState()) {
  // 예산/실제 지출 합계에는 아직 실행되지 않은 미래 예정 거래를 포함하지 않음.
  const list = txsIn(p, s).filter((t) => t.date <= APP_TODAY);
  const sum = (f: (t: Tx) => boolean) => list.filter(f).reduce((a, t) => a + t.amount, 0);
  return {
    expense: sum((t) => t.type === 'expense'),
    income: sum((t) => t.type === 'income'),
    saving: sum((t) => t.type === 'transfer'),
    count: list.length,
    list,
  };
}

/** 카테고리별 지출 (지출만) */
export function byCategory(p: Period = monthPeriod(), s: S = getState()) {
  const out: Record<string, { amount: number; txs: Tx[] }> = {};
  txsIn(p, s).filter((t) => t.type === 'expense' && t.date <= APP_TODAY).forEach((t) => {
    (out[t.category] ||= { amount: 0, txs: [] });
    out[t.category].amount += t.amount;
    out[t.category].txs.push(t);
  });
  return out;
}

export const monthlyBudget = (s: S = getState()) => Object.values(s.budgets).reduce((a, b) => a + b, 0) || s.profile.monthlyBudget;

// ---------- 결제 일정 · 부족 위험 ----------
export type CashEvent = { date: string; label: string; amount: number; kind: 'bill' | 'salary' | 'purchase' | 'transaction'; bill?: Bill; balanceAfter: number; risk: boolean };

/** 다음 월급일(현재 잔액 스냅샷 이후). 29~31일은 해당 월 말일로 조정 */
export function nextPayday(s: S = getState(), from = todayDate()) {
  const lastDay = (y: number, m: number) => new Date(y, m + 1, 0).getDate();
  const day = Math.min(s.profile.payday, lastDay(from.getFullYear(), from.getMonth()));
  const d = new Date(from.getFullYear(), from.getMonth(), day);
  if (d <= from) {
    const n = new Date(from.getFullYear(), from.getMonth() + 1, 1);
    n.setDate(Math.min(s.profile.payday, lastDay(n.getFullYear(), n.getMonth())));
    return n;
  }
  return d;
}

/** 오늘부터 days일 동안의 결제·월급 일정과 그때마다 남는 잔액 */
export function cashTimeline(days = 35, s: S = getState(), additional: { date: string; amount: number; label: string }[] = []): CashEvent[] {
  const { balance, minBalance, salary } = s.finance;
  const start = todayDate();
  const events: Omit<CashEvent, 'balanceAfter' | 'risk'>[] = [];
  for (let i = 0; i <= days; i++) {
    const d = new Date(start); d.setDate(d.getDate() + i);
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    s.bills.forEach((b) => { if (Math.min(b.day, last) === d.getDate()) events.push({ date: isoOf(d), label: b.name, amount: -b.amount, kind: 'bill', bill: b }); });
    if (i > 0 && Math.min(s.profile.payday, last) === d.getDate() && salary > 0) events.push({ date: isoOf(d), label: '월급', amount: salary, kind: 'salary' });
  }
  // 미래 날짜로 입력한 수입·체크카드·계좌이체는 현재 잔액이 아닌 예상 일정에만 반영.
  // 신용카드 승인액은 아래 청구일 추정으로 합산하며 현금 사용은 통장과 분리.
  const through = isoOf(new Date(start.getFullYear(), start.getMonth(), start.getDate() + days));
  const scheduled = s.txs.filter((t) => !t.sample && t.date > APP_TODAY && t.date <= through);
  for (const t of scheduled) {
    if (t.type === 'expense' && (isCreditPayment(t.payment) || /현금/.test(t.payment))) continue;
    if (t.type === 'income' && /현금/.test(t.payment)) continue;
    const signed = t.type === 'income' ? t.amount : -t.amount;
    if (!Number.isFinite(signed)) continue;
    const salaryExists = t.type === 'income' && (t.category === '급여' || /월급|급여/.test(t.title)) &&
      events.some((e) => e.kind === 'salary' && e.date === t.date);
    if (salaryExists) {
      const salaryEvent = events.find((e) => e.kind === 'salary' && e.date === t.date)!;
      salaryEvent.amount = t.amount;
      salaryEvent.label = `${t.title} (직접 입력)`;
    } else events.push({ date: t.date, label: t.title, amount: signed, kind: 'transaction' });
  }
  // 새로 직접 입력한 신용카드 승인액은 통장 잔액에서 즉시 빼지 않고, 가장 가까운 카드 청구일에 한 번만 가산.
  // 기존 카드값은 청구서 기입 금액으로 유지. 이 가산은 결제 명세/이용기간 확인 전까지 추정치.
  const pendingCredit = s.txs.filter((t) => !t.sample && t.type === 'expense' && isCreditPayment(t.payment));
  for (const t of pendingCredit) {
    const after = [APP_TODAY, t.date].sort().at(-1)!;
    const due = events.filter((e) => e.kind === 'bill' && e.bill?.kind === 'card' && e.date > after).sort((a,b) => a.date.localeCompare(b.date))[0];
    if (due) { due.amount -= t.amount; if (!due.label.includes('추가 승인')) due.label += ' (추가 승인 포함)'; }
  }
  for (const extra of additional) {
    if (extra.date >= APP_TODAY) events.push({ date: extra.date, label: extra.label, amount: -extra.amount, kind: 'purchase' });
  }
  // 같은 날은 월급이 먼저 들어온다고 보고 계산
  events.sort((a, b) => a.date.localeCompare(b.date) || b.amount - a.amount);
  let bal = balance;
  return events.map((e) => { bal += e.amount; return { ...e, balanceAfter: bal, risk: e.kind !== 'salary' && bal < minBalance }; });
}

/** 다음 월급 전까지의 상황 */
export function beforePayday(s: S = getState()) {
  const pay = isoOf(nextPayday(s));
  const due = cashTimeline(35, s).filter((e) => e.kind === 'bill' && e.date < pay);
  const essential = due.reduce((a, e) => a - e.amount, 0);
  const { balance, minBalance } = s.finance;
  const spendable = balance - essential - minBalance; // 오늘 쓸 수 있는 여유
  const firstRisk = cashTimeline(35, s).find((e) => e.risk && e.date < pay);
  return { payday: pay, due, essential, spendable, firstRisk, balance, minBalance };
}

/** 이 금액을 지금 쓰거나 다른 곳으로 옮기면(=통장에서 빠지면) 결제 일정이 어떻게 되는지 */
export function impactOf(amountOut: number, s: S = getState()) {
  const sim = { ...s, finance: { ...s.finance, balance: s.finance.balance - amountOut } };
  const bp = beforePayday(sim);
  return { cashAfter: sim.finance.balance, afterBills: sim.finance.balance - bp.essential, spendable: bp.spendable, risk: bp.firstRisk };
}

export const dday = (iso: string) => {
  const diff = Math.round((new Date(`${iso}T00:00:00`).getTime() - todayDate().getTime()) / 86400000);
  return diff === 0 ? 'D-DAY' : `D-${diff}`;
};
export const md = (iso: string) => `${Number(iso.slice(5, 7))}/${Number(iso.slice(8, 10))}`;

/** 지정한 미래일에 구매하는 경우: 오늘의 여유는 줄이지 않고 구매 시점의 잔액과 필수결제 리스크를 별도로 계산. */
export function futurePurchaseImpact(amount: number, delayMonths: number, s: S = getState()) {
  const date = todayDate();
  if (delayMonths === 0.25) date.setDate(date.getDate() + 7);
  else { const shifted = addMonthsClamped(date, Math.max(0, delayMonths)); date.setTime(shifted.getTime()); }
  const when = isoOf(date);
  const days = Math.max(35, Math.min(370, Math.round((date.getTime() - todayDate().getTime()) / 86400000) + 35));
  const events = cashTimeline(days, s, [{ date: when, label: '구매 연기한 상품', amount }]);
  const purchase = events.find((e) => e.kind === 'purchase');
  const risk = events.find((e) => e.risk && e.date >= when);
  return { date: when, balanceAtPurchase: purchase?.balanceAfter ?? null, risk, events };
}
