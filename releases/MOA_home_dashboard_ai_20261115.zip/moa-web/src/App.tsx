import { lazy, Suspense, useEffect, useRef } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from './lib/app';
import { settlePending } from './lib/store';
import { livePrice } from './lib/market';
import { isOnboarded } from './lib/store';
import TabBar from './components/TabBar';
import { useStore } from './lib/store';
import { requestTradeCard } from './lib/api';

const Home = lazy(() => import('./screens/Home'));
const Ledger = lazy(() => import('./screens/Ledger'));
const Report = lazy(() => import('./screens/Report'));
const Record = lazy(() => import('./screens/Record'));
const World = lazy(() => import('./screens/World'));
const WorldChoice = lazy(() => import('./pages/WorldChoice'));
const WorldRecords = lazy(() => import('./pages/WorldRecords'));
const Invest = lazy(() => import('./screens/Invest'));
const Portfolio = lazy(() => import('./screens/Portfolio'));
const More = lazy(() => import('./screens/More'));
const Onboarding = lazy(() => import('./pages/Onboarding'));
const Notifications = lazy(() => import('./pages/Notifications'));
const Savings = lazy(() => import('./pages/Savings'));
const Budget = lazy(() => import('./pages/Budget'));
const Settings = lazy(() => import('./pages/Settings'));
const Support = lazy(() => import('./pages/Support'));
const Wishlist = lazy(() => import('./pages/Wishlist'));
const Bills = lazy(() => import('./pages/Bills'));
const Growth = lazy(() => import('./pages/Growth'));
const Lab = lazy(() => import('./pages/Lab'));
const Agent = lazy(() => import('./pages/Agent'));
const LearnHub = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LearnHub })));
const LessonCards = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LessonCards })));
const LessonQuiz = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LessonQuiz })));

const TAB_ROUTES = ['/', '/ledger', '/world', '/lab'];

/** 어느 화면에 있든 대기 중인 지정가 주문을 가상 시세로 점검해 조건이 맞으면 체결 */
function OrderWatcher() {
  const { toast } = useApp();
  useEffect(() => {
    const id = window.setInterval(() => {
      const done = settlePending(livePrice);
      if (done.length) toast(`지정가 주문 ${done.length}건이 체결됐어요`, 'candlestick_chart');
    }, 5000);
    return () => window.clearInterval(id);
  }, [toast]);
  return null;
}

/** 모의 매수가 체결되면 한 번만 AI 종목 카드뉴스를 요청 (Discord 동의 시 자동 전송) */
function TradeCardWatcher() {
  const orders = useStore((s) => s.invest.orders);
  const discordOn = useStore((s) => s.learnAlert.discord && s.learnAlert.discordConsent);
  useEffect(() => {
    let sent: string[] = [];
    try { sent = JSON.parse(localStorage.getItem('moa.cardnews.sent') || '[]'); } catch { sent = []; }
    const fresh = orders.filter((o) => o.status === 'filled' && o.side === 'buy' && !sent.includes(o.id));
    if (!fresh.length) return;
    const ids = [...sent, ...fresh.map((o) => o.id)].slice(-200);
    try { localStorage.setItem('moa.cardnews.sent', JSON.stringify(ids)); } catch { /* 저장 공간 부족 */ }
    fresh.forEach((o) => { void requestTradeCard(o, discordOn); });
  }, [orders, discordOn]);
  return null;
}

function RequireOnboarding({ children }: { children: JSX.Element }) {
  return isOnboarded() ? children : <Navigate to="/onboarding" replace />;
}

export default function App() {
  const frameRef = useRef<HTMLDivElement>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const { pathname } = useLocation();
  const showTabs = TAB_ROUTES.includes(pathname);

  useEffect(() => {
    scrollerRef.current?.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="moa-stage">
      <div ref={frameRef} className="moa-frame">
        <AppProvider scrollerRef={scrollerRef} frameRef={frameRef}>
          <div ref={scrollerRef} className={`moa-scroller no-scrollbar ${showTabs ? 'has-tabs' : ''}`}>
            <Suspense fallback={<div className="h-full bg-[#F8FAFC]" />}>
              <Routes>
                <Route path="/onboarding" element={<Onboarding />} />
                <Route path="/" element={<RequireOnboarding><Home /></RequireOnboarding>} />
                <Route path="/ledger" element={<RequireOnboarding><Ledger /></RequireOnboarding>} />
                <Route path="/ledger/report" element={<RequireOnboarding><Report /></RequireOnboarding>} />
                <Route path="/record" element={<RequireOnboarding><Record /></RequireOnboarding>} />
                <Route path="/world" element={<RequireOnboarding><WorldRecords /></RequireOnboarding>} />
                <Route path="/world/compare" element={<RequireOnboarding><WorldChoice /></RequireOnboarding>} />
                <Route path="/world/explore" element={<RequireOnboarding><World /></RequireOnboarding>} />
                <Route path="/invest" element={<RequireOnboarding><Invest /></RequireOnboarding>} />
                <Route path="/invest/portfolio" element={<RequireOnboarding><Portfolio /></RequireOnboarding>} />
                <Route path="/savings" element={<RequireOnboarding><Savings /></RequireOnboarding>} />
                <Route path="/more" element={<RequireOnboarding><More /></RequireOnboarding>} />
                <Route path="/notifications" element={<RequireOnboarding><Notifications /></RequireOnboarding>} />
                <Route path="/budget" element={<RequireOnboarding><Budget /></RequireOnboarding>} />
                <Route path="/settings" element={<RequireOnboarding><Settings /></RequireOnboarding>} />
                <Route path="/support" element={<RequireOnboarding><Support /></RequireOnboarding>} />
                <Route path="/wishlist" element={<RequireOnboarding><Wishlist /></RequireOnboarding>} />
                <Route path="/bills" element={<RequireOnboarding><Bills /></RequireOnboarding>} />
                <Route path="/lab" element={<RequireOnboarding><Lab /></RequireOnboarding>} />
                <Route path="/agent" element={<RequireOnboarding><Agent /></RequireOnboarding>} />
                <Route path="/growth" element={<RequireOnboarding><Growth /></RequireOnboarding>} />
                <Route path="/learn" element={<RequireOnboarding><LearnHub /></RequireOnboarding>} />
                <Route path="/learn/:id" element={<RequireOnboarding><LessonCards /></RequireOnboarding>} />
                <Route path="/learn/:id/quiz" element={<RequireOnboarding><LessonQuiz /></RequireOnboarding>} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </div>
          {showTabs && <TabBar />}
          <OrderWatcher />
          <TradeCardWatcher />
        </AppProvider>
      </div>
    </div>
  );
}
