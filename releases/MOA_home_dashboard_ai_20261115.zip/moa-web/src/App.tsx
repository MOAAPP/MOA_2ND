import { lazy, Suspense, useEffect, useRef } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from './lib/app';
import { settlePending } from './lib/store';
import { livePrice } from './lib/market';
import { isOnboarded } from './lib/store';
import TabBar from './components/TabBar';
import { useStore } from './lib/store';
import { sendTradeCard } from './lib/api';
import { lessonById, stockLessonId } from './lib/learning';
import { stockByName } from './lib/market';

const Home = lazy(() => import('./screens/Home'));
const Ledger = lazy(() => import('./screens/Ledger'));
const Report = lazy(() => import('./screens/Report'));
const Record = lazy(() => import('./screens/Record'));
const World = lazy(() => import('./screens/World'));
const WorldChoice = lazy(() => import('./pages/WorldChoice'));
const WorldRecords = lazy(() => import('./pages/WorldRecords'));
const Invest = lazy(() => import('./screens/Invest'));
const Portfolio = lazy(() => import('./screens/Portfolio'));
const More = lazy(() => import('./screens/More'));
const Onboarding = lazy(() => import('./pages/Onboarding'));
const Notifications = lazy(() => import('./pages/Notifications'));
const Savings = lazy(() => import('./pages/Savings'));
const Budget = lazy(() => import('./pages/Budget'));
const Settings = lazy(() => import('./pages/Settings'));
const Support = lazy(() => import('./pages/Support'));
const Wishlist = lazy(() => import('./pages/Wishlist'));
const Bills = lazy(() => import('./pages/Bills'));
const Growth = lazy(() => import('./pages/Growth'));
const Lab = lazy(() => import('./pages/Lab'));
const Agent = lazy(() => import('./pages/Agent'));
const LearnHub = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LearnHub })));
const LessonCards = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LessonCards })));
const LessonQuiz = lazy(() => import('./pages/Learn').then((m) => ({ default: m.LessonQuiz })));

const TAB_ROUTES = ['/', '/ledger', '/world', '/lab'];

/** 어느 화면에 있든 대기 중인 지정가 주문을 가상 시세로 점검해 조건이 맞으면 체결 */
function OrderWatcher() {
  const { toast } = useApp();
  useEffect(() => {
    const id = window.setInterval(() => {
      const done = settlePending(livePrice);
      if (done.length) toast(`지정가 주문 ${done.length}건이 체결됐어요`, 'candlestick_chart');
    }, 5000);
    return () => window.clearInterval(id);
  }, [toast]);
  return null;
}

/** 가상 매수가 체결되면 한 번만, 그 종목 학습 카드뉴스를 Discord로 보냄 (Discord 받기를 켠 경우) */
function TradeCardWatcher() {
  const { toast } = useApp();
  const orders = useStore((s) => s.invest.orders);
  const cash = useStore((s) => s.invest.cash);
  const discordOn = useStore((s) => s.learnAlert.discord && s.learnAlert.discordConsent);
  useEffect(() => {
    let sent: string[] = [];
    try { sent = JSON.parse(localStorage.getItem('moa.cardnews.sent') || '[]'); } catch { sent = []; }
    const fresh = orders.filter((o) => o.status === 'filled' && o.side === 'buy' && !sent.includes(o.id));
    if (!fresh.length) return;
    try { localStorage.setItem('moa.cardnews.sent', JSON.stringify([...sent, ...fresh.map((o) => o.id)].slice(-200))); } catch { /* 저장 공간 부족 */ }
    if (!discordOn) { toast('설정에서 Discord 받기를 켜면 이 종목 카드뉴스가 전송돼요', 'notifications'); return; }
    fresh.forEach(async (o) => {
      const code = stockByName(o.name)?.code || 'SP500';
      const lesson = lessonById(stockLessonId(code)) || lessonById('etf')!;
      const firstSentence = (t: string) => (t.split(/(?<=[.요다])\s/)[0] || t).slice(0, 150);
      const total = Math.round(o.price * o.shares);
      const r = await sendTradeCard({
        tradeId: o.id, name: o.name, side: 'buy', shares: o.shares, price: o.price, cashLeft: cash,
        lesson: {
          title: lesson.title,
          points: lesson.cards.slice(0, 3).map((c) => `${c.title} — ${firstSentence(c.body)}`.slice(0, 200)),
          risk: lesson.cards.find((c) => c.point)?.point,
          quiz: lesson.quiz[0] ? { q: lesson.quiz[0].q.slice(0, 160), options: lesson.quiz[0].options.map((x) => x.slice(0, 60)).slice(0, 4) } : undefined,
        },
        link: `${location.origin}/learn/${lesson.id}?from=trade&order=${o.id}&amount=${total}`,
      });
      toast(r.ok ? `${o.name} 카드뉴스를 Discord로 보냈어요` : `Discord 전송 실패: ${r.error}`, r.ok ? 'send' : 'error');
    });
  }, [orders, discordOn, cash, toast]);
  return null;
}

function RequireOnboarding({ children }: { children: JSX.Element }) {
  return isOnboarded() ? children : <Navigate to="/onboarding" replace />;
}

export default function App() {
  const frameRef = useRef<HTMLDivElement>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const { pathname } = useLocation();
  const showTabs = TAB_ROUTES.includes(pathname);

  useEffect(() => {
    scrollerRef.current?.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="moa-stage">
      <div ref={frameRef} className="moa-frame">
        <AppProvider scrollerRef={scrollerRef} frameRef={frameRef}>
          <div ref={scrollerRef} className={`moa-scroller no-scrollbar ${showTabs ? 'has-tabs' : ''}`}>
            <Suspense fallback={<div className="h-full bg-[#F8FAFC]" />}>
              <Routes>
                <Route path="/onboarding" element={<Onboarding />} />
                <Route path="/" element={<RequireOnboarding><Home /></RequireOnboarding>} />
                <Route path="/ledger" element={<RequireOnboarding><Ledger /></RequireOnboarding>} />
                <Route path="/ledger/report" element={<RequireOnboarding><Report /></RequireOnboarding>} />
                <Route path="/record" element={<RequireOnboarding><Record /></RequireOnboarding>} />
                <Route path="/world" element={<RequireOnboarding><WorldRecords /></RequireOnboarding>} />
                <Route path="/world/compare" element={<RequireOnboarding><WorldChoice /></RequireOnboarding>} />
                <Route path="/world/explore" element={<RequireOnboarding><World /></RequireOnboarding>} />
                <Route path="/invest" element={<RequireOnboarding><Invest /></RequireOnboarding>} />
                <Route path="/invest/portfolio" element={<RequireOnboarding><Portfolio /></RequireOnboarding>} />
                <Route path="/savings" element={<RequireOnboarding><Savings /></RequireOnboarding>} />
                <Route path="/more" element={<RequireOnboarding><More /></RequireOnboarding>} />
                <Route path="/notifications" element={<RequireOnboarding><Notifications /></RequireOnboarding>} />
                <Route path="/budget" element={<RequireOnboarding><Budget /></RequireOnboarding>} />
                <Route path="/settings" element={<RequireOnboarding><Settings /></RequireOnboarding>} />
                <Route path="/support" element={<RequireOnboarding><Support /></RequireOnboarding>} />
                <Route path="/wishlist" element={<RequireOnboarding><Wishlist /></RequireOnboarding>} />
                <Route path="/bills" element={<RequireOnboarding><Bills /></RequireOnboarding>} />
                <Route path="/lab" element={<RequireOnboarding><Lab /></RequireOnboarding>} />
                <Route path="/agent" element={<RequireOnboarding><Agent /></RequireOnboarding>} />
                <Route path="/growth" element={<RequireOnboarding><Growth /></RequireOnboarding>} />
                <Route path="/learn" element={<RequireOnboarding><LearnHub /></RequireOnboarding>} />
                <Route path="/learn/:id" element={<RequireOnboarding><LessonCards /></RequireOnboarding>} />
                <Route path="/learn/:id/quiz" element={<RequireOnboarding><LessonQuiz /></RequireOnboarding>} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </div>
          {showTabs && <TabBar />}
          <OrderWatcher />
          <TradeCardWatcher />
        </AppProvider>
      </div>
    </div>
  );
}
