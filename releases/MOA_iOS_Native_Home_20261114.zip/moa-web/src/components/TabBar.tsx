import { NavLink, useNavigate, useLocation } from 'react-router-dom';

const ICONS = {
  home: 'M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25',
  ledger: 'M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25',
  world: 'M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z',
  lab: 'M9 3h6M10 3v6.1l-5.9 9.2A2.5 2.5 0 006.2 22h11.6a2.5 2.5 0 002.1-3.7L14 9.1V3M8.4 16h7.2',
} as const;

function Tab({ to, icon, label, end }: { to: string; icon: keyof typeof ICONS; label: string; end?: boolean }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `flex flex-col items-center justify-center w-14 h-full transition-colors ${isActive ? 'text-blue-600' : 'text-slate-400 hover:text-slate-700'}`
      }
    >
      {({ isActive }) => (
        <>
          <svg className={`w-6 h-6 ${isActive ? 'stroke-[2]' : 'stroke-[1.8]'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d={ICONS[icon]} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className={`text-[11px] mt-1 ${isActive ? 'font-bold' : 'font-medium'}`}>{label}</span>
        </>
      )}
    </NavLink>
  );
}

export default function TabBar() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  if (pathname === '/') {
    const items = [
      { to: '/', label: '홈', icon: 'home', end: true },
      { to: '/ledger', label: '가계부', icon: 'ledger' },
      { to: '/record', label: '기록', icon: 'record' },
      { to: '/world', label: '평행세계', icon: 'world' },
      { to: '/lab', label: '실험실', icon: 'lab' },
    ];
    return <nav className="moa-native-tabbar" aria-label="MOA 하단 탭">
      {items.map(item => <NavLink key={item.to} to={item.to} end={item.end} className="moa-native-tab-item" data-active={item.to === '/' ? 'true' : 'false'}>
        <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24" aria-hidden="true">
          <path d={item.icon === 'record' ? 'M12 4v16M4 12h16' : ICONS[item.icon as keyof typeof ICONS]} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span>{item.label}</span>
      </NavLink>)}
    </nav>;
  }
  return (
    <nav
      className="absolute bottom-0 left-0 right-0 h-[68px] bg-white/95 backdrop-blur-md border-t border-slate-100 flex items-center justify-around px-2 z-[45] pb-[env(safe-area-inset-bottom)] box-content"
      style={{ boxShadow: 'rgba(0, 0, 0, 0.06) 0px -4px 16px' }}
    >
      <Tab to="/" icon="home" label="홈" end />
      <Tab to="/ledger" icon="ledger" label="가계부" />
      <button
        type="button"
        aria-label="기록하기"
        onClick={() => navigate('/record')}
        className="flex flex-col items-center justify-center w-14 h-full group"
      >
        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-[0_4px_14px_rgba(37,99,235,0.35)] active:scale-95 group-hover:shadow-[0_6px_18px_rgba(6,182,212,0.45)] transition-all -mt-3 ring-4 ring-white">
          <svg className="w-5 h-5 stroke-[2.4]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d="M12 4.5v15m7.5-7.5h-15" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <span className="text-[10px] font-bold mt-0.5 text-blue-600">기록</span>
      </button>
      <Tab to="/world" icon="world" label="평행세계" />
      <Tab to="/lab" icon="lab" label="실험실" />
    </nav>
  );
}
